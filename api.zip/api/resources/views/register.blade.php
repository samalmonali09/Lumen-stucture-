
<div class="col-sm-12 col-md-8 col-lg-8">
    <form action="/insert-data" method="post"><br><br>
        <input type="text" name="name" placeholder=" NAME" align="center"><br>
        <input type="text" name="user_name" placeholder="USER NAME" align="center"><br>
        <input type="text" name="email" placeholder="EMAIL" align="center"><br>
        <input type="password" name="password" placeholder="PASSWORD" align="center"><br>
        <input type="text" name="gender" placeholder="GENDER" align="center"><br>
        <input type="text" name="company_name" placeholder="COMPANY NAME" align="center"><br>
        <input type="text" name="job_post" placeholder="JOB POST" align="center"><br>
        <input type="text" name="job_domain" placeholder="JOB DOMAIN" align="center"><br>
        <input type="text" name="salary" placeholder="SALARY" align="center"><br>


        <button type="submit" class="btn btn-success">SUBMIT</button><br><br>

    </form></center>
</div>