<?php
            return [
               'Emergency_switch_Autoig'=>'ON'

            ];