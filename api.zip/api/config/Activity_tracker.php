<?php
            return [
                'Activity_TrackerAUTOIG'=>'ON',
                                'time'=>'30'

            ];