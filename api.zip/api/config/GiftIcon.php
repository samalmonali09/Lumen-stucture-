<?php
            return [
                'Gift_Icon_Autoig'=>'ON'
            ];