<?php
return [
    'flashnews'=>'OFF',
    'banner_img_url'=>'/banner_img/banner.png',
    'module_status'=>1,
    'banner_img_url_dynamic'=>'/banner_img/Banner_static.png'
];