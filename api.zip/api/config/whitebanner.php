<?php
            return [
                'banner_img_url'=>'banner_img/15326145849318.png'

            ];