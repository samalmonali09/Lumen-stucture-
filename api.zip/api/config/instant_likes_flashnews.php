<?php
return [
    'flashnews'=>'ON',
    'banner_img_url'=>'/banner_img/banner.png',
    'module_status'=>2,
    'banner_img_url_dynamic'=>'/banner_img/Banner_static.png'
];