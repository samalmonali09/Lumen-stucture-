<?php
            return [
                'flashnews'=>'ON'
            ];