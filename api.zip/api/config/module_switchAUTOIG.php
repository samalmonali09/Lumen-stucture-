<?php
            return [
                'module_switch_statusAUTOIG'=>'ON'

            ];