<?php
            return [
                'module_switch_statusGIVR'=>'ON'
            ];