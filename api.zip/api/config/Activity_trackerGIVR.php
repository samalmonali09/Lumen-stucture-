<?php
            return [
                'Activity_trackerGIVR'=>'ON',
                                'time'=>'30'
            ];