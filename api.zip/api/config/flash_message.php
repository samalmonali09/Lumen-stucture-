<?php
            return [
                'flashnews'=>'OFF'
            ];