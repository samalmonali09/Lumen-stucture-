<?php
/**
 * @Desc
 * @Class Proxies
 * ${PARAM_DOC}
 * @return ${TYPE_HINT}
 * ${THROWS_DOC}
 * @since XX Aug 2018
 * @author Sibasankar Bhoi (sibasankarbhoi@globussoft.in)
 */

namespace App\Http\Models;


use Illuminate\Auth\Authenticatable;
use Illuminate\Support\Facades\DB;
use Laravel\Lumen\Auth\Authorizable;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Contracts\Auth\Access\Authorizable as AuthorizableContract;
use Illuminate\Contracts\Auth\Authenticatable as AuthenticatableContract;
class Proxies extends Model implements AuthenticatableContract, AuthorizableContract
{
    use Authenticatable, Authorizable;

    private static $_instance = null;

    public static function getInstance()
    {
        if (!is_object(self::$_instance))  //or if( is_null(self::$_instance) ) or if( self::$_instance == null )
            self::$_instance = new Proxies();
        return self::$_instance;
    }

    public function getProxiesDetails($where, $selectedCols = ['*']){

        try {
            $proxyDetails = DB::table('proxies')
                ->whereRaw($where['rawQuery'], isset($where['bindParams']) ? $where['bindParams'] : array())
                ->select($selectedCols)
                ->get();
            if ($proxyDetails){
                return $proxyDetails;
            }else
                return 0;
        } catch (\Exception $exc) {
            dd($exc->getMessage());
            apiResponse(401,'Proxies not found',null,null);
        }

    }

    public function getRangProxy($sql)
    {
        try {
            $proxyDetails = DB::select($sql);

            if ($proxyDetails){
                return $proxyDetails;
            }else
                return 0;
        } catch (\Exception $exc) {
            dd($exc->getMessage());
            apiResponse(401,'Proxies not found',null,null);
        }

    }


}