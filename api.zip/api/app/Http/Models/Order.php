<?php

namespace App\Http\Models;

use Illuminate\Auth\Authenticatable;
use Illuminate\Contracts\Auth\Access\Authorizable as AuthorizableContract;
use Illuminate\Contracts\Auth\Authenticatable as AuthenticatableContract;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\QueryException;
use Illuminate\Support\Facades\DB;
use Laravel\Lumen\Auth\Authorizable;

class Order extends Model implements AuthenticatableContract, AuthorizableContract
{
    use Authenticatable, Authorizable;

    private static $_instance = null;
    protected $table = 'orders';

    public static function getInstance()
    {
        if (!is_object(self::$_instance))  //or if( is_null(self::$_instance) ) or if( self::$_instance == null )
            self::$_instance = new Order();
        return self::$_instance;
    }


    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'name', 'email',
    ];

    /**
     * The attributes excluded from the model's JSON form.
     *
     * @var array
     */
    protected $hidden = [
        'password',
    ];


    /**
     * @Desc placing order
     * @param $order_placingArr
     * @return mixed
     * @since 20 jan 2018
     * @author Sibasankar Bhoi (sibasankarbhoi@globussoft.in)
     */
    public function placingOrder($order_placingArr)
    {
        try {
            $order_placed = DB::table('orders')->insertGetId($order_placingArr);
        } catch (\Exception $exc) {
            dd($exc->getMessage());
            echo json_encode(['code' => 401, 'status' => 'false', 'message' => 'Internal server error, order placing']);
        }
    }


    /**
     * @Desc  placing order for likes, comments, views, follows after complete transaction
     * @param $tx_id
     * @return mixed
     * @since 29 jan 2018
     * @author Sibasankar Bhoi (sibasankarbhoi@globussoft.in)
     */
    public function addOrdersLikes($tx_id)
    {
        try {

            $user_order_details = DB::table('transactions')->where('tx_id', $tx_id)->first();
            if (isset($user_order_details) && !empty($user_order_details)) {
                $check_order_place = DB::table('orders')->where('tx_id', $tx_id)->count();
                if ($check_order_place > 0) {
                    echo json_encode(['code' => 401, 'status' => 'false', 'message' => 'Order Allready Placed']);
                    die;
                } else {
                    return $user_order_details;
                }
            } else {
                echo json_encode(['code' => 401, 'status' => 'false', 'message' => 'transaction is not complete']);
                die;
            }
        } catch (Exception $exc) {
            echo json_encode(['code' => 401, 'status' => 'false', 'message' => 'Internal server error, order placing']);
            die;
        }
    }

    /**
     * @Desc users Order History
     * @param $user_id
     * @return mixed
     * @since 31 jan 2018
     * @author Sibasankar Bhoi (sibasankarbhoi@globussoft.in)
     */
    public function orderHistory($user_id)
    {
        try {
            $user_order_history = DB::table('orders')->where('user_id', $user_id)->get();

            return $user_order_history;

        } catch (\Exception $exc) {
            dd($exc->getMessage());
            die;
        }
    }

    /**
     * @desc insert order details in orders table
     * insertGetId method is used to insert a record and then retrieve the ID, if that table has auto-incremented id.
     * @return mixed
     * @date 28-03-2018
     * @dev saurabh Kumar <saurabh.kumar@globussoft.com>
     */
    public function insertOrder()
    {
        if (func_num_args() > 0) {

            $data = func_get_arg(0);
            try {
                return DB::table($this->table)
                    ->insertGetId($data);
            } catch (QueryException $e) {
                apiResponse(400, 'Something went wrong, please try after sometime.', $e->getMessage(), null);
            }
        }
    }

    /**
     * @desc get order details with package information
     * @return mixed
     * @date 29-06-2018
     * @dev saurabh Kumar <saurabh.kumar@globussoft.com>
     */
    public function getOrderDetailsWithPackages($where, $selectCols = ['*'])
    {
        try {
            $result = DB::table($this->table)
                ->join('packages', 'packages.package_id', '=', 'orders.package_id')
                ->join('transactions', 'transactions.tx_id', '=', 'orders.tx_id')
                ->leftjoin('comments', 'comments.comment_id', '=', 'orders.comment_id')
                ->whereRaw($where['rawQuery'], isset($where['bindParams']) ? $where['bindParams'] : array())
                ->select($selectCols)
                ->get();

            return ($result) ? json_decode($result, true) : 0;

        } catch (QueryException $e) {
//            dd($e->getMessage());
            return 0;
        }

    }

    /**
     * @desc get orders with autolikes profile details and
     * @return mixed
     * @date 28-06-2018
     * @dev saurabh Kumar <saurabh.kumar@globussoft.com>
     */
    public function getOrderDetailsWithSubscription($where, $selectCols = ['*'])
    {
        try {
            $result = DB::table($this->table)
                ->join('autolikes_orders', 'autolikes_orders.autolikes_id', '=', 'orders.autolikes_id')
                ->join('recurring_profiles', 'recurring_profiles.profile_id', '=', 'autolikes_orders.recurring_profile_id')
                ->leftjoin('comments', 'comments.comment_id', '=', 'orders.comment_id')
                ->whereRaw($where['rawQuery'], isset($where['bindParams']) ? $where['bindParams'] : array())
                ->select($selectCols)
                ->get();

            return ($result) ? json_decode($result, true) : 0;

        } catch (QueryException $e) {

            dd($e->getMessage());
            return 0;
        }

    }

    /**
     * @Desc get username
     * @param $user_id
     * @return mixed
     * @author Sibasankar Bhoi (sibasankarbhoi@globussoft.in)
     * @since 11-july-2018
     */
    public function getUsername($user_id)
    {
        try {
            $user_order_history = DB::table('users')->where('id', $user_id)->first();

            return $user_order_history;

        } catch (\Exception $exc) {
            dd($exc->getMessage());
            die;
        }
    }

}
