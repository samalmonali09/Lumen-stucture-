<?php
/**
 * Created by Monali Samal.
 * User: monali samal <monalisamal@globussoft.in>
 * Date: 15/11/2018
 * Time: 1:48 AM
 */

namespace App\Http\Models;

use Illuminate\Auth\Authenticatable;
use Illuminate\Support\Facades\DB;
use Laravel\Lumen\Auth\Authorizable;
use Illuminate\Database\Eloquent\Model;

class tutorial extends Model
{

    protected $table = 'tutorial';



    public function getDetails()

    {
        try {
            $result = DB::table('tutorial')->get();
//                ->whereRaw($where['rawQuery'], isset($where['bindParams']) ? $where['bindParams'] : array())
//                ->select($select)
//dd($result);
            if ($result) {
                return $result;
            } else {
                return 0;
            }
        } catch (QueryException $e) {
            echo $e->getMessage();
        }

    }


//    public function fetchQuery()
//    {
//        try {
//            $result = DB::table('tutorial')->get();
//
//            $data = [];
//            foreach ($result as $key => $value) {
//                $data['title'] = $value->title;
//                $data['link'] = $value->link;
//                $data['thumbnail'] = $value->link;
//                $data['description'] = $value->link;
//
//            }
////dd($data);
//
//            return $data ? $data : [];
//        } catch (QueryException $e) {
//            echo $e->getMessage();
//        }
//
//    }


    public function fetchQuery($where, $column = ['*'])
    {
        if (func_num_args() > 0) {
            try {
                $result = DB::table('tutorial')
                    ->whereRaw($where['rawQuery'], isset($where['bindParams']) ? $where['bindParams'] : array())
                    ->select($column)
                    ->get();

                return $result ? $result : [];
            } catch (QueryException $e) {
                echo $e->getMessage();
            }
        } else {
            throw new \Exception('Argument not passed');
        }
    }

}