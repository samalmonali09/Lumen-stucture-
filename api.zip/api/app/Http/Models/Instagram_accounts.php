<?php
/**
 * Created by PhpStorm.
 * User: GLB-155
 * Date: 8/4/2018
 * Time: 1:22 PM
 */

namespace App\Http\Models;


use Illuminate\Database\QueryException;
use Illuminate\Support\Facades\DB;

class Instagram_accounts
{
    protected $table = 'instagram_accounts';

    public function getrandomInsaAccount()
    {
        try {
            $data = DB::select('SELECT * FROM ' . $this->table . ' ORDER BY RAND() LIMIT 1');

            if ($data) {
                return $data;

            } else return 0;
        } catch (QueryException $msg) {
            return 0;
        }
    }
}