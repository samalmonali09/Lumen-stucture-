<?php

namespace App\Http\Models;

use App\Http\Controllers\GILR\OrdersController;
use App\Http\Controllers\InstagramScrape\InstagramScrapeController;
use Illuminate\Auth\Authenticatable;
use Illuminate\Database\QueryException;
use Illuminate\Support\Facades\DB;
use Laravel\Lumen\Auth\Authorizable;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Contracts\Auth\Authenticatable as AuthenticatableContract;
use Illuminate\Contracts\Auth\Access\Authorizable as AuthorizableContract;

class Comments extends Model implements AuthenticatableContract, AuthorizableContract
{
    use Authenticatable, Authorizable;

    private static $_instance = null;

    public static function getInstance()
    {
        if (!is_object(self::$_instance))  //or if( is_null(self::$_instance) ) or if( self::$_instance == null )
            self::$_instance = new Comments();
        return self::$_instance;
    }


    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'name', 'email',
    ];

    /**
     * The attributes excluded from the model's JSON form.
     *
     * @var array
     */
    protected $hidden = [
        'password',
    ];


    /**
     * @Desc place custom comments
     * @param $comments
     * @param $user_id
     * @return mixed
     * @since 16 feb 2018
     * @author Sibasankar Bhoi (sibasankarbhoi@globussoft.in)
     */
    public function placeComments($comments, $user_id)
    {
        $comments_array = explode('","', $comments);
        $comments_quantity = DB::table('packages')->where('package_type', 3)->select('quantity')->first()->quantity;
        if ($comments_quantity > count($comments_array)) {
            apiResponse('401', 'please neter minimum ' . $comments_quantity . ' comments', 'less comments', null);
        } elseif ($comments_quantity < count($comments_array)) {

            $comments = array_slice($comments_array, 0, $comments_quantity);
            $comments=implode('","',$comments);
        } else
            $commentsArr = array();
        $commentsArr['comments'] = $comments;
        $commentsArr['user_id'] = $user_id;
        $commentsArr['created_at'] = time();
        try {
            $insert_comments = DB::table('comments')->insertGetId($commentsArr);
            return $insert_comments;
        } catch (\Exception $exc) {
            apiResponse('401', 'comments entry error', 'null', null);
            die;
        }
    }


    /**
     * @desc :- to insert the row in comments table.
     * @param data to be inserted ( array )
     * @return inserted row id (primary key)
     * @throws \Exception
     * @since :- 05 july 2018
     * @author :- saurabh Kumar <saurabh.kumar@globussoft.com>
     */
    public function insertComments()
    {
        if (func_num_args() > 0) {
            $data = func_get_arg(0);
            try {
                $result = DB::table('comments')
                    ->insertGetId($data);
                return $result;
            } catch (QueryException $e) {
                return 0;
                dd($e->getMessage());
            }
        } else {
            throw new \Exception("Arguments not passed.");
        }
    }




    /**
     * @Desc fetch the comments of respective orders
     * @param $comment_id
     * @return mixed
     * @author Sibasankar Bhoi (sibasankarbhoi@globussoft.in)
     * @since 11-july-2018
     */
    public function getComments($comment_id)
    {
        try {
            $user_order_history = DB::table('comments')->where('comment_id', $comment_id)->get();

            return $user_order_history;

        } catch (\Exception $exc) {
            dd($exc->getMessage());
            die;
        }
    }
}
