<?php

namespace App\Http\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\QueryException;
use Illuminate\Support\Facades\DB;

class Subscription_package extends Model
{

    /*
   |--------------------------------------------------------------------------
   | Get Package count -- Saurabh - 15th June 2018
   |--------------------------------------------------------------------------
   |
   | This function get the total number of available packages in table based on the condition.
   |
   */
    public function getPackageCount($where)
    {
        try {

            $result = DB::table('subscription_packages')
                ->whereRaw($where['rawQuery'], isset($where['bindParams']) ? $where['bindParams'] : array())
                ->count();
            return ($result) ? $result : 0;

        } catch (QueryException $e) {
            return 0;
        }
    }

    /*
   |--------------------------------------------------------------------------
   | Get Package Lists -- Saurabh - 15th June 2018
   |--------------------------------------------------------------------------
   |
   | This function fetches all the package lists based on the condition and the columns to be select.
   |
   */
    public function getPackageLists($where, $selectCols = ['*'])
    {
        try {

            $result = DB::table('subscription_packages')
                ->whereRaw($where['rawQuery'], isset($where['bindParams']) ? $where['bindParams'] : array())
                ->select($selectCols)
                ->get();
            return ($result) ? json_decode($result, true) : [];

        } catch (QueryException $e) {
//            dd($e->getMessage());
            return [];
        }
    }

    /*
    |--------------------------------------------------------------------------
    | Get Package List -- Saurabh - 17th August 2018
    |--------------------------------------------------------------------------
    |
    | This function fetches the first the package based on the condition and the columns to be select.
    |
    */
    public function getPackageList($where, $selectCols = ['*'])
    {
        try {

            $result = DB::table('subscription_packages')
                ->whereRaw($where['rawQuery'], isset($where['bindParams']) ? $where['bindParams'] : array())
                ->select($selectCols)
                ->first();
            return ($result) ? json_decode(json_encode($result),true) : [];

        } catch (QueryException $e) {
            return [];
        }
    }

    /*
   |--------------------------------------------------------------------------
   | Get Filtered Package Lists -- Saurabh - 15th June 2018
   |--------------------------------------------------------------------------
   |
   | This function fetches the packages based on the condition and columns to be selected.
   | based on the offset and length ( gets the packages after the start count & till the length provided.
   |
   */
    public function getFilteredPackageLists($where, $selectCols, $start, $length)
    {

        try {
            $result = DB::table('subscription_packages')
                ->whereRaw($where['rawQuery'], isset($where['bindParams']) ? $where['bindParams'] : [])
                ->select($selectCols)
                ->skip($start)->take($length)
                ->get();
            return ($result) ? json_decode($result, true) : [];
        } catch (QueryException $e) {
            throw new \Exception($e->getMessage());
        }
    }
}
