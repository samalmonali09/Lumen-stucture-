<?php
/**
 * Created by PhpStorm.
 * User: GLB-247
 * Date: 2/7/2018
 * Time: 4:04 PM
 */

namespace App\Http\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\QueryException;
use Illuminate\Support\Facades\DB;

class InstagramUsers extends Model
{
    protected $table = 'instagram_users';

    protected static $_instance = null;

    /**
     * @return InstagramUsers|null
     */
    public static function getInstance()
    {
        if (!is_object(self::$_instance))
            self::$_instance = new InstagramUsers();
        return self::$_instance;
    }

    /**
     * getInstaUserDetail
     * @param $where
     * @param array $selectedCols
     * @return array
     * @throws \Exception
     */
    public function getInstaUserDetail($where, $selectedCols = ['*'])
    {
        if (func_num_args() > 0) {
            try {
                $result = DB::table($this->table)
                    ->whereRaw($where['rawQuery'], isset($where['bindParams']) ? $where['bindParams'] : array())
                    ->select($selectedCols)
                    ->first();
                return ($result) ? $result : [];
            } catch (\Exception $e) {
                throw new \Exception($e->getMessage());
            }
        } else {
            throw new \Exception("argument not passed.");
        }
    }

    /**
     * addIstaUsers
     * @param $data
     * @return array
     * @throws \Exception
     */
    public function addIstaUsers($data)
    {
        if (func_num_args() > 0) {
            try {
                $result = DB::table($this->table)->insertGetId($data);
                return $result ? $result : [];
            } catch (\Exception $e) {
                throw new \Exception($e->getMessage());
            }
        } else {
            throw new \Exception("argument not passed.");
        }
    }

    /**
     * updateIstaUsers
     * @param $where
     * @param $data
     * @return array
     * @throws \Exception
     */
    public function updateInstaUsers($where, $data)
    {
        if (func_num_args() > 0) {
            try {
                $result = DB::table('insta_users')
                    ->whereRaw($where['rawQuery'], isset($where['bindParams']) ? $where['bindParams'] : array())
                    ->update($data);
                return ($result) ? $result : 0;
            } catch (\Exception $e) {
                return 0;
//                throw new \Exception($e->getMessage());
            }
        } else {
            return 0;
//            throw new \Exception("argument not passed.");
        }
    }


    public function addCookies($data)
    {
        try {
            $result = DB::table('cookies')
                ->insertGetId($data);
            return $result;
        } catch (QueryException $e) {
            echo $e->getMessage();
        }


    }

    //Saurabh -- to add user profile details and session_details and browser details
    public function addInstaUserDetails($data)
    {
        try {

            $result = DB::table('insta_users')->insertGetId($data);
            return $result ? $result : 0;
        } catch (QueryException $e) {
            return 0;
        }
    }

    public function getInstaUserDetails($where, $selCols = ['*'])
    {
        try {
            $result = DB::table('insta_users')
                ->whereRaw($where['rawQuery'], isset($where['bindParams']) ? $where['bindParams'] : array())
                ->select($selCols)
                ->get();
            return ($result) ? $result : [];
        } catch (QueryException $e) {
            return $e->getMessage();
        }
    }

    public function getAllInstaUserDetails()
    {
        try {
            $result = DB::table('insta_users')
                ->get();
            return ($result) ? $result : [];
        } catch (QueryException $e) {
            return $e->getMessage();
        }
    }

    public function getInstaUserMetaDetails($where, $selCols = ['*'])
    {
        try {
            $result = DB::table('insta_users_meta')
                ->whereRaw($where['rawQuery'], isset($where['bindParams']) ? $where['bindParams'] : array())
                ->select($selCols)
                ->get();
            return $result ? (json_decode(json_encode($result), true)) : [];
        } catch (QueryException $e) {
            return $e->getMessage();
        }
    }

    public function addInstaUsersMeta($data)
    {
        try {
            $result = DB::table('insta_users_meta')->insertGetId($data);
            return $result ? $result : 0;
        } catch (QueryException $e) {
            return $e->getMessage();
        }

    }

    public function updateInstaUsersMeta($where, $data)
    {
        try {
            $result = DB::table('insta_users_meta')
                ->whereRaw($where['rawQuery'], isset($where['bindParams']) ? $where['bindParams'] : array())
                ->update($data);
            return ($result) ? $result : [];
        } catch (QueryException $e) {
            return $e->getMessage();
        }
    }

    public function getInstaUsersWithMetaDetails($where, $selectCols = ['*'])
    {
        try {
            $result = DB::table('insta_users')
                ->whereRaw($where['rawQuery'], isset($where['bindParams']) ? $where['bindParams'] : array())
                ->join('insta_users_meta', 'insta_users.ins_user_id', '=', 'insta_users_meta.ins_user_id')
                ->select($selectCols)
                ->get();
            return ($result) ? json_decode(json_encode($result), true) : [];

        } catch (QueryException $e) {
            return $e->getMessage();
        }

    }

    public function updateInstaUsersWithMetaDetails($where, $data)
    {
        try {
            $result = DB::table('insta_users')
                ->whereRaw($where['rawQuery'], isset($where['bindParams']) ? $where['bindParams'] : array())
                ->join('insta_users_meta', 'insta_users.ins_user_id', '=', 'insta_users_meta.ins_user_id')
                ->update($data);
            return ($result) ? $result : 0;
        } catch (QueryException $e) {
            return $e->getMessage();
        }
    }

    public function deleteInstaUsersWithMetaDetails($where)
    {
        try {
            $result = DB::table('insta_users', 'insta_users_meta')
                ->whereRaw($where['rawQuery'], isset($where['bindParams']) ? $where['bindParams'] : array())
                ->join('insta_users_meta', 'insta_users.ins_user_id', '=', 'insta_users_meta.ins_user_id')
                ->delete();
            return ($result) ? $result : 0;
        } catch (QueryException $e) {
            return $e->getMessage();
        }
    }

}