<?php
/**
 * Created by Dibyaranjan Pradhan<dibyaranjanpradhan@globussoft.in>.
 * User: GLB-368
 * Date: 2/10/2018
 * Time: 12:28 PM
 */

namespace App\Http\Models;

use DB;
use Illuminate\Database\Eloquent\Model;

class UserStatsDetails extends Model
{

    protected $table = 'user_stats_details';

    protected static $_instance = null;

    /**
     * @return UserStatsDetails|null
     */
    public static function getInstance()
    {
        if (!is_object(self::$_instance))
            self::$_instance = new UserStatsDetails();
        return self::$_instance;
    }

    /**
     * updateUserStats
     * @param $where
     * @param $update
     * @return int
     * @throws \Exception
     * @author Dibyaranjan Pradhan<dibyaranjanpradhan@globussoft.in>
     * @since 10-Feb-2018
     */
    public function updateUserStats($where, $update)
    {
        if (func_num_args() > 0) {
            try {
                $result = DB::table($this->table)
                    ->whereRaw($where['rawQuery'], isset($where['bindParams']) ? $where['bindParams'] : array())
                    ->update($update);

                return $result ? $result : 0;
            } catch (\Exception $e) {
                return $e->getMessage();
            }
        } else {
            throw new \Exception("Argument not passed.");
        }
    }

    /**
     * getUserStatsDetail
     * @param $where
     * @param $select
     * @return int|string
     * @throws \Exception
     * @author Dibyaranjan Pradhan<dibyaranjanpradhan@globussoft.in>
     * @since 10-Feb-2018
     */
    public function getUserStatsDetail($where, $select = ['*'])
    {
        if (func_num_args() > 0) {
            try {
                $result = DB::table($this->table)
                    ->whereRaw($where['rawQuery'], isset($where['bindParams']) ? $where['bindParams'] : array())
                    ->select($select)
                    ->first();

                return $result ? $result : 0;
            } catch (\Exception $e) {
                return $e->getMessage();
            }
        } else {
            throw new \Exception("Argument not passed.");
        }
    }

    /**
     * insertUserStatsDetails
     * @param $data
     * @return array
     * @throws \Exception
     * @author Nandita Patel<nanditapatel@globussoft.in>
     * @since 14-Feb-2018
     */
    public function insertUserStatsDetails($data)
    {
        if (func_num_args() > 0) {
            try {
                $result = DB::table($this->table)->insertGetId($data);
                return $result ? $result : [];
            } catch (\Exception $e) {
                throw new \Exception($e->getMessage());
            }
        } else {
            throw new \Exception("argument not passed.");
        }
    }

    /**
     * getAllUserStatsDetails
     * @param $where
     * @param array $selectedCols
     * @return array
     * @throws \Exception
     * @author Nandita Patel<nanditapatel@globussoft.in>
     * @since 14-Feb-2018
     */
    public function getAllUserStatsDetails($where, $selectedCols = ['*'])
    {
        if (func_num_args() > 0) {
            try {
                $result = DB::table($this->table)
                    ->join('instagram_users', 'instagram_users.insta_user_id', '=', $this->table . '.by_insta_user_id')
                    ->whereRaw($where['rawQuery'], isset($where['bindParams']) ? $where['bindParams'] : array())
                    ->select($selectedCols)
                    ->get();
                return $result ? json_decode($result, true) : [];
            } catch (\Exception $e) {
                throw new \Exception($e->getMessage());
            }
        } else {
            throw new \Exception("argument not passed.");
        }
    }

    public function removeUserStatsDetails($where)
    {
        if (func_num_args() > 0) {
            try {
                $result = DB::table($this->table)
                    ->whereRaw($where['rawQuery'], isset($where['bindParams']) ? $where['bindParams'] : array())
                    ->delete();
                return $result ? $result : 0;
            } catch (\Exception $e) {
                throw new \Exception($e->getMessage());
            }
        } else {
            throw new \Exception("argument not passed.");
        }

    }

}