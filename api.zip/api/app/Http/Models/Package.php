<?php

namespace App\Http\Models;

use Illuminate\Auth\Authenticatable;
use Illuminate\Support\Facades\DB;
use Laravel\Lumen\Auth\Authorizable;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\QueryException;
use Illuminate\Contracts\Auth\Authenticatable as AuthenticatableContract;
use Illuminate\Contracts\Auth\Access\Authorizable as AuthorizableContract;

class Package extends Model implements AuthenticatableContract, AuthorizableContract
{
    use Authenticatable, Authorizable;

    private static $_instance = null;

    public static function getInstance()
    {
        if (!is_object(self::$_instance))  //or if( is_null(self::$_instance) ) or if( self::$_instance == null )
            self::$_instance = new Package();
        return self::$_instance;
    }


    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'name', 'email',
    ];

    /**
     * The attributes excluded from the model's JSON form.
     *
     * @var array
     */
    protected $hidden = [
        'password',
    ];


    /**
     * @Desc fetching all packages
     * @Class packageList
     * @return mixed
     * @since 17 jan 2018
     * @author Sibasankar Bhoi (sibasankarbhoi@globussoft.in)
     */
    public function packageList($package_for)
    {
        try {

            $packageList = DB::table('packages')->where('package_for',$package_for)->get();
            if ($packageList == null) {                                    //set validation
                echo json_encode(['code' => 401, 'status' => 'false', 'message' => 'No packages found']);
            } else {
                return $packageList;
            }

        } catch (\Exception $exc) {
            dd($exc->getMessage());
            echo json_encode(['code' => 401, 'status' => 'false', 'message' => 'Internal server error, package list']);
        }
        return $packageList;
    }

    public function getAllPackages($where, $selectedColumns = ['*'])
    {
        $result = DB::table('packages')
            ->whereRaw($where['rawQuery'], isset($where['bindParams']) ? $where['bindParams'] : [])
            ->select($selectedColumns)
            ->get();
        return ($result) ? json_decode($result, true) : 0;
    }

    public function countAllPackages($where)
    {
        $result = DB::table('packages')
            ->whereRaw($where['rawQuery'], isset($where['bindParams']) ? $where['bindParams'] : [])
            ->count();
        return ($result) ? json_decode($result, true) : 0;
    }

    public function getPackageDetails($where, $selectedCols = ['*'])
    {
        try {
            $result = DB::table('packages')
                ->whereRaw($where['rawQuery'], isset($where['bindParams']) ? $where['bindParams'] : [])
                ->select($selectedCols)
                ->get();
            return ($result) ? $result : 0;
        } catch (QueryException $e) {
            return 0;
        }

    }

    public function getFilteredPackages($where, $selectedCols, $startCount, $length)
    {
        $result = DB::table('packages')
            ->whereRaw($where['rawQuery'], isset($where['bindParams']) ? $where['bindParams'] : [])
            ->select($selectedCols)
            ->skip($startCount)->take($length)
            ->get();
        return ($result) ? json_decode($result, true) : 0;
    }


    /**
     * @Desc fetch all packages according to package_for
     * @param $package_for
     * @param $package_type
     * @return mixed
     * @author Sibasankar Bhoi (sibasankarbhoi@globussoft.in)
     * @since 17-May-2018
     */
    public function fetchPackage($package_for, $package_type){
        try {
            $packageList = DB::table('packages')->where('package_type',$package_type)->where('package_for',$package_for)->get();
            if ($packageList == null) {                                    //set validation
                echo json_encode(['code' => 401, 'status' => 'false', 'message' => 'No packages found']);
            } else {
                return $packageList;
            }

        } catch (\Exception $exc) {
            dd($exc->getMessage());
            echo json_encode(['code' => 401, 'status' => 'false', 'message' => 'Internal server error, package list']);
        }

    }
    /**
     * @Desc fetch package details
     * @param $id
     * @return mixed
     * @author Sibasankar Bhoi (sibasankarbhoi@globussoft.in)
     * @since 23-May-2018
     */
    public function packageDetails($id){

        try {
            $packageList = DB::table('packages')->where('package_id',$id)->get();
            if ($packageList == null) {                                    //set validation
                echo json_encode(['code' => 401, 'status' => 'false', 'message' => 'No packages found']);
            } else {
                return $packageList;
            }

        } catch (\Exception $exc) {
            dd($exc->getMessage());
            echo json_encode(['code' => 401, 'status' => 'false', 'message' => 'Internal server error, package list']);
        }

    }

}
