<?php

namespace App\Http\Models;

use Illuminate\Auth\Authenticatable;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\QueryException;
use Illuminate\Support\Facades\DB;

class User extends Model
{
    protected $fillable = ['firstname', 'lastname', 'email', 'password', 'username', 'role', 'status', 'registered_through', 'device_type', 'device_id', 'user_free_package', 'rated_app', 'created_at', 'updated_at', 'activation_otp'];
    protected $hidden = ['password', 'pd_reset_token'];

    private static $_instance = null;

    public static function getInstance()
    {
        if (!is_object(self::$_instance))  //or if( is_null(self::$_instance) ) or if( self::$_instance == null )
            self::$_instance = new User();
        return self::$_instance;
    }


    /**
     * @Desc   Register user
     * @param $userDetails
     * @return array
     * @since 11 jan 2018
     * @author Sibasankar Bhoi (sibasankarbhoi@globussoft.in)
     */
    public function insertUserData($userDetails)
    {
        try {
            $check_user_activeation = DB::table('users')->where('email', $userDetails['email'])->where('registered_through', $userDetails['registered_through'])->first();
            if (isset($check_user_activeation)) {
                if (isset($check_user_activeation) && $check_user_activeation->status == 0) {
                    return $check_user_activeation;

                } elseif (isset($check_user_activeation) && $check_user_activeation->status == 1) {
                    apiResponse('400', 'Account allready registered please login', 'allready registered', $check_user_activeation->id);
                }
            } else
                $result = DB::table('users')->insertGetId($userDetails);
            if (isset($result) && !empty($result)) {
                return $result;
            }
        } catch (\Exception $exc) {
            dd($exc->getMessage());
            $response = ['code' => 400, 'message' => 'Internal Server Error', 'data' => null];
        }
        return $result;
    }


    /**
     * @Desc Activation of users through OTP verification for GIVE
     * @Class userActivation
     * @param $otp
     * @return mixed
     * @since 1 feb 2018
     * @author Sibasankar Bhoi (sibasankarbhoi@globussoft.in)
     */
    public function userActivation($otp, $user_id)
    {
        $verifyOtp = DB::table('users')->where('id', $user_id)->first();
        if (isset($verifyOtp) && !empty($verifyOtp) && $verifyOtp->status==1) {
//        if (isset($verifyOtp) && $verifyOtp->status == 1) {
            apiResponse(400, 'account already activated', 'duplicate entry', null);
        } elseif ($verifyOtp == null) {
            apiResponse(400, 'user id not found', 'wrong user Id', null);
        } else {
            try {
                $verifyOtp = DB::table('users')->where('activation_otp', $otp)->first();
                if ($verifyOtp->id == $user_id) {
                    return $verifyOtp;
                } else {
                    echo json_encode(['status' => 'false', 'code' => 412, 'message' => 'Enter Correct user ID']);
                    die;
                }
            } catch (\Exception $exc) {
                dd($exc->getMessage());
                $response = ['code' => 500, 'message' => 'Internal Server Error, User Activation', 'data' => null];
            }
        }
    }


    /**
     * @Desc  Login User
     * @param $email
     * @return mixed
     * @since 11 Dec 2017
     * @author Sibasankar Bhoi (sibasankarbhoi@globussoft.in)
     */
    public function getUserData($email, $registered_through,$name)
    {
        try {
            $userdetails = DB::table('users')->where($name, $email)->where('registered_through', $registered_through)->first();

            if (isset($userdetails)) {
                    return $userdetails;
//
//                if ($userdetails->status == 1) {
//                    return $userdetails;
//                } else {
//                    dd($userdetails);
//
//                    echo json_encode(['code' => 401, 'status' => 'false', 'message' => 'Please activate your account, OTP sent to your mail', 'user_id' => $userdetails->id]);
//                    die;
//                }
            } elseif ($registered_through==2){
                apiResponse(401, 'ваша учетная запись не зарегистрирована', 'unkown account', null);

            }else
                apiResponse(401, 'your account is not registered', 'unkown account', null);
        } catch (\Exception $exc) {
            $response = ['code' => 404, 'message' => 'Internal Server Error', 'data' => null];
        }

    }


    /**
     * @Desc  verification of OTP forget password and update to null after verified
     * @Class verifyOtp
     * @param $otp
     * @return mixed
     * @since 12 Dec 2018
     * @author Sibasankar Bhoi (sibasankarbhoi@globussoft.in)
     */
    public function verifyOtp($otp, $user_id)
    {
        try {
            $check_id = DB::table('users')->where('pd_reset_token', $otp)->select('id')->first()->id;

            if ($check_id == $user_id) {
                return $check_id;
            } else {
                echo json_encode(['status' => 'false', 'code' => 412, 'message' => 'Enter Correct user ID']);
                die;
            }
        } catch (\Exception $exc) {
            dd($exc->getMessage());
            echo json_encode(['status' => 'false', 'code' => 401, 'message' => 'Internal Server Error, password token verification']);
        }
    }


    /**
     * @Desc  fetching media details
     * @Class getmediaDetails
     * @param $data
     * @since 16 jan 2018
     * @author Sibasankar Bhoi (sibasankarbhoi@globussoft.in)
     */
    public function getmediaDetails($data)
    {
        try {
            if ($data) {
                echo json_encode(['status' => 'success', 'code' => 200, 'message' => 'user is exist', 'followed-by' => $data['user']['followed_by']['count'], 'followers' => $data['user']['follows']['count'], 'account-private' => $data['user']['is_private']]);
                die;
                print_r($data['user']['followed_by']['count']);
                print_r($data['user']['follows']['count']);
                die;
            } else {
                echo json_encode(['status' => 'false', 'code' => 404, 'message' => 'user not found']);
                die;
            }

        } catch (\Exception $exc) {

            echo json_encode(['status' => 'failed', 'code' => 401, 'message' => 'user not exist', 'data' => null]);
            die;
        }
    }

    /**
     * @param $where
     * @return int
     * @date 10-2-2016
     * @dev saurabh Kumar <saurabh.kumar@globussoft.com>
     */
    public function deleteUserDetails($where)
    {
        $result = DB::table('users')
            ->whereRaw($where['rawQuery'], isset($where['bindParams']) ? $where['bindParams'] : array())
            ->delete();
        if ($result)
            return $result;
        else
            return 0;
    }

    public function getUserDetail($where, $selectedCols = ['*'])
    {

        try {
            $result = DB::table('users')
                ->whereRaw($where['rawQuery'], isset($where['bindParams']) ? $where['bindParams'] : array())
                ->select($selectedCols)
                ->first();
            return ($result) ? json_decode(json_encode($result), true) : 0;
        } catch (QueryException $e) {
//            echo $e->getMessage();
            return 0;
        }

    }

    public function updateUserDetails($where, $data)
    {
//        dd($where, $data);
        try {
            $result = DB::table('users')
                ->whereRaw($where['rawQuery'], isset($where['bindParams']) ? $where['bindParams'] : array())
                ->update($data);
            return ($result) ? $result : 0;
        } catch (QueryException $e) {
//            echo $e->getMessage();
            return 2;
        }

    }

}
