<?php

namespace App\Http\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\QueryException;
use Illuminate\Support\Facades\DB;

class  Autolikes_order extends Model
{

    /*
   |--------------------------------------------------------------------------
   | Insert data -- Saurabh - 15th June 2018
   |--------------------------------------------------------------------------
   |
   | This function inserts the data in autolikes_orders table and return true/false
   |
   */
    public function insert($data)
    {
        try {

            $result = DB::table('autolikes_orders')
                ->insert($data);

            return $result;

        } catch (QueryException $e) {
            dd($e->getMessage());
        }
    }


    /*
    |--------------------------------------------------------------------------
    | Select All -- Saurabh - 15th June 2018
    |--------------------------------------------------------------------------
    |
    | This function gets all the autolikes order records based on the condition.
    |
    */
    public function selectAll($where, $selectCols)
    {
        try {

            $result = DB::table('autolikes_orders')
                ->whereRaw($where['rawQuery'], isset($where['bindParams']) ? $where['bindParams'] : array())
                ->select($selectCols)
                ->get();

            return ($result) ? json_decode($result, true) : 0;

        } catch (QueryException $e) {
            return 0;
            throw new \Exception($e->getMessage());
        }

    }


    /*
    |--------------------------------------------------------------------------
    | Select first -- Saurabh - 15th June 2018
    |--------------------------------------------------------------------------
    |
    | This function selects the first fetched records and returns. (only first)
    |
    */
    public function select($where, $selectCols)
    {
        try {

            $result = DB::table('autolikes_orders')
                ->whereRaw($where['rawQuery'], isset($where['bindParams']) ? $where['bindParams'] : array())
                ->select($selectCols)
                ->first();

            return ($result) ? json_decode($result, true) : 0;

        } catch (QueryException $e) {
            throw new \Exception($e->getMessage());
        }

    }

    /*
    |--------------------------------------------------------------------------
    | Count the records fetched  -- Saurabh - 15th June 2018
    |--------------------------------------------------------------------------
    |
    */
    public function countRecord($where)
    {
        try {

            $result = DB::table('autolikes_orders')
                ->whereRaw($where['rawQuery'], isset($where['bindParams']) ? $where['bindParams'] : array())
                ->count();

            return ($result) ? json_decode($result, true) : 0;

        } catch (QueryException $e) {
            throw new \Exception($e->getMessage());
        }

    }


    public function getProfileWithRecurringAndPackageDetails($where, $selectCols = ['*'])
    {
        try {
            $result = DB::table('autolikes_orders')
                ->join('recurring_profiles', 'recurring_profiles.profile_id', '=', 'autolikes_orders.recurring_profile_id')
                ->join('subscription_packages', 'subscription_packages.sub_package_id', '=', 'autolikes_orders.sub_package_id')
                ->whereRaw($where['rawQuery'], isset($where['bindParams']) ? $where['bindParams'] : array())
                ->select($selectCols)
                ->get();
            return ($result) ? json_decode($result, true) : [];
        } catch (QueryException $e) {
            return $e->getMessage();
            return [];
        }

    }

    public function profileMetaWithRecurringAndPackageDetails($where, $selectCols = ['*'])
    {
        try {
            $result = DB::table('autolikes_orders')
                ->join('autolikes_orders_meta', 'autolikes_orders_meta.parent_autolikes_id', 'autolikes_orders.autolikes_id')
                ->join('recurring_profiles', 'recurring_profiles.profile_id', '=', 'autolikes_orders.recurring_profile_id')
                ->join('subscription_packages', 'subscription_packages.sub_package_id', '=', 'autolikes_orders.sub_package_id')
                ->whereRaw($where['rawQuery'], isset($where['bindParams']) ? $where['bindParams'] : array())
                ->select($selectCols)
                ->get();
            return ($result) ? json_decode($result, true) : [];
        } catch (QueryException $e) {
            return $e->getMessage();
            return [];
        }

    }

}