<?php

namespace App\Http\Models;

use App\Http\Controllers\GILR\TransactionController;
use App\Http\Controllers\GIVE\GiveTransactionController;
use Illuminate\Auth\Authenticatable;
use Illuminate\Support\Facades\DB;
use Laravel\Lumen\Auth\Authorizable;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Contracts\Auth\Authenticatable as AuthenticatableContract;
use Illuminate\Contracts\Auth\Access\Authorizable as AuthorizableContract;

class Transaction extends Model implements AuthenticatableContract, AuthorizableContract
{
    use Authenticatable, Authorizable;

    private static $_instance = null;

    public static function getInstance()
    {
        if (!is_object(self::$_instance))  //or if( is_null(self::$_instance) ) or if( self::$_instance == null )
            self::$_instance = new Transaction();
        return self::$_instance;
    }


    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'name', 'email',
    ];

    /**
     * The attributes excluded from the model's JSON form.
     *
     * @var array
     */
    protected $hidden = [
        'password',
    ];


    /**
     * @Desc fetching Transaction History
     * @Class getDetails
     * @param $data
     * @since 13 jan 2018
     * @author Sibasankar Bhoi (sibasankarbhoi@globussoft.in)
     */
    public function transactionhistory($user_id)
    {
        try {
            $transaction_history = DB::table('transactions')->where('user_id', $user_id)->get();
            if (isset($transaction_history) && !empty($transaction_history)) {
                return $transaction_history;
            } else {
                echo json_encode(['code' => 404, 'status' => 'failed', 'message' => 'No transaction Found', 'data' => null]);
                die;
            }
        } catch (\Exception $exc) {
            dd($exc->getMessage());
            echo json_encode(['code' => 401, 'status' => 'failed', 'message' => 'Internal server error, Transaction History', 'data' => $exc->getMessage()]);
            die;
        }
    }


    public function paymentHistory($tx_id, $user_id){
        $transaction = new GiveTransactionController();

        try {
            $payment_history = DB::table('transactions')->where('tx_id', $tx_id)->where('user_id',$user_id)->first();
            if (isset($payment_history) && !empty($payment_history)) {
                return $payment_history;
            } else {
                $transaction->apiError('401','No transaction Found');
                die;
            }
        } catch (\Exception $exc) {
            $transaction->apiError('401','No transactiadscdaon Found');
            die;
        }
    }


    /**
     * @desc insert payment details in transactions table (after successful txn)
     * insertGetId method is used to insert a record and then retrieve the ID, if that table has auto-incremented id.
     * @return mixed
     * @date 28-03-2018
     * @dev saurabh Kumar <saurabh.kumar@globussoft.com>
     */
    public function insertTransaction()
    {
        if (func_num_args() > 0) {

            $data = func_get_arg(0);
            try {
                return DB::table('transactions')
                    ->insertGetId($data);
            } catch (QueryException $e) {
                apiResponse(400, 'Something went wrong, please try after sometime.', $e->getMessage(), null);
            }
        }
    }
    
    /**
     * @desc fetching the transaction details for checking ip address when order free package
     * @param $where
     * @param array $findData
     * @return array
     */
    public function getTransactionDetails($where, $findData=['*'])
    {
        if (func_num_args() > 0) {
            try {
                $result = DB::table('transactions')
                    ->whereRaw($where['rawQuery'], isset($where['bindParams']) ? $where['bindParams'] : array())
                    ->select($findData)
                    ->get();
                return $result ? $result : [];
            } catch (QueryException $e) {
                echo $e->getMessage();
            }
        } else {
            echo 'Argument not passed!';
        }
    }


}



