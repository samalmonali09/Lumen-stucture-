<?php

namespace App\Http\Models;

use Illuminate\Auth\Authenticatable;
use Illuminate\Support\Facades\DB;
use Laravel\Lumen\Auth\Authorizable;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Contracts\Auth\Authenticatable as AuthenticatableContract;
use Illuminate\Contracts\Auth\Access\Authorizable as AuthorizableContract;

class Service extends Model
{

    private static $_instance = null;

    public static function getInstance()
    {
        if (!is_object(self::$_instance))  //or if( is_null(self::$_instance) ) or if( self::$_instance == null )
            self::$_instance = new Service();
        return self::$_instance;
    }


    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'name', 'email',
    ];

    /**
     * The attributes excluded from the model's JSON form.
     *
     * @var array
     */
    protected $hidden = [
        'password',
    ];


    /**
     * @Desc checking user is exist or not
     * @Class getDetails
     * @param $data
     * @since 13 jan 2018
     * @author Sibasankar Bhoi (sibasankarbhoi@globussoft.in)
     */
    public function getaccountDetails($data)
    {
        try {
            if (isset($data) && $data['graphql']['user']['is_private'] == false) {
                $userDetailsArr = [];
                $userDetailsArr['followed_by'] = convertNumberIntoProperNotation($data['graphql']['user']['edge_followed_by']['count']);
                $userDetailsArr['following'] = convertNumberIntoProperNotation($data['graphql']['user']['edge_follow']['count']);
                $userDetailsArr['isPrivate'] = $data['graphql']['user']['is_private'];
                $userDetailsArr['full_name'] = $data['graphql']['user']['full_name'];
                $userDetailsArr['id'] = $data['graphql']['user']['id'];
                $userDetailsArr['profile_image'] = $data['graphql']['user']['profile_pic_url_hd'];
                $userDetailsArr['total_post'] = convertNumberIntoProperNotation($data['graphql']['user']['edge_owner_to_timeline_media']['count']);
                $userDetailsArr['has_next_page'] = $data['graphql']['user']['edge_owner_to_timeline_media']['page_info']['has_next_page'];
                $userDetailsArr['end_cursor'] = $data['graphql']['user']['edge_owner_to_timeline_media']['page_info']['end_cursor'];

//                echo json_encode(['code' => 200, 'status' => 'success', 'message' => 'user is exist', 'data' => $userDetailsArr]);
                return $userDetailsArr;
            } elseif (isset($data) && $data['graphql']['user']['is_private'] == true) {


                $userDetailsArr = [];
                $userDetailsArr['followed_by'] = convertNumberIntoProperNotation($data['graphql']['user']['edge_followed_by']['count']);
                $userDetailsArr['following'] = convertNumberIntoProperNotation($data['graphql']['user']['edge_follow']['count']);
                $userDetailsArr['isPrivate'] = $data['graphql']['user']['is_private'];
                $userDetailsArr['full_name'] = $data['graphql']['user']['full_name'];
                $userDetailsArr['total_post'] = convertNumberIntoProperNotation($data['graphql']['user']['edge_owner_to_timeline_media']['count']);

                $userDetailsArr['profile_image'] = $data['graphql']['user']['profile_pic_url_hd'];

                echo json_encode(['code' => 200, 'status' => 'success', 'message' => 'user is private', 'data' => $userDetailsArr]);
                die;

            } else {
                echo json_encode(['code' => 401, 'status' => 'false', 'message' => 'user not found', 'data' => null]);
                die;
            }
        } catch (\Exception $exc) {
            dd($exc->getMessage());
            echo json_encode(['code' => 401, 'status' => 'failed', 'message' => 'user not exist', 'data' => null]);
            die;
        }
    }

    /**
     * @Desc checking free package, user can get or not
     * @Class checkfreePackage
     * @param $uesername
     * @return mixed
     * @since 17 jan 2018
     * @author Sibasankar Bhoi (sibasankarbhoi@globussoft.in)
     */
    public function checkfreePackage($uesername, $access_token)
    {
        try {
            $freepackage = DB::table('users')->where('username', $uesername)->first();
            $freepackage_status = $freepackage->user_free_package;
            if ($freepackage_status == 0) {

                echo json_encode(['status' => 'success', 'code' => 200, 'message' => 'user can get free package', 'package_status' => $freepackage_status, 'url' => env('WEB_URL') . '/gilr/free-package-order/' . $access_token]);
                die;
            } else {
                echo json_encode(['code' => 401, 'status' => 'false', 'message' => 'user has already taken free package', 'package_status' => $freepackage_status]);
            }
        } catch (\Exception $exc) {
            echo json_encode(['code' => 401, 'status' => 'false', 'message' => 'user is not exist']);
        }
        return $freepackage;
    }


    /**
     * @Desc checking free packages after rating APP
     * @Class ratedAppfreepackage
     * @param $uesername
     * @return mixed
     * @since 17 jan 2018
     * @author Sibasankar Bhoi (sibasankarbhoi@globussoft.in)
     */
//    public function ratedAppfreepackage($ueserid, $order_token = '')
//    {
//        try {
//            $freepackage = DB::table('users')->where('id', $ueserid)->first();
//            $freepackage_status = $freepackage->rated_app;
//
//            if ($freepackage_status == 1) {
//                if ($order_token == '') {
//                    $url = null;
//                } else {
//                    $url = 'http://gaia.globusdemos.com/gilr/free-package-order/' . $order_token;
//                }
//                echo json_encode(['status' => 'success',
//                    'code' => 200,
//                    'message' => 'user can get free package',
//                    'package_status' => $freepackage_status,
//                    'url' => $url]);
//                die;
//            } elseif ($freepackage_status == 0) {
//                return $freepackage_status;
////                echo json_encode(['code' => 401, 'status' => 'false', 'message' => 'user has not rate the app', 'package_status' => $freepackage_status]);
//            } else {
//                apiResponse('401', 'user has already taken free package', null, $freepackage_status);
//
////                return json_encode(['code' => 401, 'status' => 'false', 'message' => 'user has already taken free package', 'package_status' => $freepackage_status]);
//            }
//        } catch (\Exception $exc) {
//            dd($exc->getMessage());
//            echo json_encode(['code' => 401, 'status' => 'false', 'message' => 'user is not exist']);
//        }
//        return $freepackage;
//    }
    public function ratedAppfreepackage($ueserid, $order_token = '')
    {
        try {
            $freepackage = DB::table('users')->where('id', $ueserid)->first();
            $freepackage_status = $freepackage->user_free_package;
            $ratedApp_status = $freepackage->rated_app;
//            dd($ratedApp_status, $freepackage_status);
            $url='';
            if ($freepackage_status == 0) {
                echo json_encode(['status' => 'success',
                    'code' => 200,
                    'message' => 'user can get free package',
                    'package_status' => $freepackage_status,
                    'url' =>'http://gaia.globusdemos.com//gilr/free-package-order/' . $order_token]);
                die;
            }if ($ratedApp_status == 1) {
                echo json_encode(['status' => 'success',
                    'code' => 200,
                    'message' => 'user can get free package',
                    'package_status' => $freepackage_status,
                    'url' =>'http://gaia.globusdemos.com/gilr/free-package-order/' . $order_token]);
                die;
            }
            ;


        } catch (\Exception $exc) {
            echo json_encode(['code' => 401, 'status' => 'false', 'message' => 'user is not exist']);
        }
        return $freepackage;
    }
    public function ratedAppfreepackageGIVR($ueserid, $order_token = '')
    {
        try {
            $freepackage = DB::table('users')->where('id', $ueserid)->first();
            $freepackage_status = $freepackage->user_free_package;
            $ratedApp_status = $freepackage->rated_app;
//            dd($ratedApp_status, $freepackage_status);
            $url='';
            if ($freepackage_status == 0) {
                echo json_encode(['status' => 'success',
                    'code' => 200,
                    'message' => 'user can get free package',
                    'package_status' => $freepackage_status,
                    'url' =>'http://gaia.globusdemos.com//givr/free-package-order/' . $order_token]);
                die;
            }if ($ratedApp_status == 1) {
                echo json_encode(['status' => 'success',
                    'code' => 200,
                    'message' => 'user can get free package',
                    'package_status' => $freepackage_status,
                    'url' =>'http://gaia.globusdemos.com/givr/free-package-order/' . $order_token]);
                die;
            }
            ;


        } catch (\Exception $exc) {
            echo json_encode(['code' => 401, 'status' => 'false', 'message' => 'user is not exist']);
        }
        return $freepackage;
    }

}
