<?php
////==========================Test Route=====================================//
//$router->get('/instastats/test', 'InstaStats\UserController@testFucntion');
////==========================App Authentication Route=======================//
////For Signup
//$router->post('/instastats/signup', 'InstaStats\UserController@signup');
////For Activate account
////$router->post('/instastats/activate-account', 'InstaStats\UserController@activateAccount');
//$router->get('/instastats/activate-account', 'InstaStats\UserController@activateAccount');
////For user login
//$router->post('/instastats/login', 'InstaStats\UserController@login');
////For reset password
//$router->post('/instastats/reset-password', 'InstaStats\UserController@resetPassword');
////==========================Instagram All Route=======================//
////=========================NANDITA===============================//
//For instagram account add
$router->post('/instastats/add-account', 'InstaStats\UserController@addInstaAccount');
//For verify instagram account with choice(email or phone)
$router->post('/instastats/insta-verify-choice', 'InstaStats\UserController@instaAccountVerifyChoice');
//For verify instagram account with code
$router->post('/instastats/insta-verify-code', 'InstaStats\UserController@instaAccountVerifyCode');
//For verify instagram account with phone
$router->post('/instastats/insta-verify-phone', 'InstaStats\UserController@verifyPhoneNumber');
////For update instagram user profile details using cron
//$router->get('/instastats/update-all-user-details', 'InstaStats\UserController@updateInstaUserDetails');
////For get insta user details on page refresh
//$router->post('/instastats/get-insta-user-details', 'InstaStats\UserController@fetchInstaUserDetails');
////For re-connect Instagram account
//$router->post('/instastats/reconnect-insta-account', 'InstaStats\UserController@reconnectInstaAccount');
////For USER DayWise-user-Followers-Following-Follower_gain-Recent_post_like Count..
//$router->post('/instastats/user-stats', 'InstaStats\StatisticsController@getUserStats');
////For User Day-Wise Likes Count on particular media
//$router->post('/instastats/user-media-stats', 'InstaStats\StatisticsController@getMediaLikesCount');
////For Other Media Details
//$router->post('/instastats/other-media_details', 'InstaStats\StatisticsController@otherMediaDetails');
////===============================================================//
//
////=============================DRP===============================//
////For get followeing details..
//$router->post('/instastats/following-stats', 'InstaStats\StatisticsController@followingStats');
////For get follower details.. not complete
//$router->post('/instastats/followers-stats', 'InstaStats\StatisticsController@followersStats');
////For USER Non-followers..
//$router->post('/instastats/get-non-followers', 'InstaStats\StatisticsController@getNonFollowers');
////For USER Recent Post..
//$router->post('/instastats/get-recent-media-details', 'InstaStats\StatisticsController@getRecentMediaDetails');
////For USER Top-Likers..
//$router->post('/instastats/get-top-likers', 'InstaStats\StatisticsController@getTopLikers'); // first 10
//$router->post('/instastats/get-more-top-likers', 'InstaStats\StatisticsController@getMoreTopLikers'); // next 10 from 'COUNT'
////For USER Likes from Followers..
//$router->post('/instastats/get-likes-from-followers', 'InstaStats\StatisticsController@getLikesFromFollowers');
////For USER Unfollow service..
//$router->post('/instastats/unfollow-the-user', 'InstaStats\StatisticsController@userUnfollowService');
////==============================================================//
//
