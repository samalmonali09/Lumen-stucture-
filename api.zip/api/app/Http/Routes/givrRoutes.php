<?php
$router->get('/', function () use ($router) {
    return $router->app->version();
});

//Routes for Authentication for GIVE Users --Sibansankar

$router->post('/givr/register', 'GIVR\AuthenticationController@userRegistration');
$router->POST('/givr/user-activation', 'GIVR\AuthenticationController@userActivation');
$router->POST('/givr/login', 'GIVR\AuthenticationController@userLogin');
$router->POST('/givr/forget-password', 'GIVR\AuthenticationController@forgetPassword');
$router->POST('/givr/verify-otp', 'GIVR\AuthenticationController@verifyOtp');
$router->POST('/givr/reset-password', 'GIVR\AuthenticationController@resetPassword');
$router->post('/givr/resend-otp-activation', 'GIVR\AuthenticationController@resendOTPforActivation');
$router->GET('/givr/package-list', 'GIVR\GivrPackagesController@GivePackageList');
$router->post('/givr/package', 'GIVR\GivrPackagesController@package');  //get package acco. package_type
$router->POST('/givr/check-user-account', 'GIVR\GivrUserdetailsController@checkuserAccount');
$router->POST('/givr/check-user-exist', 'GIVR\GivrUserdetailsController@usernameExist');
$router->POST('/givr/media-details', 'GIVR\GivrUserdetailsController@getmediaDetails');
$router->post('/givr/add-order', 'GIVR\GivrOrderController@addOrder');   //order placing



//user activities tracking
$router->get('/givr/ActivityTrackerSwitchGIVR', 'GIVR\GivrUserdetailsController@ActivityTrackerSwitchGIVR');// for status on/of with time

$router->post('/givr/insertUserActivities', 'GIVR\ActivityController@insertUserActivities');


$router->get('/givr/Tutorial', 'GIVR\GivrUserdetailsController@Tutorial');
//$router->post('/givr/Tutorial', 'GIVR\GivrUserdetailsController@Tutorial');





$router->get('/givr/moduleDetailsGIVR', 'GIVR\GivrUserdetailsController@moduleDetailsGIVR');

$router->group(['middleware' => 'checkSession'], function () use ($router) {

    $router->POST('/givr/free-package', 'GIVR\GivrUserdetailsController@freepackage');
    $router->POST('/givr/ratedapp-free-package', 'GIVR\GivrUserdetailsController@ratedappPackage');  //checking status of free packages after rated APP
    $router->POST('/givr/place-order', 'GIVR\GivrOrderController@GivrPlaceOrders');
    $router->POST('/givr/order-history', 'GIVR\GivrOrderController@GivrorderHistory');
    $router->POST('/givr/transaction-history', 'GIVR\GivrTransactionController@GivrTransactionHistory');
     $router->POST('/givr/payment-details', 'GIVR\GivrTransactionController@GivrPaymentHistory');
    $router->POST('/givr/rate-app', 'GIVR\GivrUserdetailsController@rateapp');

});