<?php
$router->get('/', function () use ($router) {
    return $router->app->version();
});

//Routes for Authentication for GIVE Users --Sibansankar

$router->post('/givr/register', 'GIVR\AuthenticationController@userRegistration');
$router->POST('/givr/user-activation', 'GIVR\AuthenticationController@userActivation');
$router->POST('/givr/login', 'GIVR\AuthenticationController@userLogin');
$router->POST('/givr/forget-password', 'GIVR\AuthenticationController@forgetPassword');
$router->POST('/givr/verify-otp', 'GIVR\AuthenticationController@verifyOtp');
$router->POST('/givr/reset-password', 'GIVR\AuthenticationController@resetPassword');
//
$router->GET('/givr/package-list', 'GIVR\GivrPackagesController@GivePackageList');
//
$router->POST('/givr/check-user-account', 'GIVR\GivrUserdetailsController@checkuserAccount');
$router->POST('/givr/check-user-exist', 'GIVR\GivrUserdetailsController@usernameExist');
$router->POST('/givr/media-details', 'GIVR\GivrUserdetailsController@getmediaDetails');
$router->post('/give/add-order', 'GIVR\GiveOrderController@addOrder');   //order placing
$router->group(['middleware' => 'checkSession'], function () use ($router) {
    $router->POST('/givr/free-package', 'GIVR\GivrUserdetailsController@freepackage');
    $router->POST('/givr/ratedapp-free-package', 'GIVR\GivrUserdetailsController@ratedappPackage');  //checking status of free packages after rated APP
    $router->POST('/givr/place-order', 'GIVR\GivrOrderController@GivrPlaceOrders');
    $router->POST('/givr/order-history', 'GIVR\GivrOrderController@GivrorderHistory');
    $router->POST('/givr/transaction-history', 'GIVR\GivrTransactionController@GivrTransactionHistory');
    $router->POST('/givr/payment-details', 'GIVR\GivrTransactionController@GivrPaymentHistory');
    $router->POST('/givr/rate-app', 'GIVR\GivrUserdetailsController@rateapp');

});