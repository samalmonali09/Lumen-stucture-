<?php

/*----------------------------------------------------------------
        Routes for cron controllers
----------------------------------------------------------------*/
$router->get('/scheduleOrdersCronJob', 'CommonAPI\CronController@scheduleOrdersCronJob');
$router->get('/placeOrdersToProcessOrdersCronJob', 'CommonAPI\CronController@placeOrdersToProcessOrdersCronJob');
$router->get('/placeProcessOrdersToSupplierCronJob', 'CommonAPI\CronController@placeProcessOrdersToSupplierCronJob');
$router->get('/checkInactiveProxies', 'CommonAPI\CronController@checkInactiveProxies');