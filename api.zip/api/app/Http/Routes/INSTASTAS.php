<?php

$router->group(['namespace' => 'INSTASTATS', 'prefix' => 'instastats'], function ($router) {

    /*--------------------------------------------------------------------------
                        Routes for Authentication
     --------------------------------------------------------------------------*/
    $router->post('/signup', 'UserController@signup');
    $router->post('/activateAccount', 'UserController@activateAccount');
    $router->post('/login', 'UserController@login');
    $router->post('/recoverPassword', 'UserController@recoverPassword');
    $router->post('/resetPassword', 'UserController@resetPassword');
    $router->post('/getProfileDetails', 'UserController@getProfileDetails');
    $router->post('/updateProfile', 'UserController@updateProfile');
    $router->post('/updatePassword', 'UserController@updatePassword');
    $router->post('/changeAvatar', 'UserController@changeAvatar');

//    $router->get('/getBanner', 'UserController@getBanner');
    $router->post('/getBanner', 'UserController@getBanner');

    /*--------------------------------------------------------------------------
                        Routes for Add Instagram Account
    --------------------------------------------------------------------------*/
//    $router->post('/addAccount', 'InstaController@addAccount');
    $router->post('/addAccount', 'InstaController@addAccountNew');
    $router->post('/verifyAccount', 'InstaController@verifyAccount');

    $router->get('/getProfileDetails', 'InstaController@getProfileDetails');

    $router->post('/getNonFollowerDetails', 'InstaController@getNonFollowerDetails');
    $router->post('/refreshAccount', 'InstaController@refreshAccount');
    $router->post('/getFollowersProgress', 'InstaController@getFollowersProgress');
    $router->post('/getFollowingsProgress', 'InstaController@getFollowingsProgress');
    $router->post('/getLikesStats', 'InstaController@getLikesStats');  //by prana
    $router->post('/deleteAccount', 'InstaController@deleteAccount');
    $router->post('/unfollowAccount', 'InstaController@unfollowAccount');

    $router->post('/getFollowerNonfolllowersLikers', 'InstaController@getFollowerNonfolllowersLikers');  //added by prana kishore

    $router->post('/geTtopLikersDetails', 'InstaController@geTtopLikersDetails');  //top likers
    $router->post('/getLikesStatsForsingleMedia', 'InstaController@getLikesStatsForsingleMedia');  //getting likes stats for all media with like from follower and non follower


    $router->get('/getNonFollowerList', 'CronController@getNonFollowerList');  //cron
    $router->get('/updateFollowersCountCronJob', 'CronController@updateFollowersCountCronJob');
    //=============== Added by prana kishore on 18-05-2018  ===getLikersDetails
    $router->get('/getNullMediaListAndGetDetailsCronjob', 'CronController@getNullMediaListAndGetDetails');
    $router->get('/getTopLikersCron', 'CronController@getTopLikersCron');  //to update top likers details

    $router->get('/tem', 'CronController@tem');  //test
    $router->post('/scrapmediaTest', 'CronController@scrapmediaTest');  //test likers
    $router->post('/testss', 'InstaController@testsss');  //to update top likers details
    $router->post('/testNonfollowers', 'InstaController@testNonfollowers');  //to update top likers details

});
