<?php
$router->get('/', function () use ($router) {
    return $router->app->version();
});
//Routes for Authentication for GILR Users --Sibansankar
$router->POST('/gilr/register', 'GILR\AuthenticationController@userRegistration');
$router->POST('/gilr/user-activation', 'GILR\AuthenticationController@userActivation');
$router->POST('/gilr/login', 'GILR\AuthenticationController@userLogin');
$router->POST('/gilr/forget-password', 'GILR\AuthenticationController@forgetPassword');
$router->POST('/gilr/verify-otp', 'GILR\AuthenticationController@verifyOtp');
$router->POST('/gilr/reset-password', 'GILR\AuthenticationController@resetPassword');

$router->GET('/gilr/package-list', 'GILR\PackagesController@packageList');
$router->POST('/gilr/check-user-account', 'GILR\UserController@checkuserAccount');
$router->POST('/gilr/check-user-exist', 'GILR\UserController@usernameExist');
$router->POST('/gilr/media-details', 'GILR\UserController@getmediaDetails');               //get all media with their likes,comments,urls
$router->POST('/gilr/media-views', 'GILR\UserController@mediaViews');
$router->post('/gilr/package', 'GILR\PackagesController@package');  //get package acco. package_type
$router->post('/gilr/add-order', 'GILR\OrdersController@addOrder');

$router->get('/gilr/moduleDetailsGILR', 'GILR\UserController@moduleDetailsGILR');
$router->get('/gilr/ActivityTrackerSwitchGILR', 'GILR\UserController@ActivityTrackerSwitchGILR');


$router->post('/gilr/resend-otp-activation', 'GILR\AuthenticationController@resendOTPforActivation');
$router->post('/gilr/resend-otp-forget-pass', 'GILR\AuthenticationController@resendOTPforgetPassword');


$router->group(['middleware' => 'checkSession'], function () use ($router) {

    $router->POST('/gilr/ratedapp-free-package', 'GILR\UserController@ratedappPackage');  //checking status of free packages after rated APP
    $router->POST('/gilr/free-package', 'GILR\UserController@freepackage');
    $router->POST('/gilr/transaction-history', 'GILR\TransactionController@transactionHistory');
    $router->POST('/gilr/payment-history', 'GILR\TransactionController@paymentHistory');
    $router->POST('/gilr/order-place', 'GILR\OrdersController@orderPlacing');
    $router->POST('/gilr/place-order', 'GILR\OrdersController@placeOrders');
    $router->POST('/gilr/order-history', 'GILR\OrdersController@orderHistory');
    $router->POST('/gilr/logout', 'GILR\AuthenticationController@sessionDestroy');

    $router->POST('/gilr/rate-app', 'GILR\UserController@rateapp');

});