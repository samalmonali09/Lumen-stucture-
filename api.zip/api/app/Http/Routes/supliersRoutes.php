<?php
$router->get('/', function () use ($router) {
    return $router->app->version();
});
$router->post('/story-views', 'Supliers\SocialPanel24@storyViews');
$router->post('/live-video-views', 'Supliers\SocialPanel24@liveVideoViews');
