<?php

$router->group(['namespace' => 'AUTOIG', 'prefix' => 'autoig'], function ($router) {

    /*--------------------------------------------------------------------------
                        Routes for Authentication
     --------------------------------------------------------------------------*/
    $router->post('/signup', 'UserController@signup');
    $router->post('/resendOTP', 'UserController@resendOTP');
    $router->post('/activateAccount', 'UserController@activateAccount');
    $router->post('/login', 'UserController@login');
    $router->post('/recoverPassword', 'UserController@recoverPassword');
    $router->post('/resetPassword', 'UserController@resetPassword');
    $router->post('/profileDetails', 'UserController@profileDetails');
    $router->post('/updateProfile', 'UserController@updateProfile');
    $router->post('/updatePassword', 'UserController@updatePassword');
    $router->post('/changeAvatar', 'UserController@changeAvatar');
    $router->post('/contactUs', 'UserController@contactUs');
    $router->post('/ratedApp', 'UserController@ratedApp');
    $router->get('/switchModule', 'UserController@switchModule');
    $router->get('/GiftIcon', 'UserController@GiftIcon');
    $router->get('/moduleDetailsAUTOIG', 'UserController@moduleDetailsAUTOIG');
    $router->get('/ActivityTrackerSwitch', 'UserController@ActivityTrackerSwitch');
    $router->post('/AdBanner', 'UserController@AdBanner');




    /*--------------------------------------------------------------------------
                        Routes for Payment
    --------------------------------------------------------------------------*/
    $router->post('/packageLists', 'PaymentController@packageLists');
    $router->post('/oneTimeCheckout', 'PaymentController@oneTimeCheckout');

    
    /*--------------------------------------------------------------------------
                      Routes for Orders
    --------------------------------------------------------------------------*/
    $router->post('/verifyInstaUsername', 'OrderController@verifyInstaUsername');
    $router->post('/getAllMedia', 'OrderController@getAllMedia');
    $router->post('/getMediaDetails', 'OrderController@getMediaDetails');
    $router->post('/addOrder', 'OrderController@addOrder');
    $router->post('/placeOrder', 'OrderController@placeOrder');
    $router->post('/orderHistory', 'OrderController@orderHistory');
    $router->post('/commentLists', 'OrderController@commentLists');

    /*--------------------------------------------------------------------------
                    Routes for Subscriptions [Autolikes]
    --------------------------------------------------------------------------*/
    $router->post('/getSubscriptionPackages', 'AutolikesController@getSubscriptionPackages');
    $router->post('/addAutolikesOrder', 'AutolikesController@addAutolikesOrder');
    $router->post('/confirmPayment', 'AutolikesController@confirmPayment');
    $router->post('/subscriptionsHistory', 'AutolikesController@subscriptionsHistory');
    $router->post('/paymentDetails', 'AutolikesController@paymentDetails');
    $router->post('/changeUsername', 'AutolikesController@changeUsername');
    $router->post('/autolikesDashboard', 'AutolikesController@autolikesDashboard');
    $router->post('/autolikesChangeStatus', 'AutolikesController@autolikesChangeStatus');
    $router->get('/emergencyModule', 'AutolikesController@emergencyModule');
    $router->post('/emergencyOrder', 'AutolikesController@emergencyOrder');
    $router->post('/reactivateProfile', 'AutolikesController@reactivateProfile');
    $router->post('/getAddOnServiceDetails', 'AutolikesController@getAddOnServiceDetails');
    $router->post('/placeAddOnServiceOrder', 'AutolikesController@placeAddOnServiceOrder');
    $router->post('/storeAddOnServiceOrder', 'AutolikesController@storeAddOnServiceOrder');
    $router->post('/placeFreeAutolikes', 'AutolikesController@placeFreeAutolikes');
    $router->post('/dailyCounterDetails', 'AutolikesController@dailyCounterDetails');
    $router->post('/resetDailyCounter', 'AutolikesController@resetDailyCounter');
    $router->post('/getProfileDetails', 'AutolikesController@getProfileDetails');
    $router->post('/updateSplitSettings', 'AutolikesController@updateSplitSettings');
    $router->post('/ipnListener', 'AutolikesController@ipnListener');


    $router->post('/storeUserActivities', 'ActivityController@storeUserActivities');
    $router->post('/storeUserActivitiesAutoig', 'ActivityController@storeUserActivitiesAutoig');

    $router->get('/flashNews', 'OrderController@flashNews');
//    $router->get('/flashNewsNew', 'OrderController@flashNewsnNew');

    $router->get('/instant-likes-flash-news', 'OrderController@instantLikesFlashnews');


});
$router->get('/get-instant-likes/flash-news', 'AUTOIG\OrderController@getInstantLikesFlashnews');  // URL FOR ON GIL(ENGLISH)
