<?php

//$router->group(['namespace' => 'TrendingApp ', 'prefix' => 'TrendingApp'], function ($router) {
$router->get('/', function () use ($router) {
    return $router->app->version();
});
//    $router->get('/testing', 'TrendApp\UserController@AddBanner');

$router->post('/trendapp/ad-banner', 'TrendApp\UserController@adBanner');
$router->get('/trendapp/TrendingMessage', 'TrendApp\UserController@TrendingMessage');


//    $router->post('/TrendApp/AddBanner', 'TrendApp\UserController@AddBanner');


//});
