<?php

namespace App\Http\Middleware;

use Closure;
use Firebase\JWT\JWT;

class CheckSession
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request $request
     * @param  \Closure $next
     * @return mixed
     */
    public function handle($request, Closure $next)
    {
        if (!empty($request->header('access-token') or !empty($request->all()['access-token'])) ) {
            try {
                $access_token = ($request->header('access-token')) ? $request->header('access-token') : (($request->all()['access-token']) ? $request->all()['access-token'] : '');
                $key = env('JWT_KEY');
                $decoded = JWT::decode($access_token, $key, array('HS256'));     //  user details as a TOKEN
//                if ($decoded->iat < time() - 60 * 60 * 24) {
//                    echo json_encode(['code' => 504, 'status' => 'false', 'message' => 'Session Expired. Please Login Again']);
//                } else
                    return $next($request);
            } catch (\Exception $exc) {
                echo json_encode(['code' => 404, 'status' => 'false', 'message' => 'Please enter valid Token']);
            }
        } else {
            echo json_encode(['code' => 412, 'status' => 'false', 'message' => 'Please Enter  Token']);

        }

    }
}