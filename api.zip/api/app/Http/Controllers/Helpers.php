<?php

use Firebase\JWT\JWT;

/**
 * @date 29-01-2018
 * @dev Saurabh Kumar <saurabh.kumar@globussoft.com>
 */
function apiResponse($code, $msg, $err, $data)
{
    $data = [
        'code' => $code,
        'message' => $msg,
        'error' => $err,
        'data' => $data
    ];

    http_response_code($code);
//    echo response()->json($data, $code);
    echo json_encode($data, $code);
    die;
}

function generateAccessToken($data)
{
    return JWT::encode($data, env('JWT_KEY_SANDBOX'));
}
function AccessTokenforGive_Gilr($data)
{
    return JWT::encode($data, env('JWT_KEY'));
}

function parseAccessToken($token)
{
    try {
        $decoded = JWT::decode($token, env('JWT_KEY_SANDBOX'), array('HS256'));
        return json_decode(json_encode($decoded), true);
    } catch (Exception $e) {
        apiResponse(401, 'Unauthorized! Access token in not valid. Login required.', $e->getMessage(), null);
    }
}
function parseAccessTokenforGive_Gilr($token)
{
    try {
        $decoded = JWT::decode($token, env('JWT_KEY'), array('HS256'));
        return json_decode(json_encode($decoded), true);
    } catch (Exception $e) {
        apiResponse(401, 'Unauthorized! Access token in not valid. Login required.', $e->getMessage(), null);
    }
}

function sendEmailThroughMandrill($toEmail, $subject, $bodyContent)
{
    $mandrill = new Mandrill(env('MANDRILL_KEY'));
    $async = false;
    $ip_pool = 'Main Pool';
    $message = array(
        'html' => $bodyContent,
        'subject' => $subject,
        'from_email' => "support@messazon.com",
        'to' => array(
            array(
                'email' => $toEmail,
                'type' => 'to'
            )
        ),
        'merge_vars' => array(
            array(
                "rcpt" => $toEmail,
                'vars' => array()
            )
        ),
    );
    try {
        $mailResponse = $mandrill->messages->send($message, $async, $ip_pool);
    } catch (Exception $e) {
        apiResponse(400, 'Some error occurred in sending mail, try again.', 'Error in sending mail.', null);
    }
    return $mailResponse;
}

function getTemplates($templateFor, $data, $app = 'AUTOIG')
{
    $content = '';
    switch ($templateFor) {
        case 'registration':
            $content = '<div style="border: 1px solid #4A4A4A; border-radius: 10px; padding:30px; width:60%; margin-left: 20%; margin-right: 20%;" >
                            <div>
                                <a class="text-center" href="http://messazon.com/">
                                    <img src="' . env('WEB_URL') . '/assets/images/logo/' . strtolower($app) . '-logo.png" alt="' . $app . '" class="img-responsive" height="120" width="180" style="margin-left: 20%; margin-top: -3%;" />
                                </a>
                            </div>
                            <hr color="#5752A4">
                            <div style="padding-left:30px;">
                                Dear ' . strtoupper($data['username']) . ',<br>
                                    <p style="padding-left:12px;">You have successfully created an account in AUTOIG application. </p>Please enter the OTP in your application to verify your account.
                                    <br>
                                One Time Password is <u>' . $data['otp'] . '</u> .<br><br>
                                Use this credentials for further login <br>
                                Username :' . $data['username'] . '<br>
                                Password :' . $data['password'] . '<br>
                            <br><br>
                            <small style="color: #a08d8d;"><i>In case of any issues regarding account activation and application you can  <a href="mailto:proceedinteractive@gmail.com" target="_top">contact us here</a>.</i><small>
                            </div><br>
                            <hr color="#5752A4">
                            <font color = "#4A4A4A" > Regards, <br> ' . $app . ' Team <br> Contact : proceedinteractive@gmail.com </font>
                        </div>';
            break;
        case 'recoverPasswordOTP':
            $content = '<div style="border: 1px solid #4A4A4A; border-radius: 10px; padding:30px; width:60%; margin-left: 20%; margin-right: 20%;" >
                            <div>
                                <a class="text-center" href="http://messazon.com/">
                                    <img src="' . env('WEB_URL') . '/assets/images/logo/' . strtolower($app) . '-logo.png" alt="' . $app . '" class="img-responsive" height="120" width="180" style="margin-left: 20%; margin-top: -3%;" />
                                </a>
                            </div>
                            <hr color="#5752A4">
                            <div style="padding-left:30px;">
                                Hi ' . strtoupper($data['username']) . ',<br>
                                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Please use the following code to confirm your identity and reset your password. 
                                <br><b><u>' . $data['otp'] . '</u></b><br><br>
                                If this wasn\'t you, please ignore this message.
                            <br><br>
                            </div><br>
                            <hr color="#5752A4">
                            <font color = "#4A4A4A" > Regards <br> ' . $app . ' Team <br> Contact : proceedinteractive@gmail.com </font>
                        </div>';
            break;
        case 'passwordChanged':
            $content = '<div style="border: 1px solid #4A4A4A; border-radius: 10px; padding:30px; width:60%; margin-left: 20%; margin-right: 20%;" >
                            <div>
                                <a class="text-center" href="http://messazon.com/">
                                    <img src="' . env('WEB_URL') . '/assets/images/logo/' . strtolower($app) . '-logo.png" alt="' . $app . '" class="img-responsive" height="120" width="180" style="margin-left: 20%; margin-top: -3%;" />
                                </a>
                            </div>
                            <hr color="#5752A4">
                            <div style="padding-left:30px;">
                                Hi ' . strtoupper($data['username']) . ',<br>
                                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Your password has been changed recently, please use the new credentials for login. 
                                <br>
                                Email :' . $data['email'] . '<br>
                                Username :' . $data['username'] . '<br>
                                Password :' . $data['password'] . '<br>
                            <br><br>
                            </div><br>
                            <hr color="#5752A4">
                            <font color = "#4A4A4A" >Best Regards <br> ' . $app . ' Team <br> Contact : proceedinteractive@gmail.com </font>
                        </div>';
            break;
        case 'activateAccount':
            $content = '<div style="border: 1px solid #4A4A4A; border-radius: 10px; padding:30px; width:60%; margin-left: 20%; margin-right: 20%;" >
                            <div>
                                <a class="text-center" href="http://messazon.com/">
                                    <img src="' . env('WEB_URL') . '/assets/images/logo/' . strtolower($app) . '-logo.png" alt="' . $app . '" class="img-responsive" height="120" width="180" style="margin-left: 20%; margin-top: -3%;" />
                                </a>
                            </div>
                            <hr color="#5752A4">
                            <div style="padding-left:30px;">
                                Hi ' . strtoupper($data['username']) . ',<br>
                                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;You have successfully registered ' . convertRelativeTime($data['created_at']) . ', please activate account now.
                                <br>Your OTP to activate the account is <u>' . $data['otp'] . '</u><br><br>
                            </div><br>
                            <hr color="#5752A4">
                            <font color = "#4A4A4A" > Regards <br> ' . $app . ' Team <br> Contact : proceedinteractive@gmail.com </font>
                        </div>';
            break;
        case 'contactUs':
            $content = '<div style="border: 1px solid #4A4A4A; border-radius: 10px; padding:30px; width:60%; margin-left: 20%; margin-right: 20%;" >
                            <div>
                                <h4 style="text-align:center;">AUTOIG - Contact us</h4>
                               <table class="table table-bordered table-striped" >
                                <tbody>
                                <tr style="background-color: #f2f2f2;">
                                    <td style="width:25%;">
                                        Name
                                    </td>
                                   
                                    <td style="width:75%;">
                                        <span class="text-muted">
                                        '.$data['name'].'</span>
                                    </td>
                                </tr><tr>
                                    <td style="width:25%;">
                                        Email
                                    </td>
                                   
                                    <td style="width:75%;">
                                        <span class="text-muted">
                                        '.$data['email'].'</span>
                                    </td>
                                </tr><tr style="background-color: #f2f2f2;">
                                    <td style="width:25%;">
                                        Subject
                                    </td>
                                   
                                    <td style="width:75%;">
                                        <span class="text-muted">
                                        '.$data['subject'].'</span>
                                    </td>
                                </tr><tr>
                                    <td style="width:25%;">
                                        Message
                                    </td>
                                   
                                    <td style="width:75%;">
                                        <span class="text-muted">
                                        '.$data['message'].' </span>
                                    </td>
                                </tr>
                                </table>
                            </div>
                        </div>';
            break;


    }
    return $content;
}

/**
 * @param $unixTimestamp
 * @return false|string
 * @date 21-02-2018
 * @dev Saurabh Kumar <saurabh.kumar@globussoft.com>
 */
function convertRelativeTime($unixTimestamp)
{
    $difference = time() - $unixTimestamp;

    $timeArr = [
        'sec' => 60,
        'min' => 60,
        'hr' => 24,
        'day' => 7,
        'week' => 4,
        'month' => 12,
        'year' => 12, //upto 12 years.
    ];

    foreach ($timeArr as $key => $val) {
        if ($difference < $val)
            return $difference . ' ' . $key . ($difference > 1 ? 's' : '') . ' ago';

        $difference = round($difference / $val);
    }

    return date('d-m-Y H:i:s', $unixTimestamp); //Return the exact date if nothing found.
}

/**
 * @param $image
 * @return int
 * @date 21-02-2018
 * @dev Saurabh Kumar <saurabh.kumar@globussoft.com>
 */
function imageQuality($image)
{
    $imageSize = filesize($image) / (1024 * 1024);
    if ($imageSize < 0.5) {
        return 70;
    } elseif ($imageSize > 0.5 && $imageSize < 1) {
        return 60;
    } elseif ($imageSize > 1 && $imageSize < 2) {
        return 50;
    } elseif ($imageSize > 2 && $imageSize < 5) {
        return 40;
    } elseif ($imageSize > 5) {
        return 30;
    } else {
        return 50;
    }
}

/**
 * @desc :- This function will convert the large number to its proper notation likes million, billion
 * @param $number
 * @return string
 * @since :- 03 JULY 2018
 * @author :- saurabh Kumar <saurabh.kumar@globussoft.com>
 */
function convertNumberIntoProperNotation($number)
{

    $temp = str_replace(',', '', $number);

    if (!is_numeric($temp) || $temp < 1000) {
        return $number; //if it is not a number , dont do anything just return as it is.
    } else {
        $number = $temp;
    }

    $notationArr = [
//        1000000000000 => 'T',
        1000000000 => 'B',
        1000000 => 'M',
        1000 => 'K',
    ];

    foreach ($notationArr as $val => $str) {

        $num = ($number / $val);
        if (round($num, 2) >= 1) {

            if (round($num, 2) > 99 && $str !== 'B') {
                $newVal = $val * 1000;
                $num = $number / $newVal;
                $str = $notationArr[$newVal];
            }
            return floatval(number_format($num, 1)) . $str;
        }

    }

}

/**
 * @desc :- This function will convert the unix timestamp to proper date like 21st July 2018.
 * @param $number
 * @return string
 * @since :- 21st JULY 2018
 * @author :- saurabh Kumar <saurabh.kumar@globussoft.com>
 */
function convertTimestampToString($unixTimestamp)
{
    $date = date("d", $unixTimestamp);
    $unitDigit = $date % 10;
    $str = "th";
    if (in_array($date, range(11, 13))) {
        $str = "th";
    } else if ($unitDigit > 3) {
        $str = "th";
    } else if ($unitDigit == 1) {
        $str = "st";
    } else if ($unitDigit == 2) {
        $str = "nd";
    } else if ($unitDigit == 3) {
        $str = "rd";
    }
    return $date . $str . date(" M Y", $unixTimestamp);
}

function sendEmailThroughSendgrid($toEmail, $subject, $bodyContent)
{
    $from = new \SendGrid\Email(null, '007.saurabh.1234@gmail.com');
    $subject = $subject;
    $to = new \SendGrid\Email(null, $toEmail);
    $content = new \SendGrid\Content("text/html", $bodyContent);
    $mail = new \SendGrid\Mail($from, $subject, $to, $content);
    $apiKey = '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';
    $sg = new \SendGrid($apiKey);
    $response = $sg->client->mail()->send()->post($mail);
    if ($response->statusCode() == 202) {
        return 1;
    } else {
        return 0;
    }
}

function getTemplates1($templateFor, $data, $for_site, $module)
{
    $content = '';
    switch ($templateFor) {
        case 'registration':
            $content = '<style>
    body {
        padding: 0;
        margin: 0;
    }
    
    html {
        -webkit-text-size-adjust: none;
        -ms-text-size-adjust: none;
    }
    
    @media only screen and (max-device-width: 680px),
    only screen and (max-width: 680px) {
        *[class="table_width_100"] {
            width: 96% !important;
        }
        *[class="border-right_mob"] {
            border-right: 1px solid #dddddd;
        }
        *[class="mob_100"] {
            width: 100% !important;
        }
        *[class="mob_center"] {
            text-align: center !important;
        }
        *[class="mob_center_bl"] {
            float: none !important;
            display: block !important;
            margin: 0px auto;
        }
        .iage_footer a {
            text-decoration: none;
            color: #929ca8;
        }
        img.mob_display_none {
            width: 0px !important;
            height: 0px !important;
            display: none !important;
        }
        img.mob_width_50 {
            width: 40% !important;
            height: auto !important;
        }
    }
    
    .table_width_100 {
        width: 680px;
    }
</style>



<div id="mailsub" class="notification" align="center">

    <table width="100%" border="0" cellspacing="0" cellpadding="0" style="min-width: 320px; height: 100%;">
        <tr>
            <td align="center" bgcolor="#eff3f8">

                <table border="0" cellspacing="0" cellpadding="0" class="table_width_100" width="100%" style="max-width: 680px;min-width: 300px;width: 680px;">
                    <tr>
                        <td>
                            <!-- padding -->
                        </td>
                    </tr>
                    <!--header -->
                    <tr>
                        <td align="center" bgcolor="#ffffff">
                            <!-- padding -->
                            <table width="90%" border="0" cellspacing="0" cellpadding="0">
                                <div style="height: 30px; line-height: 30px; font-size: 10px;"></div>
                                <tr>
                                    <td align="center">
                                        <a href="#" target="_blank" style="color: #596167; font-family: Arial, Helvetica, sans-serif; float:left; width:100%; padding:20px;text-align:center; font-size: 13px;">
                                           
									<img src="' . env('APP_URL') . '/' . $module . '" width="120" style="width: 320px" border="0"></a>
                                    </td>
                                    <td align="right">
                      
                                    </td>
                                </tr>
                                <!--header END-->

                                <!--content 1 -->
                                <tr>
                                    <td align="center" bgcolor="#fbfcfd">
                                        <table width="90%" border="0" cellspacing="0" cellpadding="0">
                                            <tr>
                                                <td align="center">
                                                    <!-- padding -->
<!--                                                    <div style="height: 60px; line-height: 60px; font-size: 10px;"></div>-->
                                                    <div style="line-height: 44px;">
                                                        <font face="Arial, Helvetica, sans-serif" size="5" color="#57697e" style="font-size: 20px;">
					<span style="font-family: Arial, Helvetica, sans-serif; font-size: 20px; color: #57697e;">
					Hi <Username>,
You have Successfully created an Account in ' . $for_site . ' application. 
Please Enter the  OTP in your Application to verify your account.<br>

 One Time Password is 


					</span></font>
                                                    </div>
                                                    <!-- padding -->
                                                    <div style="height: 40px; line-height: 40px; font-size: 10px;"></div>
                                                </td>
                                            </tr>
                                             <tr>
                                                <td align="center">
                                                    <div style="width: auto;font-family: Arial, Helvetica, sans-serif;font-size: 30px;border: 1px solid #0ab497;padding: 10px 20px;">
                                                       
					                                         <b style="color:#4B0082 ">' . $data . '</b>
					
                                                    </div>
                                                    <!-- padding -->
                                                    <div style="height: 60px; line-height: 60px; font-size: 10px;"></div>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td align="center">
                                                    <div style="line-height: 24px;">
                                                        <font face="Arial, Helvetica, sans-serif" size="4" color="#57697e" style="font-size: 15px;">
					<span style="font-family: Arial, Helvetica, sans-serif; font-size: 14px; color: #57697e;">
In case of any issues regarding account activation and application you can contact us in <b>proceedinteractive@gmail.com.</b><br>

					</span></font>

                                                    </div>
                                                    <hr>

<div style="line-height: 24px;font-family: Arial, Helvetica, sans-serif; font-size: 12px; color: #57697e;text-align: left">
  <b>Regards,</b><br>
Proceed Interactive Team
</div>
                                                    <!-- padding -->
                                                </td>
                                            </tr>
                                           

                                          
                                        </table>
                                    </td>
                                </tr>


                            </table>
                            <!--[if gte mso 10]>
</td></tr>s
</table>
<![endif]-->

                        </td>
                    </tr>
                </table>
            </td>
        </tr>
    </table>
</div>';
            break;
        case 'forgetPassword':
            $content = '<style>
    body {
        padding: 0;
        margin: 0;
    }
    
    html {
        -webkit-text-size-adjust: none;
        -ms-text-size-adjust: none;
    }
    
    @media only screen and (max-device-width: 680px),
    only screen and (max-width: 680px) {
        *[class="table_width_100"] {
            width: 96% !important;
        }
        *[class="border-right_mob"] {
            border-right: 1px solid #dddddd;
        }
        *[class="mob_100"] {
            width: 100% !important;
        }
        *[class="mob_center"] {
            text-align: center !important;
        }
        *[class="mob_center_bl"] {
            float: none !important;
            display: block !important;
            margin: 0px auto;
        }
        .iage_footer a {
            text-decoration: none;
            color: #929ca8;
        }
        img.mob_display_none {
            width: 0px !important;
            height: 0px !important;
            display: none !important;
        }
        img.mob_width_50 {
            width: 40% !important;
            height: auto !important;
        }
    }
    
    .table_width_100 {
        width: 680px;
    }
</style>



<div id="mailsub" class="notification" align="center">

    <table width="100%" border="0" cellspacing="0" cellpadding="0" style="min-width: 320px; height: 100%;">
        <tr>
            <td align="center" bgcolor="#eff3f8">

                <table border="0" cellspacing="0" cellpadding="0" class="table_width_100" width="100%" style="max-width: 680px;min-width: 300px;width: 680px;">
                    <tr>
                        <td>
                            <!-- padding -->
                        </td>
                    </tr>
                    <!--header -->
                    <tr>
                        <td align="center" bgcolor="#ffffff">
                            <!-- padding -->
                            <table width="90%" border="0" cellspacing="0" cellpadding="0">
                                <div style="height: 30px; line-height: 30px; font-size: 10px;"></div>
                                <tr>
                                    <td align="center">
                                        <a href="#" target="_blank" style="color: #596167; font-family: Arial, Helvetica, sans-serif; float:left; width:100%; padding:20px;text-align:center; font-size: 13px;">
                                           
									<img src="' . env('APP_URL') . '/' . $module . '" width="120" style="width: 320px" border="0"></a>
                                    </td>
                                    <td align="right">
                      
                                    </td>
                                </tr>
                                <!--header END-->

                                <!--content 1 -->
                                <tr>
                                    <td align="center" bgcolor="#fbfcfd">
                                        <table width="90%" border="0" cellspacing="0" cellpadding="0">
                                            <tr>
                                                <td align="center">
                                                    <!-- padding -->
<!--                                                    <div style="height: 60px; line-height: 60px; font-size: 10px;"></div>-->
                                                    <div style="line-height: 44px;">
                                                        <font face="Arial, Helvetica, sans-serif" size="5" color="#57697e" style="font-size: 20px;">
					<span style="font-family: Arial, Helvetica, sans-serif; font-size: 20px; color: #57697e;">
					Hi <Username>,
					Please use the following code to confirm your identity and reset your password for ' . $for_site . '.
<br>

 One Time OTP is 


					</span></font>
                                                    </div>
                                                    <!-- padding -->
                                                    <div style="height: 40px; line-height: 40px; font-size: 10px;"></div>
                                                </td>
                                            </tr>
                                             <tr>
                                                <td align="center">
                                                    <div style="width: auto;font-family: Arial, Helvetica, sans-serif;font-size: 30px;border: 1px solid #0ab497;padding: 10px 20px;">
                                                       
					                                         <b style="color:#4B0082 ">' . $data . '</b>
					
                                                    </div>
                                                    <!-- padding -->
                                                    <div style="height: 60px; line-height: 60px; font-size: 10px;"></div>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td align="center">
                                                    <div style="line-height: 24px;">
                                                        <font face="Arial, Helvetica, sans-serif" size="4" color="#57697e" style="font-size: 15px;">
					<span style="font-family: Arial, Helvetica, sans-serif; font-size: 14px; color: #57697e;">
In case of any issues regarding account activation and application you can contact us in <b>proceedinteractive@gmail.com.</b><br>

					</span></font>

                                                    </div>
                                                    <hr>

<div style="line-height: 24px;font-family: Arial, Helvetica, sans-serif; font-size: 12px; color: #57697e;text-align: left">
  <b>Regards,</b><br>
Proceed Interactive Team
</div>
                                                    <!-- padding -->
                                                </td>
                                            </tr>
                                           

                                          
                                        </table>
                                    </td>
                                </tr>


                            </table>
                            <!--[if gte mso 10]>
</td></tr>s
</table>
<![endif]-->

                        </td>
                    </tr>
                </table>
            </td>
        </tr>
    </table>
</div>';
            break;

        case 'recoverPasswordOTP':

            $content = '<div style="border: 1px solid #4A4A4A; border-radius: 10px; padding:30px; width:60%; margin-left: 20%; margin-right: 20%;" >
                            <div>
                                <a class="text-center" href="http://messazon.com/">
                                    <img src="http://messazonclone.localhost.com/assets/images/give.png" class="img-responsive" alt="logo" height="50px" width="250px" style="margin-left: 15%; margin-top: -1%;" />
                                </a>
                            </div>
                            <hr color="#4A4A4A">
                            <div style="padding-left:30px;">
                                Hi ' . strtoupper($data['firstname']) . ',<br>
                                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Please use the following code to confirm your identity and reset your password. 
                                <br><b><u>' . $data['otp'] . '</u></b><br><br>
                                If this wasn\'t you, please ignore this message.
                            <br><br>
                            </div><br>
                            <hr color="#4A4A4A">
                            <font color = "#4A4A4A" > Regards <br> ' . strtoupper($module) . ' Team <br> Contact : support@messazon.com </font>
                        </div>';
            break;
        case 'passwordChanged':

            $content = '<div style="border: 1px solid #4A4A4A; border-radius: 10px; padding:30px; width:60%; margin-left: 20%; margin-right: 20%;" >
                            <div>
                                <a class="text-center" href="http://messazon.com/">
                                    <img src="http://igautolikes.globusapps.com/images/autoig_logo.png" alt="AUTOIG" class="img-responsive" alt="logo" height="50px" width="250px" style="margin-left: 15%; margin-top: -1%;" />
                                </a>
                            </div>
                            <hr color="#4A4A4A">
                            <div style="padding-left:30px;">
                                Hi ' . strtoupper($data['firstname']) . ',<br>
                                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Your password has been changed recently, please use the new credentials for login. 
                                <br>
                                Email :' . $data['email'] . '<br>
                                Password :' . $data['password'] . '<br>
                            <br><br>
                            </div><br>
                            <hr color="#4A4A4A">
                            <font color = "#4A4A4A" >Best Regards <br> AUTOIG Team <br> Contact : support@messazon.com </font>
                        </div>';
            break;


    }
    return $content;
}

function instaResponse($code, $msg, $err, $data)
{
    $data = [
        'code' => $code,
        'message' => $msg,
        'error' => $err,
        'data' => $data
    ];

//    http_response_code($code);
    return $data;
}

if (!function_exists('print_a')) {
    /**
     * Print human-readable information about a variable and stop execution(die)
     * @param $data
     * @since 08-02-2016
     */
    function print_a($data)
    {
        echo '<pre>';
        for ($i = 0; $i < func_num_args(); $i++)
            print_r(func_get_arg($i));
        print_r('<br>');
        die;
    }
}

function extractStr($str, $start)
{
    $newStr = substr($str, strpos($str, $start));
    $newStr = substr($newStr, strlen($start));
    $newStr = substr($newStr, 0, strlen($str));
    return trim($newStr);
}

