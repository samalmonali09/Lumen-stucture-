<?php namespace App\Http\Controllers\InstagramScrape;

use Illuminate\Support\Facades\DB;

class InstagramScrapeController
{


    /**
     * @Desc fetch users post details
     * @param $shortCode
     * @return array
     * @since 24 jan 2018
     * @author Sibasankar Bhoi (sibasankarbhoi@globussoft.in)
     */
    public function instagramLinkDetails($shortCode)
    {
        $url = 'https://www.instagram.com/p/' . $shortCode . '/?__a=1';
        $result = $this->instaCurlHitGet($url);
        $postDetails = $result;
        if ($postDetails['graphql']['shortcode_media']['owner']['is_private'] == false) {
            $mediaDetailsArr = [];
            $mediaDetailsArr['comments_count'] = $postDetails['graphql']['shortcode_media']['edge_media_to_comment']['count'];
            $mediaDetailsArr['likes_count'] = $postDetails['graphql']['shortcode_media']['edge_media_preview_like']['count'];
            $mediaDetailsArr['is_video'] = $postDetails['graphql']['shortcode_media']['is_video'];
            if ($mediaDetailsArr["is_video"] == true) {
                $mediaDetailsArr['views_count'] = $postDetails['graphql']['shortcode_media']['video_view_count'];

            }
            return $mediaDetailsArr;
        } else {
            echo json_encode(['code' => 401, 'status' => 'false', 'message' => 'User Account is private']);
            die;
        }
    }

    /**
     * @Desc fetch users profile details
     * @Class instagramProfileDetails
     * @param $username
     * @return array
     * @since 24 jan 2018
     * @author Sibasankar Bhoi (sibasankarbhoi@globussoft.in)
     */
    public function instagramProfileDetails($username)
    {
        $url = 'https://www.instagram.com/' . $username . '/?__a=1';

        $data = $this->instaCurlHitGet($url);

        if (!empty($data)) {

            if ($data['graphql']['user']['is_private'] == false) {
                $profileDetailsArr = [];
                $profileDetailsArr['id'] = $data['graphql']['user']['id'];
                $profileDetailsArr['name'] = $data['graphql']['user']['full_name'];
                $profileDetailsArr['followed_by'] = $data['graphql']['user']['edge_followed_by']['count'];
                $profileDetailsArr['follows'] = $data['graphql']['user']['edge_follow']['count'];
                $profileDetailsArr['postCount'] = $data['graphql']['user']['edge_owner_to_timeline_media']['count'];
                $profileDetailsArr['profile_pic_url'] = $data['graphql']['user']['profile_pic_url_hd'];
                return $profileDetailsArr;
            } else {
                apiResponse(400, 'Account is private.', 'Private account.', null);
            }
        } else {
            apiResponse(400, 'Username doesn\'t exist.', 'No results found.', null);
        }

    }

    /**
     * @desc To get all media of insta user based on endCount(length)
     * @param $username , int $length, string $postType
     * @return array
     * @date 21-03-2018
     * @dev Saurabh Kumar <saurabh.kumar@globussoft.com>
     */
    public function getAllMedia($username, $length = 12, $postType = 'both')
    {

        $url = 'https://www.instagram.com/' . $username . '/?__a=1';

        $has_next_page = false;
        $end_cursor = '';
        $id = '';
        $first = 24;
        $mainStr = 'graphql';
        $mediaDetails = [];

        $count = 0;
        $exit = false;

        do {

            if (($has_next_page == true) && ($end_cursor != '')) {
                $url = 'https://www.instagram.com/graphql/query/?query_hash=472f257a40c653c64c666ce877d59d2b&variables={%22id%22%3A%22' . $id . '%22%2C%22first%22%3A' . $first . '%2C%22after%22%3A%22' . $end_cursor . '%22}';
                $mainStr = 'data';
            }

            $details = $this->instaCurlHitGet($url);
            dd(json_encode($details));

            if (!empty($details)) {

                if ((isset($details[$mainStr]['user']["is_private"]) && $details[$mainStr]['user']["is_private"] == false) || (!empty($details['data']['user']['edge_owner_to_timeline_media']['edges']))) {
                    $has_next_page = $details[$mainStr]['user']['edge_owner_to_timeline_media']['page_info']['has_next_page'];
                    $end_cursor = $details[$mainStr]['user']['edge_owner_to_timeline_media']['page_info']['end_cursor'];
                    $id = ($mainStr == 'graphql') ? $details[$mainStr]['user']['id'] : $id;

                    $media = $details[$mainStr]['user']['edge_owner_to_timeline_media']['edges'];

                    foreach ($media as $key => $val) {

                        if ($postType == 'video') {

                            if ($val['node']['is_video'] == true) {

                                $mediaDetails['media'][$count]['link'] = 'https://www.instagram.com/p/' . $val['node']['shortcode'];
                                $mediaDetails['media'][$count]['display_url'] = $val['node']['display_url'];
                                $mediaDetails['media'][$count]['like_count'] = $val['node']['edge_media_preview_like']['count'];
                                $mediaDetails['media'][$count]['comment_count'] = $val['node']['edge_media_to_comment']['count'];
                                $mediaDetails['media'][$count]['is_video'] = $val['node']['is_video'];
                                $mediaDetails['media'][$count]['view_count'] = ($val['node']['is_video']) ? $val['node']['video_view_count'] : 0;

                                ++$count;
                                if ($count == $length) {
                                    $exit = true;
                                    break;
                                }
                            }
                        }
                    }
                    if ($exit == true)
                        break;


//                echo '<pre>';
//                print_r($mediaDetails);
//                die;
//
//                switch ($postType) {
//                    case 'image':
//
//                }

                } else {
                    apiResponse(400, 'Account is private.', 'Private account.', null);
                }
            } else
                apiResponse(400, 'Username doesn\'t exists.', 'No results found.', null);

        } while (($has_next_page != false) && ($end_cursor != ''));

        $mediaDetails['has_next_page'] = $has_next_page;
        $mediaDetails['end_cursor'] = $end_cursor;
        $mediaDetails['id'] = $id;
        return $mediaDetails;

    }

    public function getInstagramMediaMain($id, $length, $end_cursor, $postType = 'image')
    {

        $has_next_page = false;

        do {

            $url = 'https://www.instagram.com/graphql/query/?query_hash=472f257a40c653c64c666ce877d59d2b&variables={%22id%22%3A%22' . $id . '%22%2C%22first%22%3A' . $length . '%2C%22after%22%3A%22' . $end_cursor . '%22}';
            $details = $this->instaCurlHitGet($url);

            if (!empty($details)) {

                if (!empty($details['data']['user'])) {

                    if (!empty($details['data']['user']['edge_owner_to_timeline_media']['edges'])) {
                        $mediaDetails = [];
                        $has_next_page = $details['data']['user']['edge_owner_to_timeline_media']['page_info']['has_next_page'];
                        $end_cursor = $details['data']['user']['edge_owner_to_timeline_media']['page_info']['end_cursor'];
                        $mediaDetails['has_next_page'] = $details['data']['user']['edge_owner_to_timeline_media']['page_info']['has_next_page'];
                        $mediaDetails['end_cursor'] = $details['data']['user']['edge_owner_to_timeline_media']['page_info']['end_cursor'];
                        $mediaDetails['post_count'] = $details['data']['user']['edge_owner_to_timeline_media']['count'];
                        $mediaDetails['id'] = $id;

                        $media = $details['data']['user']['edge_owner_to_timeline_media']['edges'];

                        foreach ($media as $key => $val) {
                            if ($postType == 'video') {
                                if ($val['node']['is_video'] == true) {
                                    $mediaDetails['media'][$key]['link'] = 'https://www.instagram.com/p/' . $val['node']['shortcode'];
                                    $mediaDetails['media'][$key]['display_url'] = $val['node']['display_url'];
                                    $mediaDetails['media'][$key]['like_count'] = $val['node']['edge_media_preview_like']['count'];
                                    $mediaDetails['media'][$key]['comment_count'] = $val['node']['edge_media_to_comment']['count'];
                                    $mediaDetails['media'][$key]['is_video'] = $val['node']['is_video'];
                                    $mediaDetails['media'][$key]['view_count'] = ($val['node']['is_video']) ? $val['node']['video_view_count'] : 0;
                                    $mediaDetails['media'][$key]['order_token'] = generateAccessToken($mediaDetails['media'][$key]);

                                }
                            } else {
                                $mediaDetails['media'][$key]['link'] = 'https://www.instagram.com/p/' . $val['node']['shortcode'];
                                $mediaDetails['media'][$key]['display_url'] = $val['node']['display_url'];
                                $mediaDetails['media'][$key]['like_count'] = $val['node']['edge_media_preview_like']['count'];
                                $mediaDetails['media'][$key]['comment_count'] = $val['node']['edge_media_to_comment']['count'];
                                $mediaDetails['media'][$key]['is_video'] = $val['node']['is_video'];
                                $mediaDetails['media'][$key]['view_count'] = ($val['node']['is_video']) ? $val['node']['video_view_count'] : 0;
                                $mediaDetails['media'][$key]['order_token'] = generateAccessToken($mediaDetails['media'][$key]);
                            }
                        }


                        return $mediaDetails;

                    } else
                        apiResponse(400, 'Account may be private.', 'Private account.', null);
                } else {
                    apiResponse(400, 'Insta id is not valid.', 'Invalid id.', null);
                }
            } else
                apiResponse(400, 'Something went wrong, please try after sometime.', 'No results found.', null);
        } while (($has_next_page != false) && ($end_cursor != ''));
    }

    public function getInstagramMedia($id, $length, $end_cursor, $postType = 'both')
    {
        $has_next_page = false;
        $count = 0;
        $exit = false;
        $first = 24;
        $mediaDetails = [];

        do {

            $url = 'https://www.instagram.com/graphql/query/?query_hash=472f257a40c653c64c666ce877d59d2b&variables={%22id%22%3A%22' . $id . '%22%2C%22first%22%3A' . $first . '%2C%22after%22%3A%22' . $end_cursor . '%22}';
            $details = $this->instaCurlHitGet($url);

            if (!empty($details)) {

                if (!empty($details['data']['user'])) {

                    if (!empty($details['data']['user']['edge_owner_to_timeline_media']['edges'])) {

                        $has_next_page = $details['data']['user']['edge_owner_to_timeline_media']['page_info']['has_next_page'];
                        $end_cursor = $details['data']['user']['edge_owner_to_timeline_media']['page_info']['end_cursor'];

                        $media = $details['data']['user']['edge_owner_to_timeline_media']['edges'];

                        foreach ($media as $key => $val) {
                            if ($postType == 'video') {
                                if ($val['node']['is_video'] == true) {

                                    $mediaDetails['media'][$count]['link'] = 'https://www.instagram.com/p/' . $val['node']['shortcode'];
                                    $mediaDetails['media'][$count]['display_url'] = $val['node']['display_url'];
                                    $mediaDetails['media'][$count]['like_count'] = $val['node']['edge_media_preview_like']['count'];
                                    $mediaDetails['media'][$count]['comment_count'] = $val['node']['edge_media_to_comment']['count'];
                                    $mediaDetails['media'][$count]['is_video'] = $val['node']['is_video'];
                                    $mediaDetails['media'][$count]['view_count'] = ($val['node']['is_video']) ? $val['node']['video_view_count'] : 0;
                                    $mediaDetails['media'][$count]['order_token'] = generateAccessToken($mediaDetails['media'][$count]);

                                    ++$count;

                                }
                            } else {
                                $mediaDetails['media'][$count]['link'] = 'https://www.instagram.com/p/' . $val['node']['shortcode'];
                                $mediaDetails['media'][$count]['display_url'] = $val['node']['display_url'];
                                $mediaDetails['media'][$count]['like_count'] = $val['node']['edge_media_preview_like']['count'];
                                $mediaDetails['media'][$count]['comment_count'] = $val['node']['edge_media_to_comment']['count'];
                                $mediaDetails['media'][$count]['is_video'] = $val['node']['is_video'];
                                $mediaDetails['media'][$count]['view_count'] = ($val['node']['is_video']) ? $val['node']['video_view_count'] : 0;
                                $mediaDetails['media'][$count]['order_token'] = generateAccessToken($mediaDetails['media'][$count]);

                                ++$count;

                            }

                            if ($count == $length) {
                                $exit = true;
                                break;
                            }

                        }

                        if ($exit == true)
                            break;

                    } else
                        apiResponse(400, 'Account may be private.', 'Private account.', null);
                } else {
                    apiResponse(400, 'Insta id is not valid.', 'Invalid id.', null);
                }
            } else
                apiResponse(400, 'Something went wrong, please try after sometime.', 'No results found.', null);
        } while (($has_next_page != false) && ($end_cursor != ''));

        $mediaDetails['has_next_page'] = $has_next_page;
        $mediaDetails['end_cursor'] = ($mediaDetails['has_next_page']) ? $end_cursor : null;
        $mediaDetails['id'] = $id;
        return $mediaDetails;

    }


    /**
     * @Desc fetch data from IG url
     * @Class instaCurlHitGet
     * @param $url
     * @return mixed|null
     * @since 24 jan 2018
     * @author Sibasankar Bhoi (sibasankarbhoi@globussoft.in)
     */
    public function instaCurlHitGet($url)
    {
        //TODO Hit instagram with proxies;
        $ch = curl_init();

        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_HEADER, false);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, array('Cookie: ig_pr=1;'));

        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
        curl_setopt($ch, CURLOPT_VERBOSE, 1);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 120);
        curl_setopt($ch, CURLOPT_TIMEOUT, 120);

        $result = curl_exec($ch);
        if (curl_errno($ch) > 0) {
            print_r(curl_error($ch));
        }
        curl_close($ch);
        return ($result) ? json_decode($result, true) : null;

    }

    public function extractContent($string, $startIndex, $endIndex)
    {
        $str = substr($string, strpos($string, $startIndex));
        if (isset($endIndex))
            $str = (substr($str, strlen($startIndex)));
        $extractedStr = substr($str, 0, strpos($str, $endIndex));
        return trim($extractedStr);
    }

}