<?php
/**
 * Created by PhpStorm.
 * User: GLB-131
 * Date: 11/1/2018
 * Time: 3:59 PM
 */

namespace App\Http\Controllers\GIVR;

use App\Http\Models\DBClass;
use Illuminate\Support\Facades\Validator;
use Illuminate\Validation\Rule;
use Laravel\Lumen\Routing\Controller;
use Illuminate\Http\Request;

class ActivityController
{
    protected $_db;

    public function __construct()
    {
        $this->_db = DBClass::getInstance();
    }

    public function insertUserActivities1(Request $request){
        $validator = Validator::make($request->all(), [
            'message' => 'required'
        ]);
        if (!$validator->fails()) {
            $postParams = $request->all();

            $validParams = ['device_id', 'user_id', 'message', 'email', 'username'];
            $wrongParams = array_diff(array_keys($postParams), $validParams);
            if (empty($wrongParams)) {
                $message = json_decode($postParams['message'], true);
                $message = array_reverse($message);
                unset($postParams['message']);
                if (!empty($message) && is_array($message)) {

                    if (isset($postParams['device_id']) && trim($postParams['device_id']) != "") {

                        $activities = $this->_db->selectQuery('activities_givr', ['rawQuery' => 'device_id = ?', 'bindParams' => [$postParams['device_id']]]);

                        if (empty($activities)) {
                            /* Insert */
                            $dataToInsert = array_merge($postParams, ['message' => json_encode($message), 'created_at' => time(), 'updated_at' => time()]);
                            $inserted = $this->_db->insert('activities_givr', $dataToInsert);
                            if ($inserted)
                                apiResponse(200, 'Activity has been recorded', null, $inserted);
                            else
                                apiResponse(400, 'Something went wrong.', null, null);
                        } else {
                            $activities = $activities[0];
                            $prevMsg = json_decode($activities['message'], true);
                            $message = array_merge($message, $prevMsg);
                            if (count($message) > 2000) {
                                $message = array_slice($message, 0, 2000);
                            }
                            $dataToUpdate = array_merge($postParams, ['message' => json_encode($message), 'updated_at' => time()]);
                            $updated = $this->_db->updateQuery('activities_givr', ['rawQuery' => 'device_id = ?', 'bindParams' => [$postParams['device_id']]], $dataToUpdate);
                            if ($updated)
                                apiResponse(200, 'Activity has been recorded', null, null);
                            else
                                apiResponse(400, 'Something went wrong.', null, null);
                        }
                    } else if (isset($postParams['user_id']) && trim($postParams['user_id']) != "") {

                        $activities = $this->_db->selectQuery('activities_givr', ['rawQuery' => 'user_id = ?', 'bindParams' => [$postParams['user_id']]]);

                        if (empty($activities)) {
                            /* Insert */
                            unset($postParams['message']);
                            $dataToInsert = array_merge($postParams, ['message' => json_encode($message), 'created_at' => time(), 'updated_at' => time()]);
                            $inserted = $this->_db->insert('activities_givr', $dataToInsert);
                            if ($inserted)
                                apiResponse(200, 'Activity has been recorded', null, $inserted);
                            else
                                apiResponse(400, 'Something went wrong.', null, null);
                        } else {
                            $activities = $activities[0];
                            $prevMsg = json_decode($activities['message'], true);
                            $message = array_merge($message, $prevMsg);
                            if (count($message) > 2000) {
                                $message = array_slice($message, 0, 2000);
                            }
                            $dataToUpdate = array_merge($postParams, ['message' => json_encode($message), 'updated_at' => time()]);
                            $updated = $this->_db->updateQuery('activities_givr', ['rawQuery' => 'user_id = ?', 'bindParams' => [$postParams['user_id']]], $dataToUpdate);
                            if ($updated)
                                apiResponse(200, 'Activity has been recorded', null, null);
                            else
                                apiResponse(400, 'Something went wrong.', null, null);
                        }
                    } else {
                        /* Insert */
                        $dataToInsert = array_merge($postParams, ['message' => json_encode($message), 'created_at' => time(), 'updated_at' => time()]);
                        $inserted = $this->_db->insert('activities_givr', $dataToInsert);
                        if ($inserted)
                            apiResponse(200, 'Activity has been recorded', null, $inserted);
                        else
                            apiResponse(400, 'Something went wrong.', null, null);
                    }

                } else
                    apiResponse(400, 'Сообщения пустые или нет в надлежащем формате.', null, null);


            } else {
                apiResponse(400, reset($wrongParams) . ' is a wrong param, please correct it.', 'wrong param', null);
            }

        } else {
            $errMsg = json_decode($validator->messages(), true);
            apiResponse(412, array_values($errMsg)[0][0], 'Validation error', null);
        }

    }

    public function insertUserActivities(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'message' => 'required'
        ]);
        if (!$validator->fails()) {
            $postParams = $request->all();

            $validParams = ['device_id', 'user_id', 'message', 'email', 'username'];
            $wrongParams = array_diff(array_keys($postParams), $validParams);
            if (empty($wrongParams)) {
                $message = json_decode($postParams['message'], true);
                $message = array_reverse($message);
                unset($postParams['message']);
                if (!empty($message) && is_array($message)) {

                    if (isset($postParams['device_id']) && trim($postParams['device_id']) != "") {

                        $activities = $this->_db->selectQuery('activities_givr', ['rawQuery' => 'device_id = ?', 'bindParams' => [$postParams['device_id']]]);

                        if (empty($activities)) {
                            /* Insert */
                            $dataToInsert = array_merge($postParams, ['message' => json_encode($message), 'created_at' => time(), 'updated_at' => time()]);
                            $inserted = $this->_db->insert('activities_givr', $dataToInsert);
                            if ($inserted)
                                apiResponse(200, 'Activity has been recorded', null, $inserted);
                            else
                                apiResponse(400, 'Something went wrong.', null, null);
                        } else {
                            $activities = $activities[0];
                            $prevMsg = json_decode($activities['message'], true);
                            $message = array_merge($message, $prevMsg);
                            if (count($message) > 2000) {
                                $message = array_slice($message, 0, 2000);
                            }
                            $dataToUpdate = array_merge($postParams, ['message' => json_encode($message), 'updated_at' => time()]);
                            $updated = $this->_db->updateQuery('activities_givr', ['rawQuery' => 'device_id = ?', 'bindParams' => [$postParams['device_id']]], $dataToUpdate);
                            if ($updated)
                                apiResponse(200, 'Activity has been recorded', null, null);
                            else
                                apiResponse(400, 'Something went wrong.', null, null);
                        }
                    } else if (isset($postParams['user_id']) && trim($postParams['user_id']) != "") {

                        $activities = $this->_db->selectQuery('activities_givr', ['rawQuery' => 'user_id = ?', 'bindParams' => [$postParams['user_id']]]);

                        if (empty($activities)) {
                            /* Insert */
                            unset($postParams['message']);
                            $dataToInsert = array_merge($postParams, ['message' => json_encode($message), 'created_at' => time(), 'updated_at' => time()]);
                            $inserted = $this->_db->insert('activities_givr', $dataToInsert);
                            if ($inserted)
                                apiResponse(200, 'Activity has been recorded', null, $inserted);
                            else
                                apiResponse(400, 'Something went wrong.', null, null);
                        } else {
                            $activities = $activities[0];
                            $prevMsg = json_decode($activities['message'], true);
                            $message = array_merge($message, $prevMsg);
                            if (count($message) > 2000) {
                                $message = array_slice($message, 0, 2000);
                            }
                            $dataToUpdate = array_merge($postParams, ['message' => json_encode($message), 'updated_at' => time()]);
                            $updated = $this->_db->updateQuery('activities_givr', ['rawQuery' => 'user_id = ?', 'bindParams' => [$postParams['user_id']]], $dataToUpdate);
                            if ($updated)
                                apiResponse(200, 'Activity has been recorded', null, null);
                            else
                                apiResponse(400, 'Something went wrong.', null, null);
                        }
                    } else {
                        /* Insert */
                        $dataToInsert = array_merge($postParams, ['message' => json_encode($message), 'created_at' => time(), 'updated_at' => time()]);
                        $inserted = $this->_db->insert('activities_givr', $dataToInsert);
                        if ($inserted)
                            apiResponse(200, 'Activity has been recorded', null, $inserted);
                        else
                            apiResponse(400, 'Something went wrong.', null, null);
                    }

                } else
                    apiResponse(400, 'Messages are empty or not in proper format.', null, null);


            } else {
                apiResponse(400, reset($wrongParams) . ' is a wrong param, please correct it.', 'wrong param', null);
            }

        } else {
            $errMsg = json_decode($validator->messages(), true);
            apiResponse(412, array_values($errMsg)[0][0], 'Validation error', null);
        }


    }

}