<?php

namespace App\Http\Controllers\GIVR;

use App\Http\Controllers\InstagramScrape\InstagramScrapeController;
use App\Http\Models\Service;
use App\User;
use Firebase\JWT\JWT;
use Illuminate\Database\DetectsDeadlocks;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;

class GivrUserdetailsController
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        //
    }

    //


    /**
     * @Desc checking user account and followers
     * @Class checkUser
     * @param Request $request
     * @since 08 feb 2018
     * @author Sibasankar Bhoi (sibasankarbhoi@globussoft.in)
     */
    public function checkuserAccount(Request $request)
    {
        $rules = [
            'username' => 'required',
        ];
        $message = [
            'username.required' => 'Please Enter Your User Name',
        ];
        $response = array('response' => '', 'Success' => false);
        $validator = Validator::make($request->input(), $rules, $message);
        if ($validator->fails()) {
            $this->apiError('412',$validator->messages());

        } else {
            $name = $request->all()['username'];
            $url = 'https://www.instagram.com/' . $name . '/?__a=1';
            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, $url);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            $result = curl_exec($ch);                                         //get all the data
            $data = json_decode($result, true);
            $objmodeluser = Service::getInstance();
            $checkuser = $objmodeluser->getaccountDetails($data);
        }
    }

    /**
     * @Desc   check user name exist or not
     * @Class usernameExist
     * @param Request $request
     * @return string
     * @since 08 feb 2018
     * @author Sibasankar Bhoi (sibasankarbhoi@globussoft.in)
     */
    public function usernameExist(Request $request)
    {
        $rules = [
            'username' => 'required',
        ];
        $message = [
            'username.required' => 'Please Enter Your User Name',
        ];
        $response = array('response' => '', 'Success' => false);
        $validator = Validator::make($request->input(), $rules, $message);
        if ($validator->fails()) {
            $this->apiError('412',$validator->messages());

//            return json_encode(['code' => 100, 'status' => 'Failed', 'message' => $validator->messages()]);
        } else {
            $name = $request->all()['username'];
            $url = 'https://www.instagram.com/' . $name . '/?__a=1';

            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, $url);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

            $result = curl_exec($ch);
            $data = json_decode($result, true);
            if ($data == null) {
                $this->apiError('412','User name does not exist');

            } else {
                return json_encode(['code' => 200, 'status' => 'success', 'message' => 'user name  exist']);
            }
        }
    }


    /**
     * @Desc fetching media details with comments, likes
     * @Class getmediaDetails
     * @param Request $request
     * @return string
     * @since 08 feb 2018
     * @author Sibasankar Bhoi (sibasankarbhoi@globussoft.in)
     */
    public function getmediaDetails(Request $request)
    {
        $name = $request->all()['username'];
        if(isset($request->all()['end_cursor'])) {
            $end_cursor = $request->all()['end_cursor'];
        }
        $url = 'https://www.instagram.com/' . $name . '/?__a=1';
        $objInstagramScrape = new InstagramScrapeController();
        $insta_user_id = $objInstagramScrape->instaCurlHitGet($url);

        if($insta_user_id['graphql']['user']['is_private']==true){     //checking account is private
            apiResponse(412, 'User account is private', 'private account', null);

        }
        $post_count = $insta_user_id['graphql']['user']['edge_owner_to_timeline_media']['count'];
        if ($post_count == 0) {
            apiResponse(412, 'No post found for this user', 'No post found for this user', null);

        }
        $user_id = $insta_user_id['graphql']["user"]["id"];

        if ($user_id == null) {                        //checking condition user exist or not
            return json_encode([
                'code' => 412,
                'status' => 'false',
                'message' => 'user not found, please enter correct user name',
                'data' => null
            ]);
        } elseif ($user_id) {

            if(isset($request->all()['end_cursor'])) {

                $details_url = 'https://www.instagram.com/graphql/query/?query_id=17888483320059182&variables={"id":"' . $user_id . '","first":150,"after":"' . $end_cursor . '"}';
            }else
                $details_url = 'https://www.instagram.com/graphql/query/?query_id=17888483320059182&variables={"id":"' . $user_id . '","first":150}';
            $data_details = $objInstagramScrape->instaCurlHitGet($details_url);

            $end_cursor=$data_details["data"]["user"]["edge_owner_to_timeline_media"]["page_info"]["end_cursor"];
            $has_next = $data_details["data"]["user"]["edge_owner_to_timeline_media"]["page_info"]["has_next_page"];

            if($end_cursor==null){
                apiResponse(412,'Enter correct end_cursor','end_cursor not valid',null);
            }
            $mediaDetailsArr = [];
            foreach ($data_details['data']['user'] ["edge_owner_to_timeline_media"]["edges"] as $key => $media) {
                $mediaDetailsArr[$key]['media_image_url'] = $media["node"]["thumbnail_src"];
                $mediaDetailsArr[$key]['comments_count'] = $media["node"]["edge_media_to_comment"]["count"];
                $mediaDetailsArr[$key]['likes_count'] = $media["node"]["edge_media_preview_like"]['count'];
                $mediaDetailsArr[$key]['is_video'] = $media["node"]["is_video"];
                if ($mediaDetailsArr[$key]['is_video'] == true) {
                    $mediaDetailsArr[$key]['video_view_count'] = $media["node"]["video_view_count"];
                }
                $mediaDetailsArr[$key]['media_url'] = 'https://instagram.com/p/' . $media["node"]["shortcode"];
            }
//            if ($post_count > count($mediaDetailsArr)) {
//                $has_next = true;
//                $next_post = $end_cursor ;
//            } else {
//                $has_next = false;
//                $next_post = 0;
//            }
            return json_encode([
                'code' => 200,
                'status' => 'success',
                'message' => 'users media fetched succesfully',
                'has_next' => $has_next,
                'end_cursor' => $end_cursor,
                'data' => $mediaDetailsArr
            ]);
        } else {                                           // response for if no media found
            return json_encode([
                'code' => 200,
                'status' => 'success',
                'message' => 'fetched succesfully, No media found',
                'data' => null
            ]);
        }


    }

    /**
     * @Desc check free package, after sign up user get a free package
     * @Class freepackage
     * @since 08 feb 2018
     * @author Sibasankar Bhoi (sibasankarbhoi@globussoft.in)
     */
    public function freepackage(Request $request)
    {
        try {
            $access_token = ($request->header('access-token')) ? $request->header('access-token') : (($request->all()['access-token']) ? $request->all()['access-token'] : '');
            $key = "User access token";
            $decoded = JWT::decode($access_token, $key, array('HS256'));     //  user details as a TOKEN
            $userdetails = DB::table('users')->where('email', $decoded->email)->first();
            $username = $userdetails->username;
            $objmodeluser = Service::getInstance();    //checking free package status
            $freepackage = $objmodeluser->checkfreePackage($username);
        } catch (\Exception $exc) {
            echo json_encode(['code' => 401, 'status' => 'false', 'message' => 'Please Enter valid Token']);
        }
    }


    /**
     * @Desc checking free packages after rated APP
     * @Class ratedAppfreepackage
     * @param Request $request
     * @return string
     * @since 08 feb 2018
     * @author Sibasankar Bhoi (sibasankarbhoi@globussoft.in)
     */
    public function ratedappPackage(Request $request)
    {
        try {
            $access_token = ($request->header('access-token')) ? $request->header('access-token') : (($request->all()['access-token']) ? $request->all()['access-token'] : '');
            $key = "User access token";
            $decoded = JWT::decode($access_token, $key, array('HS256'));     //  user details as a TOKEN
            $userdetails = DB::table('users')->where('email', $decoded->email)->first();
            $username = $userdetails->username;
            $objmodeluser = Service::getInstance();    //checking free package status
            $ratedAppfreepackage = $objmodeluser->ratedAppfreepackage($username);
        } catch (\Exception $exc) {
            echo json_encode(['code' => 401, 'status' => 'false', 'message' => 'Please Enter valid Token']);
        }
    }

    /**
     * @Desc error response function
     * @Class apiError
     * @param $code
     * @param $msg
     * @since 08 feb 2018
     * @author Sibasankar Bhoi (sibasankarbhoi@globussoft.in)
     */
    public function apiError($code, $msg)
    {
        header('Content-Type: application/json');
        http_response_code($code);
        echo json_encode(['code' => $code, 'status' => 'failed', 'message' => $msg, 'data' => null]);
        die();
    }
}


