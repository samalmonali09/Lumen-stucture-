<?php

namespace App\Http\Controllers\GIVR;

use App\Http\Models\Package;
use App\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class GivrPackagesController
{

    /**
     * @Desc  fetching all packages
     * @Class packageList
     * @param Request $request
     * @since 08 feb 2018
     * @author Sibasankar Bhoi (sibasankarbhoi@globussoft.in)
     */
    public function GivePackageList()
    {
        $package_for = 4;      //only for GIVE
        $objmodeluser = Package::getInstance(); //  fetch all packages
        $packageList = $objmodeluser->packageList($package_for);
        $errorResponse = new AuthenticationController();
        $packageListArr = [];
        foreach ($packageList as $key => $list) {
            $packageListArr[$key]['package_id'] = $list->package_id;
            $packageListArr[$key]['package_name'] = $list->package_name;
            $packageListArr[$key]['package_type'] = $list->package_type;
            $packageListArr[$key]['package_status'] = $list->package_status;
            $packageListArr[$key]['package_for'] = $list->package_for;
            $packageListArr[$key]['quantity'] = $list->quantity;
            $packageListArr[$key]['price'] = $list->price;
            $packageListArr[$key]['plan_id'] = $list->plan_id;

        }
        if (isset($packageListArr) && !empty($packageListArr)) {
            echo json_encode([
                'code' => 200,
                'status' => 'Success',
                'message' => 'All packages fetched Succesfully',
                'data' => $packageListArr
            ]);
        } else $errorResponse->apiError('401', 'No packages found');

    }
    public function package(Request $request)
    {
        $package_for = 4    ;
        $package_type = $request->all()['package_type'];
        $errorResponse = new AuthenticationController();

        $objmodeluser = Package::getInstance(); //  fetch all packages
        $packageList = $objmodeluser->fetchPackage($package_for, $package_type);
        $packageListArr = [];
        foreach ($packageList as $key => $list) {
            if ($list->price != 0) {

                $packageListArr[$key]['package_id'] = $list->package_id;
                $packageListArr[$key]['package_name'] = $list->package_name;
                $packageListArr[$key]['package_type'] = $list->package_type;
                $packageListArr[$key]['package_status'] = $list->package_status;
                $packageListArr[$key]['package_for'] = $list->package_for;
                $packageListArr[$key]['quantity'] = $list->quantity;
                $packageListArr[$key]['price'] = $list->price;
                $packageListArr[$key]['plan_id'] = $list->plan_id;
            }
        }
        $count = count($packageListArr);

        if (isset($request->all()['quantity']) && isset($request->all()['end_cursor'])) {
            $quantity = $request->all()['quantity'];
            if ($count > $quantity) {
                $end_cursor1 = $request->all()['end_cursor'] + $quantity;

                if ($count < $end_cursor1) {
                    $hasnext = false;
                    $end_cursor = null;
                    $dataPaginate = array_slice($packageListArr, $request->all()['end_cursor'], $quantity);
                } else {
                    $dataPaginate = array_slice($packageListArr, $request->all()['end_cursor'], $quantity);
                    $hasnext = true;
                    $end_cursor = $end_cursor1;
                }
            } else {
                $errorResponse->apiError('401', 'Quantity is higher than Packages count');
                die;
            }
        } else {
            $dataPaginate = array_slice($packageListArr, 0, 8);
            $hasnext = true;
            $end_cursor = 2;
        }

        if (isset($dataPaginate) && !empty($dataPaginate)) {
            echo json_encode([
                'code' => 200,
                'hasnext' => $hasnext,
                'end_cursor' => $end_cursor,
                'status' => 'Success',
                'message' => 'All packages fetched Succesfully',
                'data' => $dataPaginate
            ]);

        } else $errorResponse->apiError('401', 'No packages found');
//        }
    }

}


