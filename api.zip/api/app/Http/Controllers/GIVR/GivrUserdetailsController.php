<?php

namespace App\Http\Controllers\GIVR;

use App\Http\Controllers\InstagramScrape\InstagramScrapeController;
use App\Http\Models\Package;
use App\Http\Models\Service;
use App\Http\Models\tutorial;
use App\User;
use Firebase\JWT\JWT;
use Illuminate\Database\DetectsDeadlocks;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;

class GivrUserdetailsController
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        //
    }

    //


    /**
     * @Desc checking user account and followers
     * @Class checkUser
     * @param Request $request
     * @since 08 feb 2018
     * @author Sibasankar Bhoi (sibasankarbhoi@globussoft.in)
     */
    public function checkuserAccount(Request $request)
    {

        $name = $request->all()['username'];
        ini_set('memory_limit', '1024M');

        $result = $this->curlUsingGet('https://instagram.com/' . $name);

        if ($result != '' || $result != null) {
            $profileDetails = explode('window._sharedData = ', $result);
            if (count($profileDetails) > 1) {
                $profileDetailsJson = explode(';</script>', $profileDetails[1]);
                $profileDetailsArr = json_decode($profileDetailsJson[0], TRUE);
                if (isset($profileDetailsArr['entry_data']['ProfilePage']) && !empty($profileDetailsArr['entry_data']['ProfilePage'])) {
                    $result = $profileDetailsArr['entry_data']['ProfilePage'][0];
                    $objmodeluser = Service::getInstance();
                    $userDetails = $objmodeluser->getaccountDetails($result);
                    $userDetails['followers_order_token'] = AccessTokenforGive_Gilr(
                        [
                            'link' => 'https://www.instagram.com/' . $name,
                            'display_url' => $userDetails['profile_image'],
                            'full_name' => $userDetails['full_name'],
                            'isPrivate' => $userDetails['isPrivate'],
                            'following' => $userDetails['following'],
                            'followers_count' => convertNumberIntoProperNotation($userDetails['followed_by'])
                        ]
                    );
                    $mediaDetailsArr = [];
                    if (isset($request->all()['is_video']) && !empty($request->all()['is_video'])) {

                        $is_video = $request->all()['is_video'];

                        if ($is_video == true) {
                            foreach ($result ['graphql']['user']['edge_owner_to_timeline_media']['edges'] as $key => $media) {
                                if ($media["node"]["is_video"] == 'true') {


                                    if (isset($media['node']['thumbnail_resources'][2]['src']) && !empty($media['node']['thumbnail_resources'][2]['src'])) {
                                        $mediaDetailsArr[$key]['media_image_url'] = $media['node']['thumbnail_resources'][2]['src'];
                                    } else {
                                        $mediaDetailsArr[$key]['media_image_url'] = $media["node"]["thumbnail_src"];
                                    }
                                    $mediaDetailsArr[$key]['comments_count'] = convertNumberIntoProperNotation($media["node"]["edge_media_to_comment"]["count"]);
                                    $mediaDetailsArr[$key]['likes_count'] = convertNumberIntoProperNotation($media["node"]["edge_media_preview_like"]['count']);
                                    $mediaDetailsArr[$key]['is_video'] = $media["node"]["is_video"];
                                    if ($mediaDetailsArr[$key]['is_video'] == true) {
                                        $mediaDetailsArr[$key]['video_view_count'] = convertNumberIntoProperNotation($media["node"]["video_view_count"]);
                                    }
                                    $mediaDetailsArr[$key]['media_url'] = 'https://instagram.com/p/' . $media["node"]["shortcode"];
                                    $mediaDetailsArr[$key]['order_token'] = AccessTokenforGive_Gilr($mediaDetailsArr[$key]);
                                }
                            }
                        }
                    } else
                        foreach ($result ['graphql']['user']['edge_owner_to_timeline_media']['edges'] as $key => $media) {
                            if (isset($media['node']['thumbnail_resources'][2]['src']) && !empty($media['node']['thumbnail_resources'][2]['src'])) {

                                $mediaDetailsArr[$key]['media_image_url'] = $media['node']['thumbnail_resources'][4]['src'];
                            } else {
                                $mediaDetailsArr[$key]['media_image_url'] = $media["node"]["thumbnail_src"];

                            }
                            $mediaDetailsArr[$key]['comments_count'] = convertNumberIntoProperNotation($media["node"]["edge_media_to_comment"]["count"]);
                            $mediaDetailsArr[$key]['likes_count'] = convertNumberIntoProperNotation($media["node"]["edge_media_preview_like"]['count']);
                            $mediaDetailsArr[$key]['is_video'] = $media["node"]["is_video"];
                            if ($mediaDetailsArr[$key]['is_video'] == true) {
                                $mediaDetailsArr[$key]['video_view_count'] = convertNumberIntoProperNotation($media["node"]["video_view_count"]);
                            }
                            $mediaDetailsArr[$key]['media_url'] = 'https://instagram.com/p/' . $media["node"]["shortcode"];
                            $mediaDetailsArr[$key]['order_token'] = AccessTokenforGive_Gilr($mediaDetailsArr[$key]);
                        }


                    $mediaDetailsArr1 = array_values($mediaDetailsArr);
                    $media = [];
                    $media['media'] = $mediaDetailsArr1;
                    $data = array_merge($userDetails, $media);
//                    array_push($mediaDetailsArr1, $userDetails);

                    return json_encode(['code' => 200, 'status' => 'success', 'message' => 'пользователь существует', 'data' => $data]);

//                    dd($data);
                } else

                    apiResponse('401', 'Пользователь не найден', 'null', 'null');


            } else
                apiResponse('401', 'User not found', 'null', 'null');
        }
        return null;
    }

    public function curlUsingGet($url, $headers = '')
    {

        ini_set('max_execution_time', 600);

        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        if (!empty($headers))
            curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
        curl_setopt($ch, CURLOPT_VERBOSE, 1);
        $curl_scraped_page = curl_exec($ch);
//        if (isset($headers) && !empty($headers)){
//            dd($headers,$curl_scraped_page);
//        }
        if (curl_errno($ch) > 0) {
            print_r(curl_error($ch));
        }
        curl_close($ch);
        return $curl_scraped_page;
    }


    /**
     * @Desc   check user name exist or not
     * @Class usernameExist
     * @param Request $request
     * @return string
     * @since 08 feb 2018
     * @author Sibasankar Bhoi (sibasankarbhoi@globussoft.in)
     */
    public function usernameExist(Request $request)
    {
        $rules = [
            'username' => 'required',
        ];
        $message = [
            'username.required' => 'Please Enter Your User Name',
        ];
        $response = array('response' => '', 'Success' => false);
        $validator = Validator::make($request->input(), $rules, $message);
        if ($validator->fails()) {
            $this->apiError('412', $validator->messages());

//            return json_encode(['code' => 100, 'status' => 'Failed', 'message' => $validator->messages()]);
        } else {


            $name = $request->all()['username'];
            ini_set('memory_limit', '1024M');

            $result = $this->curlUsingGet('https://instagram.com/' . $name);

            if ($result != '' || $result != null) {
                $profileDetails = explode('window._sharedData = ', $result);
                if (count($profileDetails) > 1) {
                    $profileDetailsJson = explode(';</script>', $profileDetails[1]);
                    $profileDetailsArr = json_decode($profileDetailsJson[0], TRUE);
                    if (isset($profileDetailsArr['entry_data']['ProfilePage']) && !empty($profileDetailsArr['entry_data']['ProfilePage'])) {
                        $result = $profileDetailsArr['entry_data']['ProfilePage'][0];

                        $objmodeluser = Service::getInstance();
                        $checkuser = $objmodeluser->getaccountDetails($result);
                    } else

                        apiResponse('401', 'Имя пользователя не существует', 'null', 'null');


                }
                return null;
            }
            return null;
        }
    }


    /**
     * @Desc fetching media details with comments, likes
     * @Class getmediaDetails
     * @param Request $request
     * @return string
     * @since 08 feb 2018
     * @author Sibasankar Bhoi (sibasankarbhoi@globussoft.in)
     */
    public function getmediaDetails(Request $request)
    {
        $user_id = $request->all()['id'];
        $end_cursor = $request->all()['end_cursor'];
        try {
            $mediaDetailsArr = $allMediaDetail = [];
            getNewData:
            $details_url = 'https://www.instagram.com/graphql/query/?query_id=17888483320059182&variables={"id":' . $user_id . ',"first":20,"after":"' . $end_cursor . '"}';
            $headers = [
                'Host: www.instagram.com',
                'User-Agent: Mozilla/5.0 (Windows NT 6.1; WOW64; rv:42.0) Gecko/20100101 Firefox/42.0',
                'Accept: */*',
                'Accept-Language: en-US,en;q=0.5',
                'X-Requested-With: XMLHttpRequest',
                'Referer: https://www.instagram.com/',
                'Cookie: mid=W8XhWwAEAAEyWZ8bo9DK6ocVWtqW; mcd=3; csrftoken=VpvKEuwvXiEiHD7va2fRA3dmF9ZRmDji; fbm_124024574287414=base_domain=.instagram.com; shbid=11308; ds_user_id=6451482720; sessionid=6451482720%3AMFedIMc7yvk5fP%3A9; rur=PRN; urlgen="{\"103.217.90.98\": 133255}:1gEu4J:0UXPvwIEEWTM-7W-EpUEsn_Ei_I"; fbsr_124024574287414=bPTBfniqK87M6bAP7Y9kZOE12x5q9gCOIbKaR52dWRc.eyJhbGdvcml0aG0iOiJITUFDLVNIQTI1NiIsImNvZGUiOiJBUUFJYnhxeGIxOVZDUmdDYVAzZHNOd1ZVX0o0Q2FOZXZZOGRQSHFuMjNzSDJmUDRhVFllVEU4TjBLcG1uZWkyNkh0QnJSeC16Y1M2VUZXMkZmTG9KeTFIeUQtbEt2TzdSQ2V3VF85WC1GcktDV1Z0dlVlU2c1NENleGZhWFFtVzg4U1A1OFg0R0JHd0drQll3UkdrT2xyS2Y1Ty1ma2k4ekxGbk1nVVZKTnhCLURWWTF6RnIzaURNOVNid1duLVNEdldnVUt2RlIybEhheDA1eWp2cFBVeGcxSUJDZnd1M2pJWjdTb1VMcFNsZkRpem1aMFdPeWhGdjc0TF9CYmpOX0RZNThIeUpsQ215M1F2STFxVEhXRndsd1pMY3Y3bUhILVFoS0FWeGVJd1dlWW0wTHdwTTFhTEZVU1NsbDg1SkJSZ19LeU5JcFpjVTR3Sks4Y0Z0N2pfVyIsImlzc3VlZF9hdCI6MTU0MDI5MDk4NSwidXNlcl9pZCI6IjEwMDAxNDgzOTIxNjY4NyJ9',
                'Connection: keep-alive'
            ];
            $mediaDetails = $this->curlUsingGet($details_url, $headers);
            $data_details = json_decode($mediaDetails, true);
            if ($data_details['data']['user'] == null) {

                apiResponse(401, 'User not found', null, null);
            }

            $end_cursor = $data_details["data"]["user"]["edge_owner_to_timeline_media"]["page_info"]["end_cursor"];
            $has_next = $data_details["data"]["user"]["edge_owner_to_timeline_media"]["page_info"]["has_next_page"];

//        if ($end_cursor == null) {
//            apiResponse(412, 'Enter correct end_cursor', 'ig token has expired', null);
//        }


            if (isset($request->all()['is_video']) && !empty($request->all()['is_video'])) {

                $is_video = $request->all()['is_video'];
                if ($is_video == 'true') {
                    foreach ($data_details['data']['user'] ["edge_owner_to_timeline_media"]["edges"] as $key => $media) {
                        if ($media["node"]["is_video"] == true) {
                            if (isset($media['node']['thumbnail_resources'][2]['src']) && !empty($media['node']['thumbnail_resources'][2]['src'])) {
                                $mediaDetailsArr[$key]['media_image_url'] = $media['node']['thumbnail_resources'][2]['src'];
                            } else {
                                $mediaDetailsArr[$key]['media_image_url'] = $media["node"]["thumbnail_src"];
                            }
                            $mediaDetailsArr[$key]['comments_count'] = convertNumberIntoProperNotation($media["node"]["edge_media_to_comment"]["count"]);
                            $mediaDetailsArr[$key]['likes_count'] = convertNumberIntoProperNotation($media["node"]["edge_media_preview_like"]['count']);
                            $mediaDetailsArr[$key]['is_video'] = $media["node"]["is_video"];
                            if ($mediaDetailsArr[$key]['is_video'] == true) {
                                $mediaDetailsArr[$key]['video_view_count'] = convertNumberIntoProperNotation($media["node"]["video_view_count"]);
                            }
                            $mediaDetailsArr[$key]['media_url'] = 'https://instagram.com/p/' . $media["node"]["shortcode"];
                            $mediaDetailsArr[$key]['order_token'] = AccessTokenforGive_Gilr($mediaDetailsArr[$key]);
                            $allMediaDetail[] = $mediaDetailsArr[$key];
                        }
                    }
                }
            } else {
                foreach ($data_details['data']['user'] ["edge_owner_to_timeline_media"]["edges"] as $key => $media) {
                    if (isset($media['node']['thumbnail_resources'][2]['src']) && !empty($media['node']['thumbnail_resources'][2]['src'])) {
                        $mediaDetailsArr[$key]['media_image_url'] = $media['node']['thumbnail_resources'][2]['src'];
                    } else {
                        $mediaDetailsArr[$key]['media_image_url'] = $media["node"]["thumbnail_src"];
                    }
                    $mediaDetailsArr[$key]['comments_count'] = convertNumberIntoProperNotation($media["node"]["edge_media_to_comment"]["count"]);
                    $mediaDetailsArr[$key]['likes_count'] = convertNumberIntoProperNotation($media["node"]["edge_media_preview_like"]['count']);
                    $mediaDetailsArr[$key]['is_video'] = $media["node"]["is_video"];
                    if ($mediaDetailsArr[$key]['is_video'] == true) {
                        $mediaDetailsArr[$key]['video_view_count'] = convertNumberIntoProperNotation($media["node"]["video_view_count"]);
                    }
                    $mediaDetailsArr[$key]['media_url'] = 'https://instagram.com/p/' . $media["node"]["shortcode"];
                    $mediaDetailsArr[$key]['order_token'] = AccessTokenforGive_Gilr($mediaDetailsArr[$key]);
                    $allMediaDetail[] = $mediaDetailsArr[$key];
                }


            }
            if (count($allMediaDetail) <= 12 && $end_cursor) {
                goto getNewData;
            }

            if (!$has_next)
                $end_cursor = null;
            return json_encode([
                'code' => 200,
                'status' => 'success',
                'message' => 'СМИ пользователей успешно',
                'has_next' => $has_next,
                'end_cursor' => $end_cursor,
                'data' => $allMediaDetail,
            ]);


        } catch (\Exception $exc) {
            dd($exc->getMessage());
        }


//    } else{                                           // response for if no media found
//return json_encode(['code' => 200,
//'status' => 'success',
//'message' => 'fetched succesfully, No media found',
//'data' => null]);

    }

    /**
     * @Desc check free package, after sign up user get a free package
     * @Class freepackage
     * @since 08 feb 2018
     * @author Sibasankar Bhoi (sibasankarbhoi@globussoft.in)
     */
    public function freepackage(Request $request)
    {
        try {
            $key = env('JWT_KEY');               // create access TOKEN

//            if (isset($order_token) && !empty($order_token)){
//
//                $order_token = $request->all()['order_token'];
//                $decoded = JWT::decode($order_token, $key, array('HS256'));
//            }

            $access_token = ($request->header('access-token')) ? $request->header('access-token') : (($request->all()['access-token']) ? $request->all()['access-token'] : '');
            $decoded2 = JWT::decode($access_token, $key, array('HS256'));     //  user details as a TOKEN
            $ip_address = $request->ip();
            $findData = ['ip_address'];
            $getTransactiiomDetails = \App\Http\Models\Transaction::getInstance()->getTransactionDetails([    //get package id
                'rawQuery' => 'user_id = ? and amount=?',
                'bindParams' => [$decoded2->user_id, 'freePackage']
            ], $findData);
            if (count($getTransactiiomDetails) > 0 && $getTransactiiomDetails[0]->ip_address == $ip_address) {
                apiResponse(401, 'User has allready taken free package', 'ip_address is same', null);
            }
            if (isset($request->all()['package_type']) && !empty($request->all()['package_type'])) {
                $package_type = $request->all()['package_type'];
            } else
                $package_type = 0;
            if (isset($order_token) && !empty($order_token)) {

                $order_token = $request->all()['order_token'];
                $decoded = JWT::decode($order_token, $key, array('HS256'));
                $token = array(
                    "media_url" => $decoded->media_url,
                    "likes_count" => $decoded->likes_count,
                    "created_time" => $decoded2->created_time,
                    "email" => $decoded2->email,
                    "user_id" => $decoded2->user_id,
                    "user_name" => $decoded2->user_name,
                    "iat" => $decoded2->iat,
                    "register_through" => $decoded2->register_through,
                    "ip_address" => $ip_address,
                    "package_type" => $package_type
                );
                $access_token = JWT::encode($token, $key);
                $decoded1 = JWT::decode($access_token, $key, array('HS256'));     // sending user details as a TOKEN
            }
//            $token = array(
//                "media_url" => $decoded->media_url,
//                "likes_count" => $decoded->likes_count,
//                "created_time" => $decoded2->created_time,
//                "email" => $decoded2->email,
//                "user_id" => $decoded2->user_id,
//                "user_name" => $decoded2->user_name,
//                "iat" => $decoded2->iat,
//                "register_through" => $decoded2->register_through,
//                "ip_address" => $ip_address,
//                "package_type" => $package_type
//            );
//            $access_token = JWT::encode($token, $key);
//            $decoded1 = JWT::decode($access_token, $key, array('HS256'));     // sending user details as a TOKEN

            $userdetails = DB::table('users')->where('email', $decoded2->email)->first();
            $username = $userdetails->username;
            $objmodeluser = Service::getInstance();    //checking free package status
            $freepackage = $objmodeluser->checkfreePackage($username, $access_token);
//            $ratedAppfreepackage = $objmodeluser->ratedAppfreepackage($username);
        } catch (\Exception $exc) {
            dd($exc->getMessage());
            apiResponse(401, 'Please Enter valid Token', 'Invalid Token', null);

        }
    }


    /**
     * @Desc checking free packages after rated APP
     * @Class ratedAppfreepackage
     * @param Request $request
     * @return string
     * @since 08 feb 2018
     * @author Sibasankar Bhoi (sibasankarbhoi@globussoft.in)
     */
//    public function ratedappPackage(Request $request)
//    {
//        try {
//            $rules = ['device_id' => 'required',
//                'access-token' => 'required'
//            ];
//            $message = [
//                'device_id.required' => 'Please Enter Device_id',
//                'access-token.required' => 'Please Enter Access token',
//            ];
//            $response = array('response' => '', 'Success' => false);
//            $validator = Validator::make($request->input(), $rules, $message);
//            if ($validator->fails()) {
//                $errMsg = json_decode($validator->messages(), true);
//                apiResponse(412, array_values($errMsg)[0][0],'Validation Error', null);
//            }
//            $access_token = ($request->header('access-token')) ? $request->header('access-token') : (($request->all()['access-token']) ? $request->all()['access-token'] : '');
//            $key = env('JWT_KEY');
//            $decoded = JWT::decode($access_token, $key, array('HS256'));     //  user details as a TOKEN
//            $ip_address = $request->ip();
//            $device_id=$request->all()['device_id'];
//            if (isset($request->all()['package_type']) && !empty($request->all()['package_type'])) {
//
//                $findpackage = ['package_id'];     // checking packge existance
//                $getPackage = Package::getInstance()->getPackageDetails([
//                    'rawQuery' => 'price = ? and package_type = ? and package_for=?',
//                    'bindParams' => [0, $request->all()['package_type'],4]
//                ], $findpackage);
//                if (count($getPackage) == 0) {
//                    apiResponse(401, 'В настоящее время нет бесплатного пакета', null, null);
//                }
//            }
//            $userdetails = DB::table('users')->where('id', $decoded->user_id)->first();
//            if ($userdetails && !empty($userdetails)) {
//                if ($userdetails->user_free_package == 0) {
//                    $findData = ['ip_address','device_id'];
//                    $getTransactiiomDetails = \App\Http\Models\Transaction::getInstance()->getTransactionDetails([   //checking ip and device id for duplicate order
//                        'rawQuery' => 'user_id = ? and transaction_id=?',
//                        'bindParams' => [$decoded->user_id, 'Free Package']
//                    ], $findData);
//                    if (count($getTransactiiomDetails) > 0){
//                        if ($getTransactiiomDetails[0]->ip_address == $ip_address or $getTransactiiomDetails[0]->device_id==$device_id) {
//                            apiResponse(401, 'Этому устройству уже сделали бесплатные впечатления', 'ip_address or Device id is same', null);
//                        }
//                    }
//                    $check_device_id = \App\Http\Models\Transaction::getInstance()->getTransactionDetails([    //checking ip and device id for duplicate order
//                        'rawQuery' => 'device_id = ? and transaction_id=?',
//                        'bindParams' => [$device_id, 'Free Package']
//                    ], $findData);
//                    if (count($check_device_id) > 0){
//                        if ( $check_device_id[0]->device_id==$device_id) {
//                            apiResponse(401, 'Этому устройству уже сделали бесплатные впечатления', 'ip_address or Device id is same', null);
//                        }
//                    }
//                    if (isset($request->all()['order_token']) && !empty($request->all()['order_token'])) {
//                        $decode_order_token = JWT::decode($request->all()['order_token'], $key, array('HS256'));     //  order details as a TOKEN
//                        $token = array(
//                            "media_url" => $decode_order_token->media_url,
//                            "likes_count" => $decode_order_token->likes_count,
//                            "created_time" => $decoded->created_time,
//                            "email" => $decoded->email,
//                            "user_id" => $decoded->user_id,
//                            "user_name" => $decoded->user_name,
//                            "iat" => $decoded->iat,
//                            "register_through" => $decoded->registered_through,
//                            "ip_address" => $ip_address,
//                            "device_id" => $device_id,
//                            "transaction_id" => 'Free Package',
//                            "package_for" => 3,
//                            "package_type" => $request->all()['package_type'],
//                            "user_free_package" => 1                //status changed to 2 after get free likes
//                        );
//                        $order_token = JWT::encode($token, $key);
//                        $order_token_decode = JWT::decode($order_token, $key, array('HS256'));
//
//                        $objmodeluser = Service::getInstance();    //checking free package status
//                        $ratedAppfreepackage = $objmodeluser->ratedAppfreepackage($userdetails->id, $order_token);
//
//                    } else
//                        apiResponse(200, 'пользователь может получить бесплатный пакет', null, 'please provide Order token and package type for get free package');
//
//                }
//                if ($userdetails->rated_app == 1) {
//                    if (isset($request->all()['order_token']) && !empty($request->all()['order_token'])) {
//                        $decode_order_token = JWT::decode($request->all()['order_token'], $key, array('HS256'));     //  order details as a TOKEN
//                        $token = array(
//                            "media_url" => $decode_order_token->media_url,
//                            "likes_count" => $decode_order_token->likes_count,
//                            "created_time" => $decoded->created_time,
//                            "email" => $decoded->email,
//                            "user_id" => $decoded->user_id,
//                            "user_name" => $decoded->user_name,
//                            "iat" => $decoded->iat,
//                            "register_through" => $decoded->registered_through,
//                            "ip_address" => $ip_address,
//                            "transaction_id" => 'Rated App Free Package',
//                            "device_id" => $device_id,
//                            "package_for" => 3,
//                            "package_type" => $request->all()['package_type'],
//                            "rated_app" => 2                //status changed to 2 after get free likes
//                        );
//                        $objmodeluser = \App\Http\Models\User::getInstance();    //checking free package status
//
//                        $update_status = $objmodeluser->updateUserDetails(['rawQuery' => 'id = ?', 'bindParams' => [$userdetails->id]], ['rated_app' => 1]);
//
//                        $order_token = JWT::encode($token, $key);
//                        $order_token_decode = JWT::decode($order_token, $key, array('HS256'));
//
//                        $objmodeluser = Service::getInstance();    //checking free package status
//                        $ratedAppfreepackage = $objmodeluser->ratedAppfreepackage($userdetails->id, $order_token);
//
//                    } else
//                        apiResponse(200, 'Пользователь может получить бесплатный пакет ', null, 'please provide Order token and package type for get rate app free package');
//
//
//                }if($userdetails->rated_app == 0){
//
//                    apiResponse(401, 'Оцените приложение, которое вы получите бесплатно.', null, null);
//
//                }
//                else
//                    apiResponse(401, 'Пользователь взял все бесплатные пакеты', null, null);
//
//            } else {
//                apiResponse(401, 'Пользователь не найден', null, null);
//            }
//
//        } catch (\Exception $exc) {
//            dd($exc);
//            echo json_encode(['code' => 401, 'status' => 'false', 'message' => 'Please Enter valid Token']);
//        }
//    }

    public function ratedappPackage(Request $request)
    {
        try {
            $rules = ['device_id' => 'required',
                'access-token' => 'required'
            ];
            $message = [
                'device_id.required' => 'Please Enter Device_id',
                'access-token.required' => 'Please Enter Access token',
            ];
            $response = array('response' => '', 'Success' => false);
            $validator = Validator::make($request->input(), $rules, $message);
            if ($validator->fails()) {
                $errMsg = json_decode($validator->messages(), true);
                apiResponse(412, array_values($errMsg)[0][0], 'Validation Error', null);
            }
            $access_token = ($request->header('access-token')) ? $request->header('access-token') : (($request->all()['access-token']) ? $request->all()['access-token'] : '');
            $key = env('JWT_KEY');
            $decoded = JWT::decode($access_token, $key, array('HS256'));     //  user details as a TOKEN
            $ip_address = $request->ip();
            $device_id = $request->all()['device_id'];
            if (isset($request->all()['package_type']) && !empty($request->all()['package_type'])) {

                $findpackage = ['package_id'];     // checking packge existance
                $getPackage = Package::getInstance()->getPackageDetails([
                    'rawQuery' => 'price = ? and package_type = ? and package_for=?',
                    'bindParams' => [0, $request->all()['package_type'], 4]
                ], $findpackage);
                if (count($getPackage) == 0) {
                    apiResponse(401, 'В настоящее время нет бесплатного пакета', null, null);
                }
            }
            $userdetails = DB::table('users')->where('id', $decoded->user_id)->first();
            if ($userdetails && !empty($userdetails)) {
                if ($userdetails->user_free_package == 0) {

                    $findData = ['device_id'];
                    $getTransactiiomDetails = \App\Http\Models\Transaction::getInstance()->getTransactionDetails([   //checking ip and device id for duplicate order
                        'rawQuery' => 'user_id = ? and transaction_id=?',
                        'bindParams' => [$decoded->user_id, 'Free Package']
                    ], $findData);
                    if (count($getTransactiiomDetails) > 0) {
                        if ($getTransactiiomDetails[0]->device_id == $device_id) {
                            apiResponse(401, 'Этому устройству уже сделали бесплатные впечатления', 'ip_address or Device id is same', null);
                        }
                    }
                    $check_device_id = \App\Http\Models\Transaction::getInstance()->getTransactionDetails([    //checking ip and device id for duplicate order
                        'rawQuery' => 'device_id = ? and transaction_id=?',
                        'bindParams' => [$device_id, 'Free Package']
                    ], $findData);
                    if (count($check_device_id) > 0) {
                        if ($check_device_id[0]->device_id == $device_id) {
                            apiResponse(401, 'Этому устройству уже сделали бесплатные впечатления', 'ip_address or Device id is same', null);
                        }
                    }
                    if (isset($request->all()['order_token']) && !empty($request->all()['order_token'])) {
                        $decode_order_token = JWT::decode($request->all()['order_token'], $key, array('HS256'));     //  order details as a TOKEN
                        $token = array(
                            "media_url" => $decode_order_token->media_url,
                            "likes_count" => $decode_order_token->likes_count,
                            "created_time" => $decoded->created_time,
                            "email" => $decoded->email,
                            "user_id" => $decoded->user_id,
                            "user_name" => $decoded->user_name,
                            "iat" => $decoded->iat,
                            "register_through" => $decoded->registered_through,
                            "ip_address" => $ip_address,
                            "device_id" => $device_id,
                            "transaction_id" => 'Free Package',
                            "package_for" => 3,
                            "package_type" => $request->all()['package_type'],
                            "user_free_package" => 1                //status changed to 2 after get free likes
                        );
                        $order_token = JWT::encode($token, $key);
                        $order_token_decode = JWT::decode($order_token, $key, array('HS256'));

                        $objmodeluser = Service::getInstance();    //checking free package status
                        $ratedAppfreepackage = $objmodeluser->ratedAppfreepackageGIVR($userdetails->id, $order_token);

                    } else
                        apiResponse(200, 'пользователь может получить бесплатный пакет', null, 'please provide Order token and package type for get free package');

                }
                if ($userdetails->rated_app == 1) {
                    if (isset($request->all()['order_token']) && !empty($request->all()['order_token'])) {
                        $decode_order_token = JWT::decode($request->all()['order_token'], $key, array('HS256'));     //  order details as a TOKEN
                        $token = array(
                            "media_url" => $decode_order_token->media_url,
                            "likes_count" => $decode_order_token->likes_count,
                            "created_time" => $decoded->created_time,
                            "email" => $decoded->email,
                            "user_id" => $decoded->user_id,
                            "user_name" => $decoded->user_name,
                            "iat" => $decoded->iat,
                            "register_through" => $decoded->registered_through,
                            "ip_address" => $ip_address,
                            "transaction_id" => 'Rated App Free Package',
                            "device_id" => $device_id,
                            "package_for" => 3,
                            "package_type" => $request->all()['package_type'],
                            "rated_app" => 2,                //status changed to 2 after get free likes

                        );
                        $objmodeluser = \App\Http\Models\User::getInstance();    //checking free package status

                        $update_status = $objmodeluser->updateUserDetails(['rawQuery' => 'id = ?', 'bindParams' => [$userdetails->id]], ['rated_app' => 1]);

                        $order_token = JWT::encode($token, $key);
                        $order_token_decode = JWT::decode($order_token, $key, array('HS256'));

                        $objmodeluser = Service::getInstance();    //checking free package status
                        $ratedAppfreepackage = $objmodeluser->ratedAppfreepackageGIVR($userdetails->id, $order_token);

                    } else
                        apiResponse(200, 'Пользователь может получить бесплатный пакет ', null, 'please provide Order token and package type for get rate app free package');


                }
                if ($userdetails->rated_app == 0) {

                    apiResponse(401, 'Оцените приложение, которое вы получите бесплатно.', null, null);

                } else
                    apiResponse(401, 'Пользователь взял все бесплатные пакеты', null, null);

            } else {
                apiResponse(401, 'Пользователь не найден', null, null);
            }

        } catch (\Exception $exc) {
            dd($exc);
            echo json_encode(['code' => 401, 'status' => 'false', 'message' => 'Please Enter valid Token']);
        }
    }

    public function rateApp(Request $request)     //on hit user will rate the app and status will be 1
    {

        $access_token = ($request->header('access-token')) ? $request->header('access-token') : (($request->all()['access-token']) ? $request->all()['access-token'] : '');
        $key = env('JWT_KEY');
        $decoded = JWT::decode($access_token, $key, array('HS256'));     //  user details as a TOKEN
        $userdetails = DB::table('users')->where('id', $decoded->user_id)->first();
        if ($userdetails->rated_app == 0) {
            $objmodeluser = \App\Http\Models\User::getInstance();    //checking free package status

            $update_status = $objmodeluser->updateUserDetails(['rawQuery' => 'id = ?', 'bindParams' => [$userdetails->id]], ['rated_app' => 1]);
            if ($update_status) {
                apiResponse('200', 'Вы успешно оцениваете приложение', null, null);
            }
        } else {
            apiResponse('401', 'У вас есть Alredy Оценить приложение', null, null);

        }

    }

    /**
     * @Desc error response function
     * @Class apiError
     * @param $code
     * @param $msg
     * @since 08 feb 2018
     * @author Sibasankar Bhoi (sibasankarbhoi@globussoft.in)
     */
    public function apiError($code, $msg)
    {
        header('Content-Type: application/json');
        http_response_code($code);
        echo json_encode(['code' => $code, 'status' => 'failed', 'message' => $msg, 'data' => null]);
        die();
    }


    /**
     * @Desc:moduleDetailsGIVR
     * @param Request $request
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\View\View
     * @since 23/10/2018
     * @author Monali Samal (monalisamal@globussoft.in)
     */
    public function moduleDetailsGIVR()
    {
        $data['blackhat_module'] = config('module_switchGIVR.module_switch_statusGIVR');
        http_response_code(200);
        echo json_encode(['code' => 200, 'status' => 'success', 'message' => 'Module details for get instant Views Russian.', 'data' => $data]);
        die();


    }

    /**
     * @Desc:ActivityTrackerSwitchGIVR
     * @param Request $request
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\View\View
     * @since 23/10/2018
     * @author Monali Samal (monalisamal@globussoft.in)
     */

    public function ActivityTrackerSwitchGIVR()
    {
        $module = config('Activity_trackerGIVR.Activity_trackerGIVR');
        $time = config('Activity_trackerGIVR.time');
        if ($module === 'ON')
            apiResponse('200', 'Activity_tracker Get Instant Views Russian', null, ['Activity_tracker' => 'on', 'time' => $time]);
        else
            apiResponse('200', 'Activity_trackerGIVR is off', null, ['Activity_tracker' => 'off', 'time' => 0]);
    }




    /**
     * @Desc:Tutorial
     * @param Request $request
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\View\View
     * @since 23/10/2018
     * @author Monali Samal (monalisamal@globussoft.in)
     */
    public function Tutorial(Request $request)
    {
            $objimageModal = new tutorial();
            $dataDetails = $objimageModal->getDetails();
//            $link=[];
//           $title=[];
//           $thumbnail=[];
//           $description=[];

        $data=[];
        $doc=[];
            if ($dataDetails) {
                foreach ($dataDetails  as  $key=> $val){
//                    $title[]=$val['title'];
                    $doc['link']=$dataDetails[$key]->link;
                    $doc['title']=$dataDetails[$key]->title;
                    $doc['thumbnail']=$dataDetails[$key]->thumbnail;
                    $doc['description']=$dataDetails[$key]->description;
                    $data[]=$doc;
                }
                return json_encode(['code' => 200, 'message' => 'Tutorial details for GIVR app.', 'data'=>$data]);
            } else {
                return json_encode(['code' => 400, 'message' => 'No Tutorial found for GIVR app.', 'data' => null]);
            }
    }

}


