<?php

namespace App\Http\Controllers\GIVR;

use App\Http\Models\Transaction;
use Firebase\JWT\JWT;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;

class GivrTransactionController
{

    /**
     * @Desc  fetching all transaction details
     * @Class packageList
     * @param Request $request
     * @since 18 jan 2018
     * @author Sibasankar Bhoi (sibasankarbhoi@globussoft.in)
     */
    public function GivrTransactionHistory(Request $request)
    {

        $access_token = ($request->header('access-token')) ? $request->header('access-token') : (($request->all()['access-token']) ? $request->all()['access-token'] : '');
            $key = "User access token";               // create access TOKEN
            try {
               $eat=time();
                $decoded = JWT::decode($access_token, $key, array('HS256'));     //  user details as a TOKEN

                $user_id = $decoded->user_id;                                    //fetch user id from Token
                $objmodeluser = Transaction::getInstance(); //  fetch all packages
                $transactionHistory = $objmodeluser->transactionhistory($user_id);



                    $transaction_historyArr = [];
                    foreach ($transactionHistory as $key => $transaction) {
                        $package=DB::table('packages')->where('package_id',$transaction->package_id)->first();
                        $transaction_historyArr[$key]['tx_id'] = $transaction->tx_id;
                        $transaction_historyArr[$key]['tx_type'] = $transaction->tx_type;
                        $transaction_historyArr[$key]['tx_mode'] = $transaction->tx_mode;
                        $transaction_historyArr[$key]['tx_code'] = $transaction->tx_code;
                        $transaction_historyArr[$key]['transaction_id'] = $transaction->transaction_id;
                        $transaction_historyArr[$key]['user_id'] = $transaction->user_id;
                        $transaction_historyArr[$key]['user_id'] = $transaction->user_id;
                        $transaction_historyArr[$key]['order_id'] = $transaction->order_id;
                        $transaction_historyArr[$key]['autolikes_id'] = $transaction->autolikes_id;
                        $transaction_historyArr[$key]['order_id'] = $transaction->order_id;
                        $transaction_historyArr[$key]['package_id'] = $transaction->package_id;
                        $transaction_historyArr[$key]['package_name'] = $package->package_name;
                        $transaction_historyArr[$key]['package_name'] = $package->package_name;
                        $transaction_historyArr[$key]['package_type'] = $package->package_type;
                     }

                if ($transaction_historyArr == null) {
                        $this->apiError(401,'No transaction found for this user');

                } else {
                    return json_encode([
                        'code' => 200,
                        'status' => 'success',
                        'message' => 'Transactio history fetched',
                        'data' => $transaction_historyArr
                    ]);
                }
//            }
            } catch (\Exception $exc) {
//                dd($exc->getMessage());
                $this->apiError(401,'Token Expired. Please Login Again');
            }


    }



    /**
     * @Desc get payment history of single transaction
     * @Class PaymentHistory
     * @param Request $request
     * @return string
     * @since 07 feb 2018
     * @author Sibasankar Bhoi (sibasankarbhoi@globussoft.in)
     */
    public function GivrPaymentHistory(Request $request)
    {

        $access_token = ($request->header('access-token')) ? $request->header('access-token') : (($request->all()['access-token']) ? $request->all()['access-token'] : '');
        $key = "User access token";
        $decoded = JWT::decode($access_token, $key, array('HS256'));     //  user details as a TOKEN

        $user_id = $decoded->user_id; // create access TOKEN
        $objmodeluser = Transaction::getInstance(); //  fetch all packages
        $paymentHistory = $objmodeluser->paymentHistory($request->all()['tx_id'],$user_id);

        $paymentHistory_historyArr = [];
            $package=DB::table('packages')->where('package_id',$paymentHistory->package_id)->first();
            $paymentHistory_historyArr[$key]['tx_id'] = $paymentHistory->tx_id;
            $paymentHistory_historyArr[$key]['tx_type'] = $paymentHistory->tx_type;
            $paymentHistory_historyArr[$key]['tx_mode'] = $paymentHistory->tx_mode;
            $paymentHistory_historyArr[$key]['tx_code'] = $paymentHistory->tx_code;
            $paymentHistory_historyArr[$key]['transaction_id'] = $paymentHistory->transaction_id;
            $paymentHistory_historyArr[$key]['user_id'] = $paymentHistory->user_id;
            $paymentHistory_historyArr[$key]['user_id'] = $paymentHistory->user_id;
            $paymentHistory_historyArr[$key]['order_id'] = $paymentHistory->order_id;
            $paymentHistory_historyArr[$key]['autolikes_id'] = $paymentHistory->autolikes_id;
            $paymentHistory_historyArr[$key]['order_id'] = $paymentHistory->order_id;
            $paymentHistory_historyArr[$key]['package_id'] = $paymentHistory->package_id;
            $paymentHistory_historyArr[$key]['package_name'] = $package->package_name;
            $paymentHistory_historyArr[$key]['package_name'] = $package->package_name;
            $paymentHistory_historyArr[$key]['package_type'] = $package->package_type;


        if ($paymentHistory_historyArr == null) {
            $this->apiError(401,'No transaction found for this user');

        } else {
            return json_encode([
                'code' => 200,
                'status' => 'success',
                'message' => 'Transactio history fetched',
                'data' => $paymentHistory_historyArr
            ]);
        }
    }

    /**
     * @Desc error response function
     * @Class apiError
     * @param $code
     * @param $msg
     * @since 17 jan 2018
     * @author Sibasankar Bhoi (sibasankarbhoi@globussoft.in)
     */
    public function apiError($code, $msg)
    {
        header('Content-Type: application/json');
        http_response_code($code);
        echo json_encode(['code' => $code, 'status' => 'failed', 'message' => $msg, 'data' => null]);
        die();
    }






}


