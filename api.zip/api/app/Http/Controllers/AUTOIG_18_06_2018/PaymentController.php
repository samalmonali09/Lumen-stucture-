<?php namespace App\Http\Controllers\AUTOIG;

use App\Http\Models\Package;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use Illuminate\Validation\Rule;
use Laravel\Lumen\Routing\Controller;

class PaymentController extends Controller
{
    protected $objModelPackage;
    protected $availablePackageType;

    public function __construct()
    {
        $this->objModelPackage = Package::getInstance();
        $this->availablePackageType = ['likes' => 0, 'followers' => 1, 'comments' => 3, 'views' => 4];
    }

    public function packageLists(Request $request)
    {
        if (($request->input('package_type'))) {

            if (array_key_exists($request['package_type'], $this->availablePackageType)) {

                $start = ($request->input('next_id')) ? abs($request->input('next_id')) : 0;
                $length = ($request->input('length')) ? abs($request->input('length')) : 6;

                $totalPackages = $this->objModelPackage->countAllPackages(['rawQuery' => 'package_for = 5 and package_status =1 and package_type = ' . $this->availablePackageType[$request['package_type']]]);

                if ($start < $totalPackages) {

                    $packages = $this->objModelPackage->getFilteredPackages(['rawQuery' => 'package_for = 5 and package_status =1 and package_type = ' . $this->availablePackageType[$request['package_type']]], ['*'], $start, $length);

                    if ($packages) {

                        if ($start + $length < $totalPackages) {
                            $nextId = $start + count($packages);
                            $hasNext = true;
                        } else {
                            $nextId = 0;
                            $hasNext = false;
                        }

                        http_response_code(200);
                        echo json_encode(['code' => 200, 'message' => $request['package_type'] . ' package lists', 'error' => null, 'next_id' => $nextId, 'has_next' => $hasNext, 'data' => $packages]);
                        die;

                    } else {
                        apiResponse(400, 'There is no any package currently available.', 'No available package', $packages);
                    }
                } else {
                    apiResponse(400, 'next_id is greater than the total ' . $request['package_type'] . ' packages', 'next_id is not proper.', null);
                }

            } else {
                apiResponse(412, 'Package_type value should be likes/comments/followers/views only', 'package_type doesn\'t match.', null);
            }
        } else {
            apiResponse(412, 'Please provide the package_type (likes/followers/views/comments)', 'package_type is missing', null);
        }

    }

    public function oneTimeCheckout(Request $request)
    {
        if ($request->isMethod('post')) {

            $validator = Validator::make($request->all(), [
                'access_token' => 'required|',
                'package_id' => ['required', Rule::exists('packages', 'package_id')->where('package_for', 5)],
            ]);

            if (!$validator->fails()) {

                $accessTokenArr = parseAccessToken($request['access_token']);
                if (!array_key_exists('id', $accessTokenArr)) {
                    apiResponse(401, 'access token is not valid', 'Unauthorized token', null);
                }

                $packageDetails = $this->objModelPackage->getPackageDetails(['rawQuery' => 'package_id=?', 'bindParams' => [$request['package_id']]]);

                $checkoutConfig = array_merge($accessTokenArr, ["package_details" => $packageDetails]);
                $checkoutToken = generateAccessToken($checkoutConfig);

                apiResponse(200, 'User is authenticated, proceed.', null, ['checkout_token' => $checkoutToken]);

            } else
                apiResponse(412, 'Validation error', json_decode($validator->messages(), true), null);
        } else
            apiResponse(405, 'Method not allowed.', 'Only request through post method is allowed.', null);
    }

}