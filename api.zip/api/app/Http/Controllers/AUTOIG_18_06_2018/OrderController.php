<?php namespace App\Http\Controllers\AUTOIG;

use App\Http\Controllers\InstagramScrape\InstagramScrapeController;
use App\Http\Models\Order;
use App\Http\Models\Transaction;
use Illuminate\Http\Request;
use Laravel\Lumen\Routing\Controller;

class OrderController extends Controller
{

    protected $objInstagramScrapeController;

    public function __construct()
    {
        $this->objInstagramScrapeController = new InstagramScrapeController();
    }

    public function flashNews()
    {
        $msg_status = config('flash_message.flashnews');
        $module_status = config('flash_message.module');
        if ($module_status==2) {
            $banner_img_url = config('flash_message.banner_img_url');
        }else
            $banner_img_url = config('flash_message.banner_img_url_dynamic');

//        $img_dimenssion = config('flash_message.img_dimenssion');

        if ($msg_status == 'OFF') {
            apiResponse(400, "Flash news is temporarily off", null, ['module_status'=>$module_status,
                'banner_img_url'=>env('WEB_URL') .$banner_img_url]);
        } else{
            apiResponse(200, "Flash news is ON",
                null,
                ['content' => env('WEB_URL') . '/assets/flashnews.html',
                    'module_status'=>$module_status,
                    'banner_img_url'=>env('WEB_URL') .$banner_img_url]);

        }

    }

    /**
     * @Desc flash news for instant likes app
     * @Class instantLikesFlashnews
     * @since 18 april 2018
     * @author Sibasankar Bhoi (sibasankarbhoi@globussoft.in)
     */
    public function instantLikesFlashnews()
    {
        $msg_status = config('instant_likes_flashnews.flashnews');
        $module_status = config('instant_likes_flashnews.module_status');
        if ($module_status==2) {
            $banner_img_url = config('instant_likes_flashnews.banner_img_url');
        }else
            $banner_img_url = config('instant_likes_flashnews.banner_img_url_dynamic');

//        $img_dimenssion = config('flash_message.img_dimenssion');

        if ($msg_status == 'OFF') {
            apiResponse(400, "Flash news is temporarily off", null, ['module_status'=>$module_status,
                'banner_img_url'=>env('APP_URL') .$banner_img_url]);
        } else{
            apiResponse(200, "Flash news is ON",
                null,
                ['content' => env('WEB_URL') . '/assets/flashnews.html',
                    'module_status'=>$module_status,
                    'banner_img_url'=>env('APP_URL') .$banner_img_url]);

        }

    }


    public function getInstantLikesFlashnews()
    {
        $msg_status = config('gil.flashnews');
        $module_status = config('gil.module_status');
        if ($module_status==2) {
            $banner_img_url = config('gil.banner_img_url');
        }else
            $banner_img_url = config('gil.banner_img_url_dynamic');

//        $img_dimenssion = config('flash_message.img_dimenssion');

        if ($msg_status == 'OFF') {
            apiResponse(400, "Flash news is temporarily off", null, ['module_status'=>$module_status,
                'banner_img_url'=>env('APP_URL') .$banner_img_url]);
        } else{
            apiResponse(200, "Flash news is ON",
                null,
                ['content' => env('WEB_URL') . '/assets/flashnews.html',
                    'module_status'=>$module_status,
                    'banner_img_url'=>env('APP_URL') .$banner_img_url]);

        }

    }




    public function verifyInstaUsername(Request $request)
    {
        if (!empty($request->input('checkout_token')) && array_key_exists('package_details', parseAccessToken($request['checkout_token']))) {

            if (!empty($request->input('insta_username'))) {
                $details = $this->objInstagramScrapeController->instagramProfileDetails($request['insta_username']);
                if ($details)
                    apiResponse(200, 'Instagram profile details', null, $details);
                else
                    apiResponse(400, 'Something went wrong, please try again.', 'error in fetching profile details', null);
            } else
                apiResponse(412, 'Please provide the insta_username.', 'Instagram username is missing.', null);

        } else {
            apiResponse(401, 'Provide a valid checkout_token', 'invalid checkout_token', null);
        }

    }

    public function getAllMedia(Request $request)
    {
        if (!empty($request->input('checkout_token')) && array_key_exists('package_details', parseAccessToken($request['checkout_token']))) {

            if (!empty($request->input('insta_username'))) {
                $details = $this->objInstagramScrapeController->getAllMedia($request['insta_username'], 12, 'video');

                if ($details)
                    apiResponse(200, 'Instagram profile details', null, $details);
                else
                    apiResponse(400, 'Something went wrong, please try again.', 'error in fetching profile details', null);
            } else
                apiResponse(412, 'Please provide the id.', 'id is missing.', null);

        } else {
            apiResponse(401, 'Provide a valid checkout_token', 'invalid checkout_token', null);
        }
    }

    public function getMediaDetails(Request $request)
    {
        if (!empty($request->input('checkout_token')) && array_key_exists('package_details', parseAccessToken($request['checkout_token']))) {

            if (!empty($request->input('id'))) {

                $endCursor = ($request->input('end_cursor')) ? $request['end_cursor'] : '';
                $length = ($request->input('length')) ? $request['length'] : 12;

                $details = $this->objInstagramScrapeController->getInstagramMedia($request['id'], $length, $endCursor);

                if ($details)
                    apiResponse(200, 'Instagram media details', null, $details);
                else
                    apiResponse(400, 'Something went wrong, please try again.', 'error in fetching profile details', null);
            } else
                apiResponse(412, 'Please provide the id.', 'id is missing.', null);

        } else {
            apiResponse(401, 'Provide a valid checkout_token', 'invalid checkout_token', null);
        }
    }

    public function addOrder(Request $request)
    {

        if (!empty($request->input('checkout_token')) && array_key_exists('package_details', parseAccessToken($request['checkout_token']))) {

            if (!empty($request->input('order_token')) && array_key_exists('link', parseAccessToken($request['order_token']))) {

                $checkoutToken = parseAccessToken($request['checkout_token']);
                $orderToken = parseAccessToken($request['order_token']);

                $packageType = $checkoutToken['package_details'][0]['package_type'];

                $regex = '/^(http(s)?:\/\/)?(www\.)?(instagram)\.+(com)+\/+(p)\/(([a-zA-Z0-9\.\-\_])*)/';
                $linkType = (preg_match($regex, $orderToken['link'])) ? "mediaLink" : "profileLink";

                if ((($packageType == 0 || $packageType == 3 || $packageType == 4) && ($linkType != 'mediaLink')) || (($packageType == 1) && ($linkType != 'profileLink'))) {
                    apiResponse(400, 'Link looks invalid.', 'order_token is not proper for this package.', null);
                }

                $startCount = ($packageType == 0) ? $orderToken['like_count'] : ($packageType == 3 ? $orderToken['comment_count'] : $orderToken['view_count']);


//                $item_number = generateAccessToken(['id' => $checkoutToken['id'], 'package_id' => $checkoutToken['package_details'][0]['package_id'], 'link' => $orderToken['link'], 'start_count' => $startCount, 'display_url' => $orderToken['display_url']]);
                $checkoutConfig = [
                    "iat" => time(),
                    "amount" => $checkoutToken['package_details'][0]['price'] * 100,
                    "description" => "Package: " . $checkoutToken['package_details'][0]['package_name'] . "    Price: " . $checkoutToken['package_details'][0]['price'] . "   AUTOIG.",
                    "quantity" => 1,
                    "item_number" => ['id' => $checkoutToken['id'], 'package_id' => $checkoutToken['package_details'][0]['package_id'], 'link' => $orderToken['link'], 'start_count' => $startCount, 'display_url' => $orderToken['display_url']],
                    "package_details" => $checkoutToken['package_details'][0],
                ];

                $url = env('WEB_URL') . '/checkout/' . generateAccessToken($checkoutConfig);
                apiResponse(200, 'Redirect to the url.', null, ['url' => $url]);

            } else
                apiResponse(401, 'Please provide correct order_token', 'order_token is missing.', null);

        } else {
            apiResponse(401, 'Provide a valid checkout_token', 'invalid checkout_token', null);
        }

    }

    public function placeOrder(Request $request)
    {
        $postData = $request->all();
        $checkoutToken = parseAccessToken($postData['checkout_token']);

        $txDataToInsert = [
            'tx_type' => 0, // 0=single order transaction 1=for subscriptions
            'tx_mode' => 0, // 0=paypal
            'transaction_id' => $postData['txn_id'],
            'user_id' => $checkoutToken['item_number']['id'],
            'amount' => $postData['payment_gross'],
            'payer_email' => $postData['payer_email'],
            'payment_status' => $postData['payment_status'],
            'pending_reason' => $postData['pending_reason'],
            'payment_type' => $postData['payment_type'],
            'item_desc' => $postData['item_name'],
            'item_link' => $checkoutToken['item_number']['link'],
            'extra_details' => $postData['custom'],
//            'order_id' => '',
//            'autolikes_id' => $postData['payer_email'],
//            'device_id' => $postData['payer_email'],
            'package_id' => $checkoutToken['package_details']['package_id'],
            'payment_time' => strtotime($postData['payment_date']),
        ];
        $insertedTx = Transaction::getInstance()->insertTransaction($txDataToInsert);

        if ($insertedTx) {

            $orderDataToInsert = [
                'user_id' => $checkoutToken['item_number']['id'],
                'tx_id' => $insertedTx,
                'package_id' => $checkoutToken['package_details']['package_id'],
                'order_url' => $checkoutToken['item_number']['link'],
                'url_type' => 1,
                'start_count' => $checkoutToken['item_number']['start_count'],
                'quantity' => $checkoutToken['package_details']['quantity'],
//            'comment_id' =>'',
                'start_time' => time(),
//            'orders_per_run' => '',
//            'time_interval' => '',
                'status' => 0,
                'added_time' => time(),
                'updated_time' => time()
            ];
            $orderAdded = Order::getInstance()->insertOrder($orderDataToInsert);
            if ($orderAdded)
                apiResponse(200, 'Order added successfully.', null, $orderAdded);
        } else {

        }
        apiResponse(200, 'Connection successful.', null, $insertedTx);

        apiResponse(200, 'Connection successful.', null, parseAccessToken($postData['checkout_token']));

    }

}