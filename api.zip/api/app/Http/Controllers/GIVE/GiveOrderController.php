<?php

namespace App\Http\Controllers\GIVE;
use App\Http\Controllers\InstagramScrape\InstagramScrapeController;
use App\Http\Models\Comments;
use App\Http\Models\Order;
use App\Http\Models\Package;
use App\Http\Models\Transaction;
use App\Http\Models\User;
use Firebase\JWT\JWT;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Validation\Rule;
use Laravel\Lumen\Routing\Controller as BaseController;

class GiveOrderController
{

    /**
     * @Desc placing order
     * @param Request $request
     * @return string
     * @since 03 feb 2018
     * @author Sibasankar Bhoi (sibasankarbhoi@globussoft.in)
     */
//    public function orderPlacing(Request $request)  //not in used
//    {
//        $rules = [
//            'tx_id' => 'required',
//            'package_id' => 'required|exists:packages,package_id',
//            'autolikes_id' => 'required',
//            'subscription_id' => 'required',
//            'order_url' => 'required',
//        ];
//        $message = [
//            'tx_id.required' => 'Enter tx_id ',
//            'package_id.unique' => 'enter package_id',
//            'autolikes_id.required' => 'Enter autolikes_id',
//            'subscription_id.required' => 'Enter subscription_id',
//            'order_url.required' => 'Enter Your order_url',
//        ];
//        $response = array('response' => '', 'Success' => false);
//        $validator = Validator::make($request->input(), $rules, $message);
//        if ($validator->fails()) {
//            return json_encode(['code' => 412, 'status' => 'Failed', 'message' => $validator->messages()]);
//        } else {
//            try {
//                $access_token = $request->all()['access-token'];
//                $data = $request->all();
//                $packageDetails = DB::table('packages')->where('package_id', $data['package_id'])->select('quantity', 'price', 'package_type')->first();
//                $key = "User access token";
//                $decoded = JWT::decode($access_token, $key, array('HS256'));     //  user details as a TOKEN
//                $regexr = "/^(http(s)?:\/\/)?(www\.)?((instagram)\.+)(com)(\/p\/)([a-zA-Z0-9]+\_*\-*[a-zA-Z0-9]*)(\/+)([?a-zA-Z0-9._~@,-=]*)$/";
//                $urlType = (preg_match($regexr, $data['order_url'])) ? 1 : 0;
//
//                $objInstagramScrape = new InstagramScrapeController();
//                if ($urlType == 0) {
//                    if ($packageDetails->package_type == 1) {      // for profile url only
//                        $str = substr($data['order_url'], strpos($data['order_url'], '.com/'));
//                        $substr = (substr($str, strlen('.com/')));
//                        $username = rtrim($substr, '/');
//
//                        $profile_details = $objInstagramScrape->instagramProfileDetails($username);
//                        $followed_by = $profile_details['followed_by'];
//                        $follows = $profile_details['follows'];
//                    } else {
//                        return json_encode(['code' => 401, 'status' => 'Failed', 'message' => 'please selcet correct package type']);
//                    }
//                } else {
//                    if ($packageDetails->package_type != 1) {     //for post url only
//                        $shortCode = $objInstagramScrape->extractContent($data['order_url'], '/p/', '/');
//                        $post_details = $objInstagramScrape->instagramLinkDetails($shortCode);
//                        $comments_count = $post_details['comments_count'];
//                        $likes_count = $post_details['likes_count'];
//                        $is_video = $post_details['is_video'];
//                    } else {
//                        return json_encode(['code' => 401, 'status' => 'Failed', 'message' => 'please selcet correct package type']);
//                    }
//                }
//                if (preg_match("/^(http(s)?:\/\/)?(www\.)?((instagram)\.+)(com)(\/p\/)([a-zA-Z0-9]+\_*\-*[a-zA-Z0-9]*)(\/+)([?a-zA-Z0-9._~@,-=]*)$/", $data['order_url'])) {
//                    $url_type = 0;
//                } elseif (preg_match("/^(http(s)?:\/\/)?(www\.)?((instagram)\.+)(com)(\/)([a-zA-Z0-9._^%$#!~@,-]*)(\/*)$/", $data['order_url'])) {
//                    $url_type = 1;
//                } else {
//                    return json_encode(['code' => 412, 'status' => 'Failed', 'message' => 'Please Enter a valid URL']);
//                }
//                $order_placingArr = array();
//                $order_placingArr['user_id'] = $decoded->user_id;
//                $order_placingArr['tx_id'] = $data['tx_id'];
//                $order_placingArr['package_id'] = $data['package_id'];
//                $packageDetails = DB::table('packages')->where('package_id', $data['package_id'])->select('quantity', 'price', 'package_type')->first();
//                if ($packageDetails == null) {
//                    return json_encode(['code' => 401, 'status' => 'Failed', 'message' => 'Package id is not found']);
//                }
//                $order_placingArr['autolikes_id'] = $data['autolikes_id'];tus
//                $order_placingArr['subscription_id'] = $data['subscription_id'];
//                $order_placingArr['order_url'] = $data['order_url'];
//                $order_placingArr['url_type'] = $url_type;
//                $order_placingArr['quantity'] = $packageDetails->quantity;
//                $order_placingArr['package_type'] = $packageDetails->package_type;
//                $order_placingArr['comment_id'] = $data['comment_id'];
//
//                if (isset($data['start_time']) && !empty($data['start_time'])) {
//                    $order_placingArr['start_time'] = $data['start_time'];
//                } else {
//                    $order_placingArr['start_time'] = time();
//                }
//                $order_placingArr['time_interval'] = $data['time_interval'];
//                $order_placingArr['orders_per_run'] = $data['orders_per_run'];
//                $order_placingArr['added_time'] = time();
//                $order_placingArr['updated_time'] = time();
//                $objmodeluser = Order::getInstance();
//                $placing_order = $objmodeluser->placingOrder($order_placingArr);
//
//                if ($url_type == 0) {
//                    echo json_encode(['code' => 200, 'status' => 'success', 'message' => 'Oeder placed success fully', 'order_id' => $placing_order, 'likes_count' => $likes_count, 'comments_count' => $comments_count, 'is_video' => $is_video]);
//                } elseif ($url_type == 1) {
//                    echo json_encode(['code' => 200, 'status' => 'success', 'message' => 'Oeder placed success fully', 'order_id' => $placing_order, 'followed_by' => $followed_by, 'follows' => $follows]);
//                }
//            } catch (\Exception $exc) {
//                dd($exc->getMessage());
//                echo json_encode(['code' => 412, 'status' => 'false', 'order_id' => 'Please Enter valid Token']);
//            }
//        }
//    }

    /**
     * @Desc place  orders for likes, comments, views, follows after transaction
     * @param Request $request
     * @since 03 feb 2018
     * @author Sibasankar Bhoi (sibasankarbhoi@globussoft.in)
     */
    public function GivePlaceOrders(Request $request)//not in used
    {
        try {
            $rules = [
                'tx_id' => 'required|exists:transactions,tx_id',
            ];
            $message = [
                'tx_id.exists' => 'This transaction is not completed'
            ];
            $validator = Validator::make($request->input(), $rules, $message);
            if ($validator->fails()) {
                return json_encode(['code' => 412, 'status' => 'Failed', 'message' => $validator->messages()]);
            } else
                $objmodeluser = Order::getInstance();
            $user_order_details = $objmodeluser->addOrdersLikes($request->all()['tx_id']);
            if (isset($user_order_details) && !empty($user_order_details)) {
                $regexr = "/^(http(s)?:\/\/)?(www\.)?((instagram)\.+)(com)(\/p\/)([a-zA-Z0-9]+\_*\-*[a-zA-Z0-9]*)(\/+)([?a-zA-Z0-9._~@,-=]*)$/";
                $urlType = (preg_match($regexr, $user_order_details->order_url)) ? 1 : 0;   // validating url type
                $objInstagramScrape = new InstagramScrapeController();

                $objplaceorder = new GiveOrderController();
                $packageDetails = DB::table('packages')->where('package_id', $user_order_details->package_id)->select('quantity', 'price', 'package_type')->first();
                if ($packageDetails == null) {
                    $this->apiError(404, 'package not found');

                } else
                    $package_type = $packageDetails->package_type;
                if ($packageDetails->package_type == 0) {
                    if ($urlType == 0) {
                        $this->apiError(405, 'Enter a valid post url');
                        die;
                    } else {
                        $shortCode = $objInstagramScrape->extractContent($user_order_details->order_url, '/p/', '/');
                        $post_details = $objInstagramScrape->instagramLinkDetails($shortCode);
                        $comments_count = $post_details['comments_count'];
                        $likes_count = $post_details['likes_count'];
                        $is_video = $post_details['is_video'];
                        $profile_details = $objplaceorder->Placeorder($user_order_details, $urlType, $package_type, $likes_count);
                    }

                } elseif ($packageDetails->package_type == 1) {     //for profile link
                    if ($urlType == 1) {
                        $this->apiError(405, 'Enter a valid profile URL');
                        die;
                    } else {
                        $str = substr($user_order_details->order_url, strpos($user_order_details->order_url, '.com/'));
                        $substr = (substr($str, strlen('.com/')));
                        $username = rtrim($substr, '/');

                        $profile_details = $objInstagramScrape->instagramProfileDetails($username);
                        $followed_by = $profile_details['followed_by'];
                        $follows = $profile_details['follows'];


                        $profile_details = $objplaceorder->Placeorder($user_order_details, $urlType, $package_type, $followed_by);
                    }
                } elseif ($packageDetails->package_type == 2) {
                    if ($urlType == 0) {
                        $this->apiError(405, 'Enter a valid post URL');
                        die;

                    } else {
                        $shortCode = $objInstagramScrape->extractContent($user_order_details->order_url, '/p/', '/');
                        $post_details = $objInstagramScrape->instagramLinkDetails($shortCode);
                        $comments_count = $post_details['comments_count'];
                        $likes_count = $post_details['likes_count'];
                        $is_video = $post_details['is_video'];
                        $profile_details = $objplaceorder->Placeorder($user_order_details, $urlType, $package_type, $comments_count);
                    }
                } elseif ($packageDetails->package_type == 3) {
                    if ($urlType == 0) {
                        echo json_encode(['code' => 401, 'status' => 'false', 'message' => 'Enter a valid post url']);
                        die;
                    } else {
                        $rules = ['comments' => 'required'];
                        $message = ['comments.required' => 'Please enter your comments'];
                        $validator = Validator::make($request->input(), $rules, $message);
                        if ($validator->fails()) {
                            return json_encode(['code' => 412, 'status' => 'Failed', 'message' => $validator->messages()]);
                        } else

                            $comments = $request->all()['comments'];
                        $objmodeluser = Comments::getInstance();
                        $comments = $objmodeluser->placeComments($comments, $user_order_details->user_id);

                        $shortCode = $objInstagramScrape->extractContent($user_order_details->order_url, '/p/', '/');
                        $post_details = $objInstagramScrape->instagramLinkDetails($shortCode);
                        $comments_count = $post_details['comments_count'];
                        $likes_count = $post_details['likes_count'];
                        $is_video = $post_details['is_video'];
                        $profile_details = $objplaceorder->Placeorder($user_order_details, $urlType, $package_type, $comments_count, $comments);
                    }
                } elseif ($packageDetails->package_type == 4) {
                    if ($urlType == 0) {
                        $this->apiError(405, 'Enter a valid post URL');
                        die;
                    } else {
                        $package_type = 4;


                        $shortCode = $objInstagramScrape->extractContent($user_order_details->order_url, '/p/', '/');
                        $post_details = $objInstagramScrape->instagramLinkDetails($shortCode);
                        $comments_count = $post_details['comments_count'];
                        $likes_count = $post_details['likes_count'];
                        $is_video = $post_details['is_video'];
                        $views_countr = $post_details['views_count'];

                        $profile_details = $objplaceorder->Placeorder($user_order_details, $urlType, $package_type, $views_countr);
                    }
                } elseif ($packageDetails->package_type == 5) {     //for profile link
                    if ($urlType == 1) {
                        $this->apiError(405, 'Enter a valid profile URL');
                        die;
                    } else {

                        $str = substr($user_order_details->order_url, strpos($user_order_details->order_url, '.com/'));
                        $substr = (substr($str, strlen('.com/')));
                        $username = rtrim($substr, '/');

                        $profile_details = $objInstagramScrape->instagramProfileDetails($username);
                        $start_count = 0;


                        $profile_details = $objplaceorder->Placeorder($user_order_details, $urlType, $package_type, $start_count);
                    }
                } elseif ($packageDetails->package_type == 6) {     //for profile link
                    if ($urlType == 1) {
                        $this->apiError(405, 'Enter a valid profile URL');
                        die;
                    } else {

                        $str = substr($user_order_details->order_url, strpos($user_order_details->order_url, '.com/'));
                        $substr = (substr($str, strlen('.com/')));
                        $username = rtrim($substr, '/');

                        $profile_details = $objInstagramScrape->instagramProfileDetails($username);
                        $start_count = 0;


                        $profile_details = $objplaceorder->Placeorder($user_order_details, $urlType, $package_type, $start_count);
                    }
                }

            } else {
                echo json_encode(['code' => 401, 'status' => 'false', 'message' => 'internal error, orderplacing']);
            }
        } catch (\Exception $exc) {
            dd($exc->getMessage());
            echo json_encode(['code' => 401, 'status' => 'false', 'message' => 'Please enter valid Token']);
        }
    }


    /**
     * @Desc function for storing data in order table after transaction done
     * @param $userDetails
     * @param $urlType
     * @param $package_type
     * @since 29 jan 2018
     * @author Sibasankar Bhoi (sibasankarbhoi@globussoft.in)
     */
    public function Placeorder($userDetails, $urlType, $package_type, $start_count, $comments = '')//not in used
    {
        try {
            $order_placingArr = array();
            $order_placingArr['user_id'] = $userDetails->user_id;
            $order_placingArr['tx_id'] = $userDetails->tx_id;
            $order_placingArr['package_id'] = $userDetails->package_id;
            $packageDetails = DB::table('packages')->where('package_id', $userDetails->package_id)->select('quantity', 'price', 'package_type')->first();
            $order_placingArr['order_url'] = $userDetails->order_url;
            $order_placingArr['url_type'] = $urlType;
            $order_placingArr['start_count'] = $start_count;
            $order_placingArr['quantity'] = $packageDetails->quantity;
            $order_placingArr['package_type'] = $packageDetails->package_type;
            if ($packageDetails->package_type == 3) {
                $order_placingArr['comment_id'] = $comments;
            }
            $order_placingArr['start_time'] = time();
            $order_placingArr['added_time'] = time();
            $order_placingArr['updated_time'] = time();
//            dd($order_placingArr);
            $order_placed = DB::table('orders')->insertGetId($order_placingArr);
            echo json_encode(['code' => 200, 'status' => 'success', 'message' => 'order placed succesfully', 'order_id' => $order_placed]);
        } catch (\Exception $exc) {
            dd($exc->getMessage());
        }
    }

    /**
     * @Desc fetching GIVE users order history
     * @Class orderHistory
     * @param Request $request
     * @since 05 feb 2018
     * @author Sibasankar Bhoi (sibasankarbhoi@globussoft.in)
     */
    public function GiveorderHistory(Request $request)
    {
        $access_token = ($request->header('access-token')) ? $request->header('access-token') : (($request->all()['access-token']) ? $request->all()['access-token'] : '');
        $key = env('JWT_KEY');               // create access TOKEN
        $decoded = JWT::decode($access_token, $key, array('HS256'));     //  user details as a TOKEN
        $objmodeluser = Order::getInstance();
        $user_order_history = $objmodeluser->orderHistory($decoded->user_id);    //get data from orders table

        try {
            $order_historyArr = array();
            $objplaceorder = new GiveOrderController();

            foreach ($user_order_history as $key => $history) {
                if ($history->status == 0) {
                    $history->status = 'Pending';
                } elseif ($history->status == 1) {
                    $history->status = 'Queue';
                } elseif ($history->status == 2) {
                    $history->status = 'Processing';
                } elseif ($history->status == 3) {
                    $history->status = 'Completed';
                } elseif ($history->status == 4) {
                    $history->status = 'Refunded';
                } elseif ($history->status == 5) {
                    $history->status = 'Cancled';
                } elseif ($history->status == 6) {
                    $history->status = 'Failed';
                }
                $findData = ['transaction_id'];

                $getTransactDetails = Transaction::getInstance()->getTransactionDetails([
                    'rawQuery' => 'tx_id = ?',
                    'bindParams' => [$history->tx_id]
                ], $findData);
                $date = date('d-m-Y', $history->added_time);
                $time = date('H:i:s', $history->added_time);
                if ($history->amount==0 or $history->amount==null){       // Amount free when order placed by free package
                    $history->amount='Free';
                }
                if ($request->all()['package_type'] == 2 or $request->all()['package_type'] == 3) {     // checking condition for comments

                    if ($history->package_type == 2 or $history->package_type == 3) { //for comments only 2 or 3
                        $objmodeluser = Order::getInstance();       //get user id from order
                        $username = $objmodeluser->getUsername($history->user_id);
                        $objmodeluser = Comments::getInstance();   //get comments
                        $getComments = $objmodeluser->getComments($history->comment_id);

                        $order_historyArr[$key]['order_id'] = $history->order_id;

                        $order_historyArr[$key]['user_id'] = $history->user_id;
                        $order_historyArr[$key]['user_name'] = $username->username;
                        if (isset($getTransactDetails[0]->transaction_id) && !empty($getTransactDetails[0]->transaction_id)){

                            $order_historyArr[$key]['tx_id'] = $getTransactDetails[0]->transaction_id;
                        }else{

                            $order_historyArr[$key]['tx_id'] = $history->tx_id;
                        }
                        $order_historyArr[$key]['date'] = $date;
                        $order_historyArr[$key]['time'] = $time;
                        $order_historyArr[$key]['package_id'] = $history->package_id;
                        $order_historyArr[$key]['package_type'] = $history->package_type;
                        $order_historyArr[$key]['order_url'] = $history->order_url;
                        $order_historyArr[$key]['quantity'] = $history->quantity;
                        $order_historyArr[$key]['amount'] = $history->amount;
                        if ($getComments) {
                            $order_historyArr[$key]['comments'] =explode("','",trim($getComments[0]->comments,'"[\'\']"'));
                        }
                        $order_historyArr[$key]['status'] = $history->status;
                        $order_historyArr[$key]['added_time_date'] = gmdate("m-d-Y", $history->added_time);
                        $added_time = $objplaceorder->convertUT($history->added_time);   // call function for get the timw interval
                        $order_historyArr[$key]['added_time_date'] = $added_time;
                    }
                }
                if ($history->package_type == $request->all()['package_type']) {

                    $objmodeluser = Order::getInstance();
                    $username = $objmodeluser->getUsername($history->user_id);

                    $order_historyArr[$key]['order_id'] = $history->order_id;
                    $order_historyArr[$key]['user_id'] = $history->user_id;
                    $order_historyArr[$key]['user_name'] = $username->username;
                    if (isset($getTransactDetails[0]->transaction_id) && !empty($getTransactDetails[0]->transaction_id)){

                        $order_historyArr[$key]['tx_id'] = $getTransactDetails[0]->transaction_id;
                    }else{

                        $order_historyArr[$key]['tx_id'] = $history->tx_id;
                    }
                    $order_historyArr[$key]['date'] = $date;
                    $order_historyArr[$key]['time'] = $time;
                    $order_historyArr[$key]['package_id'] = $history->package_id;
                    $order_historyArr[$key]['package_type'] = $history->package_type;
                    $order_historyArr[$key]['order_url'] = $history->order_url;
                    $order_historyArr[$key]['quantity'] = $history->quantity;
                    $order_historyArr[$key]['amount'] = $history->amount;
                    $order_historyArr[$key]['status'] = $history->status;
                    $order_historyArr[$key]['added_time_date'] = gmdate("m-d-Y", $history->added_time);
                    $added_time = $objplaceorder->convertUT($history->added_time);   // call function for get the timw interval
                    $order_historyArr[$key]['added_time_date'] = $added_time;
                }
            }
            if (isset($order_historyArr) && !empty($order_historyArr)) {
                echo json_encode(['code' => 200, 'status' => 'success', 'message' => 'order history fetched succesfully', 'data' => array_values($order_historyArr)]);
            } else
                apiResponse(401,'No order placed by this user',null,null);
//                $this->apiError(401, 'No order placed by this user');


        } catch (\Exception $exc) {

            dd($exc->getMessage());
            echo json_encode(['code' => 401, 'status' => 'False', 'message' => 'No order placed by this user']);
            die;
        }

    }

    /**
     * @Desc  get the exact time interval
     * @Class convertUT
     * @param $ptime
     * @return string
     * @since 31 jan 2018
     * @author Saurabh kumar
     */
    public function convertUT($ptime)
    {
        $difftime = time() - $ptime;


        if ($difftime < 1) {
            return '0 seconds';
        }

        $timeArr = array(365 * 24 * 60 * 60 => 'year',
            30 * 24 * 60 * 60 => 'month',
            24 * 60 * 60 => 'day',
            60 * 60 => 'hour',
            60 => 'minute',
            1 => 'second'
        );
        $timePluralArr = array('year' => 'years',
            'month' => 'months',
            'day' => 'days',
            'hour' => 'hours',
            'minute' => 'minutes',
            'second' => 'seconds'
        );

        foreach ($timeArr as $secs => $str) {
            $d = $difftime / $secs;
            if ($d >= 1) {
                $r = round($d);
                return $r . ' ' . ($r > 1 ? $timePluralArr[$str] : $str);
            }
        }
    }

    /**
     * @Desc add order for followers,likes,views and comment
     * @param Request $request
     * @author Sibasankar Bhoi (sibasankarbhoi@globussoft.in)
     * @since 21-June-2018
     */

    public function addOrder(Request $request)
    {
        $key = env('JWT_KEY');               // create access TOKEN
        if (isset($request->all()['order_token']) && !empty($request->all()['order_token'])) {

            $order_token = $request->all()['order_token'];
            $data1 = JWT::decode($order_token, $key, array('HS256'));
        }
        $access_token = $request->all()['access_token'];
        $data = JWT::decode($access_token, $key, array('HS256'));
        $access_token = [];
        $access_token['users_id'] = $data->id;
        $access_token['users_name'] = $data->username;
        if (isset($data1) && !empty($data1)) {
            if (isset($data1->link) && !empty($data1->link)) {
                $access_token['media_image_url'] = $data1->link;
                $access_token['media_profile_url'] = $data1->display_url;
            }else{
                $access_token['media_image_url'] = $data1->media_url;
                $access_token['media_image_url'] = $data1->media_image_url;
            }

        }
        $objmodeluser = Package::getInstance();
        $packageDetails = $objmodeluser->packageDetails($request->all()['package_id']);     //to fetch the package details
        if ($packageDetails[0]->package_type == 2 or $packageDetails[0]->package_type == 3) {       //for comments order

            $rules = [
                'order_token' => 'required',
            ];
            $message = [
                'order_token.required' => 'Please enter order_token',
            ];
            $response = array('response' => '', 'Success' => false);
            $validator = Validator::make($request->input(), $rules, $message);
            if ($validator->fails()) {
                $errMsg = json_decode($validator->messages(), true);
                apiResponse(400, 'Validation error', array_values($errMsg)[0][0], null);
            }

            $packageDetails = $objmodeluser->packageDetails($request->all()['package_id']);         //get package details
            if (count($packageDetails) > 0) {
                if (isset($request->all()['comments']) && !empty($request->all()['comments'])) {
                    $comments_count = explode(',', $request->all()['comments']);
                    if ($packageDetails[0]->quantity <= count($comments_count)) {
                        $array = explode(' ', $request->all()['comments']);
                        $order_token = [];
                        if (isset($request->all()['username']) && !empty($request->all()['username'])){
                            $order_token['username'] = $request->all()['username'];      //for follower
                        }
                        $access_token = [];
                        $access_token['users_id'] = $data->user_id;
                        if (isset($data1->link) && !empty($data1->link)){
                            $access_token['media_url'] = $data1->link;
                            $access_token['media_image_url'] = $data1->display_url;
                            $access_token['comments_count'] = $data1->comments_count;
                        }else{
                            $access_token['media_url'] = $data1->media_url;
                            $access_token['media_image_url'] = $data1->media_image_url;
                            $access_token['comments_count'] = $data1->comments_count;

                        }
                        $access_token['comments'] = $request->all()['comments'];
                        $checkout_token = AccessTokenforGive_Gilr(array_merge($order_token, json_decode(json_encode($packageDetails[0]), true), $access_token));
                        echo json_encode(['code' => 200, 'message' => 'generate token successfully', 'url' => env('WEB_URL').'/gilr/checkout/' . $checkout_token]);
                        die;
                    } else
                        echo json_encode(['code' => 400, 'message' => 'Please add more comments']);
                    die;
                } else
                    echo json_encode(['code' => 400, 'message' => 'Please enter comments']);
                die;
            }
        }

        if (count($packageDetails) > 0) {        // for likes order
            $price = $packageDetails[0]->price;
            $quantity = $packageDetails[0]->quantity;
            if ($packageDetails[0]->package_type == 1 or $packageDetails[0]->package_type == 5 or $packageDetails[0]->package_type == 6) {       //check for followers, live videos and story views order

                $rules = [
                    'followers_order_token' => 'required',
                ];
                $message = [
                    'followers_order_token.followers_order_token' => 'Please enter followers_order_token',
                ];
                $response = array('response' => '', 'Success' => false);
                $validator = Validator::make($request->input(), $rules, $message);
                if ($validator->fails()) {
                    $errMsg = json_decode($validator->messages(), true);
                    apiResponse(400, 'Validation error', array_values($errMsg)[0][0], null);
                }
                $followers_order_token=$request->all()['followers_order_token'];
                $data_for_followers = JWT::decode($followers_order_token, $key, array('HS256'));
//                chcking users exist or not
//                $result = $this->curlUsingGet('https://instagram.com/' . $request->all()['username']);
//                    $profileDetails = explode('window._sharedData = ', $result);
//                        $profileDetailsJson = explode(';</script>', $profileDetails[1]);
//                        $profileDetailsArr = json_decode($profileDetailsJson[0], TRUE);
//                        if(!$profileDetailsArr['entry_data']&& empty($profileDetailsArr['entry_data'])){
//                            apiResponse(400, 'User not found', 'Invalid User', null);
//
//                        }

            }

            if (isset($request->all()['followers_order_token']) && !empty($request->all()['followers_order_token'])) {    //for follower order only
                $order_token = [];
//                $order_token['username'] = $request->all()['username'];
                $username = substr($data_for_followers->link, strrpos($data_for_followers->link, '/') + 1);
                $order_token['username'] = $username;
                $order_token['display_url'] = $data_for_followers->display_url;
                $order_token['followers_count'] = $data_for_followers->followers_count;
                $order_token['full_name'] = $data_for_followers->full_name;
                $order_token['isPrivate'] = $data_for_followers->isPrivate;
                $order_token['following'] = $data_for_followers->following;
                //chcking users exist

//                $result = $this->curlUsingGet('https://instagram.com/' . $request->all()['username']);
//                $profileDetails = explode('window._sharedData = ', $result);
//                $profileDetailsJson = explode(';</script>', $profileDetails[1]);
//                $profileDetailsArr = json_decode($profileDetailsJson[0], TRUE);
//                if(!$profileDetailsArr['entry_data']&& empty($profileDetailsArr['entry_data'])){
//                    apiResponse(400, 'User not found', 'Invalid User', null);
//                }
                $checkout_token = AccessTokenforGive_Gilr(array_merge($order_token, json_decode(json_encode($packageDetails[0]), true), $access_token));
                echo json_encode(['code' => 200, 'message' => 'generate token successfully', 'url' => env('WEB_URL').'/gilr/checkout/' . $checkout_token]);
                die;
                //****response url will go to web users module paymentcontroller****

            }

            $checkout_token = AccessTokenforGive_Gilr(array_merge(parseAccessTokenforGive_Gilr($order_token), json_decode(json_encode($packageDetails[0]), true), $access_token));
            echo json_encode(['code' => 200, 'message' => 'generate token successfully', 'url' =>env('WEB_URL').'/gilr/checkout/' . $checkout_token]);
        } else {
            apiResponse(400, 'package not found', null, null);
        }
    }

    /**
     * @Desc   Error response Function
     * @param $code
     * @param $msg
     * @since 11 jan 2018
     * @author Sibasankar Bhoi (sibasankarbhoi@globussoft.in)
     */
    public function apiError($code, $msg)
    {
        header('Content-Type: application/json');
        http_response_code($code);
        echo json_encode(['code' => $code, 'status' => 'failed', 'message' => $msg, 'data' => null]);
        die;
    }
    public function curlUsingGet($url, $headers = '')
    {

        ini_set('max_execution_time', 600);

        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        if (!empty($headers))
            curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
        curl_setopt($ch, CURLOPT_VERBOSE, 1);
        $curl_scraped_page = curl_exec($ch);
//        if (isset($headers) && !empty($headers)){
//            dd($headers,$curl_scraped_page);
//        }
        if (curl_errno($ch) > 0) {
            print_r(curl_error($ch));
        }
        curl_close($ch);
        return $curl_scraped_page;
    }


}


?>
