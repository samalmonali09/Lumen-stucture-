<?php

namespace App\Http\Controllers\GIVE;

use App\Http\Controllers\InstagramScrape\InstagramScrapeController;
use App\Http\Models\Package;
use App\Http\Models\Service;
use App\User;
use Firebase\JWT\JWT;
use Illuminate\Database\DetectsDeadlocks;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;

class GiveUserdetailsController
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        //
    }



    /**
     * @Desc checking user account and followers
     * @Class checkUser
     * @param Request $request
     * @since 13 jan 2018
     * @author Sibasankar Bhoi (sibasankarbhoi@globussoft.in)
     */
    public function checkuserAccount(Request $request)
    {

        $name = $request->all()['username'];
        ini_set('memory_limit', '1024M');

        $result = $this->curlUsingGet('https://instagram.com/' . $name);

        if ($result != '' || $result != null) {
            $profileDetails = explode('window._sharedData = ', $result);
            if (count($profileDetails) > 1) {
                $profileDetailsJson = explode(';</script>', $profileDetails[1]);
                $profileDetailsArr = json_decode($profileDetailsJson[0], TRUE);
                if (isset($profileDetailsArr['entry_data']['ProfilePage']) && !empty($profileDetailsArr['entry_data']['ProfilePage'])) {
                    $result = $profileDetailsArr['entry_data']['ProfilePage'][0];
                    $objmodeluser = Service::getInstance();
                    $userDetails = $objmodeluser->getaccountDetails($result);
                    $userDetails['followers_order_token'] = AccessTokenforGive_Gilr(
                        [
                            'link' => 'https://www.instagram.com/' . $name,
                            'display_url' => $userDetails['profile_image'],
                            'full_name' => $userDetails['full_name'],
                            'isPrivate' => $userDetails['isPrivate'],
                            'following' => $userDetails['following'],
                            'followers_count' => convertNumberIntoProperNotation($userDetails['followed_by'])
                        ]
                    );
                    $mediaDetailsArr = [];
                    if (isset($request->all()['is_video']) && !empty($request->all()['is_video'])){

                        $is_video = $request->all()['is_video'];

                        if ($is_video == true) {
                            foreach ($result ['graphql']['user']['edge_owner_to_timeline_media']['edges'] as $key => $media) {
                                if ($media["node"]["is_video"] == 'true') {


                                    if (isset($media['node']['thumbnail_resources'][2]['src']) && !empty($media['node']['thumbnail_resources'][2]['src'])) {
                                        $mediaDetailsArr[$key]['media_image_url'] = $media['node']['thumbnail_resources'][2]['src'];
                                    } else {
                                        $mediaDetailsArr[$key]['media_image_url'] = $media["node"]["thumbnail_src"];
                                    }
                                    $mediaDetailsArr[$key]['comments_count'] = convertNumberIntoProperNotation($media["node"]["edge_media_to_comment"]["count"]);
                                    $mediaDetailsArr[$key]['likes_count'] = convertNumberIntoProperNotation($media["node"]["edge_media_preview_like"]['count']);
                                    $mediaDetailsArr[$key]['is_video'] = $media["node"]["is_video"];
                                    if ($mediaDetailsArr[$key]['is_video'] == true) {
                                        $mediaDetailsArr[$key]['video_view_count'] = convertNumberIntoProperNotation($media["node"]["video_view_count"]);
                                    }
                                    $mediaDetailsArr[$key]['media_url'] = 'https://instagram.com/p/' . $media["node"]["shortcode"];
                                    $mediaDetailsArr[$key]['order_token'] = AccessTokenforGive_Gilr($mediaDetailsArr[$key]);
                                }
                            }
                        }
                    }
                    else
                        foreach ($result ['graphql']['user']['edge_owner_to_timeline_media']['edges'] as $key => $media) {
                            if (isset($media['node']['thumbnail_resources'][2]['src']) && !empty($media['node']['thumbnail_resources'][2]['src'])) {
                                $mediaDetailsArr[$key]['media_image_url'] = $media['node']['thumbnail_resources'][2]['src'];
                            } else {
                                $mediaDetailsArr[$key]['media_image_url'] = $media["node"]["thumbnail_src"];
                            }
                            $mediaDetailsArr[$key]['comments_count'] = convertNumberIntoProperNotation($media["node"]["edge_media_to_comment"]["count"]);
                            $mediaDetailsArr[$key]['likes_count'] = convertNumberIntoProperNotation($media["node"]["edge_media_preview_like"]['count']);
                            $mediaDetailsArr[$key]['is_video'] = $media["node"]["is_video"];
                            if ($mediaDetailsArr[$key]['is_video'] == true) {
                                $mediaDetailsArr[$key]['video_view_count'] = convertNumberIntoProperNotation($media["node"]["video_view_count"]);
                            }
                            $mediaDetailsArr[$key]['media_url'] = 'https://instagram.com/p/' . $media["node"]["shortcode"];
                            $mediaDetailsArr[$key]['order_token'] = AccessTokenforGive_Gilr($mediaDetailsArr[$key]);
                        }


                    $mediaDetailsArr1 = array_values($mediaDetailsArr);
                    $media=[];
                    $media['media']=$mediaDetailsArr1;
                    $data = array_merge($userDetails, $media);
//                    array_push($mediaDetailsArr1, $userDetails);

                    return json_encode(['code' => 200, 'status' => 'success', 'message' => 'пользователь существует', 'data' => $data]);

//                    dd($data);
                } else

                    apiResponse('401', 'User is not found', 'null', 'null');


            }
            else
                apiResponse('401', 'User not found', 'null', 'null');
        }
        return null;
    }

    public function curlUsingGet($url, $headers = '')
    {

        ini_set('max_execution_time', 600);

        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        if (!empty($headers))
            curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
        curl_setopt($ch, CURLOPT_VERBOSE, 1);
        $curl_scraped_page = curl_exec($ch);
//        if (isset($headers) && !empty($headers)){
//            dd($headers,$curl_scraped_page);
//        }
        if (curl_errno($ch) > 0) {
            print_r(curl_error($ch));
        }
        curl_close($ch);
        return $curl_scraped_page;
    }


    /**
     * @Desc   check user name exist or not
     * @Class usernameExist
     * @param Request $request
     * @return string
     * @since 14 jan 2018
     * @author Sibasankar Bhoi (sibasankarbhoi@globussoft.in)
     */
    public function usernameExist(Request $request)
    {
        $rules = [
            'username' => 'required',
        ];
        $message = [
            'username.required' => 'Please Enter Your User Name',
        ];
        $response = array('response' => '', 'Success' => false);
        $validator = Validator::make($request->input(), $rules, $message);
        if ($validator->fails()) {
            $this->apiError('412', $validator->messages());

//            return json_encode(['code' => 100, 'status' => 'Failed', 'message' => $validator->messages()]);
        } else {


            $name = $request->all()['username'];
            ini_set('memory_limit', '1024M');

            $result = $this->curlUsingGet('https://instagram.com/' . $name);

            if ($result != '' || $result != null) {
                $profileDetails = explode('window._sharedData = ', $result);
                if (count($profileDetails) > 1) {
                    $profileDetailsJson = explode(';</script>', $profileDetails[1]);
                    $profileDetailsArr = json_decode($profileDetailsJson[0], TRUE);
                    if (isset($profileDetailsArr['entry_data']['ProfilePage']) && !empty($profileDetailsArr['entry_data']['ProfilePage'])) {
                        $result = $profileDetailsArr['entry_data']['ProfilePage'][0];

                        $objmodeluser = Service::getInstance();
                        $checkuser = $objmodeluser->getaccountDetails($result);
                    } else

                        apiResponse('401', 'User name does not exist', 'null', 'null');


                }
                return null;
            }
            return null;
        }
    }


    /**
     * @Desc fetching media details with comments, likes
     * @Class getmediaDetails
     * @param Request $request
     * @return string
     * @since 16 jan 2018
     * @author Sibasankar Bhoi (sibasankarbhoi@globussoft.in)
     */
    public function getmediaDetails(Request $request)
    {
        $user_id = $request->all()['id'];
        $end_cursor = $request->all()['end_cursor'];
        try {
            $mediaDetailsArr = $allMediaDetail = [];
            getNewData:
            $details_url = 'https://www.instagram.com/graphql/query/?query_id=17888483320059182&variables={"id":' . $user_id . ',"first":20,"after":"' . $end_cursor . '"}';
            $headers = [
                'Host: www.instagram.com',
                'User-Agent: Mozilla/5.0 (Windows NT 6.1; WOW64; rv:42.0) Gecko/20100101 Firefox/42.0',
                'Accept: */*',
                'Accept-Language: en-US,en;q=0.5',
                'X-Requested-With: XMLHttpRequest',
                'Referer: https://www.instagram.com/',
                'Cookie: mid=W8XhWwAEAAEyWZ8bo9DK6ocVWtqW; mcd=3; csrftoken=VpvKEuwvXiEiHD7va2fRA3dmF9ZRmDji; fbm_124024574287414=base_domain=.instagram.com; shbid=11308; ds_user_id=6451482720; sessionid=6451482720%3AMFedIMc7yvk5fP%3A9; rur=PRN; urlgen="{\"103.217.90.98\": 133255}:1gEu4J:0UXPvwIEEWTM-7W-EpUEsn_Ei_I"; fbsr_124024574287414=bPTBfniqK87M6bAP7Y9kZOE12x5q9gCOIbKaR52dWRc.eyJhbGdvcml0aG0iOiJITUFDLVNIQTI1NiIsImNvZGUiOiJBUUFJYnhxeGIxOVZDUmdDYVAzZHNOd1ZVX0o0Q2FOZXZZOGRQSHFuMjNzSDJmUDRhVFllVEU4TjBLcG1uZWkyNkh0QnJSeC16Y1M2VUZXMkZmTG9KeTFIeUQtbEt2TzdSQ2V3VF85WC1GcktDV1Z0dlVlU2c1NENleGZhWFFtVzg4U1A1OFg0R0JHd0drQll3UkdrT2xyS2Y1Ty1ma2k4ekxGbk1nVVZKTnhCLURWWTF6RnIzaURNOVNid1duLVNEdldnVUt2RlIybEhheDA1eWp2cFBVeGcxSUJDZnd1M2pJWjdTb1VMcFNsZkRpem1aMFdPeWhGdjc0TF9CYmpOX0RZNThIeUpsQ215M1F2STFxVEhXRndsd1pMY3Y3bUhILVFoS0FWeGVJd1dlWW0wTHdwTTFhTEZVU1NsbDg1SkJSZ19LeU5JcFpjVTR3Sks4Y0Z0N2pfVyIsImlzc3VlZF9hdCI6MTU0MDI5MDk4NSwidXNlcl9pZCI6IjEwMDAxNDgzOTIxNjY4NyJ9',
                'Connection: keep-alive'
            ];
            $mediaDetails = $this->curlUsingGet($details_url, $headers);
            $data_details = json_decode($mediaDetails, true);
            if ($data_details['data']['user'] == null) {

                apiResponse(401, 'User not found', null, null);
            }

            $end_cursor = $data_details["data"]["user"]["edge_owner_to_timeline_media"]["page_info"]["end_cursor"];
            $has_next = $data_details["data"]["user"]["edge_owner_to_timeline_media"]["page_info"]["has_next_page"];

//        if ($end_cursor == null) {
//            apiResponse(412, 'Enter correct end_cursor', 'ig token has expired', null);
//        }


            if (isset($request->all()['is_video']) && !empty($request->all()['is_video'])) {

                $is_video = $request->all()['is_video'];
                if ($is_video == 'true') {
                    foreach ($data_details['data']['user'] ["edge_owner_to_timeline_media"]["edges"] as $key => $media) {
                        if ($media["node"]["is_video"] == true) {
                            if (isset($media['node']['thumbnail_resources'][2]['src']) && !empty($media['node']['thumbnail_resources'][2]['src'])) {
                                $mediaDetailsArr[$key]['media_image_url'] = $media['node']['thumbnail_resources'][2]['src'];
                            } else {
                                $mediaDetailsArr[$key]['media_image_url'] = $media["node"]["thumbnail_src"];
                            }
                            $mediaDetailsArr[$key]['comments_count'] = convertNumberIntoProperNotation($media["node"]["edge_media_to_comment"]["count"]);
                            $mediaDetailsArr[$key]['likes_count'] = convertNumberIntoProperNotation($media["node"]["edge_media_preview_like"]['count']);
                            $mediaDetailsArr[$key]['is_video'] = $media["node"]["is_video"];
                            if ($mediaDetailsArr[$key]['is_video'] == true) {
                                $mediaDetailsArr[$key]['video_view_count'] = convertNumberIntoProperNotation($media["node"]["video_view_count"]);
                            }
                            $mediaDetailsArr[$key]['media_url'] = 'https://instagram.com/p/' . $media["node"]["shortcode"];
                            $mediaDetailsArr[$key]['order_token'] = AccessTokenforGive_Gilr($mediaDetailsArr[$key]);
                            $allMediaDetail[] = $mediaDetailsArr[$key];
                        }
                    }
                }
            } else {
                foreach ($data_details['data']['user'] ["edge_owner_to_timeline_media"]["edges"] as $key => $media) {
                    if (isset($media['node']['thumbnail_resources'][2]['src']) && !empty($media['node']['thumbnail_resources'][2]['src'])) {
                        $mediaDetailsArr[$key]['media_image_url'] = $media['node']['thumbnail_resources'][2]['src'];
                    } else {
                        $mediaDetailsArr[$key]['media_image_url'] = $media["node"]["thumbnail_src"];
                    }
                    $mediaDetailsArr[$key]['comments_count'] = convertNumberIntoProperNotation($media["node"]["edge_media_to_comment"]["count"]);
                    $mediaDetailsArr[$key]['likes_count'] = convertNumberIntoProperNotation($media["node"]["edge_media_preview_like"]['count']);
                    $mediaDetailsArr[$key]['is_video'] = $media["node"]["is_video"];
                    if ($mediaDetailsArr[$key]['is_video'] == true) {
                        $mediaDetailsArr[$key]['video_view_count'] = convertNumberIntoProperNotation($media["node"]["video_view_count"]);
                    }
                    $mediaDetailsArr[$key]['media_url'] = 'https://instagram.com/p/' . $media["node"]["shortcode"];
                    $mediaDetailsArr[$key]['order_token'] = AccessTokenforGive_Gilr($mediaDetailsArr[$key]);
                    $allMediaDetail[] = $mediaDetailsArr[$key];
                }


            }
            if (count($allMediaDetail) <= 12 && $end_cursor) {
                goto getNewData;
            }

            if (!$has_next)
                $end_cursor = null;
            return json_encode([
                'code' => 200,
                'status' => 'success',
                'message' => 'Media fetched successfully',
                'has_next' => $has_next,
                'end_cursor' => $end_cursor,
                'data' => $allMediaDetail,
            ]);


        } catch (\Exception $exc) {
            dd($exc->getMessage());
        }


//    } else{                                           // response for if no media found
//return json_encode(['code' => 200,
//'status' => 'success',
//'message' => 'fetched succesfully, No media found',
//'data' => null]);

    }

    /**
     * @Desc check free package, after sign up user get a free package
     * @Class freepackage
     * @since 16 jan 2018
     * @author Sibasankar Bhoi (sibasankarbhoi@globussoft.in)
     */
    public function freepackage(Request $request)
    {
        try {
            $key = env('JWT_KEY');               // create access TOKEN

//            if (isset($order_token) && !empty($order_token)){
//
//                $order_token = $request->all()['order_token'];
//                $decoded = JWT::decode($order_token, $key, array('HS256'));
//            }

            $access_token = ($request->header('access-token')) ? $request->header('access-token') : (($request->all()['access-token']) ? $request->all()['access-token'] : '');
            $decoded2 = JWT::decode($access_token, $key, array('HS256'));     //  user details as a TOKEN
            $ip_address = $request->ip();
            $findData = ['ip_address'];
            $getTransactiiomDetails = \App\Http\Models\Transaction::getInstance()->getTransactionDetails([    //get package id
                'rawQuery' => 'user_id = ? and amount=?',
                'bindParams' => [$decoded2->user_id, 'freePackage']
            ], $findData);
            if (count($getTransactiiomDetails) > 0 && $getTransactiiomDetails[0]->ip_address == $ip_address) {
                apiResponse(401, 'User has allready taken free package', 'ip_address is same', null);
            }
            if (isset($request->all()['package_type']) && !empty($request->all()['package_type'])){
                $package_type=$request->all()['package_type'];
            }else
                $package_type=0;
            if (isset($order_token) && !empty($order_token)){

                $order_token = $request->all()['order_token'];
                $decoded = JWT::decode($order_token, $key, array('HS256'));
                $token = array(
                    "media_url" => $decoded->media_url,
                    "likes_count" => $decoded->likes_count,
                    "created_time" => $decoded2->created_time,
                    "email" => $decoded2->email,
                    "user_id" => $decoded2->user_id,
                    "user_name" => $decoded2->user_name,
                    "iat" => $decoded2->iat,
                    "register_through" => $decoded2->register_through,
                    "ip_address" => $ip_address,
                    "package_type" => $package_type
                );
                $access_token = JWT::encode($token, $key);
                $decoded1 = JWT::decode($access_token, $key, array('HS256'));     // sending user details as a TOKEN
            }
//            $token = array(
//                "media_url" => $decoded->media_url,
//                "likes_count" => $decoded->likes_count,
//                "created_time" => $decoded2->created_time,
//                "email" => $decoded2->email,
//                "user_id" => $decoded2->user_id,
//                "user_name" => $decoded2->user_name,
//                "iat" => $decoded2->iat,
//                "register_through" => $decoded2->register_through,
//                "ip_address" => $ip_address,
//                "package_type" => $package_type
//            );
//            $access_token = JWT::encode($token, $key);
//            $decoded1 = JWT::decode($access_token, $key, array('HS256'));     // sending user details as a TOKEN

            $userdetails = DB::table('users')->where('email', $decoded2->email)->first();
            $username = $userdetails->username;
            $objmodeluser = Service::getInstance();    //checking free package status
            $freepackage = $objmodeluser->checkfreePackage($username, $access_token);
//            $ratedAppfreepackage = $objmodeluser->ratedAppfreepackage($username);
        } catch (\Exception $exc) {
            dd($exc->getMessage());
            apiResponse(401, 'Please Enter valid Token', 'Invalid Token', null);

        }
    }


    /**
     * @Desc checking free packages after rated APP
     * @Class ratedAppfreepackage
     * @param Request $request
     * @return string
     * @since 17 jan 2018
     * @author Sibasankar Bhoi (sibasankarbhoi@globussoft.in)
     */
//    public function ratedappPackage(Request $request)
//    {
//        try {
//            $access_token = ($request->header('access-token')) ? $request->header('access-token') : (($request->all()['access-token']) ? $request->all()['access-token'] : '');
//            $key = env('JWT_KEY');
//            $decoded = JWT::decode($access_token, $key, array('HS256'));     //  user details as a TOKEN
//            $ip_address = $request->ip();
//
//
//            $userdetails = DB::table('users')->where('id', $decoded->user_id)->first();
//            if ($userdetails && !empty($userdetails)) {
//                if ($userdetails->user_free_package == 0) {
//                    if (isset($request->all()['order_token']) && !empty($request->all()['order_token'])) {
//                        $decode_order_token = JWT::decode($request->all()['order_token'], $key, array('HS256'));     //  order details as a TOKEN
//                        $findData = ['ip_address'];
//
//                        $getTransactiiomDetails = \App\Http\Models\Transaction::getInstance()->getTransactionDetails([    //get package id
//                            'rawQuery' => 'user_id = ? and amount=?',
//                            'bindParams' => [$decoded->user_id, 'freePackage']
//                        ], $findData);
//                        if (count($getTransactiiomDetails) > 0 && $getTransactiiomDetails[0]->ip_address == $ip_address) {
//                            apiResponse(401, 'User has allready taken free package', 'ip_address is same', null);
//                        }
//                        $token = array(
//                            "media_url" => $decode_order_token->media_url,
//                            "likes_count" => $decode_order_token->likes_count,
//                            "created_time" => $decoded->created_time,
//                            "email" => $decoded->email,
//                            "user_id" => $decoded->user_id,
//                            "user_name" => $decoded->user_name,
//                            "iat" => $decoded->iat,
//                            "register_through" => $decoded->registered_through,
//                            "ip_address" => $ip_address,
//                            "device_id" => $decoded->device_id,
//                            "package_type" => $request->all()['package_type'],
//                            "user_free_package" => 1                //status changed to 2 after get free likes
//                        );
//                        $order_token = JWT::encode($token, $key);
//                        $order_token_decode = JWT::decode($order_token, $key, array('HS256'));
//
//                        $objmodeluser = Service::getInstance();    //checking free package status
//                        $ratedAppfreepackage = $objmodeluser->ratedAppfreepackage($userdetails->id, $order_token);
//
//                    } else
//                        apiResponse(200, 'user can get the free package', null, 'please provide Order token and package type for get free package');
//
//                }
//                if ($userdetails->rated_app == 1) {
//                    if (isset($request->all()['order_token']) && !empty($request->all()['order_token'])) {
//                        $decode_order_token = JWT::decode($request->all()['order_token'], $key, array('HS256'));     //  order details as a TOKEN
//                        $token = array(
//                            "media_url" => $decode_order_token->media_url,
//                            "likes_count" => $decode_order_token->likes_count,
//                            "created_time" => $decoded->created_time,
//                            "email" => $decoded->email,
//                            "user_id" => $decoded->user_id,
//                            "user_name" => $decoded->user_name,
//                            "iat" => $decoded->iat,
//                            "register_through" => $decoded->registered_through,
//                            "ip_address" => $ip_address,
//                            "device_id" => $decoded->device_id,
//                            "package_type" => $request->all()['package_type'],
//                            "rated_app" => 2                //status changed to 2 after get free likes
//                        );
//                        $objmodeluser = \App\Http\Models\User::getInstance();    //checking free package status
//
//                        $update_status = $objmodeluser->updateUserDetails(['rawQuery' => 'id = ?', 'bindParams' => [$userdetails->id]], ['rated_app' => 1]);
//
//                        $order_token = JWT::encode($token, $key);
//                        $order_token_decode = JWT::decode($order_token, $key, array('HS256'));
//
//                        $objmodeluser = Service::getInstance();    //checking free package status
//                        $ratedAppfreepackage = $objmodeluser->ratedAppfreepackage($userdetails->id, $order_token);
//
//                    } else
//                        apiResponse(200, 'userd can get the free package after rate the app', 'user has not rate the app', 'please provide Order token and package type for get free package');
//
//
//                }if($userdetails->rated_app == 0){
//
//                    apiResponse(401, 'Please rate the App you will get a free package ', null, null);
//
//                }
//                else
//                    apiResponse(401, 'User has taken all free packages', null, null);
//
//            } else {
//                apiResponse(401, 'user not found', null, null);
//            }
//
//        } catch (\Exception $exc) {
//            dd($exc);
//            echo json_encode(['code' => 401, 'status' => 'false', 'message' => 'Please Enter valid Token']);
//        }
//    }
    public function ratedappPackage(Request $request)
    {
        try {
            $rules = ['device_id' => 'required',
                'access-token' => 'required'
                ];
            $message = [
                'device_id.required' => 'Please Enter Device_id',
                'access-token.required' => 'Please Enter Access token',
            ];
            $response = array('response' => '', 'Success' => false);
            $validator = Validator::make($request->input(), $rules, $message);
            if ($validator->fails()) {
                $errMsg = json_decode($validator->messages(), true);
                apiResponse(412, array_values($errMsg)[0][0],'Validation Error', null);
            }
            $access_token = ($request->header('access-token')) ? $request->header('access-token') : (($request->all()['access-token']) ? $request->all()['access-token'] : '');
            $key = env('JWT_KEY');
            $decoded = JWT::decode($access_token, $key, array('HS256'));     //  user details as a TOKEN
            $ip_address = $request->ip();
            $device_id=$request->all()['device_id'];
            if (isset($request->all()['package_type']) && !empty($request->all()['package_type'])) {

            $findpackage = ['package_id'];     // checking packge existance
            $getPackage = Package::getInstance()->getPackageDetails([
                'rawQuery' => 'price = ? and package_type = ? and package_for=?',
                'bindParams' => [0, $request->all()['package_type'],3]
            ], $findpackage);
            if (count($getPackage) == 0) {
                apiResponse(401, 'Currently No Package found for Free Likes', null, null);
            }
        }
            $userdetails = DB::table('users')->where('id', $decoded->user_id)->first();
            if ($userdetails && !empty($userdetails)) {
                if ($userdetails->user_free_package == 0) {
                    $findData = ['ip_address','device_id'];
                    $getTransactiiomDetails = \App\Http\Models\Transaction::getInstance()->getTransactionDetails([   //checking ip and device id for duplicate order
                        'rawQuery' => 'user_id = ? and transaction_id=?',
                        'bindParams' => [$decoded->user_id, 'Free Package']
                    ], $findData);
                    if (count($getTransactiiomDetails) > 0){
                        if ($getTransactiiomDetails[0]->ip_address == $ip_address or $getTransactiiomDetails[0]->device_id==$device_id) {
                            apiResponse(401, 'Free Likes has already been taken by this device', 'ip_address or Device id is same', null);
                        }
                    }
                    $check_device_id = \App\Http\Models\Transaction::getInstance()->getTransactionDetails([    //checking ip and device id for duplicate order
                        'rawQuery' => 'device_id = ? and transaction_id=?',
                        'bindParams' => [$device_id, 'Free Package']
                    ], $findData);
                    if (count($check_device_id) > 0){
                        if ( $check_device_id[0]->device_id==$device_id) {
                            apiResponse(401, 'Free Likes has already been taken by this device', 'ip_address or Device id is same', null);
                        }
                    }
                    if (isset($request->all()['order_token']) && !empty($request->all()['order_token'])) {
                        $decode_order_token = JWT::decode($request->all()['order_token'], $key, array('HS256'));     //  order details as a TOKEN
                        $token = array(
                            "media_url" => $decode_order_token->media_url,
                            "likes_count" => $decode_order_token->likes_count,
                            "created_time" => $decoded->created_time,
                            "email" => $decoded->email,
                            "user_id" => $decoded->user_id,
                            "user_name" => $decoded->user_name,
                            "iat" => $decoded->iat,
                            "register_through" => $decoded->registered_through,
                            "ip_address" => $ip_address,
                            "device_id" => $device_id,
                            "transaction_id" => 'Free Package',
                            "package_for" => 3,
                            "package_type" => $request->all()['package_type'],
                            "user_free_package" => 1                //status changed to 2 after get free likes
                        );
                        $order_token = JWT::encode($token, $key);
                        $order_token_decode = JWT::decode($order_token, $key, array('HS256'));

                        $objmodeluser = Service::getInstance();    //checking free package status
                        $ratedAppfreepackage = $objmodeluser->ratedAppfreepackage($userdetails->id, $order_token);

                    } else
                        apiResponse(200, 'user can get the free package', null, 'please provide Order token and package type for get free package');

                }
                if ($userdetails->rated_app == 1) {
                    if (isset($request->all()['order_token']) && !empty($request->all()['order_token'])) {
                        $decode_order_token = JWT::decode($request->all()['order_token'], $key, array('HS256'));     //  order details as a TOKEN
                        $token = array(
                            "media_url" => $decode_order_token->media_url,
                            "likes_count" => $decode_order_token->likes_count,
                            "created_time" => $decoded->created_time,
                            "email" => $decoded->email,
                            "user_id" => $decoded->user_id,
                            "user_name" => $decoded->user_name,
                            "iat" => $decoded->iat,
                            "register_through" => $decoded->registered_through,
                            "ip_address" => $ip_address,
                            "transaction_id" => 'Rated App Free Package',
                            "device_id" => $device_id,
                            "package_for" => 3,
                            "package_type" => $request->all()['package_type'],
                            "rated_app" => 2                //status changed to 2 after get free likes
                        );
                        $objmodeluser = \App\Http\Models\User::getInstance();    //checking free package status

                        $update_status = $objmodeluser->updateUserDetails(['rawQuery' => 'id = ?', 'bindParams' => [$userdetails->id]], ['rated_app' => 1]);

                        $order_token = JWT::encode($token, $key);
                        $order_token_decode = JWT::decode($order_token, $key, array('HS256'));

                        $objmodeluser = Service::getInstance();    //checking free package status
                        $ratedAppfreepackage = $objmodeluser->ratedAppfreepackage($userdetails->id, $order_token);

                    } else
                        apiResponse(200, 'User can get the free package ', null, 'please provide Order token and package type for get rate app free package');


                }if($userdetails->rated_app == 0){

                    apiResponse(401, 'Please rate the App you will get a free package ', null, null);

                }
                else
                    apiResponse(401, 'User has taken all free packages', null, null);

            } else {
                apiResponse(401, 'user not found', null, null);
            }

        } catch (\Exception $exc) {
            dd($exc);
            echo json_encode(['code' => 401, 'status' => 'false', 'message' => 'Please Enter valid Token']);
        }
    }

    public function mediaViews(Request $request)
    {
        $rules = ['username' => 'required'];
        $message = ['username.required' => 'Please Enter Your User Name'];
        $response = array('response' => '', 'Success' => false);
        $validator = Validator::make($request->input(), $rules, $message);
        if ($validator->fails()) {
            return json_encode(['code' => 412, 'status' => 'Failed', 'message' => $validator->messages()]);
        } else
            $name = $request->all()['username'];
        if (isset($request->all()['end_cursor'])) {
            $end_cursor = $request->all()['end_cursor'];
        }
        ini_set('memory_limit', '1024M');

        $result = $this->curlUsingGet('https://instagram.com/' . $name);
        if ($result != '' || $result != null) {
            $profileDetails = explode('window._sharedData = ', $result);
            if (count($profileDetails) > 1) {
                $profileDetailsJson = explode(';</script>', $profileDetails[1]);
                $profileDetailsArr = json_decode($profileDetailsJson[0], TRUE);
                if (isset($profileDetailsArr['entry_data']['ProfilePage']) == true) {
                    $insta_user_id = $profileDetailsArr['entry_data']['ProfilePage'][0];

                    if ($insta_user_id['graphql']['user']['is_private'] == true) {     //checking account is private
                        apiResponse(412, 'User account is private', 'private account', null);
                    }
                    $post_count = $insta_user_id['graphql']['user']['edge_owner_to_timeline_media']['count'];
                    if ($post_count == 0) {
                        apiResponse(412, 'No post found for this user', 'No post found for this user', null);

                    }
                    $user_id = $insta_user_id['graphql']["user"]["id"];

                    if ($user_id == null) {                        //checking condition user exist or not
                        return json_encode([
                            'code' => 412,
                            'status' => 'false',
                            'message' => 'user not found, please enter correct user name',
                            'data' => null
                        ]);
                    } elseif ($user_id) {
                        if (isset($request->all()['end_cursor'])) {
                            $details_url = 'https://www.instagram.com/graphql/query/?query_id=17888483320059182&variables={"id":' . $user_id . ',"first":50,"after":"' . $end_cursor . '"}';
                        } else
                            $details_url = 'https://www.instagram.com/graphql/query/?query_id=17888483320059182&variables={"id":' . $user_id . ',"first":50,"after":""}';
                        $headers = [
                            'Host: www.instagram.com',
                            'User-Agent: Mozilla/5.0 (Windows NT 6.1; WOW64; rv:42.0) Gecko/20100101 Firefox/42.0',
                            'Accept: */*',
                            'Accept-Language: en-US,en;q=0.5',
                            'X-Requested-With: XMLHttpRequest',
                            'Referer: https://www.instagram.com/',
                            'Cookie: csrftoken=qbTNq6vwTqOJzhljrwxnrrut1QfsthTK; mid=W035-gAEAAHHcCdPzv6RFDhwQir6; rur=ASH; mcd=3; urlgen="{\"time\": 1531889539\054 \"103.217.90.103\": 135183}:1ffhLN:LktR9tSV19PbdTKBvSCqK13PZbM"; shbid=11308; ds_user_id=6451482720; sessionid=IGSC3e1850ed608894af9555fa73403369ae7151395e5da9ecda74583269fdac10cb%3AZ5og86A422zNJoLWCp0df3b9PHkxm89L%3A%7B%22_auth_user_id%22%3A6451482720%2C%22_auth_user_backend%22%3A%22accounts.backends.CaseInsensitiveModelBackend%22%2C%22_auth_user_hash%22%3A%22%22%2C%22_platform%22%3A4%2C%22_token_ver%22%3A2%2C%22_token%22%3A%226451482720%3AY63CrDZDXCDeEcDAO35qjucKnXsPI2aE%3A84f336f936c463806865bd440c7cac13770f430feda1419483a4e0013a4c80ef%22%2C%22last_refreshed%22%3A1531889578.2035582066%7D',
                            'Connection: keep-alive'
                        ];
                        $mediaDetails = $this->curlUsingGet($details_url, $headers);
                        $data_details = json_decode($mediaDetails, true);
                        $end_cursor = $data_details["data"]["user"]["edge_owner_to_timeline_media"]["page_info"]["end_cursor"];
                        $has_next = $data_details["data"]["user"]["edge_owner_to_timeline_media"]["page_info"]["has_next_page"];

                        if ($end_cursor == null) {
                            apiResponse(412, 'Enter correct end_cursor', 'end_cursor not valid', null);
                        }

                        $mediaDetailsArr = [];
                        foreach ($data_details['data']['user'] ["edge_owner_to_timeline_media"]["edges"] as $key => $media) {
                            if ($media["node"]["is_video"] == true) {

                                $mediaDetailsArr[$key]['media_image_url'] = $media["node"]["thumbnail_src"];
                                $mediaDetailsArr[$key]['comments_count'] = $media["node"]["edge_media_to_comment"]["count"];
                                $mediaDetailsArr[$key]['likes_count'] = $media["node"]["edge_media_preview_like"]['count'];
                                $mediaDetailsArr[$key]['is_video'] = $media["node"]["is_video"];
                                if ($mediaDetailsArr[$key]['is_video'] == true) {
                                    $mediaDetailsArr[$key]['video_view_count'] = $media["node"]["video_view_count"];
                                }
                                $mediaDetailsArr[$key]['media_url'] = 'https://instagram.com/p/' . $media["node"]["shortcode"];
                                $mediaDetailsArr[$key]['order_token'] = AccessTokenforGive_Gilr($mediaDetailsArr[$key]);

                            }
                        }

                        $res = [];
                        foreach ($mediaDetailsArr as $key => $value) {
                            $res[] = $value;
                        }
                        $mediaDetailsArr = (array($mediaDetailsArr));
                        if (!$has_next)
                            $end_cursor = null;
                        return json_encode([
                            'code' => 200,
                            'status' => 'success',
                            'message' => 'users media fetched succesfully',
                            'has_next' => $has_next,
                            'end_cursor' => $end_cursor,
                            'data' => $res
                        ]);
                    } else {                                           // response for if no media found
                        return json_encode([
                            'code' => 200,
                            'status' => 'success',
                            'message' => 'fetched succesfully, No media found',
                            'data' => null
                        ]);
                    }


                } else apiResponse('401', 'user not found', null, null);

            }
        }
        return null;
    }

    /**
     * @Desc error response function
     * @Class apiError
     * @param $code
     * @param $msg
     * @since 17 jan 2018
     * @author Sibasankar Bhoi (sibasankarbhoi@globussoft.in)
     */
    public function apiError($code, $msg)
    {
        header('Content-Type: application/json');
        http_response_code($code);
        echo json_encode(['code' => $code, 'status' => 'failed', 'message' => $msg, 'data' => null]);
        die();
    }

    public function rateApp(Request $request)     //on hit user will rate the app and status will be 1
    {

        $access_token = ($request->header('access-token')) ? $request->header('access-token') : (($request->all()['access-token']) ? $request->all()['access-token'] : '');
        $key = env('JWT_KEY');
        $decoded = JWT::decode($access_token, $key, array('HS256'));     //  user details as a TOKEN
        $userdetails = DB::table('users')->where('id', $decoded->user_id)->first();
        if ($userdetails->rated_app == 0) {
            $objmodeluser = \App\Http\Models\User::getInstance();    //checking free package status

            $update_status = $objmodeluser->updateUserDetails(['rawQuery' => 'id = ?', 'bindParams' => [$userdetails->id]], ['rated_app' => 1]);
            if ($update_status){
                apiResponse('200', 'You have Sucessfully Rate the App', null, null);
            }
        }else{
            apiResponse('401', 'You have Alredy Rate the App', null, null);

        }

    }



    /**
     * @Desc:moduleDetails
     * @since 11/9/2018
     * @author Monali Samal (monalisamal@globussoft.in)
     */
    public function moduleDetails()
    {
        $moduleDetails = config('module_switch.module_switch_status');

        $data = [];
        if($moduleDetails === "ON"){
            $data['blackhat_module'] = "ON";
            $data['banner_url'] = env('WEB_URL') . '/' . config('whitebanner.banner_img_url');
        }else{
            $data['blackhat_module'] = "OFF";
        }
        http_response_code(200);
        echo json_encode(['code' => 200, 'status' => 'success', 'message' => 'Module details for get instant views english.', 'data' => $data]);
        die();


    }
}


