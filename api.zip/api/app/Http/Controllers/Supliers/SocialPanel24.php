<?php

namespace App\Http\Controllers\Supliers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;


class SocialPanel24
{

    /**
     * @Desc increase users story viewers
     * @Class storyViews
     * @param Request $request
     * @return string
     * @since 06 feb 2018
     * @author Sibasankar Bhoi (sibasankarbhoi@globussoft.in)
     */
    public function storyViews(Request $request)
    {

        $rules = [
            'key' => 'required',
            'action' => 'required',
            'service' => 'required',
            'link' => 'required',
            'quantity' => 'required|numeric|min:100',
        ];
        $message = [
            'key.required' => 'Please Enter Key',
            'action.required' => 'Please Enter Action',
            'service.required' => 'Please Enter Service ID',
            'link.required' => 'Please Enter your profile link',
            'quantity.required' => 'Please Enter Views Quantity',

        ];
        $response = array('response' => '', 'Success' => false);
        $validator = Validator::make($request->input(), $rules, $message);
        if ($validator->fails()) {
            return json_encode(['code' => 412, 'status' => 'Failed', 'message' => $validator->messages()]);
        } else {
            $data = [];
            $data['key'] = $request->all()['key'];
            $data['action'] = $request->all()['action'];
            $data['service'] = $request->all()['service'];
            $data['link'] = $request->all()['link'];
            $data['quantity'] = $request->all()['quantity'];
            if (isset($request->all()['runs'])) {
                $data['runs'] = $request->all()['runs'];
            }
            if (isset($request->all()['interval'])) {
                $data['interval'] = $request->all()['interval'];
            }
            $data['quantity'] = $request->all()['quantity'];
            $this->placeOrder($data);
        }


    }


    /**
     * @Desc increase user live video viewers
     * @Class liveVideoViews
     * @param Request $request
     * @return string
     * @since 6 fev 2018
     * @author Sibasankar Bhoi (sibasankarbhoi@globussoft.in)
     */
    public function liveVideoViews(Request $request)
    {
        $rules = [
            'key' => 'required',
            'action' => 'required',
            'service' => 'required',
            'link' => 'required',
            'quantity' => 'required|numeric|min:100',
        ];
        $message = [
            'key.required' => 'Please Enter Key',
            'action.required' => 'Please Enter Action',
            'service.required' => 'Please Enter Service ID',
            'link.required' => 'Please Enter your profile link',
            'quantity.required' => 'Please Enter Views Quantity',
        ];
        $response = array('response' => '', 'Success' => false);
        $validator = Validator::make($request->input(), $rules, $message);
        if ($validator->fails()) {
            return json_encode(['code' => 412, 'status' => 'Failed', 'message' => $validator->messages()]);
        } else {
            $data = [];
            $data['key'] = $request->all()['key'];
            $data['action'] = $request->all()['action'];
            $data['service'] = $request->all()['service'];
            $data['link'] = $request->all()['link'];
            $data['quantity'] = $request->all()['quantity'];
            if (isset($request->all()['runs'])) {
                $data['runs'] = $request->all()['runs'];
            }
            if (isset($request->all()['interval'])) {
                $data['interval'] = $request->all()['interval'];
            }
            $data['quantity'] = $request->all()['quantity'];
            $this->placeOrder($data);
        }
    }


    public function placeOrder($data)
    {
        dd($data);
//
//        $url = 'http://socialpanel24.com/api/v2';
//        $handle = curl_init($url);
//        curl_setopt($handle, CURLOPT_POST, true);
//        curl_setopt($handle, CURLOPT_POSTFIELDS, $data);
//        curl_exec($handle);
//        curl_close($handle);


    }


}


?>
