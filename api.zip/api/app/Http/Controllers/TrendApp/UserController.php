<?php

namespace App\Http\Controllers\TrendApp;


use App\Http\Models\User;
use App\Http\Models\Banner;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\App;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;
use Illuminate\Validation\Rule;
use Intervention\Image\Facades\Image as Image;
use Laravel\Lumen\Routing\Controller;

class UserController extends Controller
{

    protected $response;
    protected $objModelUser;

    public function __construct()
    {
        $this->response = new \stdClass();
        $this->objModelUser = new User();
    }

// banner hastag
    public function adBanner(Request $request)
    {
        if ($request->isMethod('post')) {


            $availableDeviceType = [1, 2];
            if ($request->input('device_type') && in_array($request['device_type'], $availableDeviceType)) {

                $objBannerModal = new Banner();
                $whereForUpdate = ['rawQuery' => 'banner_device = ? and banner_for =?', 'bindParams' => [$request->input('device_type'), 8]];
                $bannerDetails = $objBannerModal->getOneBannerDetails($whereForUpdate);
                $bannerDetails = json_decode(json_encode($bannerDetails), true);

                if ($bannerDetails) {
                    return json_encode(['code' => 200, 'message' => 'Banner details for trending app.', 'banner_image' => env('WEB_URL') . $bannerDetails['banner_image'], 'banner_url' => $bannerDetails['banner_url']]);
//                    return json_encode(['code' => 200, 'message' => 'Banner details for trending app.', 'banner_image' => env('WEB_URL') . $bannerDetails['banner_image']]);
                } else {
                    return json_encode(['code' => 400, 'message' => 'No banner found for trending app.', 'data' => null]);
                }
            } else
                return json_encode(['code' => 400, 'message' => 'device_type is missing or invalid.', 'data' => null]);
        } else {
            return json_encode(['code' => 400, 'message' => 'Error.', 'data' => null]);
        }
    }






    public function TrendingMessage()
    {
        $module = config('Trending_flashnews.flashnews');
        if ($module === 'ON')
            apiResponse('200', 'message is on ', null, ['message' => 1,'url'=>'http://gaia.globusdemos.com/flash_messageTrend.html']);
        else
            apiResponse('400', 'message is off', null, ['message' => 0,'url'=>'']);
    }



//    public function TrendingMessage()
//    {
//        $module = config('Trending_flashnews.flashnews');
//        if ($module === 'ON')
//            return json_encode(['code'=>200,'message' => 'on','url'=>'http://gaia.globusdemos.com/flash_messageTrend.html']);
//        else
//            return json_encode(['code'=>400,'message' => 'off','url'=>'']);
//    }
//

}