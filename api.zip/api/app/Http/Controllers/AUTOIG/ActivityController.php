<?php

namespace App\Http\Controllers\AUTOIG;

use App\Http\Models\DBClass;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use Illuminate\Validation\Rule;
use Laravel\Lumen\Routing\Controller;


class ActivityController extends Controller
{
    protected $_db;

    public function __construct()
    {
        $this->_db = DBClass::getInstance();
    }


    /* GILR */
    public function storeUserActivities(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'message' => 'required'
        ]);
        if (!$validator->fails()) {
            $postParams = $request->all();

            $validParams = ['device_id', 'user_id', 'message', 'email', 'username'];
            $wrongParams = array_diff(array_keys($postParams), $validParams);
            if (empty($wrongParams)) {
                $message = json_decode($postParams['message'], true);
                $message = array_reverse($message);
                unset($postParams['message']);
                if (!empty($message) && is_array($message)) {

                    if (isset($postParams['device_id']) && trim($postParams['device_id']) != "") {

                        $activities = $this->_db->selectQuery('activities', ['rawQuery' => 'device_id = ?', 'bindParams' => [$postParams['device_id']]]);

                        if (empty($activities)) {
                            /* Insert */
                            $dataToInsert = array_merge($postParams, ['message' => json_encode($message), 'created_at' => time(), 'updated_at' => time()]);
                            $inserted = $this->_db->insert('activities', $dataToInsert);
                            if ($inserted)
                                apiResponse(200, 'Activity has been recorded', null, $inserted);
                            else
                                apiResponse(400, 'Something went wrong.', null, null);
                        } else {
                            $activities = $activities[0];
                            $prevMsg = json_decode($activities['message'], true);
                            $message = array_merge($message, $prevMsg);
                            if (count($message) > 2000) {
                                $message = array_slice($message, 0, 2000);
                            }
                            $dataToUpdate = array_merge($postParams, ['message' => json_encode($message), 'updated_at' => time()]);
                            $updated = $this->_db->updateQuery('activities', ['rawQuery' => 'device_id = ?', 'bindParams' => [$postParams['device_id']]], $dataToUpdate);
                            if ($updated)
                                apiResponse(200, 'Activity has been recorded', null, null);
                            else
                                apiResponse(400, 'Something went wrong.', null, null);
                        }
                    } else if (isset($postParams['user_id']) && trim($postParams['user_id']) != "") {

                        $activities = $this->_db->selectQuery('activities', ['rawQuery' => 'user_id = ?', 'bindParams' => [$postParams['user_id']]]);

                        if (empty($activities)) {
                            /* Insert */
                            unset($postParams['message']);
                            $dataToInsert = array_merge($postParams, ['message' => json_encode($message), 'created_at' => time(), 'updated_at' => time()]);
                            $inserted = $this->_db->insert('activities', $dataToInsert);
                            if ($inserted)
                                apiResponse(200, 'Activity has been recorded', null, $inserted);
                            else
                                apiResponse(400, 'Something went wrong.', null, null);
                        } else {
                            $activities = $activities[0];
                            $prevMsg = json_decode($activities['message'], true);
                            $message = array_merge($message, $prevMsg);
                            if (count($message) > 2000) {
                                $message = array_slice($message, 0, 2000);
                            }
                            $dataToUpdate = array_merge($postParams, ['message' => json_encode($message), 'updated_at' => time()]);
                            $updated = $this->_db->updateQuery('activities', ['rawQuery' => 'user_id = ?', 'bindParams' => [$postParams['user_id']]], $dataToUpdate);
                            if ($updated)
                                apiResponse(200, 'Activity has been recorded', null, null);
                            else
                                apiResponse(400, 'Something went wrong.', null, null);
                        }
                    } else {
                        /* Insert */
                        $dataToInsert = array_merge($postParams, ['message' => json_encode($message), 'created_at' => time(), 'updated_at' => time()]);
                        $inserted = $this->_db->insert('activities', $dataToInsert);
                        if ($inserted)
                            apiResponse(200, 'Activity has been recorded', null, $inserted);
                        else
                            apiResponse(400, 'Something went wrong.', null, null);
                    }

                } else
                    apiResponse(400, 'Messages are empty or not in proper format.', null, null);


            } else {
                apiResponse(400, reset($wrongParams) . ' is a wrong param, please correct it.', 'wrong param', null);
            }

        } else {
            $errMsg = json_decode($validator->messages(), true);
            apiResponse(412, array_values($errMsg)[0][0], 'Validation error', null);
        }


    }

    /* AUTOIG */
    public function storeUserActivitiesAutoig(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'message' => 'required'
        ]);
        if (!$validator->fails()) {
            $postParams = $request->all();

            $validParams = ['device_id', 'user_id', 'message', 'email', 'username'];
            $wrongParams = array_diff(array_keys($postParams), $validParams);
            if (empty($wrongParams)) {
                $message = json_decode($postParams['message'], true);
                $message = array_reverse($message);
                unset($postParams['message']);
                if (!empty($message) && is_array($message)) {

                    if (isset($postParams['device_id']) && trim($postParams['device_id']) != "") {

                        $activities = $this->_db->selectQuery('activities_autoig', ['rawQuery' => 'device_id = ?', 'bindParams' => [$postParams['device_id']]]);

                        if (empty($activities)) {
                            /* Insert */
                            $dataToInsert = array_merge($postParams, ['message' => json_encode($message), 'created_at' => time(), 'updated_at' => time()]);
                            $inserted = $this->_db->insert('activities_autoig', $dataToInsert);
                            if ($inserted)
                                apiResponse(200, 'Activity has been recorded', null, $inserted);
                            else
                                apiResponse(400, 'Something went wrong.', null, null);
                        } else {
                            $activities = $activities[0];
                            $prevMsg = json_decode($activities['message'], true);
                            $message = array_merge($message, $prevMsg);
                            if (count($message) > 1000) {
                                $message = array_slice($message, 0, 1000);
                            }
                            $dataToUpdate = array_merge($postParams, ['message' => json_encode($message), 'updated_at' => time()]);
                            $updated = $this->_db->updateQuery('activities_autoig', ['rawQuery' => 'device_id = ?', 'bindParams' => [$postParams['device_id']]], $dataToUpdate);
                            if ($updated)
                                apiResponse(200, 'Activity has been recorded', null, null);
                            else
                                apiResponse(400, 'Something went wrong.', null, null);
                        }
                    } else if (isset($postParams['user_id']) && trim($postParams['user_id']) != "") {

                        $activities = $this->_db->selectQuery('activities_autoig', ['rawQuery' => 'user_id = ?', 'bindParams' => [$postParams['user_id']]]);

                        if (empty($activities)) {
                            /* Insert */
                            unset($postParams['message']);
                            $dataToInsert = array_merge($postParams, ['message' => json_encode($message), 'created_at' => time(), 'updated_at' => time()]);
                            $inserted = $this->_db->insert('activities_autoig', $dataToInsert);
                            if ($inserted)
                                apiResponse(200, 'Activity has been recorded', null, $inserted);
                            else
                                apiResponse(400, 'Something went wrong.', null, null);
                        } else {
                            $activities = $activities[0];
                            $prevMsg = json_decode($activities['message'], true);
                            $message = array_merge($message, $prevMsg);
                            if (count($message) > 2000) {
                                $message = array_slice($message, 0, 2000);
                            }
                            $dataToUpdate = array_merge($postParams, ['message' => json_encode($message), 'updated_at' => time()]);
                            $updated = $this->_db->updateQuery('activities_autoig', ['rawQuery' => 'user_id = ?', 'bindParams' => [$postParams['user_id']]], $dataToUpdate);
                            if ($updated)
                                apiResponse(200, 'Activity has been recorded', null, null);
                            else
                                apiResponse(400, 'Something went wrong.', null, null);
                        }
                    } else {
                        /* Insert */
                        $dataToInsert = array_merge($postParams, ['message' => json_encode($message), 'created_at' => time(), 'updated_at' => time()]);
                        $inserted = $this->_db->insert('activities_autoig', $dataToInsert);
                        if ($inserted)
                            apiResponse(200, 'Activity has been recorded', null, $inserted);
                        else
                            apiResponse(400, 'Something went wrong.', null, null);
                    }

                } else
                    apiResponse(400, 'Messages are empty or not in proper format.', null, null);


            } else {
                apiResponse(400, reset($wrongParams) . ' is a wrong param, please correct it.', 'wrong param', null);
            }

        } else {
            $errMsg = json_decode($validator->messages(), true);
            apiResponse(412, array_values($errMsg)[0][0], 'Validation error', null);
        }


    }

}