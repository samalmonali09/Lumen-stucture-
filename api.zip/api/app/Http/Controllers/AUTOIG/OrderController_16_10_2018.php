<?php namespace App\Http\Controllers\AUTOIG;

use App\Http\Controllers\CommonAPI\Instagram_scrape;
use App\Http\Controllers\InstagramScrape\InstagramScrapeController;
use App\Http\Models\Comments;
use App\Http\Models\DBClass;
use App\Http\Models\Order;
use App\Http\Models\Transaction;
use Illuminate\Http\Request;
use Laravel\Lumen\Routing\Controller;

class OrderController extends Controller
{

    protected $objInstagramScrapeController;
    protected $instaScrape, $_apiToken, $availablePackageType;

    public function __construct()
    {
        $this->objInstagramScrapeController = new InstagramScrapeController();
        $this->instaScrape = new Instagram_scrape();
        $this->_apiToken = env('API_TOKEN_AUTOIG');
        $this->availablePackageType = ['likes' => 0, 'followers' => 1, 'comments' => 3, 'views' => 4];
    }

    public function instantLikesFlashnews()
    {
        $msg_status = config('instant_likes_flashnews.flashnews');
        $module_status = config('instant_likes_flashnews.module_status');
        if ($module_status == 2) {
            $banner_img_url = config('instant_likes_flashnews.banner_img_url');
        } else
            $banner_img_url = config('instant_likes_flashnews.banner_img_url_dynamic');

//        $img_dimenssion = config('flash_message.img_dimenssion');

        if ($msg_status == 'OFF') {
            apiResponse(400, "Flash news is temporarily off", null, ['module_status' => $module_status,
                'banner_img_url' => env('APP_URL') . $banner_img_url]);
        } else {
            apiResponse(200, "Flash news is ON",
                null,
                ['content' => env('WEB_URL') . '/assets/flashnews.html',
                    'module_status' => $module_status,
                    'banner_img_url' => env('APP_URL') . $banner_img_url]);

        }

    }

    public function getInstantLikesFlashnews()
    {
        $msg_status = config('instant_likes_flashnews.flashnews');
        $module_status = config('instant_likes_flashnews.module_status');
        if ($module_status == 2) {
            $banner_img_url = config('instant_likes_flashnews.banner_img_url');
        } else
            $banner_img_url = config('instant_likes_flashnews.banner_img_url_dynamic');

//        $img_dimenssion = config('flash_message.img_dimenssion');

        if ($msg_status == 'OFF') {
            apiResponse(400, "Flash news is temporarily off", null, ['module_status' => $module_status,
                'banner_img_url' => env('APP_URL') . $banner_img_url]);
        } else {
            apiResponse(200, "Flash news is ON",
                null,
                ['content' => env('WEB_URL') . '/assets/flashnews.html',
                    'module_status' => $module_status,
                    'banner_img_url' => env('APP_URL') . $banner_img_url]);

        }

    }

    public function flashNews()
    {
        apiResponse(200, "Flash news", null, ['content' => "http://gaia.globusdemos.com/assets/flashnews.html"]);
    }

    public function verifyInstaUsername(Request $request)
    {
        if (!empty($request->input('api_token'))) {

            if ($request['api_token'] == $this->_apiToken) {

                if (!empty($request->input('insta_username'))) {

                    if ($request->input('is_video') && $request['is_video'] === "true") {
                        $details = json_decode($this->instaScrape->getProfileDetails($request['insta_username'], "video"), true);
                        $details['response']['has_next_page'] = false;
                        $details['response']['end_cursor'] = null;
                    } else
                        $details = json_decode($this->instaScrape->getProfileDetails($request['insta_username']), true);

                    if ($request->input('autolikes') && $request['autolikes'] === "true") {
                        //fetch the niche details
                        $_db = DBClass::getInstance();
                        $nicheDetails = $_db->selectQuery('niches', ['rawQuery' => 'status = 1'], ['niche']);

                        if ($details['code'] == 200) {
                            if (!empty($nicheDetails) && is_array($nicheDetails)) {
                                $niches = array_map(function ($n) {
                                    return $n['niche'];
                                }, $nicheDetails);
                                $details['response']['niche'] = "on";
                                $details['response']['niches'] = $niches;
                            } else {
                                $details['response']['niche'] = "off";
                            }
                        }
                    }

                    if ($details['code'] == 200)
                        apiResponse(200, 'Instagram profile details', null, $details['response']);
                    else if ($details['code'] == 400)
                        apiResponse(400, $details['response'], 'Username may be private or doesn\'t exist.', null);
                    else
                        apiResponse(400, 'Something went wrong, please try again.', 'error in fetching profile details', null);
                } else
                    apiResponse(412, 'Please provide the insta_username.', 'Instagram username is missing.', null);

            } else {
                apiResponse(401, 'Provide a valid api token', 'invalid api_token', null);
            }
        } else {
            apiResponse(401, 'Please provide a api token.', 'api_token is missing.', null);
        }

    }

    public function getAllMedia(Request $request)
    {
        if (!empty($request->input('api_token'))) {

            if ($request['api_token'] == $this->_apiToken) {

                if (!empty($request->input('insta_username'))) {
                    $details = $this->objInstagramScrapeController->getAllMedia($request['insta_username'], 12, 'video');

                    if ($details)
                        apiResponse(200, 'Instagram profile details', null, $details);
                    else
                        apiResponse(400, 'Something went wrong, please try again.', 'error in fetching profile details', null);
                } else
                    apiResponse(412, 'Please provide the id.', 'id is missing.', null);

            } else {
                apiResponse(401, 'Provide a valid checkout_token', 'invalid checkout_token', null);
            }
        } else {
            apiResponse(401, 'Please provide a api token.', 'api_token is missing.', null);
        }
    }

    public function getMediaDetailsOLD(Request $request)
    {
        if (!empty($request->input('api_token'))) {

            if ($request['api_token'] == $this->_apiToken) {

                if (!empty($request->input('id'))) {

                    if (!empty($request->input('end_cursor'))) {

                        $length = ($request->input('length')) ? $request['length'] : 12;

                        $details = $this->instaScrape->getMoreMediaDetails($request['id'], $length, $request['end_cursor']);

                        if ($details)
                            apiResponse(200, 'Instagram media details', null, $details);
                        else
                            apiResponse(400, 'Something went wrong, please try again.', 'error in fetching profile details', null);
                    } else
                        apiResponse(412, 'Please provide the end_cursor.', 'end_cursor is missing.', null);
                } else
                    apiResponse(412, 'Please provide the id.', 'id is missing.', null);

            } else {
                apiResponse(401, 'Provide a valid checkout_token', 'invalid checkout_token', null);
            }
        } else {
            apiResponse(401, 'Please provide a api token.', 'api_token is missing.', null);
        }
    }

    public function getMediaDetails(Request $request)
    {
        if (!empty($request->input('api_token'))) {

            if ($request['api_token'] == $this->_apiToken) {

                if (!empty($request->input('id'))) {


                    $length = ($request->input('length')) ? $request['length'] : 12;

                    if ($request->input('is_video') && $request['is_video'] === "true") {

                        $end_cursor = ($request->input('end_cursor')) ? $request['end_cursor'] : "";
                        $details = $this->instaScrape->getMoreMediaDetails($request['id'], $length, $end_cursor, "video");

                    } else if (!empty($request->input('end_cursor'))) {

                        $details = $this->instaScrape->getMoreMediaDetails($request['id'], $length, $request['end_cursor']);

                    } else
                        apiResponse(412, 'Please provide the end_cursor.', 'end_cursor is missing.', null);

                    if ($details)
                        apiResponse(200, 'Instagram media details', null, $details);
                    else
                        apiResponse(400, 'Something went wrong, please try again.', 'error in fetching profile details', null);
                } else
                    apiResponse(412, 'Please provide the id.', 'id is missing.', null);

            } else {
                apiResponse(401, 'Provide a valid api_token', 'invalid api_token', null);
            }
        } else {
            apiResponse(401, 'Please provide a api token.', 'api_token is missing.', null);
        }
    }

    public function addOrder(Request $request)
    {

        if (!empty($request->input('checkout_token')) && array_key_exists('package_details', parseAccessToken($request['checkout_token']))) {

            if (!empty($request->input('order_token')) && array_key_exists('link', parseAccessToken($request['order_token']))) {

                $checkoutToken = parseAccessToken($request['checkout_token']);
                $orderToken = parseAccessToken($request['order_token']);

                $packageType = $checkoutToken['package_details'][0]['package_type'];

                //To check the comments and store it in comments table
                if ($packageType == 3) {

                    if ($request->input('comments')) {

                        if (is_array($commentsArr = json_decode($request['comments']))) {

                            if (count($commentsArr) >= $checkoutToken['package_details'][0]['quantity']) {

                                $objModelComments = new Comments();
                                $insertedCommentId = $objModelComments->insertComments([
                                    'comment_group_id' => 0,
                                    'comments' => $request['comments'],
                                    'user_id' => $checkoutToken['id'],
                                    'added_at' => time()
                                ]);

                                if (!$insertedCommentId) {
                                    apiResponse(400, 'Something went wrong in adding comments, please try after sometime.', 'error in comment insertion.', null);
                                }

                            } else
                                apiResponse(400, 'Comments should not be less than ' . $checkoutToken['package_details'][0]['quantity'], 'less comment quantity.', null);
                        } else
                            apiResponse(400, 'Comments text is not in proper format.', 'invalid format.', null);

                    } else {
                        apiResponse(412, 'Please provide the comment lists', 'comments param is missing.', null);
                    }
                }

                $regex = '/^(http(s)?:\/\/)?(www\.)?(instagram)\.+(com)+\/+(p)\/(([a-zA-Z0-9\.\-\_])*)/';
                $linkType = (preg_match($regex, $orderToken['link'])) ? "mediaLink" : "profileLink";

                if ((($packageType == 0 || $packageType == 3 || $packageType == 4) && ($linkType != 'mediaLink')) || (($packageType == 1) && ($linkType != 'profileLink'))) {
                    apiResponse(400, 'Link looks invalid.', 'order_token is not proper for this package.', null);
                }

                $startCount = ($packageType == 0) ? $orderToken['likes_count'] : ($packageType == 3 ? $orderToken['comments_count'] : ($packageType == 1 ? $orderToken['followers_count'] : $orderToken['views_count']));


//                $item_number = generateAccessToken(['id' => $checkoutToken['id'], 'package_id' => $checkoutToken['package_details'][0]['package_id'], 'link' => $orderToken['link'], 'start_count' => $startCount, 'display_url' => $orderToken['display_url']]);
                $checkoutConfig = [
                    "iat" => time(),
                    "amount" => $checkoutToken['package_details'][0]['price'] * 100,
                    "description" => "Package: " . $checkoutToken['package_details'][0]['package_name'] . "    Price: " . $checkoutToken['package_details'][0]['price'] . "   AUTOIG.",
                    "quantity" => 1,
                    "item_number" => ['id' => $checkoutToken['id'], 'package_id' => $checkoutToken['package_details'][0]['package_id'], 'link' => $orderToken['link'], 'start_count' => $startCount, 'display_url' => $orderToken['display_url']],
                    "package_details" => $checkoutToken['package_details'][0],
                ];
                if (isset($insertedCommentId)) {
                    // it will set only for comments package
                    $checkoutConfig['item_number']['comment_id'] = $insertedCommentId;

                }

                $url = env('WEB_URL') . '/checkout/' . generateAccessToken($checkoutConfig);
                apiResponse(200, 'Redirect to the url.', null, ['url' => $url]);

            } else
                apiResponse(401, 'Please provide correct order_token', 'order_token is missing.', null);

        } else {
            apiResponse(401, 'Provide a valid checkout_token', 'invalid checkout_token', null);
        }

    }

    public function placeOrder(Request $request)
    {
        $postData = $request->all();
        $checkoutToken = parseAccessToken($postData['checkout_token']);

        $txDataToInsert = [
            'tx_type' => 0, // 0=single order transaction 1=for subscriptions
            'tx_mode' => 0, // 0=paypal
            'transaction_id' => $postData['txn_id'],
            'user_id' => $checkoutToken['item_number']['id'],
            'amount' => $postData['payment_gross'],
            'payer_email' => $postData['payer_email'],
            'payment_status' => $postData['payment_status'],
            'pending_reason' => $postData['pending_reason'],
            'payment_type' => $postData['payment_type'],
            'item_desc' => $postData['item_name'],
            'item_link' => $checkoutToken['item_number']['link'],
            'extra_details' => $postData['custom'],
//            'order_id' => '',
//            'autolikes_id' => $postData['payer_email'],
//            'device_id' => $postData['payer_email'],
            'package_id' => $checkoutToken['package_details']['package_id'],
            'payment_time' => strtotime($postData['payment_date']),
        ];
        $insertedTx = Transaction::getInstance()->insertTransaction($txDataToInsert);

        if ($insertedTx) {

            $orderDataToInsert = [
                'user_id' => $checkoutToken['item_number']['id'],
                'tx_id' => $insertedTx,
                'package_id' => $checkoutToken['package_details']['package_id'],
                'order_url' => $checkoutToken['item_number']['link'],
                'url_type' => 1,
                'start_count' => $checkoutToken['item_number']['start_count'],
                'quantity' => $checkoutToken['package_details']['quantity'],
                'start_time' => time(),
//            'orders_per_run' => '',
//            'time_interval' => '',
                'status' => 0,
                'added_time' => time(),
                'updated_time' => time()
            ];

            if ($checkoutToken['package_details']['package_type'] == 3) {
                $orderDataToInsert['comment_id'] = $checkoutToken['item_number']['comment_id'];
            }

            $orderAdded = Order::getInstance()->insertOrder($orderDataToInsert);
            if ($orderAdded)
                apiResponse(200, 'Order added successfully.', null, $orderAdded);
        } else {

        }

    }

    public function orderHistory(Request $request)
    {
        if ($request->input('access_token')) {

            $tokenDetails = parseAccessToken($request['access_token']);

            if (array_key_exists('id', $tokenDetails)) {

                if (($request->input('order_type'))) {

                    if (array_key_exists($request['order_type'], $this->availablePackageType)) {

                        if ($request->input('order_from')) {

                            switch ($request['order_from']) {
                                case "single_orders":
                                    $whereCondition = ['rawQuery' => 'orders.user_id = ? and packages.package_type = ?', 'bindParams' => [$tokenDetails['id'], $this->availablePackageType[$request['order_type']]]];
                                    $selectCols = ['orders.order_id', 'orders.order_url', 'orders.start_count', 'orders.status', 'orders.added_time', 'packages.price', 'transactions.transaction_id', 'transactions.amount', 'packages.package_name', 'comments.comments'];
                                    $orderDetails = Order::getInstance()->getOrderDetailsWithPackages($whereCondition, $selectCols);

                                    $statusLabel = ['Pending', 'Queue', 'Processing', 'Completed', 'Refunded', 'Cancelled', 'Failed'];

                                    foreach ($orderDetails as $key => $orderDetail) {
                                        $orderDetails[$key]['start_count'] = convertNumberIntoProperNotation($orderDetail['start_count']);
                                        $orderDetails[$key]['status'] = $statusLabel[$orderDetail['status']];
                                        $orderDetails[$key]['added_time'] = convertRelativeTime($orderDetail['added_time']);
                                        $orderDetails[$key]['price'] = number_format($orderDetail['amount'], 2);
                                        $orderDetails[$key]['order_from'] = 'single_orders';
                                        if ($request['order_type'] === "comments") {
                                            $orderDetails[$key]['comments'] = json_decode($orderDetails[$key]['comments']);
                                        }
                                        unset($orderDetails[$key]['amount']);
                                    }

                                    if ($orderDetails)
                                        apiResponse(200, 'Records fetched successfully.', null, $orderDetails);
                                    else
                                        apiResponse(400, 'No records found.', 'no records', null);
                                    break;

                                case "auto_orders":
                                    $whereCondition = ['rawQuery' => 'orders.user_id = ? and orders.package_type = ?', 'bindParams' => [$tokenDetails['id'], $this->availablePackageType[$request['order_type']]]];
                                    $selectCols = ['orders.order_id', 'orders.order_url', 'orders.quantity', 'orders.start_count', 'orders.status', 'orders.added_time', 'comments.comments', 'autolikes_orders.insta_username', 'recurring_profiles.paypal_profile_id'];
                                    $orderDetails = Order::getInstance()->getOrderDetailsWithSubscription($whereCondition, $selectCols);

                                    $statusLabel = ['Pending', 'Queue', 'Processing', 'Completed', 'Refunded', 'Cancelled', 'Failed'];

                                    foreach ($orderDetails as $key => $orderDetail) {
                                        $orderDetails[$key]['start_count'] = convertNumberIntoProperNotation($orderDetail['start_count']);
                                        $orderDetails[$key]['status'] = $statusLabel[$orderDetail['status']];
                                        $orderDetails[$key]['added_time'] = convertRelativeTime($orderDetail['added_time']);
                                        $orderDetails[$key]['order_from'] = 'auto_orders';
                                        if ($request['order_type'] === "comments") {
                                            $orderDetails[$key]['comments'] = json_decode($orderDetails[$key]['comments']);
                                        }
                                    }

                                    if ($orderDetails)
                                        apiResponse(200, 'Records fetched successfully.', null, $orderDetails);
                                    else
                                        apiResponse(400, 'No records found.', 'no records', null);
                                    break;

                                case "both":

                                    $whereCondition = ['rawQuery' => 'orders.user_id = ? and packages.package_type = ?', 'bindParams' => [$tokenDetails['id'], $this->availablePackageType[$request['order_type']]]];
                                    $selectCols = ['orders.order_id', 'orders.order_url', 'orders.start_count', 'orders.status', 'orders.added_time', 'packages.price', 'transactions.transaction_id', 'transactions.amount', 'packages.package_name', 'comments.comments'];
                                    $orderDetails = Order::getInstance()->getOrderDetailsWithPackages($whereCondition, $selectCols);

                                    $statusLabel = ['Pending', 'Queue', 'Processing', 'Completed', 'Refunded', 'Cancelled', 'Failed'];

                                    foreach ($orderDetails as $key => $orderDetail) {
                                        $orderDetails[$key]['start_count'] = convertNumberIntoProperNotation($orderDetail['start_count']);
                                        $orderDetails[$key]['status'] = $statusLabel[$orderDetail['status']];
//                                        $orderDetails[$key]['added_time'] = convertRelativeTime($orderDetail['added_time']);
                                        $orderDetails[$key]['price'] = number_format($orderDetail['amount'], 2);
                                        $orderDetails[$key]['order_from'] = 'single_orders';
                                        if ($request['order_type'] === "comments") {
                                            $orderDetails[$key]['comments'] = json_decode($orderDetails[$key]['comments']);
                                        }
                                        unset($orderDetails[$key]['amount']);
                                    }


                                    $whereCondition = ['rawQuery' => 'orders.user_id = ? and orders.package_type = ?', 'bindParams' => [$tokenDetails['id'], $this->availablePackageType[$request['order_type']]]];
                                    $selectCols = ['orders.order_id', 'orders.order_url', 'orders.quantity', 'orders.start_count', 'orders.status', 'orders.added_time', 'comments.comments', 'autolikes_orders.insta_username', 'recurring_profiles.paypal_profile_id'];
                                    $autoOrderDetails = Order::getInstance()->getOrderDetailsWithSubscription($whereCondition, $selectCols);

                                    $statusLabel = ['Pending', 'Queue', 'Processing', 'Completed', 'Refunded', 'Cancelled', 'Failed'];

                                    foreach ($autoOrderDetails as $key => $orderDetail) {
                                        $autoOrderDetails[$key]['start_count'] = convertNumberIntoProperNotation($orderDetail['start_count']);
                                        $autoOrderDetails[$key]['status'] = $statusLabel[$orderDetail['status']];
//                                        $autoOrderDetails[$key]['added_time'] = convertRelativeTime($orderDetail['added_time']);
                                        $autoOrderDetails[$key]['order_from'] = 'auto_orders';
                                        if ($request['order_type'] === "comments") {
                                            $autoOrderDetails[$key]['comments'] = json_decode($autoOrderDetails[$key]['comments']);
                                        }
                                    }

                                    $orderDetails = array_merge($autoOrderDetails, $orderDetails);
                                    if ($orderDetails) {
                                        usort($orderDetails, function ($prevValue, $nextValue) {
                                            $prevValue = $prevValue['added_time'];
                                            $nextValue = $nextValue['added_time'];
                                            if ($prevValue == $nextValue) return 0;
                                            return ($prevValue < $nextValue) ? -1 : 1;
                                        });

                                        array_walk($orderDetails, function (&$value, $key) {
                                            $value['added_time'] = convertRelativeTime($value['added_time']);
                                        });

                                        apiResponse(200, 'Records fetched successfully.', null, $orderDetails);
                                    } else
                                        apiResponse(400, 'No records found.', 'no records', null);
                                    break;

                                default:
                                    apiResponse(400, 'order_from is not valid.', 'invalid order_from.', null);
                                    break;
                            }
                        } else
                            apiResponse(412, 'Please provide the order_from (auto_orders/single_orders)', 'order_type is missing', null);

                    } else {
                        apiResponse(412, 'Order type value should be likes/comments/followers/views only', 'order_type doesn\'t match.', null);
                    }
                } else {
                    apiResponse(412, 'Please provide the order_type (likes/followers/views/comments)', 'order_type is missing', null);
                }

            } else
                apiResponse(400, 'Not a valid access_token', 'invalid access_token', null);
        } else
            apiResponse(400, 'Please provide the correct access_token', 'access_token is missing.', null);

    }

    public function commentLists(Request $request)
    {
        if ($request->input('access_token')) {

            $tokenDetails = parseAccessToken($request['access_token']);

            if (array_key_exists('id', $tokenDetails)) {

                if ($request->input('order_id')) {

                    $whereCondition = ['rawQuery' => 'orders.order_id = ?', 'bindParams' => [$request['order_id']]];
                    $selectCols = ['comments.comments'];
                    $orderDetails = Order::getInstance()->getOrderDetailsWithPackages($whereCondition, $selectCols);
                    $comments = json_decode($orderDetails[0]['comments']);

                    if ($orderDetails)
                        apiResponse(200, 'Comment lists.', null, $comments);
                    else
                        apiResponse(400, 'No comments found.', 'no comments', null);

                } else {
                    apiResponse(400, 'Please provide the order id ', 'order_id is missing.', null);
                }

            } else
                apiResponse(400, 'Not a valid access_token', 'invalid access_token', null);
        } else
            apiResponse(400, 'Please provide the correct access_token', 'access_token is missing.', null);

    }


}