<?php

namespace App\Http\Controllers\AUTOIG;

use App\Http\Controllers\CommonAPI\Instagram_scrape;
use App\Http\Models\Autolikes_order;
use App\Http\Models\Comments;
use App\Http\Models\DBClass;
use App\Http\Models\Subscription_package;
use App\Http\Models\Transaction;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Validator;
use Illuminate\Validation\Rule;
use Laravel\Lumen\Routing\Controller;
use SaurabhBond\RecurringPayment\PaymentController as Bond;

class AutolikesController extends Controller
{

    protected $objAutolikesOrder, $_db;

    public function __construct()
    {
        $this->objAutolikesOrder = new Autolikes_order();
        $this->_db = DBClass::getInstance();
    }

    public function getSubscriptionPackages(Request $request)
    {

        $start = ($request->input('next_id')) ? abs($request->input('next_id')) : 0;
        $length = ($request->input('length')) ? abs($request->input('length')) : 6;

        //create object of subscription_packages table (models)
        $objSubPackages = new Subscription_package();
        $totalPackages = $objSubPackages->getPackageCount(['rawQuery' => 'sub_package_for = 5 and sub_package_type = 0 and status =1']);

        if ($start < $totalPackages) {

            $packages = $objSubPackages->getFilteredPackageLists(['rawQuery' => 'sub_package_for = 5 and sub_package_type = 0 and status =1'], ['*'], $start, $length);

            foreach ($packages as $key => $package) {
                $count = 0;
                $dailyDetails = json_decode($package['daily_details'], true)[0];
                $weeklyDetails = json_decode($package['weekly_details'], true)[0];
                $monthlyDetails = json_decode($package['monthly_details'], true)[0];
                if (!empty($dailyDetails)) {
                    $packages[$key]['details'][$count]['billing_cycle'] = $dailyDetails['billing_frequency'] . ' ' . $dailyDetails['billing_period'];
                    $packages[$key]['details'][$count]['price'] = $dailyDetails['price'];
                    $packages[$key]['details'][$count]['package_mode'] = 'daily_details';
                    $packages[$key]['start_price'] = $dailyDetails['price'];
                    ++$count;
                }
                if (!empty($weeklyDetails)) {
                    $packages[$key]['details'][$count]['billing_cycle'] = $weeklyDetails['billing_frequency'] . ' ' . $weeklyDetails['billing_period'];
                    $packages[$key]['details'][$count]['price'] = $weeklyDetails['price'];
                    $packages[$key]['details'][$count]['package_mode'] = 'weekly_details';
                    ++$count;
                }
                if (!empty($monthlyDetails)) {
                    $packages[$key]['details'][$count]['billing_cycle'] = $monthlyDetails['billing_frequency'] . ' ' . $monthlyDetails['billing_period'];
                    $packages[$key]['details'][$count]['price'] = $monthlyDetails['price'];
                    $packages[$key]['details'][$count]['package_mode'] = 'monthly_details';
                    ++$count;
                }
                if ($package['auto_views'] === "on") {
                    if ($package['views_price'] == 0) {
                        $packages[$key]['auto_views'] = "free";
                    } else
                        $packages[$key]['auto_views'] = "on";
                } else
                    $packages[$key]['auto_views'] = "off";


                unset($packages[$key]['daily_details']);
                unset($packages[$key]['weekly_details']);
                unset($packages[$key]['monthly_details']);


                $maxLikesPerDelay = json_decode($package['max_likes_per_delay'], true);
                $itr1 = 0;
                if (isset($maxLikesPerDelay) && !empty($maxLikesPerDelay) && is_array($maxLikesPerDelay)) {

                    $packages[$key]['max_likes_per_delay'] = [];
                    foreach ($maxLikesPerDelay as $time => $amount) {
                        $packages[$key]['max_likes_per_delay'][$itr1]['time'] = $time;
                        $packages[$key]['max_likes_per_delay'][$itr1]['amount'] = $amount;
                        ++$itr1;
                    }
                    $packages[$key]['min_delay_quantity_likes'] = end($packages[$key]['max_likes_per_delay'])['amount'];
                    $packages[$key]['max_delay_time_likes'] = reset($packages[$key]['max_likes_per_delay'])['time'];
                }

                $maxViewsPerDelay = json_decode($package['max_views_per_delay'], true);
                $itr2 = 0;
                if (isset($maxViewsPerDelay) && !empty($maxViewsPerDelay) && is_array($maxLikesPerDelay)) {
                    $packages[$key]['max_views_per_delay'] = [];
                    foreach ($maxViewsPerDelay as $time => $amount) {
                        $packages[$key]['max_views_per_delay'][$itr2]['time'] = $time;
                        $packages[$key]['max_views_per_delay'][$itr2]['amount'] = $amount;
                        ++$itr2;
                    }
                    $packages[$key]['min_delay_quantity_views'] = end($packages[$key]['max_views_per_delay'])['amount'];
                    $packages[$key]['max_delay_time_views'] = reset($packages[$key]['max_views_per_delay'])['time'];
                }

            }

            if ($packages) {

                if ($start + $length < $totalPackages) {
                    $nextId = $start + count($packages);
                    $hasNext = true;
                } else {
                    $nextId = 0;
                    $hasNext = false;
                }

                //get free autolikes package details
                $freePackage = $objSubPackages->getPackageList(['rawQuery' => 'sub_package_for = 5 and sub_package_type = 2 and status =1'], ['sub_package_id', 'sub_package_name', 'quantity']);

                http_response_code(200);
                echo json_encode(['code' => 200, 'message' => 'Subscription package lists', 'error' => null, 'next_id' => $nextId, 'has_next' => $hasNext, 'data' => $packages, 'free_sub_package_id' => $freePackage['sub_package_id'], 'free_quantity' => $freePackage['quantity']]);
                die;

            } else {
                apiResponse(400, 'There is no any package currently available.', 'No available package', null);
            }
        } else {
            apiResponse(400, 'next_id is greater than the total subscription packages', 'next_id is not proper.', null);
        }

    }

    public function addAutolikesOrder(Request $request)
    {
//        Log::info("-------request----------", $request->all());
        $rules = [
            'access_token' => ['required', function ($attribute, $val, $msg) {
                if (!array_key_exists('id', parseAccessToken($val))) return $msg('Please provide correct ' . $attribute);
            }],
            'sub_package_id' => ['required', Rule::exists('subscription_packages')->where('status', 1)],
            'insta_username' => 'required',
            'profile_image' => 'required|string|nullable',
            'package_mode' => ['required', function ($attribute, $value, $fail) {
                if (!in_array($value, ['daily_details', 'weekly_details', 'monthly_details'])) {
                    return $fail($attribute . ' is invalid. package_mode should be only (daily_details, weekly_details, monthly_details)');
                }
            }],
            'likes_split_option' => ['required', function ($att, $val, $msg) {
                if (!in_array($val, ['on', 'off'])) return $msg($att . ' is invalid');
            }],
            'likes_quantity_per_run' => 'required_unless:likes_split_option,off|numeric',
            'likes_delay_interval' => 'required_unless:likes_split_option,off|numeric|min:600|max:21600',
            'auto_views' => ['required', function ($attr, $val, $msg) {
                if (!in_array($val, ['on', 'off'])) return $msg($attr . ' is invalid');
            }],
            'views_split_option' => ['required_unless:auto_views,off', function ($att, $val, $msg) {
                if (!in_array($val, ['on', 'off'])) return $msg($att . ' is invalid');
            }],
            'views_quantity_per_run' => 'required_unless:views_split_option,off|numeric',
            'views_delay_interval' => 'required_unless:views_split_option,off|numeric|min:600|max:21600',
            'likes_start_delay' => 'numeric|min:300|max:3600',
            'views_start_delay' => 'numeric|min:300|max:3600'
        ];

        $validator = Validator::make($request->all(), $rules, [
            'access_token.required' => 'Please provide access_token',
            'sub_package_id.required' => 'Please provide the subscription package id.',
            'sub_package_id.exists' => 'Package id  may be inactive or doesn\'t exist.',
            'insta_username.required' => 'Please enter the username.',
            'likes_delay_interval.min' => 'Delay interval must be greater than 600 secs(10 mins)',
            'views_delay_interval.min' => 'Delay interval must be greater than 600 secs(10 mins)',
            'likes_delay_interval.max' => 'Delay interval must be lesser than 21600 secs(6 hrs)',
            'views_delay_interval.max' => 'Delay interval must be lesser than 21600 secs(6 hrs)',
            'likes_start_delay.min' => 'Delay for first likes must be greater than 5 mins (300 secs)',
            'views_start_delay.min' => 'Delay for first views must be greater than 5 mins (300 secs)',
            'likes_start_delay.max' => 'Delay for first likes must be lesser than 1 hr (3600 secs)',
            'views_start_delay.max' => 'Delay for first views must be lesser than 1 hr (3600 secs)',
        ]);

        /*TODO
         *  niche -> fashion, photography
         *  gender -> M /F /B
         *  age_range -> 20-60
         *
         *  start_delay -> 600
         *  split_option_enabled => on/off
         *  quantity_per_run =>
         *  delay_interval
         */

        if (!$validator->fails()) {

            //get the details from subscription_packages table  //create object of subscription_packages table (models)
            $objSubPackages = new Subscription_package();
            $packageDetails = $objSubPackages->getPackageLists(['rawQuery' => 'sub_package_id = ?', 'bindParams' => [$request['sub_package_id']]]);

            $packageBillingDetails = json_decode($packageDetails[0][$request['package_mode']], true);
            $amount = $packageBillingDetails[0]['price'];
            $billingPeriod = $packageBillingDetails[0]['billing_period'];
            $billingFrequency = $packageBillingDetails[0]['billing_frequency'];
            $postLimit = $packageBillingDetails[0]['post_limit'];
            $dailyPostLimit = $packageBillingDetails[0]['daily_post_limit'];

            $user_id = parseAccessToken($request['access_token'])['id'];


            //validation
            /*
             * a) max sub orders/splits can be 50 (that’s the settings that we have in messazon
                already)
                b) min likes per run can be 10 , not less
                c) max  likes per run must be set as
                  - max 100 likes per run every 15 mins
                  - max 250 likes per run every 20 mins
                  - max 350 likes per run every 25 mins
                  - max 500 likes per run every 30 mins
             */
            $totalQuantity = $packageDetails[0]['quantity'];
            $minQuantityPerRun = ($totalQuantity / 50 > 10) ? $totalQuantity / 50 : 10;

            $likesStartDelay = ($request->input('likes_start_delay')) ? $request['likes_start_delay'] : 0;
            if ($request['likes_split_option'] === "on") {

                $lQuantityPerRun = $request['likes_quantity_per_run'];
                $lDelayInterval = $request['likes_delay_interval'];

                if ($lQuantityPerRun < $minQuantityPerRun)
                    apiResponse(400, 'Minimum likes quantity per run should be greater than ' . $minQuantityPerRun, 'validation error.', null);

                if ($lQuantityPerRun > $totalQuantity)
                    apiResponse(400, 'Likes quantity per run should be lesser than ' . $totalQuantity, 'validation error.', null);


                $likes_split_option = ["likes_start_delay" => $likesStartDelay, "likes_split_option_enabled" => "on", "likes_quantity_per_run" => $lQuantityPerRun, "likes_delay_interval" => $lDelayInterval];
            } else {
                $likes_split_option = ["likes_start_delay" => $likesStartDelay, "likes_split_option_enabled" => "off", "likes_quantity_per_run" => "0", "likes_delay_interval" => "0"];
            }

            $viewsStartDelay = ($request->input('views_start_delay')) ? $request['views_start_delay'] : 0;
            if ($request['views_split_option'] === "on") {

                $vQuantityPerRun = $request['views_quantity_per_run'];
                $vDelayInterval = $request['views_delay_interval'];

                if ($vQuantityPerRun < $minQuantityPerRun)
                    apiResponse(400, 'Minimum views quantity per run should be greater than ' . $minQuantityPerRun, 'validation error.', null);

                if ($vQuantityPerRun > $totalQuantity)
                    apiResponse(400, 'Views quantity per run should be lesser than ' . $totalQuantity, 'validation error.', null);

                $views_split_option = ["views_start_delay" => $viewsStartDelay, "views_split_option_enabled" => "on", "views_quantity_per_run" => $vQuantityPerRun, "views_delay_interval" => $vDelayInterval];
            } else {
                $views_split_option = ["views_start_delay" => $viewsStartDelay, "views_split_option_enabled" => "off", "views_quantity_per_run" => "0", "views_delay_interval" => "0"];
            }

            $likes_impression = ($request->input('likes_impression')) ? $request['likes_impression'] : 'off';


            //call suarabh-bond recurring package
            $payment = Bond::createObject();

            $description = "App AUTO IG -". $packageDetails[0]['quantity']."L - $billingFrequency $billingPeriod AL Points";

            $checkoutToken = generateAccessToken([
                'username' => $request['insta_username'],
                'profile_image' => $request['profile_image'],
                'sub_package_id' => $request['sub_package_id'],
                'description' => $description,
                'user_id' => $user_id,
                'price' => $amount,
                'billing_cycle' => "$billingFrequency $billingPeriod",
                'package_mode' => $request['package_mode'],
                'auto_views' => $request->input('auto_views') ? $request['auto_views'] : null,
                'likes_split_option' => json_encode($likes_split_option),
                'views_split_option' => json_encode($views_split_option),
                'likes_impression' => $likes_impression
            ]);

            $returnUrl = env('WEB_URL') . '/autolikes-checkout/success/' . $checkoutToken;
            $cancelUrl = env('WEB_URL') . '/autolikes-checkout/error/' . $checkoutToken;
            $ipnUrl = 'http://api.gaia.globusdemos.com/autoig/ipnListener';

            $response = $payment->createRecurringProfile($description, $cancelUrl, $returnUrl, $ipnUrl);

//            Log::info("-------response----------", $response);

            $response = json_decode($response, true);
            if ($response['status'] == 200) {
                apiResponse(200, $response['message'], null, ['url' => $response['url']]);
            } else {
                apiResponse(400, $response['message'], $response['errMsg'], null);
            }

        } else {
            $errMsg = json_decode($validator->messages(), true);
            apiResponse(412, array_values($errMsg)[0][0], 'Validation error', null);
        }

    }

    public function confirmPayment(Request $request)
    {
        $token = $request['token'];
        $checkoutToken = parseAccessToken($request['checkout_token']);
//        $token = 'EC-5RP02392XN4158313';
//        $checkoutToken = parseAccessToken('eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJ1c2VybmFtZSI6InNhdXJhYmhfYm9uZCIsInByb2ZpbGVfaW1hZ2UiOiJodHRwczpcL1wvc2NvbnRlbnQtbnJ0MS0xLmNkbmluc3RhZ3JhbS5jb21cL3ZwXC8zMzAxMmM2ZmRhNGQyODQxNjdjOTZiOTc0ZmI4Njk5MFwvNUJENUUwNTlcL3Q1MS4yODg1LTE5XC9zMTUweDE1MFwvMTEzNzA5ODhfMTE3NjUxMzEyMjM2NDEyM18xODc5MzA1MDcyX2EuanBnIiwic3ViX3BhY2thZ2VfaWQiOiIzIiwiZGVzY3JpcHRpb24iOiJzYXVyYWJoX2JvbmQgOiAyMDAgTGlrZXMiLCJ1c2VyX2lkIjoxNTYsInByaWNlIjoiOC4wMCIsImJpbGxpbmdfY3ljbGUiOiIxIERheSIsInBhY2thZ2VfbW9kZSI6ImRhaWx5X2RldGFpbHMiLCJhdXRvX3ZpZXdzIjoib24iLCJsaWtlc19zcGxpdF9vcHRpb24iOiJ7XCJsaWtlc19zdGFydF9kZWxheVwiOlwiMzAwXCIsXCJsaWtlc19zcGxpdF9vcHRpb25fZW5hYmxlZFwiOlwib25cIixcImxpa2VzX3F1YW50aXR5X3Blcl9ydW5cIjpcIjUwXCIsXCJsaWtlc19kZWxheV9pbnRlcnZhbFwiOlwiMTIwMFwifSIsInZpZXdzX3NwbGl0X29wdGlvbiI6IntcInZpZXdzX3N0YXJ0X2RlbGF5XCI6XCIzNjAwXCIsXCJ2aWV3c19zcGxpdF9vcHRpb25fZW5hYmxlZFwiOlwib25cIixcInZpZXdzX3F1YW50aXR5X3Blcl9ydW5cIjpcIjUwXCIsXCJ2aWV3c19kZWxheV9pbnRlcnZhbFwiOlwiNjAwXCJ9In0.FbF8ndUXMUlgU16l2M4Rrckx74wdQr0aj-jYOU4xkbU');

        $description = $checkoutToken['description'];
        $package_id = $checkoutToken['sub_package_id'];

        $objSubPackages = new Subscription_package();
        $packageDetails = $objSubPackages->getPackageLists(['rawQuery' => 'sub_package_id = ?', 'bindParams' => [$package_id]]);

        $packageBillingDetails = json_decode($packageDetails[0][$checkoutToken['package_mode']], true);
        $amount = $packageBillingDetails[0]['price'];
        $billingPeriod = $packageBillingDetails[0]['billing_period'];
        $billingFrequency = $packageBillingDetails[0]['billing_frequency'];
        $postLimit = $packageBillingDetails[0]['post_limit'];
        $dailyPostLimit = $packageBillingDetails[0]['daily_post_limit'];
        $likes_quantity = $packageDetails[0]['quantity'];
        $views_quantity = $packageDetails[0]['views_per_post'];

        $payment = Bond::createObject();

//        dd($token, trim($description), $amount, $initialAmount = '', $billingPeriod, $billingFrequency);

        $paymentResponse = $payment->confirmPayment($token, trim($description), $amount, $initialAmount = '', $billingPeriod, $billingFrequency);
        $paymentResponse = json_decode($paymentResponse, true);

        if ($paymentResponse['status'] === 200) {

            $insertedId = $this->_db->insert('recurring_profiles', [
                'paypal_profile_id' => $paymentResponse['data']['PROFILEID'],
                'sub_package_id' => $checkoutToken['sub_package_id'],
                'by_user_id' => $checkoutToken['user_id'],
//                'for_autolikes_id' => $checkoutDetails['autolikes_id'],
                'profile_status' => ($paymentResponse['data']['PROFILESTATUS'] === 'ActiveProfile') ? 1 : 0,
                'added_time' => date("d-m-Y H:i:s", strtotime($paymentResponse['data']['TIMESTAMP'])),
                'created_at' => time(),
                'price' => $checkoutToken['price'],
                'billing_period' => $checkoutToken['billing_cycle'],
                'sub_package_type' => $checkoutToken['package_mode'],
            ]);

            if ($insertedId) {

                $ordersAdded = $this->_db->insert('autolikes_orders', [
                    'by_user_id' => $checkoutToken['user_id'],
                    'insta_username' => $checkoutToken['username'],
                    'profile_image' => $checkoutToken['profile_image'],
                    'recurring_profile_id' => $insertedId,
                    'sub_package_id' => $checkoutToken['sub_package_id'],
                    'post_limit' => $postLimit,
                    'post_fetch_count' => 0,
                    'post_done' => 0,
                    'daily_post_limit' => $dailyPostLimit,
                    'daily_post_done' => 0,
                    'likes_randomize' => json_encode(['min_quantity' => $likes_quantity, 'max_quantity' => $likes_quantity]),
                    'views_randomize' => json_encode(['min_quantity' => $views_quantity, 'max_quantity' => $views_quantity]),
                    'likes_split_option' => $checkoutToken['likes_split_option'],
                    'views_split_option' => $checkoutToken['views_split_option'],
                    'first_post_fetched_time' => 0,
                    'last_post_created_time' => time(),
                    'reset_counter_time' => 0,
                    'last_checked_time' => 0,
                    'last_delivered_time' => 0,
                    'last_delivered_link' => '',
                    'likes_impression' => $checkoutToken['likes_impression'],
                    'auto_views' => $checkoutToken['auto_views'],
//                    'auto_views' => ($packageDetails[0]['auto_views'] == "on") ? $packageDetails[0]['auto_views'] : NULL,
//                    'plan_id_auto_views' => ($packageDetails[0]['auto_views'] == "on") ? $packageDetails[0]['views_plan_id'] : NULL,
//                    'views_quantity' => ($packageDetails[0]['auto_views'] == "on") ? $packageDetails[0]['views_per_post'] : NULL,
                    'message' => 'Profile is pending.',
                    'status' => 0,
                    'cron_status' => 0,
                    'created_at' => time(),

                ]);

                if ($ordersAdded) {
                    apiResponse(200, 'Profile has been added successfully.', null, ['profile_id' => $ordersAdded, 'paypal_profile_id' => $paymentResponse['data']['PROFILEID']]);
                } else
                    apiResponse(400, 'Something went wrong in storing details, Please contact us.', 'error in profile insertion.', null);

            } else {
                apiResponse(400, 'Something went wrong in storing details, Please contact us.', 'error in recurring profile insertion.', null);
            }

        } else {
            apiResponse(400, $paymentResponse['message'], 'error in confirming paypal details.', null);
        }

    }

    public function placeFreeAutolikesOLD(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'access_token' => ['required', function ($attribute, $val, $msg) {
                if (!array_key_exists('id', parseAccessToken($val))) return $msg('Please provide correct ' . $attribute);
            }],
            'sub_package_id' => ['required', Rule::exists('subscription_packages')->where('sub_package_type', 2)], //2 means free package
            'insta_username' => 'required',
            'display_url' => 'required'
        ], [
            'sub_package_id.exists' => 'Subscription package id does\'t exist or may be not a free package'
        ]);

        if (!$validator->fails()) {

            /* serach for device id */
            $deviceIdExists = $this->_db->selectQuery('usersmeta', ['rawQuery' => 'device_id = ?', 'bindParams' => [parseAccessToken($request['access_token'])['device_id']]]);
            if (!empty($deviceIdExists) && count($deviceIdExists) >= 2) {
                apiResponse(400, 'Free autolikes package has been already used.', 'already used free package for this device', null);
            }

            $whereForUsersMeta = ['rawQuery' => 'user_id = ?', 'bindParams' => [parseAccessToken($request['access_token'])['id']]];
            $usermetaExists = $this->_db->selectQuery('usersmeta', $whereForUsersMeta);

            if (empty($usermetaExists) || (!empty($usermetaExists) && $usermetaExists[0]['free_package_used'] == 0) || (!empty($usermetaExists) && $usermetaExists[0]['rated_app'] == 1)) {

                $insertedId = $this->_db->insert('recurring_profiles', [
                    'paypal_profile_id' => 'FreeAutoLikes',
                    'sub_package_id' => $request['sub_package_id'],
                    'by_user_id' => parseAccessToken($request['access_token'])['id'],
//                'for_autolikes_id' => $checkoutDetails['autolikes_id'],
                    'profile_status' => 1,
                    'added_time' => date("d-m-Y H:i:s", time()),
                    'created_at' => time(),
                    'price' => 0,
                    'billing_period' => '',
                    'sub_package_type' => '',
                ]);

                if ($insertedId) {

                    $ordersAdded = $this->_db->insert('autolikes_orders', [
                        'by_user_id' => parseAccessToken($request['access_token'])['id'],
                        'insta_username' => $request['insta_username'],
                        'profile_image' => $request['display_url'],
                        'recurring_profile_id' => $insertedId,
                        'sub_package_id' => $request['sub_package_id'],
                        'post_limit' => 1,
                        'post_fetch_count' => 0,
                        'post_done' => 0,
                        'daily_post_limit' => 1,
                        'daily_post_done' => 0,
                        'likes_split_option' => null,
                        'views_split_option' => null,
                        'first_post_fetched_time' => 0,
                        'last_post_created_time' => time(),
                        'reset_counter_time' => 0,
                        'last_checked_time' => 0,
                        'last_delivered_time' => 0,
                        'last_delivered_link' => '',
                        'auto_views' => 'off',
//                    'auto_views' => ($packageDetails[0]['auto_views'] == "on") ? $packageDetails[0]['auto_views'] : NULL,
//                    'plan_id_auto_views' => ($packageDetails[0]['auto_views'] == "on") ? $packageDetails[0]['views_plan_id'] : NULL,
//                    'views_quantity' => ($packageDetails[0]['auto_views'] == "on") ? $packageDetails[0]['views_per_post'] : NULL,
                        'message' => 'Script is running and waiting for new post.',
                        'status' => 1,
                        'cron_status' => 0,
                        'created_at' => time(),
                    ]);

                    if ($ordersAdded) {
                        //insert one row in usersmeta table also
//                        $whereForUsersMeta = ['rawQuery' => 'user_id = ?', 'bindParams' => [parseAccessToken($request['access_token'])['id']]];
//                        $usermetaExists = $this->_db->selectQuery('usersmeta', $whereForUsersMeta);
                        if (empty($usermetaExists)) {
                            $this->_db->insert('usersmeta', [
                                'user_id' => parseAccessToken($request['access_token'])['id'],
                                'free_package_used' => 1,
                                'rated_app' => 0,
                                'device_id' => parseAccessToken($request['access_token'])['device_id'],
                                'ip' => $request->ip()
                            ]);
                        } else {
                            //check if
                            if ($usermetaExists[0]['free_package_used'] == 0) {
                                $this->_db->updateQuery('usersmeta', $whereForUsersMeta, [
                                    'free_package_used' => 1,
                                    'device_id' => parseAccessToken($request['access_token'])['device_id'],
                                    'ip' => $request->ip()
                                ]);
                            } else if ($usermetaExists[0]['rated_app'] == 1) {
                                $this->_db->updateQuery('usersmeta', $whereForUsersMeta, [
                                    'rated_app' => 2,
                                    'device_id' => parseAccessToken($request['access_token'])['device_id'],
                                    'ip' => $request->ip()
                                ]);
                            }

                        }
                        apiResponse(200, 'Profile has been added for 50 autolikes.', null, ['profile_id' => $ordersAdded]);
                    } else
                        apiResponse(400, 'Something went wrong in storing details, Please contact us.', 'error in profile insertion.', null);

                } else {
                    apiResponse(400, 'Something went wrong in storing details, Please contact us.', 'error in recurring profile insertion.', null);
                }
            } else {
                apiResponse(400, 'Free autolikes has been already assigned.', 'already used free package for this user', null);
            }
        } else {
            $errMsg = json_decode($validator->messages(), true);
            apiResponse(412, array_values($errMsg)[0][0], 'Validation error', null);
        }


    }

    public function placeFreeAutolikes(Request $request)
    {
        if ($request->input('method')) {

            switch ($request['method']) {
                case "validate":
                    if ($request->input('access_token')) {
                        $tokenDetails = parseAccessToken($request['access_token']);

                        if (array_key_exists('id', $tokenDetails)) {

                            /* serach for device id */
                            $deviceIdExists = $this->_db->selectQuery('usersmeta', ['rawQuery' => 'device_id = ?', 'bindParams' => [parseAccessToken($request['access_token'])['device_id']]]);
                            if (!empty($deviceIdExists) && count($deviceIdExists) >= 2) {
                                apiResponse(400, 'Free autolikes package has been already used.', 'already used free package for this device', null);
                            }

                            $whereForUsersMeta = ['rawQuery' => 'user_id = ?', 'bindParams' => [parseAccessToken($request['access_token'])['id']]];
                            $usermetaExists = $this->_db->selectQuery('usersmeta', $whereForUsersMeta);

                            if (empty($usermetaExists) || (!empty($usermetaExists) && $usermetaExists[0]['free_package_used'] == 0) || (!empty($usermetaExists) && $usermetaExists[0]['rated_app'] == 1)) {
                                apiResponse(200, 'Free autolikes can be assigned.', null, null);
                            } else {
                                apiResponse(400, 'Free autolikes has been already assigned.', 'already used free package for this user', null);
                            }

                        } else
                            apiResponse(400, 'Not a valid access_token', 'invalid access_token', null);
                    } else
                        apiResponse(400, 'Please provide the correct access_token', 'access_token is missing.', null);
                    break;

                case "activate":

                    $validator = Validator::make($request->all(), [
                        'access_token' => ['required', function ($attribute, $val, $msg) {
                            if (!array_key_exists('id', parseAccessToken($val))) return $msg('Please provide correct ' . $attribute);
                        }],
                        'sub_package_id' => ['required', Rule::exists('subscription_packages')->where('sub_package_type', 2)], //2 means free package
                        'insta_username' => 'required',
                        'display_url' => 'required'
                    ], [
                        'sub_package_id.exists' => 'Subscription package id does\'t exist or may be not a free package'
                    ]);

                    if (!$validator->fails()) {

                        /* serach for device id */
                        $deviceIdExists = $this->_db->selectQuery('usersmeta', ['rawQuery' => 'device_id = ?', 'bindParams' => [parseAccessToken($request['access_token'])['device_id']]]);
                        if (!empty($deviceIdExists) && count($deviceIdExists) >= 2) {
                            apiResponse(400, 'Free autolikes package has been already used.', 'already used free package for this device', null);
                        }

                        $whereForUsersMeta = ['rawQuery' => 'user_id = ?', 'bindParams' => [parseAccessToken($request['access_token'])['id']]];
                        $usermetaExists = $this->_db->selectQuery('usersmeta', $whereForUsersMeta);

                        if (empty($usermetaExists) || (!empty($usermetaExists) && $usermetaExists[0]['free_package_used'] == 0) || (!empty($usermetaExists) && $usermetaExists[0]['rated_app'] == 1)) {

                            $insertedId = $this->_db->insert('recurring_profiles', [
                                'paypal_profile_id' => 'FreeAutoLikes',
                                'sub_package_id' => $request['sub_package_id'],
                                'by_user_id' => parseAccessToken($request['access_token'])['id'],
                                'profile_status' => 1,
                                'added_time' => date("d-m-Y H:i:s", time()),
                                'created_at' => time(),
                                'price' => 0,
                                'billing_period' => '',
                                'sub_package_type' => '',
                            ]);

                            if ($insertedId) {

                                $ordersAdded = $this->_db->insert('autolikes_orders', [
                                    'by_user_id' => parseAccessToken($request['access_token'])['id'],
                                    'insta_username' => $request['insta_username'],
                                    'profile_image' => $request['display_url'],
                                    'recurring_profile_id' => $insertedId,
                                    'sub_package_id' => $request['sub_package_id'],
                                    'post_limit' => 1,
                                    'post_fetch_count' => 0,
                                    'post_done' => 0,
                                    'daily_post_limit' => 1,
                                    'daily_post_done' => 0,
                                    'likes_split_option' => null,
                                    'views_split_option' => null,
                                    'first_post_fetched_time' => 0,
                                    'last_post_created_time' => time(),
                                    'reset_counter_time' => 0,
                                    'last_checked_time' => 0,
                                    'last_delivered_time' => 0,
                                    'last_delivered_link' => '',
                                    'auto_views' => 'off',
                                    'message' => 'Script is running and waiting for new post.',
                                    'status' => 1,
                                    'cron_status' => 0,
                                    'created_at' => time(),
                                ]);

                                if ($ordersAdded) {
                                    if (empty($usermetaExists)) {
                                        $this->_db->insert('usersmeta', [
                                            'user_id' => parseAccessToken($request['access_token'])['id'],
                                            'free_package_used' => 1,
                                            'rated_app' => 0,
                                            'device_id' => parseAccessToken($request['access_token'])['device_id'],
                                            'ip' => $request->ip()
                                        ]);
                                    } else {
                                        //check if
                                        if ($usermetaExists[0]['free_package_used'] == 0) {
                                            $this->_db->updateQuery('usersmeta', $whereForUsersMeta, [
                                                'free_package_used' => 1,
                                                'device_id' => parseAccessToken($request['access_token'])['device_id'],
                                                'ip' => $request->ip()
                                            ]);
                                        } else if ($usermetaExists[0]['rated_app'] == 1) {
                                            $this->_db->updateQuery('usersmeta', $whereForUsersMeta, [
                                                'rated_app' => 2,
                                                'device_id' => parseAccessToken($request['access_token'])['device_id'],
                                                'ip' => $request->ip()
                                            ]);
                                        }

                                    }
                                    apiResponse(200, 'Profile has been added for 50 autolikes.', null, ['profile_id' => $ordersAdded]);
                                } else
                                    apiResponse(400, 'Something went wrong in storing details, Please contact us.', 'error in profile insertion.', null);

                            } else {
                                apiResponse(400, 'Something went wrong in storing details, Please contact us.', 'error in recurring profile insertion.', null);
                            }
                        } else {
                            apiResponse(400, 'Free autolikes has been already assigned.', 'already used free package for this user', null);
                        }
                    } else {
                        $errMsg = json_decode($validator->messages(), true);
                        apiResponse(412, array_values($errMsg)[0][0], 'Validation error', null);
                    }
                    break;

                default:
                    apiResponse(400, 'Please specify the correct method (validate/activate).', 'method is invalid.', null);
                    break;
            }
        } else {
            apiResponse(400, 'Please specify the method (validate/activate).', 'method is missing.', null);
        }

    }

    public function subscriptionsHistory(Request $request)
    {
        if ($request->input('access_token')) {

            $tokenDetails = parseAccessToken($request['access_token']);

            if (array_key_exists('id', $tokenDetails)) {

                $condition = ['rawQuery' => 'autolikes_orders.by_user_id = ?', 'bindParams' => [$tokenDetails['id']]];
                $selectCols = ['autolikes_orders.autolikes_id', 'autolikes_orders.insta_username', 'autolikes_orders.profile_image', 'autolikes_orders.post_limit', 'autolikes_orders.post_fetch_count', 'autolikes_orders.daily_post_limit', 'autolikes_orders.daily_post_done', 'autolikes_orders.status', 'autolikes_orders.message', 'recurring_profiles.paypal_profile_id', 'subscription_packages.sub_package_name'];
//                $allProfiles = $this->_db->selectQueryWithJoin('autolikes_orders', 'recurring_profiles', 'recurring_profiles.profile_id', 'autolikes_orders.recurring_profile_id', $condition, $selectCols);
                $allProfiles = $this->objAutolikesOrder->getProfileWithRecurringAndPackageDetails($condition, $selectCols);

                $profileStatus = ['pending', 'running', 'finished', 'cancelled', 'stopped', 'paused', 'suspended'];

                if (!empty($allProfiles) && is_array($allProfiles)) {

                    array_walk($allProfiles, function (&$value, $key, $profileStatus) {
                        $value['status'] = ucfirst($profileStatus[$value['status']]);
                        $value['posts'] = $value['post_fetch_count'] . '/' . $value['post_limit'];
                        $value['daily_posts'] = $value['daily_post_done'] . '/' . $value['daily_post_limit'];
                        unset($value['post_fetch_count']);
                        unset($value['post_limit']);
                        unset($value['daily_post_done']);
                        unset($value['daily_post_limit']);
                    }, $profileStatus);

                    apiResponse(200, 'Subscription history.', null, $allProfiles);
                } else {
                    apiResponse(400, 'No subscription found.', null, array());
                }

            } else
                apiResponse(400, 'Not a valid access_token', 'invalid access_token', null);
        } else
            apiResponse(400, 'Please provide the access_token', 'access_token is missing.', null);
    }

    public function paymentDetails(Request $request)
    {
        if ($request->input('access_token')) {

            $tokenDetails = parseAccessToken($request['access_token']);

            if (array_key_exists('id', $tokenDetails)) {

                if ($request->input('payment_from')) {
                    switch ($request['payment_from']) {

                        case "auto_payment":
                            $selectCols = ['recurring_profiles.paypal_profile_id', 'transactions.transaction_id', 'transactions.amount', 'transactions.payment_time'];
                            $paymentDetails = $this->_db->selectQueryWithJoin('transactions', 'recurring_profiles', 'recurring_profiles.profile_id', 'transactions.recurring_profile_id', ['rawQuery' => 'user_id = ? and recurring_profile_id != ?', 'bindParams' => [$tokenDetails['id'], 0]], $selectCols);

                            if (!empty($paymentDetails) && is_array($paymentDetails)) {
                                foreach ($paymentDetails as $key => $details)
                                    $paymentDetails[$key]['payment_time'] = convertTimestampToString($details['payment_time']);

                                apiResponse(200, 'Transaction Details', null, $paymentDetails);
                            } else {
                                apiResponse(400, 'No records available.', 'No records found.', null);
                            }
                            break;
                        case "single_payment":
                            $selectCols = ['packages.package_name', 'transactions.transaction_id', 'transactions.amount', 'transactions.payment_time'];
                            $paymentDetails = $this->_db->selectQueryWithJoin('transactions', 'packages', 'transactions.package_id', 'packages.package_id', ['rawQuery' => 'transactions.user_id = ? and transactions.package_id != ?', 'bindParams' => [$tokenDetails['id'], 0]], $selectCols);

                            if (!empty($paymentDetails) && is_array($paymentDetails)) {
                                foreach ($paymentDetails as $key => $details)
                                    $paymentDetails[$key]['payment_time'] = convertTimestampToString($details['payment_time']);

                                apiResponse(200, 'Transaction Details', null, $paymentDetails);
                            } else {
                                apiResponse(400, 'No records available.', 'No records found.', null);
                            }
                            break;
                        case "add_ons":
                            $selectCols = ['transactions.item_desc', 'transactions.transaction_id', 'transactions.amount', 'transactions.payment_time'];
                            $paymentDetails = $this->_db->selectQuery('transactions', ['rawQuery' => 'transactions.user_id = ? and transactions.package_id = ? and transactions.tx_code = ?', 'bindParams' => [$tokenDetails['id'], 0, 'addonorder']], $selectCols);

                            if (!empty($paymentDetails) && is_array($paymentDetails)) {
                                foreach ($paymentDetails as $key => $details) {
                                    $paymentDetails[$key]['payment_time'] = convertTimestampToString($details['payment_time']);
                                    $paymentDetails[$key]['service_type'] = trim(explode('-', $details['item_desc'])[2]);
                                    unset($paymentDetails[$key]['item_desc']);
                                }

                                apiResponse(200, 'Transaction Details', null, $paymentDetails);
                            } else {
                                apiResponse(400, 'No records available.', 'No records found.', null);
                            }
                            break;
                        case "all":
                            $selectCols = ['recurring_profiles.paypal_profile_id', 'transactions.transaction_id', 'transactions.amount', 'transactions.payment_time'];
                            $autoPaymentDetails = $this->_db->selectQueryWithJoin('transactions', 'recurring_profiles', 'recurring_profiles.profile_id', 'transactions.recurring_profile_id', ['rawQuery' => 'user_id = ? and recurring_profile_id != ?', 'bindParams' => [$tokenDetails['id'], 0]], $selectCols);

                            $selectCols = ['packages.package_name', 'transactions.transaction_id', 'transactions.amount', 'transactions.payment_time'];
                            $singlePaymentDetails = $this->_db->selectQueryWithJoin('transactions', 'packages', 'transactions.package_id', 'packages.package_id', ['rawQuery' => 'transactions.user_id = ? and transactions.package_id != ?', 'bindParams' => [$tokenDetails['id'], 0]], $selectCols);

                            $selectCols = ['transactions.item_desc', 'transactions.transaction_id', 'transactions.amount', 'transactions.payment_time'];
                            $addOnPaymentDetails = $this->_db->selectQuery('transactions', ['rawQuery' => 'transactions.user_id = ? and transactions.package_id = ? and transactions.tx_code = ?', 'bindParams' => [$tokenDetails['id'], 0, 'addonorder']], $selectCols);
                            if (!empty($addOnPaymentDetails) && is_array($addOnPaymentDetails)) {
                                foreach ($addOnPaymentDetails as $key => $details) {
                                    $addOnPaymentDetails[$key]['service_type'] = trim(explode('-', $details['item_desc'])[2]);
                                    unset($addOnPaymentDetails[$key]['item_desc']);
                                }
                            }

                            $paymentDetails = array_merge($autoPaymentDetails, $singlePaymentDetails, $addOnPaymentDetails);
                            if (!empty($paymentDetails) && is_array($paymentDetails)) {
                                usort($paymentDetails, function ($prevValue, $nextValue) {
                                    $prevValue = $prevValue['payment_time'];
                                    $nextValue = $nextValue['payment_time'];
                                    if ($prevValue == $nextValue) return 0;
                                    return ($prevValue < $nextValue) ? -1 : 1;
                                });

                                array_walk($paymentDetails, function (&$value, $key) {
                                    $value['payment_time'] = convertRelativeTime($value['payment_time']);
                                });

                                apiResponse(200, 'Transaction Details', null, $paymentDetails);
                            } else {
                                apiResponse(400, 'No records available.', 'No records found.', null);
                            }
                            break;
                        default:
                            apiResponse(400, 'payment_from is not valid.', 'invalid payment_from.', null);
                            break;
                    }
                } else
                    apiResponse(412, 'Please provide the payment_from (auto_payment/single_payment/add_ons/all)', 'payment_from is missing', null);


            } else
                apiResponse(400, 'Not a valid access_token', 'invalid access_token', null);
        } else
            apiResponse(400, 'Please provide the access_token', 'access_token is missing.', null);
    }

    public function changeUsername(Request $request)
    {

        $validator = Validator::make($request->all(), [
            'access_token' => ['required', function ($attr, $val, $msg) {
                if (!array_key_exists('id', parseAccessToken($val))) return $msg('Please provide correct ' . $attr);
            }],
            'autolikes_id' => ['required', Rule::exists('autolikes_orders')],
            'new_username' => 'required'
        ], [
            'access_token.required' => 'Please provide the access_token.',
            'autolikes_id.required' => 'autolikes_id is missing.',
            'autolikes_id.exists' => 'autolikes_id doesn\'t exist.',
            'new_username.required' => 'Please enter the new username.'
        ]);

        if (!$validator->fails()) {
            $profileStatus = ['pending', 'running', 'finished', 'cancelled', 'stopped', 'paused', 'suspended'];
            $whereCondition = ['rawQuery' => 'autolikes_id = ?', 'bindParams' => [$request['autolikes_id']]];

            $profileDetails = $this->_db->selectQuery('autolikes_orders',
                [
                    'rawQuery' => 'autolikes_id = ? and by_user_id = ?',
                    'bindParams' => [$request['autolikes_id'], parseAccessToken($request['access_token'])['id']]
                ],
                ['insta_username', 'status']
            );
            if (!empty($profileDetails)) {


                if ($profileDetails[0]['status'] == 1) {

                    if (strcmp($request['new_username'], $profileDetails[0]['insta_username']) !== 0) {

                        $instaScrape = new Instagram_scrape();
                        $details = json_decode($instaScrape->getProfileDetails($request['new_username']), true);

                        if ($details['code'] == 200) {

                            $dataToUpdate = ['insta_username' => $request['new_username'], 'profile_image' => $details['response']['profile_pic_url']];
                            $updated = $this->_db->updateQuery('autolikes_orders', $whereCondition, $dataToUpdate);
                            if ($updated) {

                                $medias = $details['response']['media'];
                                if (!empty($medias)) {
                                    array_walk($medias, function (&$value, $key) {
                                        unset($value['order_token']);
                                    });
                                }
                                //check if its already exist , update or insert
                                $metaDetailsExists = $this->_db->getCount('autolikes_orders_meta', ['rawQuery' => 'parent_autolikes_id = ?', 'bindParams' => [$request['autolikes_id']]]);
                                if ($metaDetailsExists == 0) { // insert
                                    $this->_db->insert('autolikes_orders_meta', [
                                        'parent_autolikes_id' => $request['autolikes_id'],
                                        'medias' => json_encode($medias)
                                    ]);
                                } else { // update
                                    $this->_db->updateQuery('autolikes_orders_meta', ['rawQuery' => 'parent_autolikes_id = ?', 'bindParams' => [$request['autolikes_id']]], ['medias' => json_encode($medias)]);
                                }

                                $whereCondition = ['rawQuery' => 'autolikes_id = ?', 'bindParams' => [$request['autolikes_id']]];
                                $selectCols = ['autolikes_id', 'profile_image', 'insta_username', 'medias', 'daily_post_done', 'daily_post_limit', 'post_fetch_count', 'post_limit', 'sub_package_name', 'billing_period', 'quantity', 'views_per_post', 'message', 'autolikes_orders.status'];

                                $autolikesMetaDetails = $this->objAutolikesOrder->profileMetaWithRecurringAndPackageDetails($whereCondition, $selectCols);

                                if (!empty($autolikesMetaDetails) && is_array($autolikesMetaDetails)) {
                                    $autolikesMetaDetails = $autolikesMetaDetails[0];

                                    if ($autolikesMetaDetails['billing_period'] != "")
                                        $autolikesMetaDetails['billing_cycle'] = explode(' ', $autolikesMetaDetails['billing_period'])[1];
                                    else
                                        $autolikesMetaDetails['billing_cycle'] = null;

                                    $autolikesMetaDetails['autolikes'] = ($autolikesMetaDetails['status'] == 1) ? 'on' : 'off';
                                    $autolikesMetaDetails['medias'] = json_decode($autolikesMetaDetails['medias'], true);
                                    unset($autolikesMetaDetails['billing_period']);

                                    $profileStatus = ['pending', 'running', 'finished', 'cancelled', 'stopped', 'paused', 'suspended'];
                                    $autolikesMetaDetails['status'] = ucfirst($profileStatus[$autolikesMetaDetails['status']]);

                                    apiResponse(200, 'Username has been updated successfully.', null, $autolikesMetaDetails);

                                } else
                                    apiResponse(200, 'Username has been updated successfully.', null, $details['response']);
                            } else
                                apiResponse(400, 'Something went wrong, please try after sometime.', 'error in username updation.', null);

                        } else if ($details['code'] == 400) {
                            apiResponse(400, $details['response'], 'Username may be private or doesn\'t exist.', null);
                        } else {
                            apiResponse(400, 'Something went wrong, please try again.', 'error in fetching profile details', null);
                        }

                    } else {
                        apiResponse(400, 'Your new username can\'t be the same as old username.', 'same username as already saved.', null);
                    }
                } else {
                    apiResponse(400, 'Profile is in ' . $profileStatus[$profileDetails[0]['status']] . ' state.', 'profile is not active.', null);
                }

            } else {
                apiResponse(400, 'You are not authorized to change this username.', 'this access_token can\'t access this profile.', null);
            }
        } else {
            $errMsg = json_decode($validator->messages(), true);
            apiResponse(412, array_values($errMsg)[0][0], 'Validation error', null);
        }

    }

    public function autolikesDashboardOLD(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'access_token' => ['required', function ($attr, $val, $fail) {
                if (!array_key_exists('id', parseAccessToken($val))) return $fail($attr . ' is invalid.');
            }],
            'autolikes_id' => ['required', Rule::exists('autolikes_orders')]
        ]);

        if (!$validator->fails()) {

            /* TODO
               TODO first check the autolikes id is placed with the same access_token or not.
               todo then check if the row exists in autolikes_orders_meta table or not
               todo if not then first scrape the profile and fetch the media and store in autolikes_orders_meta table
               todo lets start first this much. :-)
               TODO 2nd join autolikes_orders and autolikes_orders_meta table
            */


            $profileDetails = $this->_db->selectQuery(
                'autolikes_orders',
                [
                    'rawQuery' => 'autolikes_id = ? and by_user_id = ?',
                    'bindParams' => [$request['autolikes_id'], parseAccessToken($request['access_token'])['id']]
                ],
                ['insta_username', 'status']
            );

            if (!empty($profileDetails)) {

                fetctProfileMetaDetails:
                $whereCondition = ['rawQuery' => 'autolikes_id = ?', 'bindParams' => [$request['autolikes_id']]];
                $selectCols = ['autolikes_id', 'profile_image', 'insta_username', 'medias', 'daily_post_done', 'daily_post_limit', 'post_fetch_count', 'post_limit', 'sub_package_name', 'billing_period', 'quantity', 'views_per_post', 'message', 'autolikes_orders.status'];

                $autolikesMetaDetails = $this->objAutolikesOrder->profileMetaWithRecurringAndPackageDetails($whereCondition, $selectCols);

                if (!empty($autolikesMetaDetails) && is_array($autolikesMetaDetails)) {
                    $autolikesMetaDetails = $autolikesMetaDetails[0];

                    if ($autolikesMetaDetails['billing_period'] != "")
                        $autolikesMetaDetails['billing_cycle'] = explode(' ', $autolikesMetaDetails['billing_period'])[1];
                    else
                        $autolikesMetaDetails['billing_cycle'] = null;

                    $autolikesMetaDetails['autolikes'] = ($autolikesMetaDetails['status'] == 1) ? 'on' : 'off';
                    $autolikesMetaDetails['medias'] = json_decode($autolikesMetaDetails['medias'], true);
                    unset($autolikesMetaDetails['billing_period']);

                    apiResponse(200, 'Subscription profile details with media', null, $autolikesMetaDetails);


                } else {
                    //means we need to create one row in autolikes_orders_meta table
                    $metaDetailsExist = $this->_db->selectQuery('autolikes_orders_meta', ['rawQuery' => 'parent_autolikes_id = ?', 'bindParams' => [$request['autolikes_id']]]);

                    if (empty($metaDetailsExist)) {

                        $insta_username = $profileDetails[0]['insta_username'];
                        //scrape media for insta_username and store in one table
                        $instaScrape = new Instagram_scrape();
                        $details = json_decode($instaScrape->getProfileDetails($insta_username), true);
                        if ($details['code'] == 200) {
                            $medias = $details['response']['media'];

                            if (is_array($medias)) { //!empty($medias) && 

                                array_walk($medias, function (&$value, $key) {
                                    unset($value['order_token']);
                                });

                                $inserted = $this->_db->insert('autolikes_orders_meta', [
                                    'parent_autolikes_id' => $request['autolikes_id'],
                                    'medias' => json_encode($medias)
                                ]);

                                if ($inserted)
                                    goto fetctProfileMetaDetails;
                                else
                                    apiResponse(400, 'Something went wrong, Please try after sometime.', 'error in meta details insertion', null);

                            } else
                                apiResponse(400, 'Something went wrong, Please try after sometime.', 'error in parsing media', null);

                        } else if ($details['code'] == 400) {
                            apiResponse(400, $details['response'], 'Username may be private or doesn\'t exist.', null);
                        } else {
                            apiResponse(400, 'Something went wrong, please try again.', 'error in fetching profile details', null);
                        }

                    } else {
                        apiResponse(400, 'Something went wrong , please try after sometime.', 'error in fetching package and recurring profile details.', null);
                    }

                }

            } else {
                apiResponse(400, 'This profile is not placed by you.', 'access_token and autolikes_id combination is wrong.', null);
            }

        } else {
            $errMsg = json_decode($validator->messages(), true);
            apiResponse(412, array_values($errMsg)[0][0], 'Validation error', null);
        }

    }

    public function autolikesDashboard(Request $request)
    {
        $rules = [
            'access_token' => ['required', function ($attr, $val, $fail) {
                if (!array_key_exists('id', parseAccessToken($val))) return $fail($attr . ' is invalid.');
            }]
        ];

        if ($request->input('autolikes_id') && $request['autolikes_id'] == "latest") {
            $rules = array_merge($rules, ['autolikes_id' => ['required']]);
        } else
            $rules = array_merge($rules, ['autolikes_id' => ['required', Rule::exists('autolikes_orders')]]);

        $validator = Validator::make($request->all(), $rules);

        if (!$validator->fails()) {

            if ($request['autolikes_id'] == "latest") {
                $latestProfileDetails = $this->_db->selectQuery('autolikes_orders', ['rawQuery' => 'by_user_id = ?', 'bindParams' => [parseAccessToken($request['access_token'])['id']]], ['insta_username', 'status', 'autolikes_id']);
                $latestProfileDetails = array_reverse($latestProfileDetails);
                if (empty($latestProfileDetails)) {
                    apiResponse(400, 'No any autolikes profile found.', 'profile not found.', null);
                } else {
                    $latestProfileDetails = $latestProfileDetails[0];
                    $request['autolikes_id'] = $latestProfileDetails['autolikes_id'];
                    unset($latestProfileDetails['autolikes_id']);
                    $profileDetails[] = $latestProfileDetails;
                }
            } else {
                $profileDetails = $this->_db->selectQuery(
                    'autolikes_orders',
                    [
                        'rawQuery' => 'autolikes_id = ? and by_user_id = ?',
                        'bindParams' => [$request['autolikes_id'], parseAccessToken($request['access_token'])['id']]
                    ],
                    ['insta_username', 'status']
                );
            }
            if (!empty($profileDetails)) {

                fetctProfileMetaDetails:
                $whereCondition = ['rawQuery' => 'autolikes_id = ?', 'bindParams' => [$request['autolikes_id']]];
                $selectCols = ['autolikes_id', 'profile_image', 'insta_username', 'medias', 'daily_post_done', 'daily_post_limit', 'post_fetch_count', 'post_limit', 'sub_package_name', 'billing_period', 'quantity', 'views_per_post', 'message', 'autolikes_orders.status'];

                $autolikesMetaDetails = $this->objAutolikesOrder->profileMetaWithRecurringAndPackageDetails($whereCondition, $selectCols);

                if (!empty($autolikesMetaDetails) && is_array($autolikesMetaDetails)) {
                    $autolikesMetaDetails = $autolikesMetaDetails[0];

                    if ($autolikesMetaDetails['billing_period'] != "")
                        $autolikesMetaDetails['billing_cycle'] = explode(' ', $autolikesMetaDetails['billing_period'])[1];
                    else
                        $autolikesMetaDetails['billing_cycle'] = null;

                    $autolikesMetaDetails['autolikes'] = ($autolikesMetaDetails['status'] == 1) ? 'on' : 'off';
                    $autolikesMetaDetails['medias'] = json_decode($autolikesMetaDetails['medias'], true);
                    unset($autolikesMetaDetails['billing_period']);

                    $profileStatus = ['pending', 'running', 'finished', 'cancelled', 'stopped', 'paused', 'suspended'];
                    $autolikesMetaDetails['status'] = ucfirst($profileStatus[$autolikesMetaDetails['status']]);

                    apiResponse(200, 'Subscription profile details with media', null, $autolikesMetaDetails);


                } else {
                    //means we need to create one row in autolikes_orders_meta table
                    $metaDetailsExist = $this->_db->selectQuery('autolikes_orders_meta', ['rawQuery' => 'parent_autolikes_id = ?', 'bindParams' => [$request['autolikes_id']]]);

                    if (empty($metaDetailsExist)) {

                        $insta_username = $profileDetails[0]['insta_username'];
                        //scrape media for insta_username and store in one table
                        $instaScrape = new Instagram_scrape();
                        $details = json_decode($instaScrape->getProfileDetails($insta_username), true);
                        if ($details['code'] == 200) {
                            $medias = $details['response']['media'];

                            if (is_array($medias)) { //!empty($medias) &&

                                array_walk($medias, function (&$value, $key) {
                                    unset($value['order_token']);
                                });

                                $inserted = $this->_db->insert('autolikes_orders_meta', [
                                    'parent_autolikes_id' => $request['autolikes_id'],
                                    'medias' => json_encode($medias)
                                ]);

                                if ($inserted)
                                    goto fetctProfileMetaDetails;
                                else
                                    apiResponse(400, 'Something went wrong, Please try after sometime.', 'error in meta details insertion', null);

                            } else
                                apiResponse(400, 'Something went wrong, Please try after sometime.', 'error in parsing media', null);

                        } else if ($details['code'] == 400) {
                            apiResponse(400, $details['response'], 'Username may be private or doesn\'t exist.', null);
                        } else {
                            apiResponse(400, 'Something went wrong, please try again.', 'error in fetching profile details', null);
                        }

                    } else {
                        apiResponse(400, 'Something went wrong , please try after sometime.', 'error in fetching package and recurring profile details.', null);
                    }

                }

            } else {
                apiResponse(400, 'This profile is not placed by you.', 'access_token and autolikes_id combination is wrong.', null);
            }

        } else {
            $errMsg = json_decode($validator->messages(), true);
            apiResponse(412, array_values($errMsg)[0][0], 'Validation error', null);
        }

    }

    public function autolikesChangeStatus(Request $request)
    {

        $validator = Validator::make($request->all(), [
            'access_token' => ['required', function ($attr, $val, $fail) {
                if (!array_key_exists('id', parseAccessToken($val))) return $fail($attr . ' is invalid.');
            }],
            'autolikes_id' => ['required', Rule::exists('autolikes_orders')],
            'status' => ['required', function ($att, $val, $msg) {
                if (!in_array($val, ['on', 'off'])) return $msg($att . ' is invalid');
            }]
        ]);

        if (!$validator->fails()) {
            $profileStatus = ['pending', 'running', 'finished', 'cancelled', 'stopped', 'paused', 'suspended'];

            $profileDetails = $this->_db->selectQuery(
                'autolikes_orders',
                [
                    'rawQuery' => 'autolikes_id = ? and by_user_id = ?',
                    'bindParams' => [$request['autolikes_id'], parseAccessToken($request['access_token'])['id']]
                ],
                ['insta_username', 'status']
            );

            if (!empty($profileDetails)) {
                if ($profileDetails[0]['status'] == 1 || $profileDetails[0]['status'] == 5) {
                    $status = ($request['status'] == "off") ? 5 : 1;
                    $statusMsg = ($request['status'] == "off") ? 'Profile has been paused.' : 'Script is running and waiting for new post.';
                    $updated = $this->_db->updateQuery('autolikes_orders', ['rawQuery' => 'autolikes_id = ?', 'bindParams' => [$request['autolikes_id']]], ['status' => $status, 'message' => $statusMsg]);
                    if ($updated) {
                        if ($updated == 1)
                            $autolikes = ($status == 5) ? 'off' : 'on';
                        else
                            $autolikes = $request['status'];
                        apiResponse(200, 'Status changed successfully', null, ['autolikes' => $autolikes, 'status' => ucfirst($profileStatus[$status])]);
                    } else
                        apiResponse(400, 'Something went wrong, Please try after sometime.', null, null);

                } else {
                    apiResponse(400, 'Profile is in ' . $profileStatus[$profileDetails[0]['status']] . ' state.', 'profile is not active.', null);
                }
            } else {
                apiResponse(400, 'This profile is not placed by you.', 'access_token and autolikes_id combination is wrong.', null);
            }
        } else {
            $errMsg = json_decode($validator->messages(), true);
            apiResponse(412, array_values($errMsg)[0][0], 'Validation error', null);
        }

    }

    public function emergencyModule()
    {
        $module = config('EmergencySwitch.Emergency_switch_Autoig');
        if ($module === 'ON')
            apiResponse(200, 'Emergency module is on.', null, ['emergency_page' => 'on']);
        else
            apiResponse(400, 'Emergency module is off.', null, ['emergency_page' => 'off']);
    }


    public function emergencyOrder(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'access_token' => ['required', function ($attr, $val, $fail) {
                if (!array_key_exists('id', parseAccessToken($val))) return $fail($attr . ' is invalid.');
            }],
            'autolikes_id' => ['required', Rule::exists('autolikes_orders')],
            'order_url' => 'required|url|regex:/^(http(s)?:\/\/)?(www\.)?(instagram)\.+(com)+\/+(p)\/(([a-zA-Z0-9\.\-\_])*)+\/*(([a-zA-Z0-9\?\-\=\.\@\_])*)/',
        ], [
            'order_url.regex' => 'Your link looks invalid! Example of a correct link for this service : http://instagram.com/p/vrTV-bAp9E/'
        ]);

        if (!$validator->fails()) {
            $profileStatus = ['pending', 'running', 'finished', 'cancelled', 'stopped', 'paused', 'suspended'];

            $whereCondition = ['rawQuery' => 'autolikes_id = ?', 'bindParams' => [$request['autolikes_id']]];
            $selectCols = ['autolikes_orders.*', 'autolikes_orders.status as profileStatus', 'subscription_packages.*', 'autolikes_orders_meta.*', 'recurring_profiles.*'];

            $profileDetails = $this->objAutolikesOrder->profileMetaWithRecurringAndPackageDetails($whereCondition, $selectCols);

            if (!empty($profileDetails)) {
                $profileDetails = $profileDetails[0];

                if ($profileDetails['profileStatus'] == 1) {

                    /* Scraping Instagram Post Link based on Shortcode */
                    $orderUrl = $request['order_url'];
                    $shortcode = explode('/', $orderUrl)[4];
                    $instaScrape = new Instagram_scrape();
                    $details = json_decode($instaScrape->getInstaMediaDetails($shortcode), true);

                    if ($details['code'] == 200 || $details['code'] == 500) {

                        if ($details['code'] == 200) {
                            $likes_start_count = $details['response']['likes_count'];
                            $views_start_count = $details['response']['views_count'];
                        } else {
                            $likes_start_count = 0;
                            $views_start_count = 0;
                        }

                        $packageType = $profileDetails['sub_package_type'];
                        $packageDetails = $profileDetails[$packageType];
                        $packageDetails = json_decode($packageDetails, true)[0];
                        $plan_id = $packageDetails['plan_id'];

                        /* likes split option settings */
                        $likesSplitOption = json_decode($profileDetails['likes_split_option'], true);
                        $start_time = time();
                        $orders_per_run = null;
                        $time_interval = null;
                        if (!empty($likesSplitOption) && is_array($likesSplitOption)) {
                            $start_time = $start_time + $likesSplitOption['likes_start_delay'];
                            if ($likesSplitOption['likes_split_option_enabled'] === "on") {
                                $orders_per_run = $likesSplitOption['likes_quantity_per_run'];
                                $time_interval = $likesSplitOption['likes_delay_interval'];
                            }
                        }

                        $orderDataToAdd[] = [
                            'user_id' => parseAccessToken($request['access_token'])['id'],
                            'package_type' => 0,
                            'autolikes_id' => $request['autolikes_id'],
                            'sub_package_id' => $profileDetails['sub_package_id'],
                            'order_url' => $request['order_url'],
                            'url_type' => 1,  //0= profile link ; 1= post link
                            'plan_id' => $plan_id,
                            'start_count' => $likes_start_count,
                            'end_count' => 0,
                            'quantity' => $profileDetails['quantity'],
                            'start_time' => $start_time,
                            'orders_per_run' => $orders_per_run,
                            'time_interval' => $time_interval,
                            'status' => 0,
                            'added_time' => time(),
                            'updated_time' => time()
                        ];

                        /* views settings */
                        if ($profileDetails['auto_views'] === "on") {
                            /* views split option settings */
                            $viewsSplitOption = json_decode($profileDetails['views_split_option'], true);
                            $start_time = time();
                            $orders_per_run = null;
                            $time_interval = null;
                            if (!empty($viewsSplitOption) && is_array($viewsSplitOption)) {
                                $start_time = $start_time + $viewsSplitOption['views_start_delay'];
                                if ($viewsSplitOption['views_split_option_enabled'] === "on") {
                                    $orders_per_run = $viewsSplitOption['views_quantity_per_run'];
                                    $time_interval = $viewsSplitOption['views_delay_interval'];
                                }
                            }

                            $orderDataToAdd[] = [
                                'user_id' => parseAccessToken($request['access_token'])['id'],
                                'package_type' => 4,
                                'autolikes_id' => $request['autolikes_id'],
                                'sub_package_id' => $profileDetails['sub_package_id'],
                                'order_url' => $request['order_url'],
                                'url_type' => 1,  //0= profile link ; 1= post link
                                'plan_id' => $profileDetails['views_plan_id'],
                                'start_count' => $views_start_count,
                                'end_count' => 0,
                                'quantity' => $profileDetails['views_per_post'],
                                'start_time' => $start_time,
                                'orders_per_run' => $orders_per_run,
                                'time_interval' => $time_interval,
                                'status' => 0,
                                'added_time' => time(),
                                'updated_time' => time()
                            ];
                        }
                        $inserted = $this->_db->insertMultipleData('orders', $orderDataToAdd);
                        if ($inserted) {

                            $profileDataToUpdate = [
                                'post_fetch_count' => DB::raw('post_fetch_count + 1'),
                                'daily_post_done' => DB::raw('daily_post_done + 1'),
                            ];

                            $updated = $this->_db->updateQuery('autolikes_orders', $whereCondition, $profileDataToUpdate);
                            apiResponse(200, 'Order placed successfully.', null, null);

                        } else
                            apiResponse(400, 'Something went wrong, please try after sometime.', null, null);

                    } else {
                        apiResponse(400, $details['response'], 'link is invalid or private.', null);
                    }
                } else {
                    apiResponse(400, 'Profile is in ' . $profileStatus[$profileDetails['profileStatus']] . ' state.', 'profile is not active.', null);
                }

            } else {
                apiResponse(400, 'This profile is not placed by you.', 'access_token and autolikes_id combination is wrong.', null);
            }
        } else {
            $errMsg = json_decode($validator->messages(), true);
            apiResponse(412, array_values($errMsg)[0][0], 'Validation error', null);
        }

    }

    public function reactivateProfile(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'access_token' => ['required', function ($attr, $val, $fail) {
                if (!array_key_exists('id', parseAccessToken($val))) return $fail($attr . ' is invalid.');
            }],
            'autolikes_id' => ['required', Rule::exists('autolikes_orders')],
        ]);

        if (!$validator->fails()) {
            $profileDetails = $this->_db->selectQueryWithJoin('autolikes_orders',
                'recurring_profiles',
                'recurring_profiles.profile_id',
                'autolikes_orders.recurring_profile_id',
                ['rawQuery' => 'autolikes_id = ? and autolikes_orders.by_user_id = ?', 'bindParams' => [$request['autolikes_id'], parseAccessToken($request['access_token'])['id']]],
                ['insta_username', 'status', 'paypal_profile_id']
            );

            if ($profileDetails) {
                $paypalProfileId = $profileDetails[0]['paypal_profile_id'];
                $payment = Bond::createObject();
                $response = $payment->manageRecurringPayments($paypalProfileId, 'Reactivate');
                if ($response['ACK'] === "Success") {
                    $this->_db->updateQuery('autolikes_orders', ['rawQuery' => 'autolikes_id = ?', 'bindParams' => [$request['autolikes_id']]], ['status' => 1]);
                    $this->_db->updateQuery('recurring_profiles', ['rawQuery' => 'paypal_profile_id = ?', 'bindParams' => [$paypalProfileId]], ['profile_status' => 1]);
                    apiResponse(200, 'Profile has been reactivated', null, null);

                } else {
                    apiResponse(400, $response['L_LONGMESSAGE0'], $response['L_SHORTMESSAGE0'], null);
                }

            } else {
                apiResponse(400, 'Profile details not found, Please try after sometime.', 'details not found.', null);
            }

        } else {
            $errMsg = json_decode($validator->messages(), true);
            apiResponse(412, array_values($errMsg)[0][0], 'Validation error', null);
        }


    }

    public function getAddOnServiceDetails(Request $request)
    {
        $selectCols = ['plan_type', 'min_quantity', 'max_quantity', 'selling_price'];
        $addOnPlansDetails = $this->_db->selectQuery('plans', ['rawQuery' => 'add_on_plans = 1'], $selectCols);

        $details = [];
        $planType = [0 => 'likes', 3 => 'comments', 4 => 'views', 7 => 'impressions'];
        foreach ($planType as $type) {
            $details[$type] = "off";
        }

        foreach ($addOnPlansDetails as $plan) {
            if (isset($planType[$plan['plan_type']])) {
                $planTypeStr = $planType[$plan['plan_type']];
                $details[$planTypeStr] = "on";
                $details[$planTypeStr . '_min_quantity'] = $plan['min_quantity'];
                $details[$planTypeStr . '_max_quantity'] = $plan['max_quantity'];
                $details[$planTypeStr . '_price_per_k'] = $plan['selling_price'];
            } else {
                continue;
            }
        }
        if ($details) {
            apiResponse(200, 'Add on plans details.', null, $details);
        } else {
            apiResponse(400, 'No add-on package found. Please try after sometime.', null, null);
        }
    }

    public function placeAddOnServiceOrder(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'access_token' => ['required', function ($attr, $val, $fail) {
                if (!array_key_exists('id', parseAccessToken($val))) return $fail($attr . ' is invalid.');
            }],
            'order_url' => 'required|url|regex:/^(http(s)?:\/\/)?(www\.)?(instagram)\.+(com)+\/+(p)\/(([a-zA-Z0-9\.\-\_])*)+\/*(([a-zA-Z0-9\?\-\=\.\@\_])*)/',
            'display_url' => 'required',
            'likes' => ['required', function ($attr, $val, $fail) {
                if (!in_array($val, ['on', 'off'])) return $fail('likes value must be on/off only');
            }],
            'likes_quantity' => 'required_unless:likes,off|numeric',

            'views' => ['required', function ($attr, $val, $fail) {
                if (!in_array($val, ['on', 'off'])) return $fail('likes value must be on/off only');
            }],
            'views_quantity' => 'required_unless:views,off|numeric',

            'comments' => ['required', function ($attr, $val, $fail) {
                if (!in_array($val, ['on', 'off'])) return $fail('likes value must be on/off only');
            }],
            'comments_quantity' => 'required_unless:comments,off|numeric',
            'comment_lists' => ['required_unless:comments,off', function ($attr, $val, $fail) {
                if (!is_array(json_decode($val, true))) return $fail('Comments text is not in proper format.');
            }],

            'impressions' => ['required', function ($attr, $val, $fail) {
                if (!in_array($val, ['on', 'off'])) return $fail('likes value must be on/off only');
            }],
            'impressions_quantity' => 'required_unless:impressions,off|numeric',
            'total_price' => "required|regex:/^\d*(\.\d{1,2})?$/"
        ]);

        if (!$validator->fails()) {
            /* calculation of price */
            $selectCols = ['plan_id', 'plan_type', 'min_quantity', 'max_quantity', 'selling_price'];
            $addOnPlansDetails = $this->_db->selectQuery('plans', ['rawQuery' => 'add_on_plans = 1'], $selectCols);

            $details = [];
            $planType = [0 => 'likes', 3 => 'comments', 4 => 'views', 7 => 'impressions'];
            foreach ($planType as $type) {
                $details[$type] = "off";
            }

            foreach ($addOnPlansDetails as $plan) {
                if (isset($planType[$plan['plan_type']])) {
                    $planTypeStr = $planType[$plan['plan_type']];
                    $details[$planTypeStr] = "on";
                    $details[$planTypeStr . '_min_quantity'] = $plan['min_quantity'];
                    $details[$planTypeStr . '_max_quantity'] = $plan['max_quantity'];
                    $details[$planTypeStr . '_price_per_k'] = $plan['selling_price'];
                    $details[$planTypeStr . '_plan_id'] = $plan['plan_id'];
                } else {
                    continue;
                }
            }

            $paypalDesc = "App AUTOIG - Add on - ";
            $allPrices = [];
            if (!empty($details)) {
                if ($request['likes'] == "on") {
                    if ($details['likes'] == "on") {
                        if ($request['likes_quantity'] < $details['likes_min_quantity'] || $request['likes_quantity'] > $details['likes_max_quantity'])
                            apiResponse(400, 'likes quantity must be between ' . $details['likes_min_quantity'] . ' and ' . $details['likes_max_quantity'], 'quantity mismatch', null);
                        $paypalDesc .= $request['likes_quantity'] . 'L ';
                        $allPrices['likes_price_per_k'] = $details['likes_price_per_k'];
                        $allPrices['likes_plan_id'] = $details['likes_plan_id'];
                    } else
                        apiResponse(400, 'You can not place likes order at this moment, please try after sometime.', 'quantity mismatch', null);

                }
                if ($request['views'] == "on") {
                    if ($details['views'] == "on") {
                        if ($request['views_quantity'] < $details['views_min_quantity'] || $request['views_quantity'] > $details['views_max_quantity'])
                            apiResponse(400, 'views quantity must be between ' . $details['views_min_quantity'] . ' and ' . $details['views_max_quantity'], 'quantity mismatch', null);
                        $paypalDesc .= $request['views_quantity'] . 'V ';
                        $allPrices['views_price_per_k'] = $details['views_price_per_k'];
                        $allPrices['views_plan_id'] = $details['views_plan_id'];
                    } else
                        apiResponse(400, 'You can not place views order at this moment, please try after sometime.', 'quantity mismatch', null);
                }
                if ($request['comments'] == "on") {
                    if ($details['comments'] == "on") {
                        if ($request['comments_quantity'] < $details['comments_min_quantity'] || $request['comments_quantity'] > $details['comments_max_quantity'])
                            apiResponse(400, 'comments quantity must be between ' . $details['comments_min_quantity'] . ' and ' . $details['comments_max_quantity'], 'quantity mismatch', null);
                        $paypalDesc .= $request['comments_quantity'] . 'C ';
                        $allPrices['comments_price_per_k'] = $details['comments_price_per_k'];
                        $allPrices['comments_plan_id'] = $details['comments_plan_id'];
                    } else
                        apiResponse(400, 'You can not place comments order at this moment, please try after sometime.', 'quantity mismatch', null);
                }
                if ($request['impressions'] == "on") {
                    if ($details['impressions'] == "on") {
                        if ($request['impressions_quantity'] < $details['impressions_min_quantity'] || $request['impressions_quantity'] > $details['impressions_max_quantity'])
                            apiResponse(400, 'impressions quantity must be between ' . $details['impressions_min_quantity'] . ' and ' . $details['impressions_max_quantity'], 'quantity mismatch', null);
                        $paypalDesc .= $request['impressions_quantity'] . 'I ';
                        $allPrices['impressions_price_per_k'] = $details['impressions_price_per_k'];
                        $allPrices['impressions_plan_id'] = $details['impressions_plan_id'];
                    } else
                        apiResponse(400, 'You can not place impressions order at this moment, please try after sometime.', 'quantity mismatch', null);
                }
                $paypalDesc .= 'Points';

                /* validation comments lists if the order is placed for comments */
                if ($request->input('comment_lists')) {
                    if (is_array($commentsArr = json_decode($request['comment_lists']))) {
                        if (count($commentsArr) >= $request['comments_quantity']) {
                            $objModelComments = new Comments();
                            $insertedCommentId = $objModelComments->insertComments([
                                'comment_group_id' => 0,
                                'comments' => $request['comment_lists'],
                                'user_id' => parseAccessToken($request['access_token'])['id'],
                                'added_at' => time()
                            ]);
                            if (!$insertedCommentId) {
                                apiResponse(400, 'Something went wrong in storing comments, please try after sometime.', 'error in comment insertion.', null);
                            }
                        } else
                            apiResponse(400, 'Comment lists should not be less than ' . $request['comments_quantity'], 'less comment quantity.', null);
                    } else
                        apiResponse(400, 'Comments text is not in proper format.', 'invalid format.', null);
                }

                if ($request['total_price'] != 0) {
                    $postData = $request->all();
                    unset($postData['access_token']);
                    $checkoutConfig = [
                        "iat" => time(),
                        "amount" => $request['total_price'] * 100,
                        "description" => $paypalDesc,
                        "quantity" => 1,
                        "item_number" => array_merge(['id' => parseAccessToken($request['access_token'])['id']], $postData, $allPrices),
//                        "package_details" => $checkoutToken['package_details'][0],
                    ];

                    if (isset($insertedCommentId)) {
                        $checkoutConfig['item_number']['comment_id'] = $insertedCommentId;
                    }

                    $url = env('WEB_URL') . '/addoncheckout/' . generateAccessToken($checkoutConfig);
                    apiResponse(200, 'Redirect to the url.', null, ['url' => $url]);
                } else {
                    apiResponse(400, 'Total price can not be zero (0)', 'price is 0', null);
                }

            } else
                apiResponse(400, 'No any add-on plan found, please check back in a while.', 'no any add-on plans', null);

        } else {
            $errMsg = json_decode($validator->messages(), true);
            apiResponse(412, array_values($errMsg)[0][0], 'Validation error', null);
        }
    }

    public function storeAddOnServiceOrder(Request $request)
    {
        $postData = $request->all();
//        $postData = [
//            "payer_email" => "saurabh.kumar-buyer@globussoft.com",
//            "payer_id" => "KJ99A3SSJ3SWQ",
//            "payer_status" => "VERIFIED",
//            "first_name" => "test",
//            "last_name" => "buyer",
//            "txn_id" => "3EB55320TR038873J",
//            "mc_currency" => "USD",
//            "mc_fee" => "0.48",
//            "mc_gross" => "4.60",
//            "protection_eligibility" => "INELIGIBLE",
//            "payment_fee" => "0.48",
//            "payment_gross" => "4.60",
//            "payment_status" => "Pending",
//            "pending_reason" => "paymentreview",
//            "payment_type" => "instant",
//            "item_name" => "App AUTOIG - Add on - 100L 100V 5C 100I Points",
//            "quantity" => "1",
//            "txn_type" => "web_accept",
//            "payment_date" => "2018-08-17T14:15:19Z",
//            "business" => "talktosaurabhkr@gmail.com",
//            "receiver_id" => "LWZ9MK2ZD56GL",
//            "notify_version" => "UNVERSIONED",
//            "custom" => '{"ip_address":"103.217.90.103","quaderno_id":404565,"application":"quaderno","tax":{"name":"GST","rate":15.0,"country":"IN"}}',
//            "verify_sign" => "AHRdi57TESH7SBc8-jTiaBLvLxXSAPXKFZ6RD.4XWS.Bx2kX5mH1mraj",
//            "checkout_token" => "eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpYXQiOjE1MzQ1MTUxOTMsImFtb3VudCI6NDAwLCJkZXNjcmlwdGlvbiI6IkFwcCBBVVRPSUcgLSBBZGQgb24gLSAxMDBMIDEwMFYgNUMgMTAwSSBQb2ludHMiLCJxdWFudGl0eSI6MSwiaXRlbV9udW1iZXIiOnsiaWQiOjMwMCwib3JkZXJfdXJsIjoiaHR0cHM6XC9cL3d3dy5pbnN0YWdyYW0uY29tXC9wXC9CbWdnWVd6SHFORFwvP3Rha2VuLWJ5PXNhdXJhYmhfYm9uZCIsImxpa2VzIjoib24iLCJsaWtlc19xdWFudGl0eSI6IjEwMCIsInZpZXdzIjoib24iLCJ2aWV3c19xdWFudGl0eSI6IjEwMCIsImNvbW1lbnRzIjoib24iLCJjb21tZW50c19xdWFudGl0eSI6IjUiLCJjb21tZW50X2xpc3RzIjoiW1wiYXdlc29tZSBwaWNcIixcInlvdSdyZSBsb29raW5nIGZhYlwiLFwiTmljZSBQaWMgYnVkZHkhIVwiLFwiSGV5IGJvbmRcIixcIndhc3N1cD9cIl0iLCJpbXByZXNzaW9ucyI6Im9uIiwiaW1wcmVzc2lvbnNfcXVhbnRpdHkiOiIxMDAiLCJ0b3RhbF9wcmljZSI6IjQiLCJkaXNwbGF5X3VybCI6Imh0dHBzOlwvXC9pbnN0YWdyYW0uZm1hYTEtMS5mbmEuZmJjZG4ubmV0XC92cFwvZDVhYjg3OTM5ZTE4ZGM4MThkOWQ3OWI3OTg3NTRmM2JcLzVCRUNGOEJCXC90NTEuMjg4NS0xNVwvZTM1XC8zODc5MDA4NF84NzAyMDIzNTY0OTg5NTlfMTI1MDM4NDE2NTIwODA2NDAwMF9uLmpwZyIsImxpa2VzX3ByaWNlX3Blcl9rIjoxLCJsaWtlc19wbGFuX2lkIjoyLCJ2aWV3c19wcmljZV9wZXJfayI6MSwidmlld3NfcGxhbl9pZCI6NSwiY29tbWVudHNfcHJpY2VfcGVyX2siOjE1LCJjb21tZW50c19wbGFuX2lkIjo0LCJpbXByZXNzaW9uc19wcmljZV9wZXJfayI6MiwiaW1wcmVzc2lvbnNfcGxhbl9pZCI6MTAsImNvbW1lbnRfaWQiOjEzMH19.tRv0e8PtVXJD4jc_bfp80OslsX4zSzY1DjwEIbugdEE",
//        ];

        $checkoutToken = parseAccessToken($postData['checkout_token']);

        $txDataToInsert = [
            'tx_type' => 0, // 0=single order transaction 1=for subscriptions
            'tx_mode' => 0, // 0=paypal
            'tx_code' => 'addonorder',
            'transaction_id' => $postData['txn_id'],
            'user_id' => $checkoutToken['item_number']['id'],
            'amount' => $postData['payment_gross'],
            'payer_email' => $postData['payer_email'],
            'payment_status' => $postData['payment_status'],
            'pending_reason' => $postData['pending_reason'],
            'payment_type' => $postData['payment_type'],
            'item_desc' => $postData['item_name'],
            'item_link' => $checkoutToken['item_number']['order_url'],
            'extra_details' => $postData['custom'],
//            'order_id' => '',
//            'autolikes_id' => $postData['payer_email'],
//            'device_id' => $postData['payer_email'],
//            'package_id' => $checkoutToken['package_details']['package_id'],
            'payment_time' => strtotime($postData['payment_date']),
        ];
        $insertedTx = Transaction::getInstance()->insertTransaction($txDataToInsert);

        if ($insertedTx) {
            $planType = ['likes' => 0, 'comments' => 3, 'views' => 4, 'impressions' => 7];

            $count = 0;
            foreach ($checkoutToken['item_number'] as $itemKey => $itemVal) {
                if (in_array($itemKey, ['likes', 'views', 'comments', 'impressions']) && $itemVal === "on") {
                    $orderDataToInsert[$count] = [
                        'user_id' => $checkoutToken['item_number']['id'],
                        'tx_id' => $insertedTx,
                        'package_id' => 0,
                        'package_type' => $planType[$itemKey],
                        'order_url' => $checkoutToken['item_number']['order_url'],
                        'url_type' => 1,
                        'plan_id' => $checkoutToken['item_number'][$itemKey . '_plan_id'],
                        'start_count' => 0,
                        'quantity' => $checkoutToken['item_number'][$itemKey . '_quantity'],
                        'start_time' => time(),
//                        'orders_per_run' => '',
//                        'time_interval' => '',
                        'status' => 0,
                        'added_time' => time(),
                        'updated_time' => time(),
                        'comment_id' => null
                    ];

                    if ($itemKey == "comments")
                        $orderDataToInsert[$count]['comment_id'] = $checkoutToken['item_number']['comment_id'];
                    ++$count;
                }
            }

            $orderAdded = $this->_db->insertMultipleData('orders', $orderDataToInsert);
            if ($orderAdded)
                apiResponse(200, 'Order added successfully.', null, $orderAdded);
        } else {
            apiResponse(400, 'Something went wrong, Please try after sometime.', null, null);
        }
    }

    public function ipnListenerTest(Request $request)
    {
        $payment = Bond::createObject();

//        $raw_post_data = file_get_contents('php://input');
//        $raw_post_data = 'transaction_subject=&payment_date=23:23:19 Jul 27, 2018 PDT&txn_type=web_accept&last_name=buyer&residence_country=IN&pending_reason=paymentreview&item_name=Package: 200 LQ Likes    Price: 1.00   AUTOIG.&payment_gross=1.15&mc_currency=USD&business=talktosaurabhkr@gmail.com&payment_type=instant&protection_eligibility=Ineligible&verify_sign=A92gRgWlga4qfY5Q17oR-WmyiRQKAn8ulH1NvikW39IeCzBGzmQ9ZUKR&payer_status=verified&test_ipn=1&payer_email=saurabh.kumar-buyer@globussoft.com&txn_id=75R72262VJ692254L&quantity=1&receiver_email=talktosaurabhkr@gmail.com&first_name=test&payer_id=KJ99A3SSJ3SWQ&receiver_id=LWZ9MK2ZD56GL&item_number=&payment_status=Pending&payment_fee=0.34&mc_fee=0.34&mc_gross=1.15&custom={"ip_address":"47.247.122.115","quaderno_id":401354,"application":"quaderno","tax":{"name":"GST","rate":15.0,"country":"IN"}}&charset=UTF-8&notify_version=3.9&ipn_track_id=7b1c7338486d2';
        $raw_post_data = 'mc_gross=4.00&period_type= Regular&outstanding_balance=0.00&next_payment_date=03:00:00 Jul 29, 2018 PDT&protection_eligibility=Ineligible&payment_cycle=Daily&address_status=unconfirmed&tax=0.00&payer_id=9QZPMG2EKNNL8&address_street=Flat no. 507 Wing A Raheja Residency
Film City Road, Goregaon East&payment_date=11:33:59 Jul 28, 2018 PDT&payment_status=Pending&product_name=saurabh_bond : 100 Likes&charset=UTF-8&recurring_payment_id=I-23RDFA3LHVHW&address_zip=400097&first_name=test&mc_fee=0.46&address_country_code=IN&address_name=test buyer&notify_version=3.9&amount_per_cycle=4.00&payer_status=verified&currency_code=USD&business=talktosaurabhkr@gmail.com&address_country=India&address_city=Mumbai&verify_sign=ARTWVaUGckuviK6HZ-Of6l88vDtdA4thcFxM9UmOBH86MjgDin4c0ZQJ&payer_email=saurabh.kumar-buyer@globussoft.in&initial_payment_amount=0.00&profile_status=Active&amount=4.00&txn_id=0W864523GJ689162A&payment_type=instant&last_name=buyer&address_state=Maharashtra&receiver_email=talktosaurabhkr@gmail.com&payment_fee=0.46&receiver_id=LWZ9MK2ZD56GL&pending_reason=paymentreview&txn_type=recurring_payment&mc_currency=USD&residence_country=IN&test_ipn=1&transaction_subject=saurabh_bond : 100 Likes&payment_gross=4.00&shipping=0.00&product_type=1&time_created=05:31:47 Jul 18, 2018 PDT&ipn_track_id=a1ebd4572670';
        $ipnResponse = $payment->ipnHandler($raw_post_data);

        $ipnResponse = json_decode($ipnResponse, true);


        if ($ipnResponse['status'] == 200) {

//            foreach ($_POST as $key => $value) {
//                echo $key . " = " . $value . "<br>";
//            }

            $raw_post_array = explode('&', $raw_post_data);
            $myPost = array();
            foreach ($raw_post_array as $keyval) {
                $keyval = explode('=', $keyval);
                if (count($keyval) == 2)
                    $myPost[$keyval[0]] = urldecode($keyval[1]);
            }
//            dd($myPost);

            $insertedProfile = $this->_db->insert('ipn_response', [
                'amount' => isset($myPost['mc_gross']) ? $myPost['mc_gross'] : '',//'mc_gross', //mc_gross
                'period_type' => isset($myPost['period_type']) ? $myPost['period_type'] : '',//' period_type', //Regular
                'outstanding_balance' => isset($myPost['outstanding_balance']) ? $myPost['outstanding_balance'] : '',//'outstanding_balance',
                'next_payment_date' => isset($myPost['next_payment_date']) ? $myPost['next_payment_date'] : '',//'03:00:00 Jul 28, 2018 PDT',
                'payment_cycle' => isset($myPost['payment_cycle']) ? $myPost['payment_cycle'] : '',//'Daily',
                'payer_id' => isset($myPost['payer_id']) ? $myPost['payer_id'] : '',//'9QZPMG2EKNNL8',
                'address_street' => isset($myPost['address_street']) ? $myPost['address_street'] : '',//'Flat no. 507 Wing A Raheja Residency Film City Road, Goregaon East',
                'payment_date' => isset($myPost['payment_date']) ? $myPost['payment_date'] : '',//'04:23:05 Jul 27, 2018 PDT',
                'payment_status' => isset($myPost['payment_status']) ? $myPost['payment_status'] : '',//'Pending',
                'product_name' => isset($myPost['product_name']) ? $myPost['product_name'] : '',//'zuck : 100 Likes',
                'recurring_payment_id' => isset($myPost['recurring_payment_id']) ? $myPost['recurring_payment_id'] : '',//'I-VCE8SUR575CU',
                'payer_email' => isset($myPost['payer_email']) ? $myPost['payer_email'] : '',//'saurabh.kumar-buyer@globussoft.in',
                'first_name' => isset($myPost['first_name']) ? $myPost['first_name'] : '',//'test',
                'last_name' => isset($myPost['last_name']) ? $myPost['last_name'] : '',//'buyer',
                'address_country_code' => isset($myPost['address_country_code']) ? $myPost['address_country_code'] : '',//'IN',
                'amount_per_cycle' => isset($myPost['amount_per_cycle']) ? $myPost['amount_per_cycle'] : '',//'4.00',
                'payer_status' => isset($myPost['payer_status']) ? $myPost['payer_status'] : '',//'verified',
                'currency_code' => isset($myPost['currency_code']) ? $myPost['currency_code'] : '',//'USD',
                'profile_status' => isset($myPost['profile_status']) ? $myPost['profile_status'] : '',//'Active',
                'txn_id' => isset($myPost['txn_id']) ? $myPost['txn_id'] : '',//'4S9587029U731824C',
                'payment_type' => isset($myPost['payment_type']) ? $myPost['payment_type'] : '',//'instant',
                'business' => isset($myPost['business']) ? $myPost['business'] : '',//'talktosaurabhkr@gmail.com',
                'receiver_email' => isset($myPost['receiver_email']) ? $myPost['receiver_email'] : '',//'talktosaurabhkr@gmail.com',
                'receiver_id' => isset($myPost['receiver_id']) ? $myPost['receiver_id'] : '',//'LWZ9MK2ZD56GL',
                'pending_reason' => isset($myPost['pending_reason']) ? $myPost['pending_reason'] : '',//'paymentreview',
                'txn_type' => isset($myPost['txn_type']) ? $myPost['txn_type'] : '',//'recurring_payment',
                'mc_currency' => isset($myPost['mc_currency']) ? $myPost['mc_currency'] : '',//'USD',
                'transaction_subject' => isset($myPost['transaction_subject']) ? $myPost['transaction_subject'] : '',//'zuck : 100 Likes',
                'time_created' => isset($myPost['time_created']) ? $myPost['time_created'] : '',//'01:24:56 Jul 17, 2018 PDT',

                'ipn_response' => $request,
                'created_at' => time(),
                'updated_at' => time(),
                'ipn_body' => "VERIFIED"
            ]);

        } else {
            echo "INVALID";
        }

    }

    public function ipnListener(Request $request)
    {
        $payment = Bond::createObject();

        $raw_post_data = file_get_contents('php://input');
        $ipnResponse = $payment->ipnHandler($raw_post_data);

        $ipnResponse = json_decode($ipnResponse, true);

        if ($ipnResponse['status'] == 200) {

            $insertedProfile = $this->_db->insert('ipn_response', [
                'amount' => isset($_POST['mc_gross']) ? $_POST['mc_gross'] : '',//'mc_gross', //mc_gross
                'period_type' => isset($_POST['period_type']) ? $_POST['period_type'] : '',//' period_type', //Regular
                'outstanding_balance' => isset($_POST['outstanding_balance']) ? $_POST['outstanding_balance'] : '',//'outstanding_balance',
                'next_payment_date' => isset($_POST['next_payment_date']) ? $_POST['next_payment_date'] : '',//'03:00:00 Jul 28, 2018 PDT',
                'payment_cycle' => isset($_POST['payment_cycle']) ? $_POST['payment_cycle'] : '',//'Daily',
                'payer_id' => isset($_POST['payer_id']) ? $_POST['payer_id'] : '',//'9QZPMG2EKNNL8',
                'address_street' => isset($_POST['address_street']) ? $_POST['address_street'] : '',//'Flat no. 507 Wing A Raheja Residency Film City Road, Goregaon East',
                'payment_date' => isset($_POST['payment_date']) ? $_POST['payment_date'] : '',//'04:23:05 Jul 27, 2018 PDT',
                'payment_status' => isset($_POST['payment_status']) ? $_POST['payment_status'] : '',//'Pending',
                'product_name' => isset($_POST['product_name']) ? $_POST['product_name'] : '',//'zuck : 100 Likes',
                'recurring_payment_id' => isset($_POST['recurring_payment_id']) ? $_POST['recurring_payment_id'] : '',//'I-VCE8SUR575CU',
                'payer_email' => isset($_POST['payer_email']) ? $_POST['payer_email'] : '',//'saurabh.kumar-buyer@globussoft.in',
                'first_name' => isset($_POST['first_name']) ? $_POST['first_name'] : '',//'test',
                'last_name' => isset($_POST['last_name']) ? $_POST['last_name'] : '',//'buyer',
                'address_country_code' => isset($_POST['address_country_code']) ? $_POST['address_country_code'] : '',//'IN',
                'amount_per_cycle' => isset($_POST['amount_per_cycle']) ? $_POST['amount_per_cycle'] : '',//'4.00',
                'payer_status' => isset($_POST['payer_status']) ? $_POST['payer_status'] : '',//'verified',
                'currency_code' => isset($_POST['currency_code']) ? $_POST['currency_code'] : '',//'USD',
                'profile_status' => isset($_POST['profile_status']) ? $_POST['profile_status'] : '',//'Active',
                'txn_id' => isset($_POST['txn_id']) ? $_POST['txn_id'] : '',//'4S9587029U731824C',
                'payment_type' => isset($_POST['payment_type']) ? $_POST['payment_type'] : '',//'instant',
                'business' => isset($_POST['business']) ? $_POST['business'] : '',//'talktosaurabhkr@gmail.com',
                'receiver_email' => isset($_POST['receiver_email']) ? $_POST['receiver_email'] : '',//'talktosaurabhkr@gmail.com',
                'receiver_id' => isset($_POST['receiver_id']) ? $_POST['receiver_id'] : '',//'LWZ9MK2ZD56GL',
                'pending_reason' => isset($_POST['pending_reason']) ? $_POST['pending_reason'] : '',//'paymentreview',
                'txn_type' => isset($_POST['txn_type']) ? $_POST['txn_type'] : '',//'recurring_payment',
                'mc_currency' => isset($_POST['mc_currency']) ? $_POST['mc_currency'] : '',//'USD',
                'transaction_subject' => isset($_POST['transaction_subject']) ? $_POST['transaction_subject'] : '',//'zuck : 100 Likes',
                'time_created' => isset($_POST['time_created']) ? $_POST['time_created'] : '',//'01:24:56 Jul 17, 2018 PDT',

                'ipn_response' => $request,
                'created_at' => time(),
                'updated_at' => time(),
                'ipn_body' => "VERIFIED"
            ]);

            if ((isset($_POST['txn_type'])) && ($_POST['txn_type'] === "subscr_payment" || $_POST['txn_type'] === "recurring_payment")) {

                $subscribeId = isset($_POST['subscr_id']) ? $_POST['subscr_id'] : $_POST['recurring_payment_id'];
                $recurringProfile = $this->_db->selectQuery('recurring_profiles', ['rawQuery' => 'paypal_profile_id = ?', 'bindParams' => [$subscribeId]], ['profile_id', 'by_user_id', 'profile_status']);

                if (!empty($recurringProfile)) {

                    $txDataToInsert = [
                        'tx_type' => 1, // 0=single order transaction 1=for subscriptions
                        'tx_mode' => 0, // 0=paypal
                        'transaction_id' => isset($_POST['txn_id']) ? $_POST['txn_id'] : '',
                        'user_id' => $recurringProfile[0]['by_user_id'],
                        'recurring_profile_id' => $recurringProfile[0]['profile_id'],
                        'amount' => isset($_POST['mc_gross']) ? $_POST['mc_gross'] : '',
                        'payer_email' => isset($_POST['payer_email']) ? $_POST['payer_email'] : '',
                        'payment_status' => isset($_POST['payment_status']) ? $_POST['payment_status'] : '',
                        'pending_reason' => isset($_POST['pending_reason']) ? $_POST['pending_reason'] : '',
                        'payment_type' => isset($_POST['payment_type']) ? $_POST['payment_type'] : '',
                        'item_desc' => isset($_POST['product_name']) ? $_POST['product_name'] : '',
                        'item_link' => '',
                        'extra_details' => '',
                        'package_id' => '',
                        'payment_time' => isset($_POST['payment_date']) ? strtotime($_POST['payment_date']) : time(),
                    ];
                    $insertedTx = Transaction::getInstance()->insertTransaction($txDataToInsert);

//                    if ((isset($_POST['payment_status'])) && ($_POST['payment_status'] === "Completed")) {

                    //update autolikes_orders and reset all the counter
                    $whereCondition = ['rawQuery' => 'recurring_profile_id = ?', 'bindParams' => [$recurringProfile[0]['profile_id']]];
                    $dataToUpdate = [
                        'post_fetch_count' => 0,
                        'post_done' => 0,
                        'daily_post_done' => 0,
                        'first_post_fetched_time' => time(),
                        'reset_counter_time' => time(),
                        'message' => 'Script is running and waiting for new post.',
                        'status' => 1,
                    ];
                    $updated = $this->_db->updateQuery('autolikes_orders', $whereCondition, $dataToUpdate);


//                    }
                }
            }

            if ((isset($_POST['txn_type'])) && ($_POST['txn_type'] === "recurring_payment_suspended" || $_POST['txn_type'] === "recurring_payment_profile_cancel")) {

                $subscribeId = $_POST['recurring_payment_id'];
                $recurringProfile = $this->_db->selectQuery('recurring_profiles', ['rawQuery' => 'paypal_profile_id = ?', 'bindParams' => [$subscribeId]], ['profile_id', 'by_user_id', 'profile_status']);


                $statusVal = ['recurring_payment_profile_cancel' => 3, 'recurring_payment_suspended' => 6];

                $status = $statusVal[$_POST['txn_type']];
                $msg = ($status == 2) ? "Cancelled." : "Suspended.";

                //update recurring_profiles + autolikes_orders table
                $whereCondition = ['rawQuery' => 'recurring_profile_id = ?', 'bindParams' => [$recurringProfile[0]['profile_id']]];
                $dataToUpdate = [
                    'message' => 'Profile has been ' . $msg,
                    'status' => $status,
                ];
                $updated = $this->_db->updateQuery('autolikes_orders', $whereCondition, $dataToUpdate);

                //updating recurring_profiles table
                $recurringProfileStatus = ($_POST['recurring_payment_id'] === 'recurring_payment_profile_cancel') ? 2 : 3;
                $updated = $this->_db->updateQuery('recurring_profiles', ['rawQuery' => 'paypal_profile_id = ?', 'bindParams' => [$_POST['recurring_payment_id']]], ['profile_status' => $recurringProfileStatus]);


            }

        } else {

            $insertedProfile = $this->_db->insert('ipn_response', [
                'ipn_response' => $request,
                'created_at' => time(),
                'updated_at' => time(),
                'ipn_body' => "INVALID"
            ]);
        }

    }

    public function ipnListenerBACKUP(Request $request)
    {

        $raw_post_data = file_get_contents('php://input');
//        $raw_post_data = 'mc_gross=4.00&period_type= Regular&outstanding_balance=0.00&next_payment_date=03:00:00 Jul 31, 2018 PDT&protection_eligibility=Ineligible&payment_cycle=Daily&address_status=unconfirmed&tax=0.00&payer_id=9QZPMG2EKNNL8&address_street=Flat no. 507 Wing A Raheja Residency
//Film City Road, Goregaon East&payment_date=04:35:37 Jul 30, 2018 PDT&payment_status=Pending&product_name=saurabh_bond : 100 Likes&charset=UTF-8&recurring_payment_id=I-23RDFA3LHVHW&address_zip=400097&first_name=test&mc_fee=0.46&address_country_code=IN&address_name=test buyer&notify_version=3.9&amount_per_cycle=4.00&payer_status=verified&currency_code=USD&business=talktosaurabhkr@gmail.com&address_country=India&address_city=Mumbai&verify_sign=AXqXsNruTOUyQtHSkqHq6S2ptbr.ABjfwuPpZof-RrO9X33YYhJGxEjF&payer_email=saurabh.kumar-buyer@globussoft.in&initial_payment_amount=0.00&profile_status=Active&amount=4.00&txn_id=0VD216796T850545G&payment_type=instant&last_name=buyer&address_state=Maharashtra&receiver_email=talktosaurabhkr@gmail.com&payment_fee=0.46&receiver_id=LWZ9MK2ZD56GL&pending_reason=paymentreview&txn_type=recurring_payment&mc_currency=USD&residence_country=IN&test_ipn=1&transaction_subject=saurabh_bond : 100 Likes&payment_gross=4.00&shipping=0.00&product_type=1&time_created=05:31:47 Jul 18, 2018 PDT&ipn_track_id=a1ebd4572670';
        $raw_post_array = explode('&', $raw_post_data);
        $myPost = array();
        foreach ($raw_post_array as $keyval) {
            $keyval = explode('=', $keyval);
            if (count($keyval) == 2)
                $myPost[$keyval[0]] = urldecode($keyval[1]);
        }

        // read the IPN message sent from PayPal and prepend 'cmd=_notify-validate'
        $req = 'cmd=_notify-validate';
        if (function_exists('get_magic_quotes_gpc')) {
            $get_magic_quotes_exists = true;
        }
        foreach ($myPost as $key => $value) {
            if ($get_magic_quotes_exists == true && get_magic_quotes_gpc() == 1) {
                $value = urlencode(stripslashes($value));
            } else {
                $value = urlencode($value);
            }
            $req .= "&$key=$value";
        }

        $res = $this->ipnHitCurlFunction($req);

        if (strcmp($res, "VERIFIED") == 0) {
            // IPN message values depend upon the type of notification sent.
            // To loop through the &_POST array and print the NV pairs to the screen:
            foreach ($_POST as $key => $value) {
                echo $key . " = " . $value . "<br>";
            }
//            dd($_POST);

            $insertedProfile = $this->_db->insert('ipn_response', [
                'amount' => isset($_POST['mc_gross']) ? $_POST['mc_gross'] : '',//'mc_gross', //mc_gross
                'period_type' => isset($_POST['period_type']) ? $_POST['period_type'] : '',//' period_type', //Regular
                'outstanding_balance' => isset($_POST['outstanding_balance']) ? $_POST['outstanding_balance'] : '',//'outstanding_balance',
                'next_payment_date' => isset($_POST['next_payment_date']) ? $_POST['next_payment_date'] : '',//'03:00:00 Jul 28, 2018 PDT',
                'payment_cycle' => isset($_POST['payment_cycle']) ? $_POST['payment_cycle'] : '',//'Daily',
                'payer_id' => isset($_POST['payer_id']) ? $_POST['payer_id'] : '',//'9QZPMG2EKNNL8',
                'address_street' => isset($_POST['address_street']) ? $_POST['address_street'] : '',//'Flat no. 507 Wing A Raheja Residency Film City Road, Goregaon East',
                'payment_date' => isset($_POST['payment_date']) ? $_POST['payment_date'] : '',//'04:23:05 Jul 27, 2018 PDT',
                'payment_status' => isset($_POST['payment_status']) ? $_POST['payment_status'] : '',//'Pending',
                'product_name' => isset($_POST['product_name']) ? $_POST['product_name'] : '',//'zuck : 100 Likes',
                'recurring_payment_id' => isset($_POST['recurring_payment_id']) ? $_POST['recurring_payment_id'] : '',//'I-VCE8SUR575CU',
                'payer_email' => isset($_POST['payer_email']) ? $_POST['payer_email'] : '',//'saurabh.kumar-buyer@globussoft.in',
                'first_name' => isset($_POST['first_name']) ? $_POST['first_name'] : '',//'test',
                'last_name' => isset($_POST['last_name']) ? $_POST['last_name'] : '',//'buyer',
                'address_country_code' => isset($_POST['address_country_code']) ? $_POST['address_country_code'] : '',//'IN',
                'amount_per_cycle' => isset($_POST['amount_per_cycle']) ? $_POST['amount_per_cycle'] : '',//'4.00',
                'payer_status' => isset($_POST['payer_status']) ? $_POST['payer_status'] : '',//'verified',
                'currency_code' => isset($_POST['currency_code']) ? $_POST['currency_code'] : '',//'USD',
                'profile_status' => isset($_POST['profile_status']) ? $_POST['profile_status'] : '',//'Active',
                'txn_id' => isset($_POST['txn_id']) ? $_POST['txn_id'] : '',//'4S9587029U731824C',
                'payment_type' => isset($_POST['payment_type']) ? $_POST['payment_type'] : '',//'instant',
                'business' => isset($_POST['business']) ? $_POST['business'] : '',//'talktosaurabhkr@gmail.com',
                'receiver_email' => isset($_POST['receiver_email']) ? $_POST['receiver_email'] : '',//'talktosaurabhkr@gmail.com',
                'receiver_id' => isset($_POST['receiver_id']) ? $_POST['receiver_id'] : '',//'LWZ9MK2ZD56GL',
                'pending_reason' => isset($_POST['pending_reason']) ? $_POST['pending_reason'] : '',//'paymentreview',
                'txn_type' => isset($_POST['txn_type']) ? $_POST['txn_type'] : '',//'recurring_payment',
                'mc_currency' => isset($_POST['mc_currency']) ? $_POST['mc_currency'] : '',//'USD',
                'transaction_subject' => isset($_POST['transaction_subject']) ? $_POST['transaction_subject'] : '',//'zuck : 100 Likes',
                'time_created' => isset($_POST['time_created']) ? $_POST['time_created'] : '',//'01:24:56 Jul 17, 2018 PDT',

                'ipn_response' => $request,
                'created_at' => time(),
                'updated_at' => time(),
                'ipn_body' => "VERIFIED"
            ]);

//            if ((isset($_POST['txn_type'])) && ($_POST['txn_type'] === "subscr_payment" || $_POST['txn_type'] === "recurring_payment")) {
//
//                $subscribeId = isset($_POST['subscr_id']) ? $_POST['subscr_id'] : $_POST['recurring_payment_id'];
//                if ((isset($_POST['payment_status'])) && ($_POST['payment_status'] === "Completed")) {
//
//                    $objInstagramUsers = new Instagram_User();
//                    $whereForUsers = ['rawQuery' => 'subscriber_id = ?', 'bindParams' => [$subscribeId]];
//                    $updateResult = $objInstagramUsers->updateUserDetails($whereForUsers, ['pics_fetch_count' => 0, 'pics_done' => 0, 'daily_post_done' => 0, 'ig_user_status' => 2, 'reset_counter_time' => time()]);
//
//                }
//            }

        } else if (strcmp($res, "INVALID") == 0) {

            $insertedProfile = $this->_db->insert('ipn_response', [
                'ipn_response' => $request,
                'created_at' => time(),
                'updated_at' => time(),
                'ipn_body' => "INVALID"
            ]);

            // IPN invalid, log for manual investigation
            echo "The response from IPN was: <b>" . $res . "</b>";
        }
    }

    public function ipnHitCurlFunction($req)
    {
//        $ch = curl_init('https://www.paypal.com/cgi-bin/webscr');
        $ch = curl_init('https://www.sandbox.paypal.com/cgi-bin/webscr');
        curl_setopt($ch, CURLOPT_HTTP_VERSION, CURL_HTTP_VERSION_1_1);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $req);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
        curl_setopt($ch, CURLOPT_FORBID_REUSE, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, array('Connection: Close'));

        if (!($res = curl_exec($ch))) {
            // error_log("Got " . curl_error($ch) . " when processing IPN data");
            curl_close($ch);
            exit;
        }
        curl_close($ch);
        return $res;
    }

    public function dailyCounterDetails(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'access_token' => ['required', function ($attr, $val, $fail) {
                if (!array_key_exists('id', parseAccessToken($val))) return $fail($attr . ' is invalid.');
            }],
            'autolikes_id' => ['required', Rule::exists('autolikes_orders')]
        ]);

        if (!$validator->fails()) {
            $profileDetails = $this->_db->selectQuery(
                'autolikes_orders',
                [
                    'rawQuery' => 'autolikes_id = ?',
                    'bindParams' => [$request['autolikes_id']]
                ],
                ['insta_username', 'status', 'first_post_fetched_time']
            );

            if (!empty($profileDetails)) {
                apiResponse(200, 'Time left to reset the daily counter', null, ($profileDetails[0]['first_post_fetched_time']) * 1000);
            } else {
                apiResponse(400, 'Profile details not found.', 'error in finding profile details.', null);
            }

        } else {
            $errMsg = json_decode($validator->messages(), true);
            apiResponse(412, array_values($errMsg)[0][0], 'Validation error', null);
        }
    }

    public function resetDailyCounter(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'access_token' => ['required', function ($attr, $val, $fail) {
                if (!array_key_exists('id', parseAccessToken($val))) return $fail($attr . ' is invalid.');
            }],
            'autolikes_id' => ['required', Rule::exists('autolikes_orders')]
        ]);

        if (!$validator->fails()) {
            $profileStatus = ['pending', 'running', 'finished', 'cancelled', 'stopped', 'paused', 'suspended'];
            $profileDetails = $this->_db->selectQuery(
                'autolikes_orders',
                [
                    'rawQuery' => 'autolikes_id = ? and by_user_id = ?',
                    'bindParams' => [$request['autolikes_id'], parseAccessToken($request['access_token'])['id']]
                ],
                ['insta_username', 'status', 'daily_counter_reset']
            );

            if (!empty($profileDetails)) {

                if ($profileDetails[0]['status'] == 1 || $profileDetails[0]['status'] == 4) {

                    if ($profileDetails[0]['daily_counter_reset'] == 0) {
                        $next24hrs = time() + 86400;
                        $dataToUpdate = [
                            'first_post_fetched_time' => $next24hrs,
                            'daily_post_done' => 0,
                            'daily_counter_reset' => 1
                        ];
                        $updated = $this->_db->updateQuery('autolikes_orders', ['rawQuery' => 'autolikes_id = ?', 'bindParams' => [$request['autolikes_id']]], $dataToUpdate);
                        if ($updated)
                            apiResponse(200, 'Daily counter has been reset.', null, ['daily_post_done' => 0, 'counter_time' => $next24hrs * 1000]);
                        else
                            apiResponse(400, 'Something went wrong, please try after sometime.', 'error in reseting daily counter.', null);

                    } else {
                        apiResponse(400, 'Profile has been already reset once for this billing cycle.', 'only once in one billing cycle.', null);
                    }
                } else {
                    apiResponse(400, 'Profile is in ' . $profileStatus[$profileDetails[0]['status']] . ' state.', 'profile is not active.', null);
//                    apiResponse(400, 'Profile is not in running state.', 'profile is not running', null);
                }

            } else {
                apiResponse(400, 'This profile is not placed by you.', 'access_token and autolikes_id combination is wrong.', null);
            }
        } else {
            $errMsg = json_decode($validator->messages(), true);
            apiResponse(412, array_values($errMsg)[0][0], 'Validation error', null);
        }
    }

    public function getProfileDetails(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'autolikes_id' => ['required', Rule::exists('autolikes_orders')]
        ]);

        if (!$validator->fails()) {
            $whereCondition = ['rawQuery' => 'autolikes_id = ?', 'bindParams' => [$request['autolikes_id']]];
            $selectCols = ['insta_username', 'first_post_fetched_time', 'likes_randomize', 'views_randomize', 'likes_split_option', 'views_split_option', 'likes_impression', 'subscription_packages.quantity', 'subscription_packages.views_per_post', 'subscription_packages.views_plan_id', 'subscription_packages.daily_details', 'subscription_packages.weekly_details', 'subscription_packages.monthly_details', 'subscription_packages.max_likes_per_delay', 'subscription_packages.max_views_per_delay', 'subscription_packages.auto_views', 'recurring_profiles.paypal_profile_id', 'recurring_profiles.sub_package_type'];
            $profileDetails = $this->objAutolikesOrder->getProfileWithRecurringAndPackageDetails($whereCondition, $selectCols);

            if (!empty($profileDetails)) {

                if ($profileDetails[0]['paypal_profile_id'] === 'FreeAutoLikes') {
                    apiResponse(400, 'This feature is not available for free autolikes profile', 'free autolikes profile', null);
                }

                $details = [];
                foreach ($profileDetails as $key => $val) {
                    $plan_id = json_decode($val[$val['sub_package_type']], true)[0]['plan_id'];

                    $likesPlanDetails = $this->_db->selectQuery('plans', ['rawQuery' => 'plan_id = ?', 'bindParams' => [$plan_id]]);
                    if (!empty($likesPlanDetails)) {
                        $details['likes_min_quantity'] = $likesPlanDetails[0]['min_quantity'];
                        $details['likes_max_quantity'] = $val['quantity'];

                        $likes_randomize = json_decode($val['likes_randomize'], true);
                        $details['likes_randomize_min_quantity'] = $likes_randomize['min_quantity'];
                        $details['likes_randomize_max_quantity'] = $likes_randomize['max_quantity'];

                        if ($details['likes_randomize_min_quantity'] < $details['likes_min_quantity'])
                            $details['likes_randomize_min_quantity'] = $details['likes_min_quantity'];
                        if ($details['likes_randomize_max_quantity'] >= $details['likes_max_quantity'])
                            $details['likes_max_quantity'] = $details['likes_randomize_max_quantity'];  // + 10
                    } else {
                        apiResponse(400, 'Something went wrong, please try after sometime.', 'error in finding likes plans details.', null);
                    }

                    if ($val['auto_views'] == "on") {

                        $viewsPlanDetails = $this->_db->selectQuery('plans', ['rawQuery' => 'plan_id = ?', 'bindParams' => [$val['views_plan_id']]]);
                        if (!empty($viewsPlanDetails)) {
                            $details['views_min_quantity'] = $viewsPlanDetails[0]['min_quantity'];
                            $details['views_max_quantity'] = $val['views_per_post'];

                            $views_randomize = json_decode($val['views_randomize'], true);
                            $details['views_randomize_min_quantity'] = $views_randomize['min_quantity'];
                            $details['views_randomize_max_quantity'] = $views_randomize['max_quantity'];

                            if ($details['views_randomize_min_quantity'] < $details['views_min_quantity'])
                                $details['views_randomize_min_quantity'] = $details['views_min_quantity'];
                            if ($details['views_randomize_max_quantity'] >= $details['views_max_quantity'])
                                $details['views_max_quantity'] = $details['views_randomize_max_quantity'];  //+ 10
                        } else {
                            apiResponse(400, 'Something went wrong, please try after sometime.', 'error in finding views plans details.', null);
                        }
                    } else {
                        $details['views_min_quantity'] = null;
                        $details['views_max_quantity'] = null;
                        $views_randomize = json_decode($val['views_randomize'], true);
                        $details['views_randomize_min_quantity'] = $views_randomize['min_quantity'];
                        $details['views_randomize_max_quantity'] = $views_randomize['max_quantity'];
                    }

                    $likes_split_option = json_decode($val['likes_split_option'], true);
                    $details['likes_start_delay_checkbox'] = ($likes_split_option['likes_start_delay'] == 0) ? "off" : "on";
                    $details['likes_start_delay'] = $likes_split_option['likes_start_delay'] / 60;
                    $details['likes_split_option_enabled'] = $likes_split_option['likes_split_option_enabled'];
                    $details['likes_quantity_per_run'] = $likes_split_option['likes_quantity_per_run'];
                    $details['likes_delay_interval'] = $likes_split_option['likes_delay_interval'] / 60;

                    $views_split_option = json_decode($val['views_split_option'], true);
                    $details['views_start_delay_checkbox'] = ($views_split_option['views_start_delay'] == 0) ? "off" : "on";
                    $details['views_start_delay'] = $views_split_option['views_start_delay'] / 60;
                    $details['views_split_option_enabled'] = $views_split_option['views_split_option_enabled'];
                    $details['views_quantity_per_run'] = $views_split_option['views_quantity_per_run'];
                    $details['views_delay_interval'] = $views_split_option['views_delay_interval'] / 60;

                    $maxLikesPerDelay = json_decode($val['max_likes_per_delay'], true);
                    $itr1 = 0;
                    if (isset($maxLikesPerDelay) && !empty($maxLikesPerDelay) && is_array($maxLikesPerDelay)) {

                        $details['max_likes_per_delay'] = [];
                        foreach ($maxLikesPerDelay as $time => $amount) {
                            $details['max_likes_per_delay'][$itr1]['time'] = $time;
                            $details['max_likes_per_delay'][$itr1]['amount'] = $amount;
                            ++$itr1;
                        }
                        $details['min_delay_quantity_likes'] = end($details['max_likes_per_delay'])['amount'];
                        $details['max_delay_time_likes'] = reset($details['max_likes_per_delay'])['time'];
                    } else {
                        $details['max_likes_per_delay'] = null;
                        $details['min_delay_quantity_likes'] = null;
                        $details['max_delay_time_likes'] = null;
                    }

                    $details['auto_views'] = $val['auto_views'];
                    $maxViewsPerDelay = json_decode($val['max_views_per_delay'], true);
                    $itr2 = 0;
                    if (isset($maxViewsPerDelay) && !empty($maxViewsPerDelay) && is_array($maxLikesPerDelay)) {
                        $details['max_views_per_delay'] = [];
                        foreach ($maxViewsPerDelay as $time => $amount) {
                            $details['max_views_per_delay'][$itr2]['time'] = $time;
                            $details['max_views_per_delay'][$itr2]['amount'] = $amount;
                            ++$itr2;
                        }
                        $details['min_delay_quantity_views'] = end($details['max_views_per_delay'])['amount'];
                        $details['max_delay_time_views'] = reset($details['max_views_per_delay'])['time'];
                    } else {
                        $details['max_views_per_delay'] = null;
                        $details['min_delay_quantity_views'] = null;
                        $details['max_delay_time_views'] = null;
                    }

                    $details['likes_impression'] = $val['likes_impression'];

                }

                apiResponse(200, 'Previous randomize quantity and split quantity settings', null, $details);
            } else {
                apiResponse(400, 'Something went wrong, please try after sometime.', 'error in finding previous details.', null);
            }

        } else {
            $errMsg = json_decode($validator->messages(), true);
            apiResponse(412, array_values($errMsg)[0][0], 'Validation error', null);
        }

    }

    public function updateSplitSettings(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'access_token' => ['required', function ($attr, $val, $fail) {
                if (!array_key_exists('id', parseAccessToken($val))) return $fail($attr . ' is invalid.');
            }],
            'autolikes_id' => ['required', Rule::exists('autolikes_orders')],
            'method' => 'required'
        ]);

        if (!$validator->fails()) {
            $profileDetails = $this->_db->selectQueryWithJoin(
                'autolikes_orders',
                'subscription_packages',
                'autolikes_orders.sub_package_id',
                'subscription_packages.sub_package_id',
                [
                    'rawQuery' => 'autolikes_id = ? and by_user_id = ?',
                    'bindParams' => [$request['autolikes_id'], parseAccessToken($request['access_token'])['id']]
                ],
                ['autolikes_orders.insta_username', 'autolikes_orders.status', 'subscription_packages.*']
            );

            if (!empty($profileDetails)) {

                if ($profileDetails[0]['status'] == 1) {

                    switch ($request['method']) {
                        case 'update_randomize_quantity':
                            $validator = Validator::make($request->all(), [
                                'likes_randomize_min_quantity' => 'required',
                                'likes_randomize_max_quantity' => 'required',
                                'views_randomize_min_quantity' => 'required',
                                'views_randomize_max_quantity' => 'required',
                            ]);
                            if (!$validator->fails()) {

                                $dataToUpdate = [
                                    'likes_randomize' => json_encode(['min_quantity' => $request['likes_randomize_min_quantity'], 'max_quantity' => $request['likes_randomize_max_quantity']]),
                                    'views_randomize' => json_encode(['min_quantity' => $request['views_randomize_min_quantity'], 'max_quantity' => $request['views_randomize_max_quantity']])
                                ];
                                $updated = $this->_db->updateQuery('autolikes_orders', ['rawQuery' => 'autolikes_id = ?', 'bindParams' => [$request['autolikes_id']]], $dataToUpdate);
                                if ($updated)
                                    apiResponse(200, 'Randomize quantity settings has been updated.', null, null);
                                else
                                    apiResponse(400, 'Something went wrong, please try after sometime.', 'error in updating randomize quantity.', null);

                            } else {
                                $errMsg = json_decode($validator->messages(), true);
                                apiResponse(412, array_values($errMsg)[0][0], 'Validation error', null);
                            }
                            break;
                        case 'update_split_option':
                            $rules = [
                                'likes_split_option' => ['required', function ($att, $val, $msg) {
                                    if (!in_array($val, ['on', 'off'])) return $msg($att . ' is invalid');
                                }],
                                'likes_quantity_per_run' => 'required_unless:likes_split_option,off|numeric',
                                'likes_delay_interval' => 'required_unless:likes_split_option,off|numeric|max:21600', //min:600|
                                'likes_start_delay' => 'numeric|max:3600', //|min:300
                                'likes_impression' => ['required', function ($att, $val, $msg) {
                                    if (!in_array($val, ['on', 'off'])) return $msg($att . ' is invalid');
                                }]

                            ];

                            if ($request->input('auto_views') && $request['auto_views'] == 'on') {
                                $rulesForViews = [
                                    'auto_views' => ['required', function ($attr, $val, $msg) {
                                        if (!in_array($val, ['on', 'off'])) return $msg($attr . ' is invalid');
                                    }],
                                    'views_split_option' => ['required_unless:auto_views,off', function ($att, $val, $msg) {
                                        if (!in_array($val, ['on', 'off'])) return $msg($att . ' is invalid');
                                    }],
                                    'views_quantity_per_run' => 'required_unless:views_split_option,off|numeric',
                                    'views_delay_interval' => 'required_unless:views_split_option,off|numeric|max:21600', //|min:600
                                    'views_start_delay' => 'numeric|max:3600' //|min:300
                                ];
                                $rules = array_merge($rules, $rulesForViews);
                            }

                            $validator = Validator::make($request->all(), $rules, [
                                'likes_delay_interval.min' => 'Delay interval must be greater than 600 secs(10 mins)',
                                'views_delay_interval.min' => 'Delay interval must be greater than 600 secs(10 mins)',
                                'likes_delay_interval.max' => 'Delay interval must be lesser than 21600 secs(6 hrs)',
                                'views_delay_interval.max' => 'Delay interval must be lesser than 21600 secs(6 hrs)',
                                'likes_start_delay.min' => 'Delay for first likes must be greater than 5 mins (300 secs)',
                                'views_start_delay.min' => 'Delay for first views must be greater than 5 mins (300 secs)',
                                'likes_start_delay.max' => 'Delay for first likes must be lesser than 1 hr (3600 secs)',
                                'views_start_delay.max' => 'Delay for first views must be lesser than 1 hr (3600 secs)',
                            ]);
                            if (!$validator->fails()) {

                                $totalQuantity = $profileDetails[0]['quantity'];
                                $minQuantityPerRun = ($totalQuantity / 50 > 10) ? $totalQuantity / 50 : 10;

                                $likesStartDelay = ($request->input('likes_start_delay')) ? $request['likes_start_delay'] : 0;
                                if ($request['likes_split_option'] === "on") {

                                    $lQuantityPerRun = $request['likes_quantity_per_run'];
                                    $lDelayInterval = $request['likes_delay_interval'];

//                                    if ($lQuantityPerRun < $minQuantityPerRun)
//                                        apiResponse(400, 'Minimum likes quantity per run should be greater than ' . $minQuantityPerRun, 'validation error.', null);

//                                    if ($lQuantityPerRun > $totalQuantity)
//                                        apiResponse(400, 'Likes quantity per run should be lesser than ' . $totalQuantity, 'validation error.', null);


                                    $likes_split_option = ["likes_start_delay" => $likesStartDelay, "likes_split_option_enabled" => "on", "likes_quantity_per_run" => $lQuantityPerRun, "likes_delay_interval" => $lDelayInterval];
                                } else {
                                    $likes_split_option = ["likes_start_delay" => $likesStartDelay, "likes_split_option_enabled" => "off", "likes_quantity_per_run" => "0", "likes_delay_interval" => "0"];
                                }

                                $totalQuantityViews = $profileDetails[0]['views_per_post'];
                                $minQuantityPerRunViews = ($totalQuantityViews / 50 > 10) ? $totalQuantityViews / 50 : 10;

                                $viewsStartDelay = ($request->input('views_start_delay')) ? $request['views_start_delay'] : 0;
                                if ($request['views_split_option'] === "on") {

                                    $vQuantityPerRun = $request['views_quantity_per_run'];
                                    $vDelayInterval = $request['views_delay_interval'];

//                                    if ($vQuantityPerRun < $minQuantityPerRunViews)
//                                        apiResponse(400, 'Minimum views quantity per run should be greater than ' . $minQuantityPerRunViews, 'validation error.', null);
//
//                                    if ($vQuantityPerRun > $totalQuantity)
//                                        apiResponse(400, 'Views quantity per run should be lesser than ' . $totalQuantity, 'validation error.', null);

                                    $views_split_option = ["views_start_delay" => $viewsStartDelay, "views_split_option_enabled" => "on", "views_quantity_per_run" => $vQuantityPerRun, "views_delay_interval" => $vDelayInterval];
                                } else {
                                    $views_split_option = ["views_start_delay" => $viewsStartDelay, "views_split_option_enabled" => "off", "views_quantity_per_run" => "0", "views_delay_interval" => "0"];
                                }

                                $dataToUpdate = [
                                    'likes_split_option' => json_encode($likes_split_option),
                                    'views_split_option' => json_encode($views_split_option),
                                    'likes_impression' => $request['likes_impression']
                                ];
                                $updated = $this->_db->updateQuery('autolikes_orders', ['rawQuery' => 'autolikes_id = ?', 'bindParams' => [$request['autolikes_id']]], $dataToUpdate);
                                if ($updated)
                                    apiResponse(200, 'Delivery speed settings has been updated.', null, null);
                                else
                                    apiResponse(400, 'Something went wrong, please try after sometime.', 'error in updating split option.', null);

                            } else {
                                $errMsg = json_decode($validator->messages(), true);
                                apiResponse(412, array_values($errMsg)[0][0], 'Validation error', null);
                            }
                            break;
                        default:

                    }
                } else {
                    apiResponse(400, 'Profile is not in running state.', 'not in running state.', null);
                }
            } else {
                apiResponse(400, 'This profile is not placed by you.', 'access_token and autolikes_id combination is wrong.', null);
            }
        } else {
            $errMsg = json_decode($validator->messages(), true);
            apiResponse(412, array_values($errMsg)[0][0], 'Validation error', null);
        }
    }

}