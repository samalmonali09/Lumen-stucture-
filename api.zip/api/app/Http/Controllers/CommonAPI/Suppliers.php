<?php

namespace App\Http\Controllers\CommonAPI;

class Suppliers
{
    protected $apiKey, $apiUrl;
    public static $_obj = null;

    private function __construct()
    {
        $this->apiKey = [
            1 => '9d6f65be87883e23b078532d3ada6a91fc3ba3bcf93fedd552f5a3c1f04707f4', //igerslike
            2 => 'f928fa9f4f1c29a728790a1648dfcc9799f36d9b', //cheapbulksocial24
            3 => 'f105da781c0526858828aa2ec0b8d5f6', //socialpanel24
            4 => '1c5d7a92d458721b040a8f4b386263cc', //socialnator
            5 => '962d79280cfdd66b17fc1ff343ba2078', //followiz
            6 => '', //top4SMM
            7 => 'Yf0Gnn43eohJKT5t', //KAMH
        ];
        $this->apiUrl = [
            1 => 'https://www.igerslike.com/api', //igerslike
            2 => 'http://cheapbulksocial.com/api.php', //cheapbulksocial24
            3 => 'https://socialpanel24.com/api/v2', //socialpanel24
            4 => 'http://socialnator.com/api/market/api.php', //socialnator
            5 => 'https://followiz.com/api/v2', //followiz
            6 => '', //top4SMM
            7 => 'https://api.panel.messazon.com/user/addOrder', //KAMH
        ];
    }

    public static function createObject()
    {
        if (!is_object(self::$_obj))
            self::$_obj = new Suppliers();
        return self::$_obj;
    }


    public function placeOrders($supplierId, $serviceId, $link, $quantity, $comments = '')
    {
        try {
            switch ($supplierId) {
                case 1:
                    // Add an order
                    $postData = array(
                        "Key" => $this->apiKey[$supplierId],
                        "ProductId" => $serviceId,
                        "Amount" => $quantity,
                        "Link" => $link
                    );
                    $comments_data = [];
                    if (isset($comments) && ($comments != null || $comments != '')) {
                        $comments_data = json_decode($comments, true);
                    }

                    if (isset($comments_data) && $comments_data != '') {
                        $postData += array(
                            'Comments' => $comments_data
                        );
                    }
                    $response = $this->curl_post($this->apiUrl[$supplierId] . '/order/add', $postData);
                    $response = json_decode($response, true);

                    if ($response['status'] == 'ok') {
                        return $this->sendJsonResponse(200, 'Order placed successfully.', null, $response['order']);
                    } else if ($response['status'] == 'fail') {
                        return $this->sendJsonResponse(400, 'Orders not placed', $response, null);
                    } else {
                        return $this->sendJsonResponse(400, 'Orders not placed', $response, null);
                    }
                    break;
                case 2:
                    break;
                case 3: //socialpanel24
                    $post_data = [];
                    $post_data['key'] = $this->apiKey[$supplierId];
                    $post_data['action'] = 'add';
                    $post_data['service'] = $serviceId; // The order type or service type string // 'type' for older API.
                    $post_data['link'] = trim(strip_tags($link)); // The order Link Here
                    $comments_data = '';
                    if (isset($comments) && ($comments != null || $comments != '')) {
                        $comments_data = json_decode($comments, true);
                        $comments_data = implode("\n", $comments_data);
                    }

                    if ($comments_data == '')
                        $post_data['quantity'] = $quantity; // The order amount
                    else
                        $post_data['comments'] = $comments_data;

                    $response = $this->curl_post($this->apiUrl[$supplierId], $post_data);
                    $response = json_decode($response, true);
                    if (current(array_keys($response, true)) == 'order') {
                        return $this->sendJsonResponse(200, 'Order placed successfully.', null, $response['order']);
                    } else if (current(array_keys($response, true)) == 'error') {
                        return $this->sendJsonResponse(400, 'Orders not placed', $response['error'], null);
                    } else {
                        return $this->sendJsonResponse(400, 'Orders not placed', $response, null);
                    }
                    break;
                case 4: //socialnator
                    $post_data = [];
                    $post_data['instagramprofileurl'] = $link;
                    $post_data['orderamount'] = $quantity;
                    $post_data['secretkey'] = $this->apiKey[$supplierId];
                    $post_data['methodname'] = $serviceId;
                    $response = $this->curl_post($this->apiUrl[$supplierId], $post_data);
                    $response = json_decode($response, true);
                    if ($response['code'] == 200) {
                        return $this->sendJsonResponse(200, 'Order placed successfully.', null, "4444");
                    } else {
                        return $this->sendJsonResponse(400, 'Orders not placed', $response['error'], null);
                    }

                    break;
                case 5: //followiz
                    $data['key'] = $this->apiKey[$supplierId];
                    $data['action'] = 'add';
                    $data['service'] = $serviceId;
                    $data['link'] = $link;
                    $data['quantity'] = $quantity;

                    $response = $this->curl_post($this->apiUrl[$supplierId], $data);

                    $response = json_decode($response, true);
                    if (current(array_keys($response, true)) == 'order') {
                        return $this->sendJsonResponse(200, 'Order placed successfully.', null, $response['order']);
                    } else if (current(array_keys($response, true)) == 'error') {
                        return $this->sendJsonResponse(400, 'Orders not placed', $response['error'], null);
                    } else {
                        return $this->sendJsonResponse(400, 'Orders not placed', $response, null);
                    }
                    break;
                case 6: //top4smmpanel
                    break;
                case 7: //KAMH //Messazon API
                    $data['access_token'] = $this->apiKey[$supplierId];
                    $data['user_id'] = '2';  // this is messazon user_id
                    $data['plan_id'] = $serviceId;  // this is messazon user_id
                    $data['order_url'] = $link;
                    $data['quantity'] = $quantity;
                    if (isset($comments) && ($comments != null || $comments != '')) {
                        $data['customCommentType'] = 0;
                        $data['commentsTextArea'] = implode("\r\n", $comments);
                    }


                    $data['order_url'] = 'https://instagram.com/p/BodWLPRHtij';
//                    $data['order_url'] = 'https://instagram.com/saurabh_bond';

                    $regex = '/^(http(s)?:\/\/)?(www\.)?(instagram)\.+(com)+\/+(p)\/(([a-zA-Z0-9\.\-\_])*)+/';
                    $urlType = (preg_match($regex, $data['order_url'])) ? "postLink" : "profileLink";

                    $response = $this->curl_post($this->apiUrl[$supplierId], $data);

                    $response = json_decode($response, true);
                    if ($response['code'] == 200) {
                        return $this->sendJsonResponse(200, 'Order placed successfully.', null, $response['data']['order_id']);
                    } else {
                        return $this->sendJsonResponse(400, 'Orders not placed', $response['message'], null);
                    }

                    break;
            }
        } catch (\Exception $e) {
            return $this->sendJsonResponse(400, 'Orders not placed', $response['error'], null);
        }

    }

    private function http_post_old($url, $post_paramas)
    {
        if (empty($url) || empty($post_paramas)) {
            return 'Parameter not Passed';
        }
        $fields_string = '';
        foreach ($post_paramas as $key => $value) {
            $fields_string .= $key . '=' . $value . '&';
        }

        $fields_string = rtrim($fields_string, '&');
        $ch = '';
        try {
            $ch = curl_init();
            //set the url, number of POST vars, POST data
            curl_setopt($ch, CURLOPT_URL, $url);
            curl_setopt($ch, CURLOPT_POST, 1);
            curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
            curl_setopt($ch, CURLOPT_POST, count($post_paramas));
            curl_setopt($ch, CURLOPT_POSTFIELDS, $fields_string);
            curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 600); # timeout after 10 seconds, you can increase it

            curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);  # Set curl to return the data instead of printing it to the browser.
            // curl_setopt($ch,  CURLOPT_USERAGENT , "Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 6.1)"); # Some server may refuse your request if you dont pass user agent
//        curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/4.0 (compatible; MSIE 5.01; Windows NT 5.0)');
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);

            $result = curl_exec($ch);
//            dd($result);
//            print_r(curl_error($ch));die;
//            dd($result);

            if (($result === FALSE) || (curl_errno($ch) != 0 && empty($result))) {     //}) || (curl_errno($ch) != 0 && empty($result))) {
//                print_r(curl_error($ch));
//                echo '<br>';
                return json_encode(['exception' => 'bad_type'], true);
            }

            curl_close($ch);
//            dd($result);
            return $result;

        } catch (\Exception $e) {
            curl_close($ch);
            return json_encode(['exception' => 'bad_type'], true);

        }

    }

    private function curl_post($url, $data)
    {
        $encode_post = http_build_query($data);
        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $encode_post);
        $response = curl_exec($ch);
        curl_close($ch);
        return $response;
    }

    private function http_post($url, $post_paramas)
    {
        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 10);
        curl_setopt($ch, CURLOPT_TIMEOUT, 20);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_HEADER, false);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);

        if (is_array($post_paramas)) {
            curl_setopt($ch, CURLOPT_POSTFIELDS, $post_paramas);
        }

        curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/4.0 (compatible; MSIE 5.01; Windows NT 5.0)');
        $result = curl_exec($ch);
        curl_close($ch);

        return $result;
    }

    public function sendJsonResponse($code, $msg, $err, $data)
    {
        $data = [
            'code' => $code,
            'message' => $msg,
            'error' => $err,
            'supplier_order_id' => $data
        ];
        http_response_code($code);
        return json_encode($data, $code);
    }


}