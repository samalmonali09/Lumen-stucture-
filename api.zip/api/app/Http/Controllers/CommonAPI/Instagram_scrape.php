<?php

namespace App\Http\Controllers\CommonAPI;

use App\Http\Models\DBClass;
use function convertNumberIntoProperNotation as cn;

class Instagram_scrape
{

    private $cookie, $auth;

    public function __construct()
    {
        $this->setCookie();
    }

    private function setCookie()
    {
        $cookiesArr = [
//            'mid=WcX5cAAEAAHSil5FrYgsPuuwRYLy; datr=2yb4WaKoM1k4rR5gU8Hy5dK8; shbid=15681; rur=FTW; urlgen="{\"time\": 1523366505}:1f5tEB:k59VJY5dRfdjylBA8T_bbPK1LIk"; ig_vw=683; ig_pr=1; ig_vh=634; ig_or=; csrftoken=JNXfQXSuQUnthRmKiC5sV3jLnvDkrtvf; ds_user_id=2210222772; sessionid=IGSCf42b292c887f6f68a44f90a73a8a35c62052b1a8c4f4439e40c255b524ede25a%3AMGfH8xaocKckYUBvRtnrMHYkgZ3XW60l%3A%7B%22_auth_user_id%22%3A2210222772%2C%22_auth_user_backend%22%3A%22accounts.backends.CaseInsensitiveModelBackend%22%2C%22_auth_user_hash%22%3A%22%22%2C%22_platform%22%3A4%2C%22_token_ver%22%3A2%2C%22_token%22%3A%222210222772%3Aa8n41qOr3Iq3HqI0rJTxQzfNzwAaiaUL%3Ab2aa01651f0bdc3e19d22af7847915822de73bf88abf28f31757ca5eec0e905b%22%2C%22last_refreshed%22%3A1523366537.9908201694%7D'
//            'csrftoken=N6QYa8j6pT54kJvW8CHG3fNxwtpfrn35; rur=FTW; mcd=3; mid=W1mAngAEAAEC5iYsqftHrlW2wMex; urlgen="{\"time\": 1532592309\054 \"103.217.90.103\": 135183}:1fibHW:OlFIzqSNtXkkqg--0kwLiRG3T4w"; shbid=15681; ds_user_id=2210222772; sessionid=IGSC090ca72adcf7fd4e18d03b3853d142977f7a8d999b46e8bf8380fabfcf178676%3AZEv3oS63KVQgwPxvRDzbSqjuq9NH2Uli%3A%7B%22_auth_user_id%22%3A2210222772%2C%22_auth_user_backend%22%3A%22accounts.backends.CaseInsensitiveModelBackend%22%2C%22_auth_user_hash%22%3A%22%22%2C%22_platform%22%3A4%2C%22_token_ver%22%3A2%2C%22_token%22%3A%222210222772%3AG6BiTwdH6vBJY5jW2VFSb2Z7EJ4IYS3M%3Ad37cf43266b55ab1acb87a07014204fea08657b2128783a9923d674a8c9235a4%22%2C%22last_refreshed%22%3A1532592334.2773928642%7D; shbts=1532592354.3316512'
            'mcd=3; mid=W9a1VQAEAAHuE-wq7wxqZap96aDz; csrftoken=mEll4nmy4sSjMSqERURqNd4lXPpmk22b; fbm_124024574287414=base_domain=.instagram.com; shbid=15681; ds_user_id=2210222772; sessionid=IGSC00ed24d1e7d22ae9c0d193dab1001343474efba6473a7a0b93ee5ae9edd781c3%3AAOAtNt9RMq19OvtzvV5FjfT81FNLYPZD%3A%7B%22_auth_user_id%22%3A2210222772%2C%22_auth_user_backend%22%3A%22accounts.backends.CaseInsensitiveModelBackend%22%2C%22_auth_user_hash%22%3A%22%22%2C%22_platform%22%3A4%2C%22_token_ver%22%3A2%2C%22_token%22%3A%222210222772%3AtsWlJvoJHz8inmz4eP59YGoagV0f83cB%3Ac2d56502f0dced2bfade3366950d85be1e477a1c00d89234dcb127812117eb45%22%2C%22last_refreshed%22%3A1541228889.1029551029%7D; shbts=1541139007.4740667; rur=FTW; urlgen="{\"103.217.90.98\": 135183}:1gIrFZ:HWfwrp9eBdxRvXiNhs7DVJpOemQ"; fbsr_124024574287414=nuzrhddglhN6oGamYyxCACCHS9c-jBroQfiJTxFO5EE.eyJhbGdvcml0aG0iOiJITUFDLVNIQTI1NiIsImNvZGUiOiJBUUN5WEFDck43dGIwQ2pFS0VVZTJlRU83Ti1NUUREalAwMkZydnJlNVNZRWJNaXlDQXA3bGNvbEwwVXZqX0pINTZDT3Uwb2QxaFJRZGlMV0RPOGVpdnRKQTFsUjFyVXZVb1NHcWFMR08zR0lUOUJPeWtOTkdvX1I0ZlM3ZVVmaEdwLU93MEY3VnFtN1BXNjdEcXpkSVZQLVZ2ZjZRdTNtdnRfNmloUTdxV1hpOEc0d3ZrcFhKYnhXdE9Cei1hNEZacWhTUW1ueE9xSzhjQlBmTFBfTklFRjJFSGdUSWZENGZ4VnVfbXdTcF9DbzdXV2dYMVpjMlFQenUzYmtid0VLNVo4TFFyTEZRc1ZmTFZkNk1nWWpxOWhhUlZsYk1kREV0RHpoVTRiNHZPeE9UNXAyRkI3cW5NRmFKZ2p4eFJHTXdsLXNlbnVmelZMUjJWano3bktXVTNWWCIsImlzc3VlZF9hdCI6MTU0MTIzMzU0NSwidXNlcl9pZCI6IjEwMDAxMDc1NDQ0ODg4OCJ9'
        ];
        $this->cookie = $cookiesArr[array_rand($cookiesArr)];
    }

    private function setHeaders()
    {
        /*
         * send or pass the session (cookie) in first argument (param),
         * if nothing is passed, then cookie will be called from the setCookie method
         * setCookie method will be always called whenever the new object of this class(instagram_scrape) is created.
         */
        if (func_num_args() > 0) {
            $this->cookie = func_get_arg(0);
        }

        return $headers = [
            'Host: www.instagram.com',
            'User-Agent: Mozilla/5.0 (Windows NT 6.1; WOW64; rv:42.0) Gecko/20100101 Firefox/42.0',
            'Accept: */*',
            'Accept-Language: en-US,en;q=0.5',
            'X-Requested-With: XMLHttpRequest',
            'Referer: https://www.instagram.com/saurabh_bond/',
            'Cookie: ' . $this->cookie,
            'Connection: keep-alive'
        ];
    }


    /*
    |--------------------------------------------------------------------------
    | Get Instagram Profile Details -- Saurabh - 14th June 2018
    |--------------------------------------------------------------------------
    |
    | This function scrapes the instagram.com/username and get the profile details
    | along with the recent 12 posts(media) details.
    | pass $postType = video, if you want to get the video media details only
    |
    */
    public function getProfileDetails($username, $postType = 'image')
    {
        ini_set('memory_limit', '1024M');

//        $result = $this->curlUsingGet('https://instagram.com/' . $username);
        $result = $this->curlUsingGetWithProxy('https://instagram.com/' . $username);

        if ($result != '' || $result != null) {
            $profileDetails = explode('window._sharedData = ', $result);
            if (count($profileDetails) > 1) {
                $profileDetailsJson = explode(';</script>', $profileDetails[1]);
                $profileDetailsArr = json_decode($profileDetailsJson[0], TRUE);

                if (!empty($profileDetailsArr['entry_data'])) {
                    $result = $profileDetailsArr['entry_data']['ProfilePage'][0];

                    if ($result["graphql"]["user"]["is_private"] == false) {

                        $details = array();
                        $details['id'] = $result["graphql"]["user"]["id"];
                        $details['username'] = $result["graphql"]["user"]["username"];
                        $details['followed_by_count'] = cn($result["graphql"]["user"]["edge_followed_by"]["count"]);
                        $details['follows_count'] = cn($result["graphql"]["user"]["edge_follow"]["count"]);
                        $details['posts_count'] = cn($result["graphql"]["user"]["edge_owner_to_timeline_media"]["count"]);
                        $details['profile_pic_url'] = $result["graphql"]["user"]["profile_pic_url"];

                        $details['followers_order_token'] = generateAccessToken(
                            [
                                'link' => 'https://www.instagram.com/' . $details['username'],
                                'display_url' => $details['profile_pic_url'],
                                'followers_count' => cn($details['followed_by_count'])
                            ]
                        );

                        $details['has_next_page'] = $result["graphql"]["user"]["edge_owner_to_timeline_media"]["page_info"]["has_next_page"];
                        if ($details['has_next_page'] == true) {
                            $details['end_cursor'] = $result["graphql"]["user"]["edge_owner_to_timeline_media"]["page_info"]["end_cursor"];
                        } else {
                            $details['end_cursor'] = null;
                        }

                        $media = $result["graphql"]["user"]["edge_owner_to_timeline_media"]["edges"];

                        $details['media'] = [];

                        if ($postType != 'video') {

                            if ($details['posts_count'] > 0) {

                                $count = 0;
                                foreach ($media as $key => $val) {
                                    if ($postType == 'video') {
                                        if ($val['node']['is_video'] == true) {
                                            $details['media'][$count]['link'] = 'https://www.instagram.com/p/' . $val['node']['shortcode'];
                                            $details['media'][$count]['display_url'] = $val['node']['display_url'];
                                            $details['media'][$count]['likes_count'] = cn($val['node']['edge_media_preview_like']['count']);
                                            $details['media'][$count]['comments_count'] = cn($val['node']['edge_media_to_comment']['count']);
                                            $details['media'][$count]['video_post'] = $val['node']['is_video'];
                                            $details['media'][$count]['views_count'] = ($val['node']['is_video']) ? cn($val['node']['video_view_count']) : 0;
                                            $details['media'][$count]['order_token'] = generateAccessToken($details['media'][$count]);
                                            ++$count;

                                        }
                                    } else {
                                        $details['media'][$count]['link'] = 'https://www.instagram.com/p/' . $val['node']['shortcode'];
                                        $details['media'][$count]['display_url'] = $val['node']['display_url'];
                                        $details['media'][$count]['likes_count'] = cn($val['node']['edge_media_preview_like']['count']);
                                        $details['media'][$count]['comments_count'] = cn($val['node']['edge_media_to_comment']['count']);
                                        $details['media'][$count]['video_post'] = $val['node']['is_video'];
                                        $details['media'][$count]['views_count'] = ($val['node']['is_video']) ? cn($val['node']['video_view_count']) : 0;
                                        $details['media'][$count]['order_token'] = generateAccessToken($details['media'][$count]);
                                        ++$count;
                                    }
                                }
                            } else {
                                $details['media'] = [];
                            }

                        }

                        return json_encode(['code' => 200, 'status' => "success", 'response' => $details]);
                    } else {
                        return json_encode(['code' => 400, 'status' => "failed", 'response' => 'Account is private.']);
                    }
                } else {
                    return json_encode(['code' => 400, 'status' => "failed", 'response' => 'Username doesn\'t exist.']);
                }
            } else {
                return json_encode(['code' => 400, 'status' => "failed", 'response' => 'Username doesn\'t exist.']);
            }
        }
    }

    /*
    |--------------------------------------------------------------------------
    | Get Instagram More Media Details -- Saurabh - 14th June 2018
    |--------------------------------------------------------------------------
    |
    | This function fetches the more media details ( not only 12 recent media)
    | based on the length provided . length is optional , if not provided 24 media will be fetched.
    | Req param : id, end_cursor( this the cursor from where the next post will be fetched)
    |
    */
    public function getMoreMediaDetails($id, $length, $end_cursor, $postType = 'both')
    {
        $has_next_page = false;
        $count = 0;
        $exit = false;
        $first = 24;
        $mediaDetails = [];
        $mediaDetails['media'] = [];

        do {

            $url = 'https://www.instagram.com/graphql/query/?query_hash=472f257a40c653c64c666ce877d59d2b&variables={%22id%22%3A%22' . $id . '%22%2C%22first%22%3A' . $first . '%2C%22after%22%3A%22' . $end_cursor . '%22}';

            $headers = $this->setHeaders();
            $details = $this->curlUsingGet($url, $headers);
            $details = json_decode($details, true);

            if (!empty($details)) {

                if (!empty($details['data']['user'])) {

                    if (!empty($details['data']['user']['edge_owner_to_timeline_media']['edges'])) {

                        $has_next_page = $details['data']['user']['edge_owner_to_timeline_media']['page_info']['has_next_page'];
                        $end_cursor = $details['data']['user']['edge_owner_to_timeline_media']['page_info']['end_cursor'];

                        $media = $details['data']['user']['edge_owner_to_timeline_media']['edges'];

                        foreach ($media as $key => $val) {
                            if ($postType == 'video') {
                                if ($val['node']['is_video'] == true) {

                                    $mediaDetails['media'][$count]['link'] = 'https://www.instagram.com/p/' . $val['node']['shortcode'];
                                    $mediaDetails['media'][$count]['display_url'] = $val['node']['display_url'];
                                    $mediaDetails['media'][$count]['likes_count'] = cn($val['node']['edge_media_preview_like']['count']);
                                    $mediaDetails['media'][$count]['comments_count'] = cn($val['node']['edge_media_to_comment']['count']);
                                    $mediaDetails['media'][$count]['video_post'] = $val['node']['is_video'];
                                    $mediaDetails['media'][$count]['views_count'] = ($val['node']['is_video']) ? cn($val['node']['video_view_count']) : 0;
                                    $mediaDetails['media'][$count]['order_token'] = generateAccessToken($mediaDetails['media'][$count]);

                                    ++$count;

                                }
                            } else {
                                $mediaDetails['media'][$count]['link'] = 'https://www.instagram.com/p/' . $val['node']['shortcode'];
                                $mediaDetails['media'][$count]['display_url'] = $val['node']['display_url'];
                                $mediaDetails['media'][$count]['likes_count'] = cn($val['node']['edge_media_preview_like']['count']);
                                $mediaDetails['media'][$count]['comments_count'] = cn($val['node']['edge_media_to_comment']['count']);
                                $mediaDetails['media'][$count]['video_post'] = $val['node']['is_video'];
                                $mediaDetails['media'][$count]['views_count'] = ($val['node']['is_video']) ? cn($val['node']['video_view_count']) : 0;
                                $mediaDetails['media'][$count]['order_token'] = generateAccessToken($mediaDetails['media'][$count]);

                                ++$count;

                            }

                            if ($count == $length) {
                                $exit = true;
                                break;
                            }

                        }

                        if ($exit == true)
                            break;

                    } else
                        apiResponse(400, 'Account may be private.', 'Private account.', null);
                } else {
                    apiResponse(400, 'Insta id is not valid.', 'Invalid id.', null);
                }
            } else
                apiResponse(400, 'Something went wrong, please try after sometime.', 'No results found.', null);
        } while (($has_next_page != false) && ($end_cursor != ''));

        $mediaDetails['has_next_page'] = $has_next_page;
        $mediaDetails['end_cursor'] = ($mediaDetails['has_next_page']) ? $end_cursor : null;
        $mediaDetails['id'] = $id;
        return $mediaDetails;

    }

    /**
     * @desc To get all media of insta user based on endCount(length)
     * @param $username , int $length, string $postType
     * @return array
     * @date 21-03-2018
     * @dev Saurabh Kumar <saurabh.kumar@globussoft.com>
     */
    public function getAllMedia($username, $length = 12, $postType = 'both')
    {

        $url = 'https://www.instagram.com/' . $username . '/?__a=1';

        $has_next_page = false;
        $end_cursor = '';
        $id = '';
        $first = 24;
        $mainStr = 'graphql';
        $mediaDetails = [];

        $count = 0;
        $exit = false;

        do {

            if (($has_next_page == true) && ($end_cursor != '')) {
                $url = 'https://www.instagram.com/graphql/query/?query_hash=472f257a40c653c64c666ce877d59d2b&variables={%22id%22%3A%22' . $id . '%22%2C%22first%22%3A' . $first . '%2C%22after%22%3A%22' . $end_cursor . '%22}';
                $mainStr = 'data';
            }

            $headers = $this->setHeaders();
            $details = $this->curlUsingGet($url, $headers);
            $details = json_decode($details, true);

            if (!empty($details)) {

                if ((isset($details[$mainStr]['user']["is_private"]) && $details[$mainStr]['user']["is_private"] == false) || (!empty($details['data']['user']['edge_owner_to_timeline_media']['edges']))) {
                    $has_next_page = $details[$mainStr]['user']['edge_owner_to_timeline_media']['page_info']['has_next_page'];
                    $end_cursor = $details[$mainStr]['user']['edge_owner_to_timeline_media']['page_info']['end_cursor'];
                    $id = ($mainStr == 'graphql') ? $details[$mainStr]['user']['id'] : $id;

                    $media = $details[$mainStr]['user']['edge_owner_to_timeline_media']['edges'];

                    foreach ($media as $key => $val) {

                        if ($postType == 'video') {

                            if ($val['node']['is_video'] == true) {

                                $mediaDetails['media'][$count]['link'] = 'https://www.instagram.com/p/' . $val['node']['shortcode'];
                                $mediaDetails['media'][$count]['display_url'] = $val['node']['display_url'];
                                $mediaDetails['media'][$count]['like_count'] = $val['node']['edge_media_preview_like']['count'];
                                $mediaDetails['media'][$count]['comment_count'] = $val['node']['edge_media_to_comment']['count'];
                                $mediaDetails['media'][$count]['is_video'] = $val['node']['is_video'];
                                $mediaDetails['media'][$count]['view_count'] = ($val['node']['is_video']) ? $val['node']['video_view_count'] : 0;

                                ++$count;
                                if ($count == $length) {
                                    $exit = true;
                                    break;
                                }
                            }
                        }
                    }
                    if ($exit == true)
                        break;


//                echo '<pre>';
//                print_r($mediaDetails);
//                die;
//
//                switch ($postType) {
//                    case 'image':
//
//                }

                } else {
                    apiResponse(400, 'Account is private.', 'Private account.', null);
                }
            } else
                apiResponse(400, 'Username doesn\'t exists.', 'No results found.', null);

        } while (($has_next_page != false) && ($end_cursor != ''));

        $mediaDetails['has_next_page'] = $has_next_page;
        $mediaDetails['end_cursor'] = $end_cursor;
        $mediaDetails['id'] = $id;
        return $mediaDetails;

    }

    /*
    |--------------------------------------------------------------------------
    | Get Instagram Media Details based on shortcode -- Saurabh - 6th July 2018
    |--------------------------------------------------------------------------
    |
    | This function fetches the more media details ( not only 12 recent media)
    | based on the length provided . length is optional , if not provided 24 media will be fetched.
    | Req param : id, end_cursor( this the cursor from where the next post will be fetched)
    |
    */
    public function getInstaMediaDetails($shortcode)
    {
        try {
            $result = $this->curlUsingGet('https://instagram.com/p/' . $shortcode . '/?__a=1');
            $result = json_decode($result, true);

            if (!empty($result)) {
                if (!$result["graphql"]["shortcode_media"]["owner"]["is_private"]) {
                    $details = [];
                    $videoPost = $result["graphql"]["shortcode_media"]["is_video"];
                    $details['likes_count'] = $result["graphql"]["shortcode_media"]["edge_media_preview_like"]["count"];
                    $details['comments_count'] = $result["graphql"]["shortcode_media"]["edge_media_to_comment"]["count"];
                    $details['views_count'] = ($videoPost == true) ? $result["graphql"]["shortcode_media"]["video_view_count"] : 0;
                    $details['image_url'] = $result["graphql"]["shortcode_media"]["display_url"];
                    return json_encode(['code' => 200, 'status' => "success", 'response' => $details]);
                } else {
                    return json_encode(['code' => 400, 'status' => "failed", 'response' => 'Account is private.']);
                }
            } else {
                return json_encode(['code' => 400, 'status' => "failed", 'response' => 'Link is invalid Or may be private.']);
            }
        } catch (\Exception $e) {
            return json_encode(['code' => 500, 'status' => "failed", 'response' => $e->getMessage()]);
        }
    }

    public function curlUsingGet($url, $headers = '')
    {
        ini_set('max_execution_time', 600);

        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);

        // if headers (session details here) is passed , set it in http headers.
        if (!empty($headers))
            curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

        curl_setopt($ch, CURLOPT_VERBOSE, 1);

        $curl_scraped_page = curl_exec($ch);

        if (curl_errno($ch) > 0) {
            print_r(curl_error($ch));
        }
        curl_close($ch);
//        dd($curl_scraped_page);
        return $curl_scraped_page;
    }

    public function curlUsingGetWithProxy($url, $headers = '')
    {
        ini_set('max_execution_time', 600);

        /* select the proxy based on last used */
        $_db = new DBClass();
        $selectedCols = [
            'proxy_id', 'ip', 'port', 'username', 'password', 'proxy_hit_count', 'proxy_type'
        ];

        $proxies = $_db->selectQuery('proxies', ['rawQuery' => 'working_status = "A" and busy_status= "F" and last_used_at= (select MIN(last_used_at) FROM proxies)'], $selectedCols);
        if (empty($proxies)) {
            $proxies = $_db->selectQuery('proxies', ['rawQuery' => 'working_status = "A" and last_used_at= (select MIN(last_used_at) FROM proxies)'], $selectedCols);
        }

        if (empty($proxies)) {
            /* add notification in table */
            $notificationInserted = $_db->insert('notifications', [
                'for_user_id' => 0,
                'notifications_txt' => 'No any active proxy found. Add new proxy.',
                'notification_status' => 'N',
                'notification_type' => 1, //proxy related
                'created_at' => time()
            ]);

            $result = $this->curlUsingGet($url);
            return $result;
        }

        $proxyRand = array_rand($proxies);
        $proxyDetails = $proxies[$proxyRand];
        $proxy = $proxyDetails['ip'] . ':' . $proxyDetails['port'];

        $start_time = microtime(true);

        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_PROXY, $proxy);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
        curl_setopt($ch, CURLOPT_VERBOSE, 1);
        if (isset($proxyDetails['username']))
            curl_setopt($ch, CURLOPT_PROXYUSERPWD, $proxyDetails['username'] . ':' . $proxyDetails['password']);
        if (!empty($headers))
            curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

        $curl_scraped_page = curl_exec($ch);

        if (curl_errno($ch) > 0) {
            print_r(curl_error($ch));
        }
        curl_close($ch);

        $end_time = microtime(true);
        $execution_time = ($end_time - $start_time);
        $execution_time = number_format($execution_time, 2);

        if (strpos($curl_scraped_page, 'Please wait a few minutes before you try again') !== FALSE) {
            echo "Please wait a few minutes before you try again <br>";
            sleep(10);
            $this->curlUsingGetWithProxy($url);
        }
        if ($curl_scraped_page === false) {
            //change proxy
            echo "Result not found, change the proxies:  <br>";

            $whereForUpdateProxy = array(
                'rawQuery' => 'proxy_id = ?',
                'bindParams' => [$proxyDetails['proxy_id']]
            );
            $dataForUpdateProxy = array('proxy_hit_count' => ++$proxyDetails['proxy_hit_count'], 'last_used_at' => time(), 'working_status' => 'I', 'execution_time' => $execution_time);
            $updateQueryResult = $_db->updateQuery('proxies', $whereForUpdateProxy, $dataForUpdateProxy);

            /* inform to admin */

            $this->curlUsingGetWithProxy($url);
        }

        $whereForUpdateProxy = array(
            'rawQuery' => 'proxy_id = ?',
            'bindParams' => [$proxyDetails['proxy_id']]
        );
        $dataForUpdateProxy = array('proxy_hit_count' => ++$proxyDetails['proxy_hit_count'], 'last_used_at' => time(), 'execution_time' => $execution_time);
        $_db->updateQuery('proxies', $whereForUpdateProxy, $dataForUpdateProxy);
        $_db->insert('notifications', [
            'for_user_id' => 0,
            'notifications_txt' => $proxyDetails['proxy_id'] . ' => ' . $proxy . ' has been inactive.',
            'notification_status' => 'N',
            'notification_type' => 7, //proxy inactivity
            'created_at' => time()
        ]);
        return $curl_scraped_page;
    }

}
