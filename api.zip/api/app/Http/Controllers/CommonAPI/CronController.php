<?php

namespace App\Http\Controllers\CommonAPI;


use App\Http\Models\Autolikes_order;
use App\Http\Models\Comments;
use App\Http\Models\DBClass;
use Illuminate\Support\Facades\DB;

class CronController
{

    protected $_db;

    public function __construct()
    {
        $this->_db = DBClass::getInstance();
    }

    public function autolikesScript()
    {
        /*TODO
            Fetch all the profiles which is in running state
            scrape insta profile and store all 12 recent medias in autolikes_orders_meta table

        */

//        `autolikes_id`, `by_user_id`, `insta_username`, `profile_image`, `recurring_profile_id`, `sub_package_id`,
//        `post_limit`, `post_fetch_count`, `post_done`, `daily_post_limit`, `daily_post_done`, `likes_split_option`,
//        `views_split_option`, `first_post_fetched_time`, `last_post_created_time`, `reset_counter_time`, `last_checked_time`,
//        `last_delivered_time`, `last_delivered_link`, `niche`, `auto_views`, `message`, `status`, `cron_status`, `created_at`

//        $whereCondition = ['rawQuery' => 'status = ? and cron_status = ?', 'bindParams' => [1, 0]];
//        $selectCols = ['autolikes_id',]
//        $this->_db->selectQueryWithJoin('autolikes_orders','autolikes_orders_meta')

    }

    /**
     * @desc This function to fetch the scraped medias from autolikes_orders_meta table
     * check the media based on the last_post_created_time means (after the last delivered post)
     * place the media to orders table based on the post limit , daily post limit and set delivery speed.
     * @date 25-09-2018
     * @dev saurabh Kumar <saurabh.kumar@globussoft.com>
     */
    public function scheduleOrdersCronJob()
    {
        $whereCondition = ['rawQuery' => 'autolikes_orders.status = ? and autolikes_orders_meta.schedule_cron_status = ? and autolikes_orders_meta.process_status = ?', 'bindParams' => [1, 0, 1]];
        $selectCols = ['autolikes_orders.*', 'autolikes_orders_meta.*', 'recurring_profiles.sub_package_type', 'subscription_packages.daily_details', 'subscription_packages.weekly_details', 'subscription_packages.monthly_details', 'subscription_packages.likes_plan_id', 'subscription_packages.views_plan_id'];
//        $autolikesProfiles = $this->_db->selectQueryWithJoin('autolikes_orders', 'autolikes_orders_meta', 'autolikes_orders.autolikes_id', 'autolikes_orders_meta.parent_autolikes_id', $whereCondition, $selectCols);
        $objAutolikesOrder = new Autolikes_order();
        $autolikesProfiles = $objAutolikesOrder->profileMetaWithRecurringAndPackageDetails($whereCondition, $selectCols);
        if (!empty($autolikesProfiles)) {
            $this->scheduleOrders($autolikesProfiles);
        }
        exit();
    }

    public function scheduleOrders($autolikesProfiles)
    {
        try {
            $autolikesIds = implode(',', array_unique(array_map(function ($val) {
                return $val['parent_autolikes_id'];
            }, $autolikesProfiles)));

            $cronUpdated = $this->_db->updateQuery('autolikes_orders_meta', ['rawQuery' => 'parent_autolikes_id IN (' . $autolikesIds . ')'], ['schedule_cron_status' => 1]); //replace to 1 when testing gets over
            $ordersDataArr = [];
            foreach ($autolikesProfiles as $profile) {
                try {

                    $whereCondition = ['rawQuery' => 'autolikes_id = ?', 'bindParams' => [$profile['autolikes_id']]];

                    if ($profile['daily_post_done'] < $profile['daily_post_limit']) {
                        /* Daily post limit condition checked */
                        if ($profile['post_fetch_count'] < $profile['post_limit']) {
                            /* Total post limit condition checked*/
                            $medias = json_decode($profile['medias'], true);

                            if (isset($medias) && !empty($medias) && is_array($medias)) {

                                $lastPostCreatedTime = 0;
                                $lastDeliveredLink = '';
                                $dailyPostLeft = intval($profile['daily_post_limit'] - $profile['daily_post_done']);
                                foreach (array_reverse($medias) as $key => $media) {
                                    try {
                                        if ($media['taken_at_timestamp'] > $profile['last_post_created_time']) {

                                            if ($dailyPostLeft == 0)
                                                break;
                                            $lastPostCreatedTime = $media['taken_at_timestamp']; //to store the last post created time
                                            $lastDeliveredLink = $media['link']; //to store the last post created time

                                            /* fetching the likes plan id based on the billing cycle , we have diff planid for diff billing cycle */
                                            if ($profile['sub_package_type'] != "") {
                                                $planId = json_decode($profile[$profile['sub_package_type']], true)[0]['plan_id'];
                                            } else {
                                                $planId = $profile['likes_plan_id'];
                                            }
                                            /* Codes for randomization quantity */
                                            $likesRandomize = json_decode($profile['likes_randomize'], true);
                                            $likesQuantity = rand($likesRandomize['min_quantity'], $likesRandomize['max_quantity']);
                                            /* Check the split option */
                                            $likesSplitOption = json_decode($profile['likes_split_option'], true);
                                            /* to add the start delay , orders will be process after the selected delay */
                                            $likesStartTime = time();
                                            if (isset($likesSplitOption['likes_start_delay'])) {
                                                $likesStartTime = $likesStartTime + $likesSplitOption['likes_start_delay'];
                                            }
                                            /* splitting orders with orders per run with delay interval */
                                            $likesOrderPerRun = $likesTimeInterval = null;
                                            if (isset($likesSplitOption['likes_split_option_enabled']) && $likesSplitOption['likes_split_option_enabled'] == "on") {
                                                $likesOrderPerRun = $likesSplitOption['likes_quantity_per_run'];
                                                $likesTimeInterval = $likesSplitOption['likes_delay_interval'];
                                            }

                                            $ordersDataArr[] = [
                                                'user_id' => $profile['by_user_id'],
//                                              'tx_id' => '',
                                                'package_id' => 0,
                                                'package_type' => 0,
                                                'autolikes_id' => $profile['autolikes_id'],
                                                'sub_package_id' => $profile['sub_package_id'],
                                                'order_url' => $media['link'],
                                                'url_type' => 1,
                                                'plan_id' => $planId,
                                                'start_count' => $media['likes_count'],
                                                'end_count' => 0,
                                                'quantity' => $likesQuantity,
//                                              'amount' => '',
                                                'quantity_done' => 0,
//                                              'comment_id' => '',
                                                'start_time' => $likesStartTime,
                                                'orders_per_run' => $likesOrderPerRun,
                                                'time_interval' => $likesTimeInterval,
                                                'status' => 0,
                                                'cron_status' => 0,
                                                'added_time' => time(),
                                                'updated_time' => time()
                                            ];
                                            $dailyPostLeft--;

                                            if (isset($profile['auto_views']) && $profile['auto_views'] == "on") {
                                                if (isset($profile['views_plan_id']) && $profile['views_plan_id'] != 0) {

                                                    $viewsRandomize = json_decode($profile['views_randomize'], true);
                                                    $viewsQuantity = rand($viewsRandomize['min_quantity'], $viewsRandomize['max_quantity']);

                                                    /* Check the split option */
                                                    $viewsSplitOption = json_decode($profile['views_split_option'], true);

                                                    $viewsStartTime = time();
                                                    if (isset($viewsSplitOption['views_start_delay'])) {
                                                        $viewsStartTime = $viewsStartTime + $viewsSplitOption['views_start_delay'];
                                                    }

                                                    $viewsOrderPerRun = $viewsTimeInterval = null;
                                                    if (isset($viewsSplitOption['views_split_option_enabled']) && $viewsSplitOption['views_split_option_enabled'] == "on") {
                                                        $viewsOrderPerRun = $viewsSplitOption['views_quantity_per_run'];
                                                        $viewsTimeInterval = $viewsSplitOption['views_delay_interval'];
                                                    }

                                                    $ordersDataArr[] = [
                                                        'user_id' => $profile['by_user_id'],
//                                                      'tx_id' => '',
                                                        'package_id' => 0,
                                                        'package_type' => 4,
                                                        'autolikes_id' => $profile['autolikes_id'],
                                                        'sub_package_id' => $profile['sub_package_id'],
                                                        'order_url' => $media['link'],
                                                        'url_type' => 1,
                                                        'plan_id' => $profile['views_plan_id'],
                                                        'start_count' => $media['views_count'],
                                                        'end_count' => 0,
                                                        'quantity' => $viewsQuantity,
//                                                      'amount' => '',
                                                        'quantity_done' => 0,
//                                                      'comment_id' => '',
                                                        'start_time' => $viewsStartTime,
                                                        'orders_per_run' => $viewsOrderPerRun,
                                                        'time_interval' => $viewsTimeInterval,
                                                        'status' => 0,
                                                        'cron_status' => 0,
                                                        'added_time' => time(),
                                                        'updated_time' => time()
                                                    ];
                                                    $dailyPostLeft--;
                                                }
                                            }
                                        }
                                    } catch (\Exception $e) {
                                        echo "inside media foreach loop" . $e->getMessage();
                                        continue;
                                    }
                                }
                                if (!empty($ordersDataArr)) {
                                    dd(json_encode($ordersDataArr));
                                    $postFetchedCount = count($ordersDataArr);
                                    $ordersInserted = $this->_db->insertMultipleData('orders', $ordersDataArr);
                                    if ($ordersInserted) {
                                        $dataToUpdate = [
                                            'post_fetch_count' => $profile['post_fetch_count'] + $postFetchedCount,
                                            'daily_post_done' => $profile['daily_post_done'] + $postFetchedCount,
                                            'last_post_created_time' => $lastPostCreatedTime,
                                            'last_checked_time' => time(),
                                            'last_delivered_time' => time(),
                                            'last_delivered_link' => $lastDeliveredLink,
                                            'process_status' => 0,
                                            'schedule_cron_status' => 0,
                                        ];
                                        $this->_db->updateQueryWithJoin('autolikes_orders', 'autolikes_orders_meta', 'autolikes_orders.autolikes_id', 'autolikes_orders_meta.parent_autolikes_id', $whereCondition, $dataToUpdate);
                                    }
                                } else {
                                    $this->_db->updateQueryWithJoin('autolikes_orders', 'autolikes_orders_meta', 'autolikes_orders.autolikes_id', 'autolikes_orders_meta.parent_autolikes_id', $whereCondition, ['last_checked_time' => time(), 'process_status' => 0, 'schedule_cron_status' => 0]);
                                }
                            } else {
                                $this->_db->updateQueryWithJoin('autolikes_orders', 'autolikes_orders_meta', 'autolikes_orders.autolikes_id', 'autolikes_orders_meta.parent_autolikes_id', $whereCondition, ['last_checked_time' => time(), 'process_status' => 0, 'schedule_cron_status' => 0]);
                            }

                        } else {
                            $dataToUpdate = ['last_checked_time' => time(), 'message' => 'Total post limit has been reached, waiting for next billing cycle to restart the profile again. ', 'status' => 2, 'cron_status' => 0, 'process_status' => 0, 'schedule_cron_status' => 0];
                            $this->_db->updateQueryWithJoin('autolikes_orders', 'autolikes_orders_meta', 'autolikes_orders.autolikes_id', 'autolikes_orders_meta.parent_autolikes_id', $whereCondition, $dataToUpdate);
                        }

                    } else {
                        $dataToUpdate = ['last_checked_time' => time(), 'message' => 'Daily post limit has been reached. Script will start fetching new post again after ' . date('d-m-y H:i:s', $profile['first_post_fetched_time']), 'status' => 4, 'cron_status' => 0, 'process_status' => 0, 'schedule_cron_status' => 0];
                        $this->_db->updateQueryWithJoin('autolikes_orders', 'autolikes_orders_meta', 'autolikes_orders.autolikes_id', 'autolikes_orders_meta.parent_autolikes_id', $whereCondition, $dataToUpdate);
                    }

                } catch (\Exception $e) {
                    echo "inside autolikes profile foreach loop" . $e->getMessage();
                    $this->_db->updateQuery('autolikes_orders_meta', ['rawQuery' => 'parent_autolikes_id = ?', 'bindParams' => [$profile['autolikes_id']]], ['schedule_cron_status' => 0]);
                    continue;
                }
            }

        } catch (\Exception $e) {
            echo "outside loop" . $e->getMessage();
            $this->_db->updateQuery('autolikes_orders_meta', ['rawQuery' => 'autolikes_meta_id IN (' . $autolikesIds . ')'], ['schedule_cron_status' => 0]);
        }

    }

    public function placeOrdersToProcessOrdersCronJob()
    {
        $whereCondition = ['rawQuery' => 'orders.status = ? and orders.cron_status = ? and orders.start_time <= ?', 'bindParams' => [0, 0, time()]];
        $selectCols = ['orders.*', 'plans.plan_name_code', 'plans.min_quantity', 'plans.max_quantity', 'plans.plan_type', 'plans.supplier_server_id'];
        $ordersDetails = $this->_db->selectQueryWithJoin('orders', 'plans', 'orders.plan_id', 'plans.plan_id', $whereCondition, $selectCols);
        if (!empty($ordersDetails)) {
            $this->placeOrdersToProcessOrders($ordersDetails);
        }
        exit;
    }

    public function placeOrdersToProcessOrders($ordersDetails)
    {
        //make cron_status = 1 for all the fetched orders first
        $whereIds = implode(',', array_unique(array_map(function ($f) {
            return $f['order_id'];
        }, $ordersDetails)));
        $this->_db->updateQuery('orders', ['rawQuery' => 'order_id in (' . $whereIds . ')'], ['cron_status' => 1]);

        try {

            foreach ($ordersDetails as $order) {
                try {

                    $totalQuantity = $order['quantity'];
                    $minQuantity = $order['min_quantity'];

                    $processOrdersToInsert = [];

                    if ($order['orders_per_run'] != null || $order['orders_per_run'] > 0) {
                        //split option is set
                        $tempQuantity = $totalQuantity;
                        $quantityPerRun = $order['orders_per_run'];
                        $delayInterval = $order['time_interval'];
                        $startTime = time();

                        //TODO we need to do fetch the comments based on planType == 3
                        /*
                         *  amount per run must be greater than plans minimum quantity (that validation should be at placing orders that only )
                         *  if not , place all the quantity at once
                         *  and quantity must be greater than the minimum quantity ( this is must validation before placing orders to orders table )
                         *  even if not atleast place the orders with the minimum quantity . :(
                         * */
                        if ($quantityPerRun >= $minQuantity) {

                            while (($tempQuantity - $quantityPerRun) >= $minQuantity) {
                                //place orders to process_orders table
                                $processOrdersToInsert[] = [
                                    'parent_order_id' => $order['order_id'],
                                    'supplier_id' => $order['supplier_server_id'],
                                    'service_id' => $order['plan_name_code'],
                                    'url' => $order['order_url'],
                                    'quantity' => $quantityPerRun,
                                    'start_time' => $startTime,
                                    'updated_time' => time(),
                                    'process_order_status' => 0,
                                    'cron_status' => 0
                                ];

                                $tempQuantity -= $quantityPerRun;
                                $startTime = $startTime + $delayInterval;
                            }
                            if ($tempQuantity >= $minQuantity) {
                                $processOrdersToInsert[] = [
                                    'parent_order_id' => $order['order_id'],
                                    'supplier_id' => $order['supplier_server_id'],
                                    'service_id' => $order['plan_name_code'],
                                    'url' => $order['order_url'],
                                    'quantity' => $tempQuantity,
                                    'start_time' => $startTime,
                                    'updated_time' => time(),
                                    'process_order_status' => 0,
                                    'cron_status' => 0
                                ];
                            }

//                            dd($order, $processOrdersToInsert);
                        } else {
                            $processOrdersToInsert = [
                                'parent_order_id' => $order['order_id'],
                                'supplier_id' => $order['supplier_server_id'],
                                'service_id' => $order['plan_name_code'],
                                'url' => $order['order_url'],
                                'start_time' => $startTime,
                                'updated_time' => time(),
                                'process_order_status' => 0,
                                'cron_status' => 0
                            ];
                            if ($totalQuantity > $minQuantity) {
                                $processOrdersToInsert['quantity'] = $totalQuantity;
                            } else {
                                $processOrdersToInsert['quantity'] = $minQuantity;
                            }

                        }
                    } else {
                        /* split option is not set */

                        $processOrdersToInsert = [
                            'parent_order_id' => $order['order_id'],
                            'supplier_id' => $order['supplier_server_id'],
                            'service_id' => $order['plan_name_code'],
                            'url' => $order['order_url'],
                            'start_time' => time(),
                            'updated_time' => time(),
                            'process_order_status' => 0,
                            'cron_status' => 0
                        ];

                        if ($order['comment_id']) {

                            $getComments = new Comments();
                            $comm = $getComments->getComments($order['comment_id']);
                            if ($comm) {
                                $processOrdersToInsert['comments'] = $comm[0]->comments;
                            }
                        }
                        if ($totalQuantity > $minQuantity) {
                            $processOrdersToInsert['quantity'] = $totalQuantity;
                        } else {
                            $processOrdersToInsert['quantity'] = $minQuantity;
                        }

                    }

                    if (!empty($processOrdersToInsert)) {
                        //place orders to process_orders table
                        DB::beginTransaction();
                        $inserted = $this->_db->insertMultipleData('process_orders', $processOrdersToInsert);
                        //update orders table status=1 and cron_status 0
                        if ($inserted) {
                            $updated = $this->_db->updateQuery('orders', ['rawQuery' => 'order_id = ?', 'bindParams' => [$order['order_id']]], ['status' => 1, 'cron_status' => 0]);
                            if ($updated)
                                DB::commit();
                            else
                                DB::rollBack();
                        }
                    } else
                        exit;

                } catch (\Exception $e) {
                    //inner foreach catch
                    DB::rollBack();
                    $this->_db->updateQuery('orders', ['rawQuery' => 'order_id = ' . $order['order_id']], ['cron_status' => 0]);
                }
            }

        } catch (\Exception $e) {
            //outer catch
            $this->_db->updateQuery('orders', ['rawQuery' => 'order_id in (' . $whereIds . ')'], ['cron_status' => 0]);
        }
    }

    public function placeProcessOrdersToSupplierCronJob()
    {
        $orderDetails = $this->_db->selectQuery('process_orders', ['rawQuery' => 'process_orders.process_order_status = ? and process_orders.cron_status = ? and process_orders.start_time <= ? and process_orders.supplier_order_id IS NULL', 'bindParams' => [0, 0, time()]]);
        if (!empty($orderDetails)) {
            $this->placeProcessOrdersToSupplier($orderDetails);
        }
        exit;
    }

    public function placeProcessOrdersToSupplier($orderDetails)
    {
        //make cron_status = 1 for all the fetched orders first
        $whereIds = implode(',', array_unique(array_map(function ($f) {
            return $f['process_order_id'];
        }, $orderDetails)));
        $this->_db->updateQuery('process_orders', ['rawQuery' => 'process_order_id in (' . $whereIds . ')'], ['cron_status' => 0]);

        try {
            foreach ($orderDetails as $order) {
                try {
                    //create object of suppliers class
//                    dd($order);
                    $supplierObj = Suppliers::createObject();

                    $comments = '';
                    if (isset($order['comments']) && ($order['comments'] != null || $order['comments'] != '')) {
                        $comments = json_decode($order['comments'], true);
                    }

                    $placed = $supplierObj->placeOrders($order['supplier_id'], $order['service_id'], $order['url'], $order['quantity'], $comments);
                    $placed = json_decode($placed, true);

                    if ($placed['code'] == 200) {
                        $whereCondition = ['rawQuery' => 'process_order_id = ?', 'bindParams' => [$order['process_order_id']]];
                        $dataToUpdate = array(
                            'process_orders.supplier_order_id' => $placed['supplier_order_id'],
                            'process_orders.updated_time' => time(),
                            'process_orders.process_order_status' => 1,
                            'process_orders.cron_status' => 0,
                            'orders.status' => 1,
                            'orders.updated_time' => time(),
                            'orders.cron_status' => 0
                        );
                        $updated = $this->_db->updateQueryWithJoin('process_orders', 'orders', 'orders.order_id', 'process_orders.parent_order_id', $whereCondition, $dataToUpdate);
                    } else {
                        $failedDataToUpdate = [
                            'cron_status' => 0,
                            'failed_iteration' => DB::raw('failed_iteration + 1'),
                            'start_time' => time() + 600,
                            'process_order_status' => DB::raw('CASE failed_iteration when 3 then 6 else process_order_status end')
                        ];
                        $this->_db->updateQuery('process_orders', ['rawQuery' => 'process_order_id = ' . $order['process_order_id']], $failedDataToUpdate);
                    }
//                    dd("stop here");


                } catch (\Exception $e) {
                    //inner foreach catch
//                    dd("inner exception", $e->getMessage());
                    $this->_db->updateQuery('process_orders', ['rawQuery' => 'process_order_id = ' . $order['process_order_id']], ['cron_status' => 0]);
                }
            }
            $this->_db->updateQuery('process_orders', ['rawQuery' => 'process_order_id in (' . $whereIds . ')'], ['cron_status' => 0]);
        } catch (\Exception $e) {
            //outer catch
//            dd("outer exception", $e->getMessage());
            $this->_db->updateQuery('process_orders', ['rawQuery' => 'process_order_id in (' . $whereIds . ')'], ['cron_status' => 0]);
        }
    }

    /* Function to check the inactive proxies again and make it active or suspended */
    public function checkInactiveProxies()
    {
        $selectedCols = [
            'proxy_id', 'ip', 'port', 'username', 'password', 'proxy_hit_count', 'proxy_type'
        ];

        $proxies = $this->_db->selectQuery('proxies', ['rawQuery' => 'working_status = ? and last_used_at < ?', 'bindParams' => ["I", time() - 600]], $selectedCols);
        $proxies = json_decode(json_encode($proxies), true);

        if (empty($proxies))
            exit;

        foreach ($proxies as $proxy) {
            $result = $this->testProxyCurlHit($proxy);

            if ($result) {
                $updated = $this->_db->updateQuery('proxies', ['rawQuery' => 'proxy_id = ?', 'bindParams' => [$proxy['proxy_id']]], ['working_status' => "A", 'execution_time' => 0]);
            } else
                $updated = $this->_db->updateQuery('proxies', ['rawQuery' => 'proxy_id = ?', 'bindParams' => [$proxy['proxy_id']]], ['working_status' => "S", 'execution_time' => 0]);

        }
    }

    public function testProxyCurlHit($proxyDetails)
    {
        ini_set("max_execution_time", 300);
        $proxy = $proxyDetails['ip'] . ':' . $proxyDetails['port'];
        $url = "https://www.instagram.com/rafiahmadanjum/?__a=1";

        $start_time = microtime(true);

        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_PROXY, $proxy);
        if (isset($proxyDetails['username']))
            curl_setopt($ch, CURLOPT_PROXYUSERPWD, $proxyDetails['username'] . ':' . $proxyDetails['password']);

        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
        curl_setopt($ch, CURLOPT_VERBOSE, 1);
        $curl_scraped_page = curl_exec($ch);

        $end_time = microtime(true);
        $execution_time = ($end_time - $start_time);
        $execution_time = number_format($execution_time, 4);

        if ($curl_scraped_page === false) {
            print_r(curl_error($ch));
            curl_close($ch);
            return false;
        }
        curl_close($ch);
        return true;
    }

}
