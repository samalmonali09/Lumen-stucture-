<?php namespace App\Http\Controllers\INSTASTATS;

use App\Http\Controllers\INSTASTATS\lib\InstagramWeb;
use App\Http\Models\InstagramUsers;
use Illuminate\Support\Collection;
use Laravel\Lumen\Routing\Controller;
use App\Http\Models\Instagram_accounts;
use Illuminate\Http\Request;


class CronController extends Controller
{
    protected $instagramWeb, $objInstaUser;

    public function __construct()
    {
        $this->instagramWeb = InstagramWeb::getInstance();
        $this->objInstaUser = InstagramUsers::getInstance();
    }

    /* code to fetch the non-followers list and update in db*/
    public function getNonFollowerList()
    {
        ini_set('max_execution_time', '300');
        //fetch records from insta users meta whose non_followers update time is less than 10 hrs
        $instaUserDetails = $this->objInstaUser->getInstaUserDetails(['rawQuery' => 'non_followers_count = 0']);
        $instaUserDetails = json_decode(json_encode($instaUserDetails), true);
//        dd($instaUserDetails);
        if (!empty($instaUserDetails)) {
            foreach ($instaUserDetails as $userDetails) {

                $ObjInstagram_acount = new Instagram_accounts();
                $user = $ObjInstagram_acount->getrandomInsaAccount();
                $proxy = [
                    'proxy_username' => $user[0]->proxy_username,
                    'proxy_password' => $user[0]->proxy_password,
                    'proxy_ip' => $user[0]->proxy_ip,
                    'proxy_port' => $user[0]->proxy_port
                ];
                /*dd($user[0]->account_browser_details);
                dd($user[0]->account_session_details);*/
                $response = $this->instagramWeb->getNonFollowerDetails($userDetails['id'], $userDetails['username'], $user[0]->account_session_details, $user[0]->account_browser_details, $proxy);
                $non_followers_count = count(json_decode(json_encode($response), true));
                $updated = $this->objInstaUser->updateInstaUsers(['rawQuery' => 'ins_user_id = ?', 'bindParams' => [$userDetails['ins_user_id']]], ['non_followers_count' => $non_followers_count]);

                //first check if row exist in insta_users_meta
                $instaUserMetaDetails = $this->objInstaUser->getInstaUserMetaDetails(['rawQuery' => 'ins_user_id = ?', 'bindParams' => [$userDetails['ins_user_id']]]);
                if (!empty($instaUserMetaDetails)) {
                    //update
                    $dataToUpdate = ['non_follower_list' => json_encode($response)];
                    $updatedUsersMeta = $this->objInstaUser->updateInstaUsersMeta(['rawQuery' => 'ins_user_id = ?', 'bindParams' => [$userDetails['ins_user_id']]], $dataToUpdate);
                } else {
                    //add
                    $dataToAdd = ['ins_user_id' => $userDetails['ins_user_id'], 'non_follower_list' => json_encode($response)];
                    $addedUserMeta = $this->objInstaUser->addInstaUsersMeta($dataToAdd);

                }

            }
        }

    }

    public function updateFollowersCountCronJob()
    {
        $where = ['rawQuery' => 'insta_users_meta.last_updated_time<=? and insta_users_meta.cron_status=?', 'bindParams' => [time() - 86400, 0]];
        $selectCols = ['insta_users_meta.*', 'insta_users.username', 'insta_users.followers_count'];
        $instaUserDetails = $this->objInstaUser->getInstaUsersWithMetaDetails($where, $selectCols);
        if (!empty($instaUserDetails)) {
            $this->updateFollowersCount($instaUserDetails);
        }
        exit;
    }

    public function updateFollowersCount($instaUsers)
    {
        ini_set('memory_limit', '1024M');
        ini_set('max_execution_time', '300');

        //making cron_status = 1 for all the fetched records
        $ins_user_ids = implode(',', array_unique(array_map(function ($f) {
            return $f['ins_user_id'];
        }, $instaUsers)));
        $updated = $this->objInstaUser->updateInstaUsersWithMetaDetails(['rawQuery' => 'insta_users.ins_user_id in (' . $ins_user_ids . ')'], ['cron_status' => 0]);

        try {

            foreach ($instaUsers as $key => $user) {

                $scrapedResult = $this->instagramWeb->instaScrapePage($user['username']); //scraping page source of instagram username

                if ($scrapedResult === "Profile not found or moved permanently.") {
                    $this->objInstaUser->updateInstaUsersWithMetaDetails(['rawQuery' => 'insta_users.ins_user_id=?', 'bindParams' => [$user['ins_user_id']]], ['last_updated_time' => time(), 'cron_status' => 0]);
                    continue;
                }

                if ($scrapedResult != null) {

                    $followersCount = $scrapedResult['edge_followed_by']['count']; //get the followers count

                    $followersGained = $followersCount - $user['followers_count']; //latest count - old followers count
                    $gainedOrLoss = ($followersGained > 0) ? 'gain' : (($followersGained < 0) ? 'loss' : 'equal');

                    $followers = new Collection();
                    $followers->push([
                        'time' => time(),
                        'followers' => $followersCount, //latest count
                        'followers_gained' => $followersGained,
                        'gainOrLoss' => $gainedOrLoss,
                        'date' => date('d M Y', time())
                    ]);

                    $totalFollowersGained = 0;
                    if ($user['followers_count_daily'] != null) { //means update the new count by combining old data

                        $followerCountDaily = json_decode($user['followers_count_daily'], true); // from db
                        $followers = array_merge(json_decode($followers, true), $followerCountDaily);

                        /* codes to update the follower_gained count in insta_users table */
                        foreach ($followerCountDaily as $val) {
                            $totalFollowersGained += $val['followers_gained'];
                        }
                    }

                    /* followings stats updation */
                    $followingsCount = $scrapedResult['edge_follow']['count']; //get the followings count
                    $followings = new Collection();
                    $followings->push([
                        'time' => time(),
                        'followings' => $followingsCount
                    ]);

                    if ($user['followings_count_daily'] != null) { //means update the new count by combining old data
                        $followingsCountDaily = json_decode($user['followings_count_daily'], true); // from db
                        $followings = array_merge(json_decode($followings, true), $followingsCountDaily);
                    }

                    $dataForUpdate = ['followers_count' => $followersCount, 'followers_count_daily' => json_encode($followers), 'followings_count_daily' => json_encode($followings), 'last_updated_time' => time(), 'cron_status' => 0, 'followers_gained' => $totalFollowersGained];
                    $this->objInstaUser->updateInstaUsersWithMetaDetails(['rawQuery' => 'insta_users.ins_user_id=?', 'bindParams' => [$user['ins_user_id']]], $dataForUpdate);
                }
            }

        } catch (\Exception $e) {
            $this->objInstaUser->updateInstaUsersWithMetaDetails(['rawQuery' => 'insta_users.ins_user_id in (' . $ins_user_ids . ')'], ['cron_status' => 0]);
            echo $e->getMessage();
        }

    }

    public function getNullMediaListAndGetDetails()
    {
        $where = ['rawQuery' => 'insta_users_meta.likes_stats IS NULL or insta_users_meta.last_likers_updated_time<=?', 'bindParams' => [time() - 86400]];
        $selectCols = ['insta_users_meta.*', 'insta_users.*'];

        $instaUserDetails = $this->objInstaUser->getInstaUsersWithMetaDetails($where, $selectCols);
        if ($instaUserDetails) {
            try {
                foreach ($instaUserDetails as $instaUserDetail) {

                    try {
                        $response = $this->instagramWeb->instaScrapePage($instaUserDetail['username']);
                        if ($response) {

                            if ($instaUserDetail['likes_stats'] == null || $instaUserDetail['likes_stats'] == '[]') { //if the stats details of user is null then new recent 9 media details willl be insetred
                                $mediaCount = $response['edge_owner_to_timeline_media']['count'];
                                $likesStats = [];
                                foreach ($response['edge_owner_to_timeline_media']['edges'] as $key => $media) {
                                    if ($key < 9) {
                                        $likesStats[$media['node']['shortcode']] = [['time' => time(), 'count' => $media['node']['edge_media_preview_like']['count']]];
                                    } else {
                                        break;
                                    }
                                }

                                $whe = ['rawQuery' => 'user_meta_id=?', 'bindParams' => [$instaUserDetail['user_meta_id']]];
                                $dataToUpdate = ['likes_stats' => json_encode($likesStats), 'last_likers_updated_time' => time()];
                                $status = $this->objInstaUser->updateInstaUsersMeta($whe, $dataToUpdate);

                            } else if ($instaUserDetail['likes_stats'] != '[]') {  //if user has data in likes_stats then inset more like data into it
                                $arrayStatsDetails = (array)json_decode($instaUserDetail['likes_stats']);
                                $lastshortCutCode = array_keys($arrayStatsDetails)[count(array_keys($arrayStatsDetails)) - 1];  //last shortcut code is in the array ..when the last short code will be thete the loop will be terminate and node more data will be inserted further
                                $decodedData = json_decode($instaUserDetail['likes_stats']);
                                $newMediaDetailsObj = new  \StdClass();

                                foreach ($response['edge_owner_to_timeline_media']['edges'] as $key => $media) {

                                    if ($lastshortCutCode == $media['node']['shortcode']) {
                                        $newCollectionTobeInserted = new \StdClass();
                                        $newCollectionTobeInserted->time = time();
                                        $newCollectionTobeInserted->count = $media['node']['edge_media_preview_like']['count'];
                                        array_push($decodedData->$lastshortCutCode, $newCollectionTobeInserted);
                                        break;

                                    } else {

                                        if (array_key_exists($media['node']['shortcode'], $arrayStatsDetails)) {

                                            $newCollectionTobeInserted = new \StdClass();
                                            $newCollectionTobeInserted->time = time();
                                            $newCollectionTobeInserted->count = $media['node']['edge_media_preview_like']['count'];
                                            $code = $media['node']['shortcode'];
                                            array_push($decodedData->$code, $newCollectionTobeInserted);
                                        } else {
                                            $newMedia = $media['node']['shortcode'];
                                            $newMediaDetailsObj->$newMedia = [['time' => time(), 'count' => $media['node']['edge_media_preview_like']['count']]];
                                        }
                                    }
                                }
                                $finalDataTobeUpdated = (object)array_merge((array)$newMediaDetailsObj, (array)$decodedData);   //https://stackoverflow.com/questions/455700/what-is-the-best-method-to-merge-two-php-objects
                                $whe = ['rawQuery' => 'user_meta_id=?', 'bindParams' => [$instaUserDetail['user_meta_id']]];
                                $dataToUpdate = ['likes_stats' => json_encode($finalDataTobeUpdated), 'last_likers_updated_time' => time()];
                                $status = $this->objInstaUser->updateInstaUsersMeta($whe, $dataToUpdate);
                            }
                        }
                    } catch (\ErrorException $e) {
                        echo $e->getMessage();
                    }
                }
            } catch (\ErrorException $e) {
                echo $e->getMessage();
            }
        }
    }

    public function getTopLikersCron()
    {

//        $where = ['rawQuery' => 'insta_users_meta.likes_stats IS NULL or insta_users_meta.last_likers_updated_time<=?', 'bindParams' => [time() - 86400]];

        ini_set('max_execution_time', 900);
        $where = ['rawQuery' => 'insta_users_meta.top_likers_lists IS NULL or insta_users_meta.top_likers_updated_time<=?', 'bindParams' => [time() - 86400]];
        $selectCols = ['insta_users_meta.*', 'insta_users.*'];
        $instaUserDetails = $this->objInstaUser->getInstaUsersWithMetaDetails($where, $selectCols);

        try {
            foreach ($instaUserDetails as $userDetails) {
                $instagramWeb = InstagramWeb::getInstance();

                $ObjInstagram_acount = new Instagram_accounts();
                $user = $ObjInstagram_acount->getrandomInsaAccount();
                $proxy = [
                    'proxy_username' => $user[0]->proxy_username,
                    'proxy_password' => $user[0]->proxy_password,
                    'proxy_ip' => $user[0]->proxy_ip,
                    'proxy_port' => $user[0]->proxy_port
                ];
                $mediaDetails = $instagramWeb->getMediaDetails($userDetails['id'], $userDetails['username'], $user[0]->account_session_details, $user[0]->account_browser_details, $proxy);
                try {
                    $allMediaWithLikers = [];
                    $AllLikersOfAllMedia = [];  //actually needed

                    foreach ($mediaDetails->media_data as $eachMediadetails) {

                        try {
                            $likesCount = $eachMediadetails ['likes_count'];
                            $thumbnail_src = $eachMediadetails['thumbnail_src'];
                            $eachMediadetails ['shortcode'];
                            $likers = $instagramWeb->getAllLikers($userDetails['username'], $user[0]->account_session_details, $user[0]->account_browser_details, 50, $eachMediadetails ['shortcode'], $proxy);

                            if ($likers == NULL) throw new \ErrorException('Likers Not found   media =>' . $eachMediadetails ['shortcode'] . '  user_name=>' . $userDetails['username']);
                            $userDetails['username'];
                            $totalLikes = count($likers);
                            $likersUsername = [];
                            foreach ($likers as $lik) {

                                array_push($likersUsername, $lik['node']['username']);
                                array_push($AllLikersOfAllMedia, $lik['node']['username']); //actuaaly needed

                            }
                            $allMediaWithLikers[$eachMediadetails ['shortcode']] = ['thumbnail' => $eachMediadetails['thumbnail_src'], 'likers' => $likersUsername,];
                        } catch (\ErrorException $e) {

                            echo $e->getMessage();
                            continue;
                        }
                    }
                    $arrayTobeSorted = array_count_values($AllLikersOfAllMedia);
                    arsort($arrayTobeSorted);
                    $topLikers = [];
                    $dd = array_keys($arrayTobeSorted);
                    array_splice($arrayTobeSorted, 12);   //top likers with likes ammount
                    array_splice($dd, 12);


                    $uuuuuuuuuu = new \StdClass();
                    foreach ($arrayTobeSorted as $yy => $my) {
                        $uuuuuuuuuu->$yy = ['TotalCountLikes' => $my, 'LikedMedia' => []];
                    }

                    $Finallly = [];
                    $fins = [];
                    foreach ($dd as $key) {  //each top likers
                        foreach ($allMediaWithLikers as $keyss => $value) {   //checking with all media

                            $value['thumbnail'];
                            $value['likers'];
                            if (in_array($key, $value['likers'])) {
                                $userprofiledetails = [
                                    'username' => $key,
                                    'imageThumbnail' => $value['thumbnail'],
                                    'shortCode' => $keyss
                                ];
                                array_push($fins, $userprofiledetails);//                                    $fins
                            }
                        }
                    }

                    foreach ($uuuuuuuuuu as $fff => $god) {
                        foreach ($fins as $keyThin => $vals) {
                            if ($fff == $vals['username']) {
                                $media = ['Thumnail' => $vals['imageThumbnail'], 'ShortCutCode' => $vals['shortCode']];
                                array_push($uuuuuuuuuu->$fff['LikedMedia'], $media);
                            }
                        }
                    }
                    $returnSTatus = $this->UpdateData(json_encode($uuuuuuuuuu), $userDetails);
                    echo $returnSTatus . 'of ' . $userDetails['username'];

                } catch (\ErrorException $e) {
                    echo $e->getMessage();
                }
            }
        } catch (\ErrorException $e) {
            echo $e->getMessage();
        }

    }

    public function UpdateData($dataTOUpdate, $userDetails)
    {
        $instagramWeb = InstagramWeb::getInstance();
        $data = json_decode($dataTOUpdate);
        try {
            foreach ($data as $key => $val) {
                $hh = $instagramWeb->instaScrapePage($key);

                if ($hh != null) $data->$key->profilePicUrl = $hh['profile_pic_url'];

                foreach ($val->LikedMedia as $keyss => $med) {
                    $deta = $instagramWeb->instaScrapePagess($med->ShortCutCode);
                    $data->$key->LikedMedia[$keyss]->like_count = $deta['shortcode_media']['edge_media_preview_like']['count'];
                    $data->$key->LikedMedia[$keyss]->is_video = $deta['shortcode_media']['is_video'];
                    $data->$key->LikedMedia[$keyss]->views_count = $deta['shortcode_media']['is_video'] ? $deta['shortcode_media']['video_view_count'] : 0;
                    $data->$key->LikedMedia[$keyss]->comment_count = $deta['shortcode_media']['edge_media_to_comment']['count'];
                }
            }
            $whe = ['rawQuery' => 'user_meta_id=?', 'bindParams' => [$userDetails['user_meta_id']]];
            $dataToUpdate = ['top_likers_lists' => json_encode($data), 'top_likers_updated_time' => time()];

            $status = $this->objInstaUser->updateInstaUsersMeta($whe, $dataToUpdate);

            return $status;
        } catch (\ErrorException $e) {
            echo $e->getMessage();
        }
    }


    public function updateMediaLikesCount()
    {
//        $where = ['rawQuery' => 'insta_users_meta.ins_user_id=?', 'bindParams' => [1]];
        $where = ['rawQuery' => 'insta_users_meta.last_likers_updated_time<=?', 'bindParams' => [time() - 86400]]; //todo tobr updated
        $selectCols = ['insta_users_meta.*', 'insta_users.*'];
        $instaUserDetails = $this->objInstaUser->getInstaUsersWithMetaDetails($where, $selectCols);
        try {

            foreach ($instaUserDetails as $userKey => $uses) {
                $scrape = $response = $this->instagramWeb->instaScrapePage($uses['username']);

                $mediaData = [];
                foreach ($response['edge_owner_to_timeline_media']['edges'] as $key => $media) {

                    $data = new \Stdclass();
                    $data->shortcode = $media['node']['shortcode'];
                    $data->countDetails = [
                        [
                            'time' => time(),
                            'count' => $media['node']['edge_media_preview_like']['count'],
                            'taken_at_timestamp' => $media['node']['taken_at_timestamp']
                        ]
                    ];
                    array_push($mediaData, $data);
                }
                $check = json_decode($instaUserDetails[$userKey]['likes_stats']);
                try {
                    foreach ($check as $key => $checks) {
                        try {
                            foreach ($mediaData as $innerKey => $newscrapedDaata) {
                                if ($checks->shortcode == $newscrapedDaata->shortcode) {

                                    $newDataTobeInserTed = ['time' => time(), 'count' => $newscrapedDaata->countDetails[0]['count']];
                                    array_push($check[$key]->countDetails, $newDataTobeInserTed);
                                }
                            }
                        } catch (\ErrorException $e) {
                            echo $e->getMessage();
                        }
                    }
                    $whe = ['rawQuery' => 'user_meta_id=?', 'bindParams' => [$uses['user_meta_id']]];
                    $dataToUpdate = ['likes_stats' => json_encode($check), 'last_likers_updated_time' => time()];
                    $statusUpdate = $this->objInstaUser->updateInstaUsersMeta($whe, $dataToUpdate);
//                    dd($statusUpdate);
                } catch (\ErrorException $e) {
                    echo $e->getMessage();
                }
            }
        } catch (\ErrorException $e) {
            echo $e->getMessage();
        }
    }

    public function scrapmediaTest(Request $request)
    {
        $shortcutkey = $request->input('shortcutkey');
        $ObjInstagram_acount = new Instagram_accounts();
        $instagramWeb = InstagramWeb::getInstance();

        $user = $ObjInstagram_acount->getrandomInsaAccount();
        $proxy = [
            'proxy_username' => $user[0]->proxy_username,
            'proxy_password' => $user[0]->proxy_password,
            'proxy_ip' => $user[0]->proxy_ip,
            'proxy_port' => $user[0]->proxy_port
        ];

        $likers = $instagramWeb->getLikers2('kishoreprana', $user[0]->account_session_details, $user[0]->account_browser_details, 50, $shortcutkey, $proxy);

        dd(json_encode($likers));

    }
}
