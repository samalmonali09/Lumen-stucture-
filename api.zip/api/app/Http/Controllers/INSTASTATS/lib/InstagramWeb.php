<?php namespace App\Http\Controllers\INSTASTATS\lib;

use App\Http\Controllers\INSTASTATS\curl\CurlRequestHandler;
use App\Http\Models\InstagramUsers;
use GuzzleHttp\Client;
use GuzzleHttp\Exception\ClientException;
use Illuminate\Support\Collection;

class InstagramWeb
{

    private $curl, $cookie, $instagramWebUrl, $client;

    public function __construct()
    {
        $this->curl = CurlRequestHandler::getInstance();
        $this->instagramWebUrl = 'https://www.instagram.com';
        $this->cookie = $this->Cookie();
        $this->client = new Client();
    }


    protected static $_instance = null;

    public static function getInstance()
    {
        if (!is_object(self::$_instance))
            self::$_instance = new InstagramWeb();
        return self::$_instance;
    }

    /**
     * Cookie
     * @return array
     * @author Nandita Patel<nanditapatel@globussoft.in>
     * @since 07-Feb-2018
     */
    protected function Cookie()
    {
        return [
            'sessionid' => null,
            'ig_dau_dismiss' => time(),
            'csrftoken' => null,
            'mid' => null,
            's_network' => null,
            'target' => null,
            'ds_user_id' => null,
            'ig_pr' => 1,
            'ig_vw' => 667,
            'checkpoint_step' => null,
            'rur' => null,
            'urlgen' => null,
        ];
    }

    /**
     * setCookies
     * @param $cookieName
     * @author Nandita Patel<nanditapatel@globussoft.in>
     * @since 07-Feb-2018
     */
    public function setCookies($cookieName)
    {
        switch ($cookieName[0]) {
            case 'sessionid':
                $this->cookie['sessionid'] = $cookieName[1];
                break;
            case 'ig_dau_dismiss':
                $this->cookie['ig_dau_dismiss'] = $cookieName[1];
                break;
            case 'csrftoken':
                $this->cookie['csrftoken'] = $cookieName[1];
                break;
            case 'mid':
                $this->cookie['mid'] = $cookieName[1];
                break;
            case 's_network':
                $this->cookie['s_network'] = $cookieName[1];
                break;
            case 'target':
                $this->cookie['target'] = $cookieName[1];
                break;
            case 'ds_user_id':
                $this->cookie['ds_user_id'] = $cookieName[1];
                break;
            case 'ig_pr':
                $this->cookie['ig_pr'] = $cookieName[1];
                break;
            case 'ig_vw':
                $this->cookie['ig_vw'] = $cookieName[1];
                break;
            case 'checkpoint_step':
                $this->cookie['checkpoint_step'] = $cookieName[1];
                break;
            case 'rur':
                $this->cookie['rur'] = $cookieName[1];
                break;
            default :
                break;
        }

    }

    /**
     * parseCookies
     * @param $cookie
     * @return string
     * @author Nandita Patel<nanditapatel@globussoft.in>
     * @since 07-Feb-2018
     */
    public function parseCookies($cookie)
    {
        if (getType($cookie) == 'string') {
            $cookieDatas = explode(';', $cookie);
            foreach ($cookieDatas as $cookieData) {
                $this->setCookies(explode('=', $cookieData));
            }
        } else if (getType($cookie) == 'array') {
            foreach ($cookie as $cookieData) {
                $this->setCookies(explode('=', explode(';', $cookieData)[0]));
            }
        } else {
            return 'Invalid parse cookie data.';
        }
    }

    /**
     * getCookieString
     * @return string
     * @author Nandita Patel<nanditapatel@globussoft.in>
     * @since 07-Feb-2018
     */
    public function getCookieString()
    {
        $currentObj = $this->cookie;
        $cookieStr = '';
        if ($currentObj['mid']) $cookieStr .= 'mid=' . $currentObj['mid'] . '; ';
        if ($currentObj['sessionid']) $cookieStr .= 'sessionid=' . $currentObj['sessionid'] . '; ';
        if ($currentObj['s_network']) $cookieStr .= 's_network=' . $currentObj['s_network'] . '; ';
        if ($currentObj['ig_pr']) $cookieStr .= 'ig_pr=' . $currentObj['ig_pr'] . '; ';
        if ($currentObj['ig_vw']) $cookieStr .= 'ig_vw=' . $currentObj['ig_vw'] . '; ';
        if ($currentObj['urlgen']) $cookieStr .= 'urlgen=' . $currentObj['urlgen'] . '; ';
        if ($currentObj['csrftoken']) $cookieStr .= 'csrftoken=' . $currentObj['csrftoken'] . '; ';
        if ($currentObj['ds_user_id']) $cookieStr .= 'ds_user_id=' . $currentObj['ds_user_id'] . '; ';
        if ($currentObj['ig_dau_dismiss']) $cookieStr .= 'ig_dau_dismiss=' . $currentObj['ig_dau_dismiss'] . '; ';
        $cookieStr = str_replace(' ', '', $cookieStr);
        $cookieStr = trim($cookieStr);

        return $cookieStr;
    }

    public function login($username, $password)
    {
        $userAgent = "Instagram 10.33.0 Android (22/6.0.1; 577dpi; 1440x2560; Lenovo; Lenovo A805e; airplayep; en_US)";
        try {
            $headers = [
                'headers' => [
                    'Host' => 'www.instagram.com',
                    'Connection' => 'keep-alive',
                    'Upgrade-Insecure-Requests' => 'keep-alive',
                    'User-Agent' => $userAgent,
                    'Accept' => 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
                    'Accept-Language' => 'en-US,en;q=0.8'
                ]
            ];

            $response = $this->client->request('GET', $this->instagramWebUrl . '/accounts/login/?hl=en', $headers);
            if ($response->getStatusCode() == 200) {
                $this->parseCookies($response->getHeader('Set-Cookie'));
                $headers = [
                    'Host' => 'www.instagram.com',
                    'Connection' => 'keep-alive',
                    'Origin' => $this->instagramWebUrl,
                    'X-Instagram-AJAX' => 1,
                    'User-Agent' => $userAgent,
                    'Content-Type' => ' application/x-www-form-urlencoded',
                    'Accept' => '*/*',
                    'X-Requested-With' => 'XMLHttpRequest',
                    'X-CSRFToken' => $this->cookie['csrftoken'],
                    'Referer' => 'https://www.instagram.com/accounts/login/',
                    'Accept-Encoding' => 'gzip, deflate, br',
                    'Accept-Language' => 'en-US,en;q=0.8',
                    'Cookie' => $this->getCookieString()
                ];
                $response = $this->client->request('POST', $this->instagramWebUrl . '/accounts/login/ajax/', [
                    'headers' => $headers,
                    'form_params' => ['username' => $username, 'password' => $password]
                ]);

                $stringBody = (string)$response->getBody();
                $GuzzleResp = \GuzzleHttp\json_decode($stringBody);
                if ($response->getStatusCode() == 200) {
                    $this->parseCookies($response->getHeader('Set-Cookie'));
                    $cookie_string = $this->getCookieString();
                    if ($response->getReasonPhrase() == 'OK') {
                        if ($GuzzleResp->authenticated == true && $GuzzleResp->user == true) {
                            return instaResponse(200, 'Account login successful', null, ['session_details' => $cookie_string, 'browser_details' => $userAgent]);
                        } else if ($GuzzleResp->authenticated == false && $GuzzleResp->user == true) {
                            return instaResponse(400, 'Sorry, your password was incorrect. Please double-check your password.', 'bad_password', null);
                        } else if ($GuzzleResp->authenticated == false && $GuzzleResp->user == false) {
                            return instaResponse(400, 'The username you entered doesn\'t belong to any account. Please check your username and try again.', 'invalid_user', null);
                        } else {
                            return instaResponse(400, 'The username you entered doesn\'t belong to any account. Please check your username and try again.', 'invalid_user', null);
                        }
                    } else {
                        return instaResponse(500, 'The username you entered doesn\'t belong to any account. Please check your username and try again.', 'invalid_user', null);
                    }
                } else {
                    return instaResponse(408, 'Error in instagram service', 'failed', null);
                }
            } else {
                return instaResponse(408, 'Error in instagram service', 'failed', null);
            }
        } catch (ClientException $e) {

            $errorResponse = json_decode($e->getResponse()->getBody(), true);

            if (isset($errorResponse) && $errorResponse['lock'] == false) {

                if (isset($errorResponse['checkpoint_url'])) {
                    return instaResponse(423, 'Please verify your account.', 'checkpoint required, suspicious login attempt', ['checkpoint_url' => $errorResponse['checkpoint_url'], 'session_details' => $this->getCookieString(), 'browser_details' => $userAgent, 'username' => $username]);
                } else {
                    return instaResponse(400, 'Your account has been disabled by Instagram. Please restore your account first.', 'inactive user', null);
                }
            } else {
                return instaResponse(400, 'Please Verify Your Account', 'checkpoint_logged_out', null);
            }
        }
    }

    public function checkpointVerification($checkpoint_url, $choice, $cookie, $user_agent)
    {
        $this->parseCookies($cookie);

        try {
            $headers = [
                'Host' => 'www.instagram.com',
                'User-Agent' => $user_agent,
                'Accept' => '*/*',
                'Accept-Language' => 'en-US,en;q=0.5',
                'Accept-Encoding' => 'gzip, deflate',
                'X-CSRFToken' => $this->cookie['csrftoken'],
                'X-Instagram-AJAX' => 1,
                'Content-Type' => 'application/x-www-form-urlencoded; charset=UTF-8',
                'X-Requested-With' => 'XMLHttpRequest',
                'Referer' => $this->instagramWebUrl . $checkpoint_url,
                'Cookie' => $cookie,
                'Content-Length' => 8,
                'Connection' => 'keep-alive'
            ];

            $response = $this->client->request('POST', $this->instagramWebUrl . $checkpoint_url, [
                'headers' => $headers,
                'form_params' => ['choice' => $choice]
            ]);

            $responseBody = $response->getBody();

            $responseBody = json_decode($responseBody, true);

            if ($responseBody['status'] == 'ok') {
                if (isset($responseBody['location']) && $responseBody['location'] === "instagram://checkpoint/dismiss") {
                    return instaResponse(202, 'Already redirected to instagram, checkpoint challenge dismiss.', 'please try adding account again.', null);
                }
//                dd($response->getHeader('Set-Cookie'),$this->getCookieString());
                return instaResponse(200, $responseBody['extraData']['content'][1]['text'], null, ['cookie' => $this->getCookieString()]);
            } else {
                return instaResponse(400, 'Something went wrong, please try after sometime.', 'error occurred in getting code', null);
            }
        } catch (ClientException $e) {

            $responseBody = json_decode($e->getResponse()->getBody(), true);


            if ($responseBody['status'] == 'fail') {

                if (isset($responseBody['challenge']) && isset($responseBody['challenge']['challengeType']) && $responseBody['challenge']['challengeType'] == "SelectVerificationMethodForm") {
                    apiResponse(400, 'Wrong choice selection, try with other way.', $responseBody['challenge']['errors'][0], null);
                }

                apiResponse(400, 'Something went wrong in checkpoint verification, please try after sometime.', $responseBody['status'], null);
            }

            return instaResponse(400, 'Error in checkpoint verificaiton', $e->getResponse()->getBody(), null);
        }
    }

    public function codeVerification($checkpoint_url, $security_code, $cookie, $user_agent)
    {
        try {

            $this->parseCookies($cookie);

            $headers = [
                'Host' => 'www.instagram.com',
                'User-Agent' => $user_agent,
                'Accept' => '*/*',
                'Accept-Language' => 'en-US,en;q=0.5',
                'Accept-Encoding' => 'gzip, deflate',
                'X-CSRFToken' => $this->cookie['csrftoken'],
                'X-Instagram-AJAX' => 1,
                'Content-Type' => 'application/x-www-form-urlencoded; charset=UTF-8',
                'X-Requested-With' => 'XMLHttpRequest',
                'Referer' => $this->instagramWebUrl . $checkpoint_url,
                'Content-Length' => 20,
                'Cookie' => $this->getCookieString(),
                'Connection' => 'keep-alive',
                'Pragma' => 'no-cache',
                'Cache-Control' => 'no-cache',
            ];
            $client = new Client();
            $response = $client->request('POST', $this->instagramWebUrl . $checkpoint_url, [
                'headers' => $headers,
                'form_params' => ['security_code' => $security_code]
            ]);
            $responseBody = json_decode($response->getBody(), true);

            if ($responseBody['status'] == 'ok') {

                $cookie = $response->getHeader('Set-Cookie');

                $this->parseCookies($cookie);
                $cookie_string = $this->getCookieString();
                return instaResponse(200, 'Account login successful', null, ['session_details' => $cookie_string, 'browser_details' => $user_agent]);
//                apiResponse(200, 'Code verification was successful.', null, ['sessionDetails' => $cookie_string]);

            } else {
                apiResponse(400, 'Something went wrong in verifying security code, please try after sometime.', $responseBody['status'], null);
            }
        } catch (ClientException $e) {
            $responseBody = json_decode($e->getResponse()->getBody(), true);

            if ($responseBody['status'] == 'fail') {

                if (isset($responseBody['challenge']) && isset($responseBody['challenge']['challengeType']) && $responseBody['challenge']['challengeType'] == "VerifySMSCodeForm") {
                    apiResponse(400, $responseBody['challenge']['errors'][0], 'entered code is wrong', null);
                }

                apiResponse(400, 'Something went wrong in verifying security code, please try after sometime.', $responseBody['status'], null);
            }
        }

    }

    public function getInstaProfileDetails($username, $sessionDetails = '', $browserDetails = '')
    {
        $result = $this->instaScrapePage($username);

        $details = array();

        $details['id'] = $result["id"];
        $details['full_name'] = $result["full_name"];
        $details['profile_pic_url'] = $result["profile_pic_url"];
        $details['biography'] = $result["biography"];
        $details['followers_count'] = $result["edge_followed_by"]["count"];
        $details['followings_count'] = $result["edge_follow"]["count"];
        $details['post_count'] = $result["edge_owner_to_timeline_media"]["count"];

        //get all media details of users and count image_post and video_post

        //precaution: dont hit if post_count is 0.
        if ($details['post_count'] > 0) {
            $details['likes_count'] = $result['edge_owner_to_timeline_media']['edges'][0]['node']['edge_media_preview_like']['count'];
//            $details['is_video'] = $result['edge_owner_to_timeline_media']['edges'][0]['node']['is_video'];
//            $details['comment_count'] = $result['edge_owner_to_timeline_media']['edges'][0]['node']['edge_media_to_comment']['count'];
            $end_cursor = '';
            $first = 50; //we can get the details till 50 medias
            $url = 'https://www.instagram.com/graphql/query/?query_hash=472f257a40c653c64c666ce877d59d2b&variables={%22id%22%3A%22' . $result["id"] . '%22%2C%22first%22%3A' . $first . '%2C%22after%22%3A%22' . $end_cursor . '%22}';

            if (empty($sessionDetails))
                $sessionDetails = 'mid=WuiziQABAAGZmw2iil5x73LdZ03m;sessionid=IGSCad13ede569fc51dd62ed6f0c741625a0340568e56ee448b4857b0d35cd5e109a%3AuPzBiEKad1XipoV1n12goNemLELxtunm%3A%7B%22_auth_user_id%22%3A2210222772%2C%22_auth_user_backend%22%3A%22accounts.backends.CaseInsensitiveModelBackend%22%2C%22_auth_user_hash%22%3A%22%22%2C%22_platform%22%3A4%2C%22_token_ver%22%3A2%2C%22_token%22%3A%222210222772%3AEabbarcsZ9mA6UTnQ1uINkDsbcF52jR1%3Af334d32e960320c173f02272df0186ba4cdbf8937a4db744779fe6015acbb431%22%2C%22last_refreshed%22%3A1525199893.8777587414%7D;ig_pr=1;ig_vw=667;csrftoken=52LrQ3cUt6JCG8Fbcdtvsvwp7FSiecTI;ds_user_id=2210222772;ig_dau_dismiss=1525199756;';
            if (empty($browserDetails))
                $browserDetails = 'Instagram 10.33.0 Android (22/6.0.1; 577dpi; 1440x2560; Lenovo; Lenovo A805e; airplayep; en_US)';

            $headers = [
                'Host: www.instagram.com',
                'User-Agent: ' . $browserDetails,
                'Accept: */*',
                'Accept-Language: en-US,en;q=0.5',
                'X-Requested-With: XMLHttpRequest',
                'Referer: https://www.instagram.com/' . $username . '/',
                'Cookie: ' . $sessionDetails,
                'Connection: keep-alive'
            ];

            $mediaDetails = $this->curlHitInstagramWithHeaders($url, $headers);

            $mediaDetails = $mediaDetails['data']['user']['edge_owner_to_timeline_media']['edges'];

            $video_post = 0;
            $image_post = 0;
//            $likes_count = 0;
            if (!empty($mediaDetails)) {
//                dd($mediaDetails);
                foreach ($mediaDetails as $key => $media) {
                    if ($media['node']['is_video'] == true) {
                        ++$video_post;
                    } else {
                        ++$image_post;
                    }
//                    $likes_count += $media['node']['edge_media_preview_like']['count'];
                }
            }

            $details['image_post'] = $image_post;
            $details['video_post'] = $video_post;
//            $details['likes_count'] = $likes_count;
            //get list of all followers

            $details['followers_gained'] = 0;
            $details['non_followers_count'] = 0;
        } else {
            $details['image_post'] = 0;
            $details['video_post'] = 0;
            $details['likes_count'] = 0;


            $details['followers_gained'] = 0;
            $details['non_followers_count'] = 0;
        }
        return $details;
    }

    public function getInstaProfileDetailsNewwithProxy($username, $browser, $session, $proxyDetails)
    {
        $result = $this->instaScrapePage($username);
        $details = array();
        $session = 'mid=W9gWtAAEAAGmX0uzMtQyCLtGv2bL; mcd=3; csrftoken=PvMMT96qIfbEfsha29r4Cv4iv7KVAlzR; fbm_124024574287414=base_domain=.instagram.com; shbid=3121; ds_user_id=6819662007; sessionid=6819662007%3AJey9SmswSKhaI9%3A28; shbts=1542011304.1975763; rur=FTW; urlgen="{\"103.217.90.98\": 135183}:1gMART:GFbFm-M6kWgA3AlrS_56ZaTVzio"; fbsr_124024574287414=4J1CXtt_S6q08BBslwvF1OySZelJm7y0gMwCw35hEO8.eyJhbGdvcml0aG0iOiJITUFDLVNIQTI1NiIsImNvZGUiOiJBUUNVNzdnZTF3dGZ2MFJZTkhaMTQyTmFpRzdWM0JhaUFUbTVNdy13WE5GanczaUlCODM3NkhCMk5DNm9fMnJzZVpJUkhfZ3ZlQjRXWDkwYnl3ZzZyVU9US2lqcWNvcHBaLVFTd0Y1RnVtZlRoQnFFenFaZl9mTkxXRUczdGtqWmc0azkzYlY2T1F4cDU0ZU1QVUdMQVVDbjVCZkI2V3NxTmdDa2FHZjhhVW81VXRhVm1CYXRfRlM1d0VhTE43MDdObEpCZ2FibUpEMm9yTFZObW5EcVIzNVRyNkV1OHR1a0ZxRGpzZ1J3NVBUaVNpQVNqa1NWeW95S0RscE5VUEFSZkFZd2tBcXRiOXh2RGVaSE4wSlZBSURkU0tNcXQ3R0xZSUxmYnpSZy11Q2xUcHVsb2tOeFJEeXlVQTFzMTBISkVwSXhqRWRGM2d2MWZ3MVM0OUdyRTczeiIsImlzc3VlZF9hdCI6MTU0MjAyMjMwMCwidXNlcl9pZCI6IjEwMDAxNDgzOTIxNjY4NyJ9';
        $details['id'] = $result["id"];
        $details['full_name'] = $result["full_name"];
        $details['profile_pic_url'] = $result["profile_pic_url"];
        $details['biography'] = $result["biography"];
        $details['followers_count'] = $result["edge_followed_by"]["count"];
        $details['followings_count'] = $result["edge_follow"]["count"];
        $details['post_count'] = $result["edge_owner_to_timeline_media"]["count"];
        if ($details['post_count'] > 0) {

            $headers = [
                'Host: www.instagram.com',
                'User-Agent: ' . $browser,
                'Accept: */*',
                'Accept-Language: en-US,en;q=0.5',
                'X-Requested-With: XMLHttpRequest',
                'Referer: https://www.instagram.com/' . $username . '/',
                'Cookie: ' . $session,
                'Connection: keep-alive'
            ];
            $end_cursor = '';
            $first = 50; //we can get the details till 50 medias
            $url = 'https://www.instagram.com/graphql/query/?query_hash=472f257a40c653c64c666ce877d59d2b&variables={%22id%22%3A%22' . $result["id"] . '%22%2C%22first%22%3A' . $first . '%2C%22after%22%3A%22' . $end_cursor . '%22}';

            $proxy = $proxyDetails ['proxy_ip'] . ':' . $proxyDetails['proxy_port'];

//            dd($this->curlHitInstagramWithHeaders($url, $headers));
//            dd($proxy);
//            $start_time = microtime(true);
            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, $url);
            curl_setopt($ch, CURLOPT_HEADER, false);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
            if (!empty($headers))
                curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

//            curl_setopt($ch, CURLOPT_PROXY, $proxy);
//            if (isset($proxyDetails['proxy_username']))
//                curl_setopt($ch, CURLOPT_PROXYUSERPWD, $proxyDetails['proxy_username'] . ':' . $proxyDetails['proxy_password']);

            curl_setopt($ch, CURLOPT_VERBOSE, 1);
            curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
            curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 120);
            curl_setopt($ch, CURLOPT_TIMEOUT, 120);
            $result = curl_exec($ch);
            if (curl_errno($ch) > 0) {
                curl_close($ch);
                return [];
            }
            curl_close($ch);
            $final = json_decode($result);
            $array = json_decode(json_encode($final), true);
            $mediaDetails = $array['data']['user']['edge_owner_to_timeline_media']['edges'];

            $video_post = 0;
            $image_post = 0;
            $likes_count = 0;
            if (!empty($mediaDetails)) {

                foreach ($mediaDetails as $key => $media) {
                    if ($media['node']['is_video'] == true) {
                        ++$video_post;
                    } else {
                        ++$image_post;
                    }
//                    $likes_count += $media['node']['edge_media_preview_like']['count'];
                }
            }

            $details['image_post'] = $image_post;
            $details['video_post'] = $video_post;
            $details['likes_count'] = $mediaDetails[0]['node']['edge_media_preview_like']['count'];

            $details['followers_gained'] = 0;
            $details['non_followers_count'] = 0;

        } else {
            $details['image_post'] = 0;
            $details['video_post'] = 0;
            $details['likes_count'] = 0;
            $details['followers_gained'] = 0;
            $details['non_followers_count'] = 0;
        }
        return $details;
    }



//    public function instaScrapePage($username)
//    {
//        ini_set('memory_limit', '1024M');
//
//        $result = $this->curlUsingGet('https://instagram.com/' . $username);
//
//        if ($result != '' || $result != null) {
//            $profileDetails = explode('window._sharedData = ', $result);
//            if (count($profileDetails) > 1) {
//                $profileDetailsJson = explode(';</script>', $profileDetails[1]);
//                $profileDetailsArr = json_decode($profileDetailsJson[0], TRUE);
//
//                $result = $profileDetailsArr['entry_data']['ProfilePage'][0];
//
//                $result = $result["graphql"]["user"];
//                return $result;
//
//            }
//            return null;
//        }
//        return null;
//    }

    public function instaScrapePage($username)
    {
        ini_set('memory_limit', '1024M');

        $result = $this->curlUsingGet('https://instagram.com/' . $username);
//        dd($result);

        try {

            if ($result != '' || $result != null) {
                $profileDetails = explode('window._sharedData = ', $result);
                if (count($profileDetails) > 1) {
                    $profileDetailsJson = explode(';</script>', $profileDetails[1]);
                    $profileDetailsArr = json_decode($profileDetailsJson[0], TRUE);

                    $result = $profileDetailsArr['entry_data']['ProfilePage'][0];

                    $result = $result["graphql"]["user"];
                    return $result;

                }
                return null;
            }
        } catch (\ErrorException $e) {
            return null;
//            echo $e->getMessage();

        }

        return null;
    }

    /* code to fetch the media details */
    public function getMediaDetails($id, $username, $sessionDetails = '', $browserDetails = '', $proxyDetails = [], $length = 0, $end_cursor = '')
    {
        if (empty($sessionDetails))
            $sessionDetails = 'mid=WuiziQABAAGZmw2iil5x73LdZ03m;sessionid=IGSCad13ede569fc51dd62ed6f0c741625a0340568e56ee448b4857b0d35cd5e109a%3AuPzBiEKad1XipoV1n12goNemLELxtunm%3A%7B%22_auth_user_id%22%3A2210222772%2C%22_auth_user_backend%22%3A%22accounts.backends.CaseInsensitiveModelBackend%22%2C%22_auth_user_hash%22%3A%22%22%2C%22_platform%22%3A4%2C%22_token_ver%22%3A2%2C%22_token%22%3A%222210222772%3AEabbarcsZ9mA6UTnQ1uINkDsbcF52jR1%3Af334d32e960320c173f02272df0186ba4cdbf8937a4db744779fe6015acbb431%22%2C%22last_refreshed%22%3A1525199893.8777587414%7D;ig_pr=1;ig_vw=667;csrftoken=52LrQ3cUt6JCG8Fbcdtvsvwp7FSiecTI;ds_user_id=2210222772;ig_dau_dismiss=1525199756;';
        if (empty($browserDetails))
            $browserDetails = 'Instagram 10.33.0 Android (22/6.0.1; 577dpi; 1440x2560; Lenovo; Lenovo A805e; airplayep; en_US)';

        $headers = [
            'Host: www.instagram.com',
            'User-Agent: ' . $browserDetails,
            'Accept: */*',
            'Accept-Language: en-US,en;q=0.5',
            'X-Requested-With: XMLHttpRequest',
            'Referer: https://www.instagram.com/' . $username . '/',
            'Cookie: ' . $sessionDetails,
            'Connection: keep-alive'
        ];

        $first = ($length == 0) ? 50 : ($length > 49 ? 50 : $length);

        $has_next_page = false;

        $medias = new Collection();
        $count = 0;
        $exit = false;
        $medias->media_data = new Collection();
        do {

            $url = 'https://www.instagram.com/graphql/query/?query_hash=472f257a40c653c64c666ce877d59d2b&variables={%22id%22%3A%22' . $id . '%22%2C%22first%22%3A' . $first . '%2C%22after%22%3A%22' . $end_cursor . '%22}';
            $mediaDetails = $this->curlHitInstagramWithHeaders($url, $headers, $proxyDetails);
            if ($mediaDetails == null) {

                $sessionDetails = 'mid=WuiziQABAAGZmw2iil5x73LdZ03m;sessionid=IGSCad13ede569fc51dd62ed6f0c741625a0340568e56ee448b4857b0d35cd5e109a%3AuPzBiEKad1XipoV1n12goNemLELxtunm%3A%7B%22_auth_user_id%22%3A2210222772%2C%22_auth_user_backend%22%3A%22accounts.backends.CaseInsensitiveModelBackend%22%2C%22_auth_user_hash%22%3A%22%22%2C%22_platform%22%3A4%2C%22_token_ver%22%3A2%2C%22_token%22%3A%222210222772%3AEabbarcsZ9mA6UTnQ1uINkDsbcF52jR1%3Af334d32e960320c173f02272df0186ba4cdbf8937a4db744779fe6015acbb431%22%2C%22last_refreshed%22%3A1525199893.8777587414%7D;ig_pr=1;ig_vw=667;csrftoken=52LrQ3cUt6JCG8Fbcdtvsvwp7FSiecTI;ds_user_id=2210222772;ig_dau_dismiss=1525199756;';
                $browserDetails = 'Instagram 10.33.0 Android (22/6.0.1; 577dpi; 1440x2560; Lenovo; Lenovo A805e; airplayep; en_US)';
                return $this->getMediaDetails($id, $username, $sessionDetails, $browserDetails, $proxyDetails, $length, $end_cursor);
            }
            $mediaPosts = $mediaDetails['data']['user']['edge_owner_to_timeline_media']['edges'];
            if (!empty($mediaPosts)) {
                $medias->page_info = $mediaDetails['data']['user']['edge_owner_to_timeline_media']['page_info'];
                foreach ($mediaPosts as $key => $media) {
                    $medias->media_data->push([
                        'thumbnail_src' => $media['node']['thumbnail_src'],
                        'shortcode' => $media['node']['shortcode'],
                        'likes_count' => $media['node']['edge_media_preview_like']['count'],
                        'comments_count' => $media['node']['edge_media_to_comment']['count'],
                        'video_post' => $media['node']['is_video'],
                        'views_count' => ($media['node']['is_video'] == true) ? $media['node']['video_view_count'] : 0
                    ]);

                    if ($length != 0) {
                        ++$count;
                        if ($count == $length) {
                            $exit = true;
                            break;
                        }
                    }
                }
                if ($exit == true)
                    break;
            }
            $has_next_page = $mediaDetails['data']['user']['edge_owner_to_timeline_media']['page_info']['has_next_page'];
            $end_cursor = $mediaDetails['data']['user']['edge_owner_to_timeline_media']['page_info']['end_cursor'];

        } while ($end_cursor != '' && $has_next_page == true);
        return $medias;
    }

    /* code to get the following details */
    public function getFollowingDetails($id, $username, $sessionDetails = '', $browserDetails = '', $proxyDetails = [])
    {

        if (empty($sessionDetails))
            $sessionDetails = 'mid=WuiziQABAAGZmw2iil5x73LdZ03m;sessionid=IGSCad13ede569fc51dd62ed6f0c741625a0340568e56ee448b4857b0d35cd5e109a%3AuPzBiEKad1XipoV1n12goNemLELxtunm%3A%7B%22_auth_user_id%22%3A2210222772%2C%22_auth_user_backend%22%3A%22accounts.backends.CaseInsensitiveModelBackend%22%2C%22_auth_user_hash%22%3A%22%22%2C%22_platform%22%3A4%2C%22_token_ver%22%3A2%2C%22_token%22%3A%222210222772%3AEabbarcsZ9mA6UTnQ1uINkDsbcF52jR1%3Af334d32e960320c173f02272df0186ba4cdbf8937a4db744779fe6015acbb431%22%2C%22last_refreshed%22%3A1525199893.8777587414%7D;ig_pr=1;ig_vw=667;csrftoken=52LrQ3cUt6JCG8Fbcdtvsvwp7FSiecTI;ds_user_id=2210222772;ig_dau_dismiss=1525199756;';
        if (empty($browserDetails))
            $browserDetails = 'Instagram 10.33.0 Android (22/6.0.1; 577dpi; 1440x2560; Lenovo; Lenovo A805e; airplayep; en_US)';

        $headers = [
            'Host: www.instagram.com',
            'User-Agent: ' . $browserDetails,
            'Accept: */*',
            'Accept-Language: en-US,en;q=0.5',
            'X-Requested-With: XMLHttpRequest',
            'Referer: https://www.instagram.com/' . $username . '/following/',
            'Cookie: ' . $sessionDetails,
            'Connection: keep-alive'
        ];

        $first = 50;
        $end_cursor = '';
        $has_next_page = false;

        $followingUsername = new Collection();
        try {

            do {

                $url = 'https://www.instagram.com/graphql/query/?query_hash=58712303d941c6855d4e888c5f0cd22f&variables={"id":"' . $id . '","first":' . $first . ',"after":"' . $end_cursor . '"}';
                $followingDetails = $this->curlHitInstagramWithHeaders($url, $headers, $proxyDetails);

                $followings = $followingDetails['data']['user']['edge_follow']['edges'];

                if (!empty($followings)) {
                    foreach ($followings as $key => $list) {
                        $followingUsername->push([
                            'id' => $list['node']['id'],
                            'username' => $list['node']['username'],
                            'full_name' => $list['node']['full_name'],
                            'profile_pic_url' => $list['node']['profile_pic_url']
                        ]);
                    }
                }

                $has_next_page = $followingDetails['data']['user']['edge_follow']['page_info']['has_next_page'];
                $end_cursor = $followingDetails['data']['user']['edge_follow']['page_info']['end_cursor'];

            } while ($end_cursor != '' && $has_next_page == true);

            return $followingUsername;
        } catch (\ErrorException $e) {
            return null;
        }


    }

    /* code to fetch the follower lists */
    public function getFollowerDetails($id, $username, $sessionDetails = '', $browserDetails = '', $proxyDetails)
    {
        ini_set('max_execution_time', '300');

        if (empty($sessionDetails))
            $sessionDetails = 'mid=WuiziQABAAGZmw2iil5x73LdZ03m;sessionid=IGSCad13ede569fc51dd62ed6f0c741625a0340568e56ee448b4857b0d35cd5e109a%3AuPzBiEKad1XipoV1n12goNemLELxtunm%3A%7B%22_auth_user_id%22%3A2210222772%2C%22_auth_user_backend%22%3A%22accounts.backends.CaseInsensitiveModelBackend%22%2C%22_auth_user_hash%22%3A%22%22%2C%22_platform%22%3A4%2C%22_token_ver%22%3A2%2C%22_token%22%3A%222210222772%3AEabbarcsZ9mA6UTnQ1uINkDsbcF52jR1%3Af334d32e960320c173f02272df0186ba4cdbf8937a4db744779fe6015acbb431%22%2C%22last_refreshed%22%3A1525199893.8777587414%7D;ig_pr=1;ig_vw=667;csrftoken=52LrQ3cUt6JCG8Fbcdtvsvwp7FSiecTI;ds_user_id=2210222772;ig_dau_dismiss=1525199756;';
        if (empty($browserDetails))
            $browserDetails = 'Instagram 10.33.0 Android (22/6.0.1; 577dpi; 1440x2560; Lenovo; Lenovo A805e; airplayep; en_US)';

        $headers = [
            'Host: www.instagram.com',
            'User-Agent: ' . $browserDetails,
            'Accept: */*',
            'Accept-Language: en-US,en;q=0.5',
            'X-Requested-With: XMLHttpRequest',
            'Referer: https://www.instagram.com/' . $username . '/followers/',
            'Cookie: ' . $sessionDetails,
            'Connection: keep-alive'
        ];

        $first = 50;
        $end_cursor = '';
        $has_next_page = false;

        $followerUsername = new Collection();
        try {

            do {

                $url = 'https://www.instagram.com/graphql/query/?query_hash=37479f2b8209594dde7facb0d904896a&variables={"id":"' . $id . '","first":' . $first . ',"after":"' . $end_cursor . '"}';
                $followerDetails = $this->curlHitInstagramWithHeaders($url, $headers, $proxyDetails);

                $followers = $followerDetails['data']['user']['edge_followed_by']['edges'];

                if (!empty($followers)) {
                    foreach ($followers as $key => $list) {
                        $followerUsername->push([
                            'id' => $list['node']['id'],
                            'username' => $list['node']['username'],
                            'full_name' => $list['node']['full_name'],
                            'profile_pic_url' => $list['node']['profile_pic_url']
                        ]);
                    }
                }

                $has_next_page = $followerDetails['data']['user']['edge_followed_by']['page_info']['has_next_page'];
                $end_cursor = $followerDetails['data']['user']['edge_followed_by']['page_info']['end_cursor'];

            } while ($end_cursor != '' && $has_next_page == true);

            return $followerUsername;
        } catch (\ErrorException $e) {
            return null;
        }

    }

    /* Non-followers means the user who dont follow me back */
    public function getNonFollowerDetails($id, $username, $sessionDetails = '', $browserDetails = '', $proxyDetails = [])
    {

        //get the following list firs
        try {

            $followingLists = $this->getFollowingDetails($id, $username, $sessionDetails, $browserDetails, $proxyDetails);
            //get the followers list
            $followerLists = $this->getFollowerDetails($id, $username, $sessionDetails, $browserDetails, $proxyDetails);

            $nonFollowerList = new Collection();

            //check if the following list exist in follower list or not // if not that user is the non-follower.
            foreach ($followingLists as $list) {
                if (!$followerLists->contains('username', $list['username'])) {
                    $nonFollowerList->push($list);
                }
            }

            return $nonFollowerList;
        } catch (\ErrorException $e) {
            return null;
        }

    }

    /* function to unfollow the instagram account */
    public function unfollowInstaAccount($id, $username, $sessionDetails, $browserDetails)
    {

        $this->parseCookies($sessionDetails);

        $url = 'https://www.instagram.com/web/friendships/' . $id . '/unfollow/';
        $headers = [
            'Host: www.instagram.com',
            'User-Agent: ' . $browserDetails,
            'Accept: */*',
            'Accept-Language: en-US,en;q=0.5',
            'X-CSRFToken: ' . $this->cookie['csrftoken'],
            'Content-Type: application/x-www-form-urlencoded',
            'X-Requested-With: XMLHttpRequest',
            'Referer: https://www.instagram.com/' . $username . '/',
            'Cookie: ' . $sessionDetails,
            'Connection: keep-alive'
        ];

        try {

            $response = $this->curlHitInstagramWithHeaders($url, $headers, true);
            return $response;
        } catch (\Exception $e) {
            return $e->getMessage();
//            dd($e->getMessage());
        }

    }

    public function curlUsingGet($url)
    {
        ini_set('max_execution_time', 600);

        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_HEADER, true);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
        curl_setopt($ch, CURLOPT_VERBOSE, 1);
        $curl_scraped_page = curl_exec($ch);

        if (curl_errno($ch) > 0) {
            print_r(curl_error($ch));
        }
        curl_close($ch);
        return $curl_scraped_page;
    }

    public function curlHitInstagramWithHeaders($url, $headers = '', $proxyDetails = [], $postMethod = false)
    {
        //Saurabh
        $ch = curl_init();  // Initialise a cURL handle
//        $proxy = '83.171.106.11:8080';
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_HEADER, false);
        if ($postMethod)
            curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);

        if ($proxyDetails) {
            $proxy = $proxyDetails ['proxy_ip'] . ':' . $proxyDetails['proxy_port'];
//            curl_setopt($ch, CURLOPT_PROXY, $proxy);  todo uncomment when the proxy will be authorised  set on 06 august 2018
            if (isset($proxyDetails['proxy_username']))
                curl_setopt($ch, CURLOPT_PROXYUSERPWD, $proxyDetails['proxy_username'] . ':' . $proxyDetails['proxy_password']);
        }


//        curl_setopt($ch, CURLOPT_HTTPHEADER, array('Host: www.instagram.com','Connection: keep-alive', 'Cache-Control: max-age=0', 'Upgrade-Insecure-Requests: 1', 'User-Agent: Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.101 Safari/537.36', 'Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8', 'Accept-Encoding: gzip, deflate, br', 'Accept-Language: en-US,en;q=0.8','Cookie: mid=WQLMLgAEAAFsm7zm3B2IX2v4YWag; ig_pr=1; ig_vw=688; rur=PRN; csrftoken=aciF9z9RfmmdA2vI9YfCPMjGwWS4KH7H'));
//        curl_setopt($ch, CURLOPT_HTTPHEADER, array('Host: www.instagram.com','Cookie: csrftoken=TlTTb9Uggn1Snl8uQNh7ZY9pd8wuq4sY; rur=PRN; mid=WshvbAAEAAGdUyzeoPq1tqiI9qvS; ig_vw=1366; ig_pr=1; ig_vh=662;'));
        if (!empty($headers))
            curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

        curl_setopt($ch, CURLOPT_VERBOSE, 1);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 120);
        curl_setopt($ch, CURLOPT_TIMEOUT, 120);

        $result = curl_exec($ch);

        if (curl_errno($ch)) {
            curl_close($ch);
            return [];
//            echo 'Curl error: ' . curl_error($ch);
//            echo curl_errno($ch);
        }


//        $username = (isset($result["user"]["username"])) ? $result["user"]["username"] : 'didnt get the result';
//        dd($username);
//        echo $url . '-------------'.$username;
//        dd($result);

        curl_close($ch);
        $result = json_decode($result, true);
        return $result;

    }

    /*----------------------------Instagram login using cURL--------------------------------*/
    public function loginUsinCurl()
    {
        $url = 'https://www.instagram.com/accounts/login/ajax/';

//        dd($this->getCookies());

        $headers = [
            'Accept: */*',
            'Accept-Language: en-US,en;q=0.5',
            'Accept-Encoding: gzip, deflate',
            'X-CSRFToken: null',
//            'X-CSRFToken: null',
            'X-Instagram-AJAX: 1',
            'Content-Type: application/x-www-form-urlencoded; charset=UTF-8',
            'X-Requested-With: XMLHttpRequest',
            'Referer: https://www.instagram.com/',
            'Content-Length: 63',
//            'Cookie: mid=null; datr=null; shbid=15681; rur=FTW; ig_vw=683; ig_pr=1; ig_vh=634; ig_or=; urlgen="{\"time\": 1523269708}:1f5WzD:qV_7uF3es-1IsOrK_HWv7AttSSs"; csrftoken=null',
            'Cookie: ' . $this->getCookies(),
            'Connection: keep-alive',
            'Pragma: no-cache',
            'Cache-Control: no-cache'
        ];

//        $data = ['username' => 'saurabh_bond', 'password' => 'instastats', 'queryParams' => '%7B%7D'];//,'queryParams'=>[]
//        $data = ['username' => 'austinanderson884', 'password' => 'peg2sTeZ', 'queryParams' => '%7B%7D'];//,'queryParams'=>[]
        $data = ['username' => 'monali_globussoft', 'password' => 'MOsa_4737', 'queryParams' => '%7B%7D'];//,'queryParams'=>[]


        $result = $this->curl->curlUsingPost($url, $data, $headers);
//        $result = json_decode($result, true);

        dd($result);
        $body = json_decode($result['data']['content'], true);
        $headers = $result['data']['headers'];

        if ($body['status'] == 'ok') {
            if ($body['authenticated'] == true && $body['user'] == true) {
                apiResponse(200, 'Account login successfully.', null, $headers);
            } else {
                dd("error in authentication");
            }
        } else {
            if ($body['lock'] == false) {
                if (isset($body['checkpoint_url'])) {
                    //store cookie and checkpoint url details in cookies table
//                    'https://i.instagram.com/challenge/2210222772/8qMGVdaNtp/';
//                    dd($body['checkpoint_url']);
                    $cookies = $this->getCookiesFromCurlHeaders($headers);
                    $cookies['checkpoint_url'] = $body['checkpoint_url'];
                    dd($cookies);

                    $cookie_token = generateAccessToken($cookies);
                    dd($cookie_token);

                    $objInstagramUsers = new InstagramUsers();

                    dd("checkpoint required");
                }
            }
            dd("error in instagram login ");
        }

        dd($body);


        dd($result);

    }

    public function verifyAccountCurl()
    {

        $url = 'https://www.instagram.com/challenge/6819662007/lhJHwvONt8/';
        $headers = [
            'Host: www.instagram.com',
            'User-Agent: Mozilla/5.0 (Windows NT 6.1; WOW64; rv:42.0) Gecko/20100101 Firefox/42.0',
            'Accept: text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
            'Accept-Language: en-US,en;q=0.5',
            'Accept-Encoding: gzip, deflate',
            'Referer: https://www.instagram.com/',
//            'Cookie: mid=WcX5cAAEAAHSil5FrYgsPuuwRYLy; datr=2yb4WaKoM1k4rR5gU8Hy5dK8; shbid=15681; rur=FTW; urlgen="{\"time\": 1523439851}:1f6CRu:8xcw3BLE4Dwt6OJAuVh5WMjNddQ"; ig_vw=683; ig_pr=1; ig_vh=634; ig_or=; csrftoken=vu5cwB0BZGNNYzFjfNgXBfoCcSQCieCU',
            'Cookie: ' . $this->getCookies(),
            'Connection: keep-alive',

        ];

        $result = $this->curl->curlUsingGet($url, $headers);

    }

    public function getCookiesFromCurlHeaders($headers)
    {
        preg_match_all('/^Set-Cookie:\s*([^;]*)/mi', $headers, $matches);
        $cookies = array();
        foreach ($matches[1] as $item) {
            parse_str($item, $cookie);
            $cookies = array_merge($cookies, $cookie);
        }

        return $cookies;
    }

    public function getCookies($cookieArr = [])
    {
        $cookie = [];

        $cookie['mid'] = (isset($cookieArr['mid'])) ? $cookieArr['mid'] : 'null';
        $cookie['datr'] = (isset($cookieArr['datr'])) ? $cookieArr['datr'] : 'null';
        $cookie['shbid'] = 15681;
        $cookie['rur'] = (isset($cookieArr['rur'])) ? $cookieArr['rur'] : 'FTW';
        $cookie['ig_vw'] = 683;
        $cookie['ig_pr'] = 1;
        $cookie['ig_vh'] = 634;
        $cookie['ig_or'] = '';
        if (isset($cookieArr['urlgen']))
            $cookie['urlgen'] = $cookieArr['urlgen'];
        $cookie['csrftoken'] = (isset($cookieArr['csrftoken'])) ? $cookieArr['csrftoken'] : 'null';

        $cookieStr = '';
        foreach ($cookie as $key => $value) {
            $cookieStr .= $key . '=' . $value . ';';
        }

        return $cookieStr;
    }

    public function getLikers($username, $sessionDetails = '', $browserDetails = '', $length, $shortCutCode, $proxy = [])
    {
        $url = 'https://www.instagram.com/graphql/query/?query_hash=1cb6ec562846122743b61e492c85999f&variables={%22shortcode%22:%22' . $shortCutCode . '%22,%22first%22:' . $length . '}';
        if (empty($sessionDetails))
            $sessionDetails = 'mid=WuiziQABAAGZmw2iil5x73LdZ03m;sessionid=IGSCad13ede569fc51dd62ed6f0c741625a0340568e56ee448b4857b0d35cd5e109a%3AuPzBiEKad1XipoV1n12goNemLELxtunm%3A%7B%22_auth_user_id%22%3A2210222772%2C%22_auth_user_backend%22%3A%22accounts.backends.CaseInsensitiveModelBackend%22%2C%22_auth_user_hash%22%3A%22%22%2C%22_platform%22%3A4%2C%22_token_ver%22%3A2%2C%22_token%22%3A%222210222772%3AEabbarcsZ9mA6UTnQ1uINkDsbcF52jR1%3Af334d32e960320c173f02272df0186ba4cdbf8937a4db744779fe6015acbb431%22%2C%22last_refreshed%22%3A1525199893.8777587414%7D;ig_pr=1;ig_vw=667;csrftoken=52LrQ3cUt6JCG8Fbcdtvsvwp7FSiecTI;ds_user_id=2210222772;ig_dau_dismiss=1525199756;';
        if (empty($browserDetails))
            $browserDetails = 'Instagram 10.33.0 Android (22/6.0.1; 577dpi; 1440x2560; Lenovo; Lenovo A805e; airplayep; en_US)';


        $headers = [
            'Host: www.instagram.com',
            'User-Agent: ' . $browserDetails,
            'Accept: */*',
            'Accept-Language: en-US,en;q=0.5',
            'X-Requested-With: XMLHttpRequest',
            'Referer: https://www.instagram.com/p/' . $shortCutCode . '/?taken-by=' . $username,
            'Cookie: ' . $sessionDetails,
            'Connection: keep-alive'
        ];


        $likersdetails = $this->curlHitInstagramWithHeaders($url, $headers, $proxy);
        return $likersdetails;


    }

    public function getAllLikers($username, $sessionDetails = '', $browserDetails = '', $length, $shortCutCode, $proxy = [])
    {

        $likers = [];
        $first = 50;
        $end_cursor = '';
        $has_next_page = false;

        try {
            do {
                $url = 'https://www.instagram.com/graphql/query/?query_hash=e0f59e4a1c8d78d0161873bc2ee7ec44&variables={"shortcode":"' . $shortCutCode . '","first":' . $first . ',"after":"' . $end_cursor . '"}';

                if (empty($sessionDetails))
                    $sessionDetails = 'mid=WuiziQABAAGZmw2iil5x73LdZ03m;sessionid=IGSCad13ede569fc51dd62ed6f0c741625a0340568e56ee448b4857b0d35cd5e109a%3AuPzBiEKad1XipoV1n12goNemLELxtunm%3A%7B%22_auth_user_id%22%3A2210222772%2C%22_auth_user_backend%22%3A%22accounts.backends.CaseInsensitiveModelBackend%22%2C%22_auth_user_hash%22%3A%22%22%2C%22_platform%22%3A4%2C%22_token_ver%22%3A2%2C%22_token%22%3A%222210222772%3AEabbarcsZ9mA6UTnQ1uINkDsbcF52jR1%3Af334d32e960320c173f02272df0186ba4cdbf8937a4db744779fe6015acbb431%22%2C%22last_refreshed%22%3A1525199893.8777587414%7D;ig_pr=1;ig_vw=667;csrftoken=52LrQ3cUt6JCG8Fbcdtvsvwp7FSiecTI;ds_user_id=2210222772;ig_dau_dismiss=1525199756;';
                if (empty($browserDetails))
                    $browserDetails = 'Instagram 10.33.0 Android (22/6.0.1; 577dpi; 1440x2560; Lenovo; Lenovo A805e; airplayep; en_US)';


                $headers = [
                    'Host: www.instagram.com',
                    'User-Agent: ' . $browserDetails,
                    'Accept: */*',
                    'Accept-Language: en-US,en;q=0.5',
                    'X-Requested-With: XMLHttpRequest',
                    'Referer: https://www.instagram.com/p/' . $shortCutCode . '/?taken-by=' . $username,
                    'Cookie: ' . $sessionDetails,
                    'Connection: keep-alive'
                ];


                $likersdetails = $this->curlHitInstagramWithHeaders($url, $headers, $proxy);

                if (!empty($likersdetails['data']['shortcode_media']['edge_liked_by']['edges'])) {

                    foreach ($likersdetails['data']['shortcode_media']['edge_liked_by']['edges'] as $key => $like) {
                        array_push($likers, $like);
                    }
                }
                $has_next_page = $likersdetails['data']['shortcode_media']['edge_liked_by']['page_info']['has_next_page'];
                $end_cursor = $likersdetails['data']['shortcode_media']['edge_liked_by']['page_info']['end_cursor'];


            } while ($end_cursor != '' && $has_next_page == true);

            return $likers;

        } catch (\ErrorException $e) {

            echo $e->getMessage() . 'line number 1115 Instagramweb';

            return null;
        }
    }


    public function instaScrapePagess($username)
    {
        ini_set('memory_limit', '1024M');

        $result = $this->curlUsingGet('https://instagram.com/p/' . $username);

        if ($result != '' || $result != null) {
            $profileDetails = explode('window._sharedData = ', $result);
            if (count($profileDetails) > 1) {
                $profileDetailsJson = explode(';</script>', $profileDetails[1]);
                $profileDetailsArr = json_decode($profileDetailsJson[0], TRUE);

                return $profileDetailsArr['entry_data']['PostPage'][0]['graphql'];

//                $result = $profileDetailsArr['entry_data']['ProfilePage'][0];
//
//                $result = $result["graphql"]["user"];
//                return $result;

            }
            return null;
        }
        return null;
    }

    public function getInstaProfileDetailsss($username, $sessionDetails = '', $browserDetails = '')
    {
        $result = $this->instaScrapePage($username);

        $details = array();

        $details['id'] = $result["id"];
        $details['full_name'] = $result["full_name"];
        $details['profile_pic_url'] = $result["profile_pic_url"];
        $details['biography'] = $result["biography"];
        $details['followers_count'] = $result["edge_followed_by"]["count"];
        $details['followings_count'] = $result["edge_follow"]["count"];
        $details['post_count'] = $result["edge_owner_to_timeline_media"]["count"];

        //get all media details of users and count image_post and video_post

        //precaution: dont hit if post_count is 0.
        if ($details['post_count'] > 0) {
            $details['likes_count'] = $result['edge_owner_to_timeline_media']['edges'][0]['node']['edge_media_preview_like']['count'];
            $details['is_video'] = $result['edge_owner_to_timeline_media']['edges'][0]['node']['is_video'];
            $details['comment_count'] = $result['edge_owner_to_timeline_media']['edges'][0]['node']['edge_media_to_comment']['count'];
//            dd($result['edge_owner_to_timeline_media']['edges'][0]['node']['is_video']);

            dd($result['edge_owner_to_timeline_media']['edges']);
            $end_cursor = '';
            $first = 50; //we can get the details till 50 medias
            $url = 'https://www.instagram.com/graphql/query/?query_hash=472f257a40c653c64c666ce877d59d2b&variables={%22id%22%3A%22' . $result["id"] . '%22%2C%22first%22%3A' . $first . '%2C%22after%22%3A%22' . $end_cursor . '%22}';

            if (empty($sessionDetails))
                $sessionDetails = 'mid=WuiziQABAAGZmw2iil5x73LdZ03m;sessionid=IGSCad13ede569fc51dd62ed6f0c741625a0340568e56ee448b4857b0d35cd5e109a%3AuPzBiEKad1XipoV1n12goNemLELxtunm%3A%7B%22_auth_user_id%22%3A2210222772%2C%22_auth_user_backend%22%3A%22accounts.backends.CaseInsensitiveModelBackend%22%2C%22_auth_user_hash%22%3A%22%22%2C%22_platform%22%3A4%2C%22_token_ver%22%3A2%2C%22_token%22%3A%222210222772%3AEabbarcsZ9mA6UTnQ1uINkDsbcF52jR1%3Af334d32e960320c173f02272df0186ba4cdbf8937a4db744779fe6015acbb431%22%2C%22last_refreshed%22%3A1525199893.8777587414%7D;ig_pr=1;ig_vw=667;csrftoken=52LrQ3cUt6JCG8Fbcdtvsvwp7FSiecTI;ds_user_id=2210222772;ig_dau_dismiss=1525199756;';
            if (empty($browserDetails))
                $browserDetails = 'Instagram 10.33.0 Android (22/6.0.1; 577dpi; 1440x2560; Lenovo; Lenovo A805e; airplayep; en_US)';

            $headers = [
                'Host: www.instagram.com',
                'User-Agent: ' . $browserDetails,
                'Accept: */*',
                'Accept-Language: en-US,en;q=0.5',
                'X-Requested-With: XMLHttpRequest',
                'Referer: https://www.instagram.com/' . $username . '/',
                'Cookie: ' . $sessionDetails,
                'Connection: keep-alive'
            ];

            $mediaDetails = $this->curlHitInstagramWithHeaders($url, $headers);

            $mediaDetails = $mediaDetails['data']['user']['edge_owner_to_timeline_media']['edges'];

            $video_post = 0;
            $image_post = 0;
//            $likes_count = 0;
            if (!empty($mediaDetails)) {
//                dd($mediaDetails);
                foreach ($mediaDetails as $key => $media) {
                    if ($media['node']['is_video'] == true) {
                        ++$video_post;
                    } else {
                        ++$image_post;
                    }
//                    $likes_count += $media['node']['edge_media_preview_like']['count'];
                }
            }

            $details['image_post'] = $image_post;
            $details['video_post'] = $video_post;
//            $details['likes_count'] = $likes_count;
            //get list of all followers

            $details['followers_gained'] = 0;
            $details['non_followers_count'] = 0;
        } else {
            $details['image_post'] = 0;
            $details['video_post'] = 0;
            $details['likes_count'] = 0;


            $details['followers_gained'] = 0;
            $details['non_followers_count'] = 0;
        }
        return $details;
    }

    public function curlUsingGets($url, $headers = '')
    {

        ini_set('max_execution_time', 600);

        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        if (!empty($headers))
            curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
        curl_setopt($ch, CURLOPT_VERBOSE, 1);
        $curl_scraped_page = curl_exec($ch);
        dd($curl_scraped_page, $headers);
//        if (isset($headers) && !empty($headers)){
//            dd($headers,$curl_scraped_page);
//        }
        if (curl_errno($ch) > 0) {
            print_r(curl_error($ch));
        }
        curl_close($ch);
        return $curl_scraped_page;
    }

    public function curlHitWithProxy($url, $proxies, $headers = '')
    {
        ini_set('max_execution_time', 600);
        if (empty($proxies)) {
            /* To add in notification table */
            $notificationInserted = Notification::getInstance()->addNewNotification([
                'for_user_id' => 1,
                'notifications_txt' => 'No active proxies found. Add new proxies.',
                'notification_status' => 'N',
                'created_at' => time()
            ]);

            $result = $this->curlUsingGet($url);
            return $result;
        }

        $objProxies = new Proxy();

        $proxyRand = array_rand($proxies);
        $proxyDetails = $proxies[$proxyRand];
        $proxy = $proxyDetails['ip'] . ':' . $proxyDetails['port'];

        $start_time = microtime(true);

        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_PROXY, $proxy);
        if (isset($proxyDetails['username']))
            curl_setopt($ch, CURLOPT_PROXYUSERPWD, $proxyDetails['username'] . ':' . $proxyDetails['password']);

        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        if (!empty($headers))
            curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
        curl_setopt($ch, CURLOPT_VERBOSE, 1);
        $curl_scraped_page = curl_exec($ch);

        curl_close($ch);

        $end_time = microtime(true);
        $execution_time = ($end_time - $start_time);
        $execution_time = number_format($execution_time, 4);


        if (strpos($curl_scraped_page, 'Please wait a few minutes before you try again') !== FALSE) {
            echo "Please wait a few minutes before you try again <br>";
            sleep(10);
            $this->curlUsingGet($url);
        }

        if ($curl_scraped_page === false) {
            //change proxy
            echo "Result not found, change the proxies:  <br>";
            print_r($proxyDetails);

            $whereForUpdateProxy = array(
                'rawQuery' => 'proxy_id = ?',
                'bindParams' => [$proxyDetails['proxy_id']]
            );
            $dataForUpdateProxy = array('proxy_hit_count' => ++$proxyDetails['proxy_hit_count'], 'last_used_at' => time(), 'working_status' => 'I', 'execution_time' => $execution_time);
            $updateQueryResult = $objProxies->updateProxy($whereForUpdateProxy, $dataForUpdateProxy);

            unset($proxies[$proxyRand]);
            $this->curlUsingGet($url);
        }

        $whereForUpdateProxy = array(
            'rawQuery' => 'proxy_id = ?',
            'bindParams' => [$proxyDetails['proxy_id']]
        );
        $dataForUpdateProxy = array('proxy_hit_count' => ++$proxyDetails['proxy_hit_count'], 'last_used_at' => time(), 'execution_time' => $execution_time);
        $updateQueryResult = $objProxies->updateProxy($whereForUpdateProxy, $dataForUpdateProxy);

//        $result = json_decode($curl_scraped_page, true);

        return $curl_scraped_page;
    }
}