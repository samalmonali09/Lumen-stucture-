<?php namespace App\Http\Controllers\INSTASTATS;

use App\Http\Controllers\INSTASTATS\lib\InstagramWeb;
use App\Http\Models\InstagramUsers;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use Laravel\Lumen\Routing\Controller;
use App\Http\Models\Instagram_accounts;

class InstaController extends Controller
{

    public function addAccount(Request $request)
    {
        if ($request->isMethod('post')) {

            $validator = Validator::make($request->all(), [
                    'username' => 'required', //Rule::unique('insta_users')->where('device_id', $request['device_id'])
                    'password' => 'required',
                    'device_type' => 'required',
                    'device_id' => 'required',
                ]
//                ['username.unique' => 'You have already added this account, please reconnect it.']
            );


            if (!$validator->fails()) {

                $instagramWeb = InstagramWeb::getInstance();
                $loginResponse = $instagramWeb->login($request['username'], $request['password']);

                if ($loginResponse['code'] == 423) {
                    //Checkpoint required  //TODO generate one JWT with all cookie details and checkpoint_url and send it to mobile team for next request hit

                    $checkpoint_token = generateAccessToken(array_merge($request->all(), $loginResponse['data']));
                    apiResponse($loginResponse['code'], $loginResponse['message'], $loginResponse['error'], ['checkpoint_token' => $checkpoint_token]);

                } else if ($loginResponse['code'] == 200) {

                    //Todo Get the profile details with the session got and store the session with users basic profile info

                    $profileDetails = $this->getProfileDetails($request['username'], $loginResponse['data']['session_details'], $loginResponse['data']['browser_details']);

                    if (!empty($profileDetails) && is_array($profileDetails)) {
                        //store in table and send response to mobile team as well

                        $profileDetails['username'] = $request['username'];
                        $profileDetails['password'] = $request['password'];
                        $profileDetails['device_id'] = $request['device_id'];
                        $profileDetails['device_type'] = $request['device_type'];
                        $profileDetails['session_details'] = $loginResponse['data']['session_details'];
                        $profileDetails['browser_details'] = $loginResponse['data']['browser_details'];
                        $nonFollwersDetails = $instagramWeb->getNonFollowerDetails('', $request['username'], $loginResponse['data']['session_details'], $loginResponse['data']['browser_details']);
                        $profileDetails['non_followers_count'] = count(json_decode(json_encode($nonFollwersDetails), true));

//                        dd('non followers details>>', $nonFollwersDetails, 'session details', $loginResponse['data']['session_details'], '<<<<<browser details', $loginResponse['data']['browser_details']);

                        $objModelInstaUsers = new InstagramUsers();
                        //code to check if the same username(instagram id) is already present in table, update the row.
                        $checkOlderDetails = $objModelInstaUsers->getInstaUserDetails(['rawQuery' => 'id = ?', 'bindParams' => [$profileDetails['id']]], ['ins_user_id']);
                        $checkOlderDetails = json_decode(json_encode($checkOlderDetails), true);
                        if (!empty($checkOlderDetails)) {
                            //only update rows with recent count and new session & browser details.

//                            unset($profileDetails['followers_gained']);

                            $objModelInstaUsers->updateInstaUsers(['rawQuery' => 'ins_user_id = ?', 'bindParams' => [$checkOlderDetails[0]['ins_user_id']]], $profileDetails);
                            $addedInstaUser = $checkOlderDetails[0]['ins_user_id'];
                        } else {
                            $addedInstaUser = $objModelInstaUsers->addInstaUserDetails($profileDetails);
                        }

                        if ($addedInstaUser) {
                            unset($profileDetails['session_details']);
                            unset($profileDetails['browser_details']);
                            unset($profileDetails['password']);
                            unset($profileDetails['device_id']);
                            unset($profileDetails['device_type']);

                            $profileDetails['account_token'] = generateAccessToken(['username' => $request['username'], 'device_id' => $request['device_id'], 'device_type' => $request['device_type'], 'ins_user_id' => $addedInstaUser]);
                            apiResponse(200, 'Account added successfully.', null, $profileDetails);
                        } else {
                            apiResponse(400, 'Something went wrong in adding account.', 'error in account adding', null);
                        }
                    } else {
                        apiResponse(400, 'Something went wrong in fetching details, please try after sometime.', 'error in account adding', null);
                    }

                } else {
                    apiResponse($loginResponse['code'], $loginResponse['message'], $loginResponse['error'], $loginResponse['data']);
                }

            } else {
                $errMsg = json_decode($validator->messages(), true);
                $err = '';
                foreach ($errMsg as $key => $val) {
                    $err = $val[0];
                    break;
                }
                apiResponse(412, 'Validation error', $err, null);
            }

        } else
            apiResponse(405, 'Method not allowed.', 'Only request through post method is allowed.', null);
    }

    public function addAccountNew(Request $request)
    {
        if ($request->isMethod('post')) {

            $validator = Validator::make($request->all(), [
                    'username' => 'required', //Rule::unique('insta_users')->where('device_id', $request['device_id'])
//                    'user_id' => 'required',
                    'device_type' => 'required',
                    'device_id' => 'required',
                ]
            );

            if (!$validator->fails()) {

//                $id = $request->input('user_id');
                $username = $request->input('username');
                $objModelInstaUsers = new InstagramUsers();
                $profileDetails = $this->ProfileDetailsNew($username);
//                dd($profileDetails);
                if (!empty($profileDetails) && is_array($profileDetails)) {

                    $profileDetails['username'] = $request['username'];
                    $profileDetails['device_id'] = $request['device_id'];
                    $profileDetails['device_type'] = $request['device_type'];

                    $objModelInstaUsers = new InstagramUsers();
                    $checkOlderDetails = $objModelInstaUsers->getInstaUserDetails(['rawQuery' => 'id = ?', 'bindParams' => [$profileDetails['id']]], ['ins_user_id']);
//                    dd($checkOlderDetails, count($checkOlderDetails));
                    if (count($checkOlderDetails)) {

                        $array = json_decode(json_encode($checkOlderDetails), true);
                        $objModelInstaUsers->updateInstaUsers(['rawQuery' => 'ins_user_id = ?', 'bindParams' => [$array [0]['ins_user_id']]], $profileDetails);
                        $addedInstaUser = $array [0]['ins_user_id'];
                    } else {
                        $addedInstaUser = $objModelInstaUsers->addInstaUserDetails($profileDetails);
                    }
                    if ($addedInstaUser) {
                        unset($profileDetails['device_id']);
                        unset($profileDetails['device_type']);

                        $profileDetails['account_token'] = generateAccessToken(['username' => $request['username'], 'device_id' => $request['device_id'], 'device_type' => $request['device_type'], 'ins_user_id' => $addedInstaUser]);
                        apiResponse(200, 'Account added successfully.', null, $profileDetails);
                    } else {
                        apiResponse(400, 'Something went wrong in adding account.', 'error in account adding', null);
                    }


                } else {
                    apiResponse(400, 'Something went wrong in fetching details, please try after sometime.', 'error in account adding', null);
                }
            } else {
                $errMsg = json_decode($validator->messages(), true);
                $err = '';
                foreach ($errMsg as $key => $val) {
                    $err = $val[0];
                    break;
                }
                apiResponse(412, 'Validation error', $err, null);
            }

        } else
            apiResponse(405, 'Method not allowed.', 'Only request through post method is allowed.', null);
    }

    public function ProfileDetailsNew($username)
    {
//        getrandomInsaAccount
        $ObjInstagram_acount = new Instagram_accounts();
        $user = $ObjInstagram_acount->getrandomInsaAccount();

        $proxy = [
            'proxy_username' => $user[0]->proxy_username,
            'proxy_password' => $user[0]->proxy_password,
            'proxy_ip' => $user[0]->proxy_ip,
            'proxy_port' => $user[0]->proxy_port
        ];

        $objInstaweb = new InstagramWeb();
        $data = $objInstaweb->getInstaProfileDetailsNewwithProxy($username, $user[0]->account_browser_details, $user[0]->account_session_details, $proxy);
        return $data;

    }

    public function verifyAccount(Request $request)
    {
        if (!empty($request->input('checkpoint_token')) && array_key_exists('checkpoint_url', parseAccessToken($request['checkpoint_token']))) {
            if (!empty($request->input('method')) && in_array($request['method'], ['getCode', 'verifyCode'])) {
                $instagramWeb = InstagramWeb::getInstance();
                $checkpointDetails = parseAccessToken($request['checkpoint_token']);
                switch ($request['method']) {
                    case 'getCode':
                        if (isset($request->all()['choice']) && in_array($request['choice'], [0, 1])) {

                            $response = $instagramWeb->checkpointVerification($checkpointDetails['checkpoint_url'], $request['choice'], $checkpointDetails['session_details'], $checkpointDetails['browser_details']);
                            if ($response['code'] == 200) {
                                $checkpointDetails['session_details'] = $response['data']['cookie'];
                                apiResponse($response['code'], $response['message'], null, ['checkpoint_token' => generateAccessToken($checkpointDetails)]);
                            } else
                                apiResponse($response['code'], $response['message'], $response['error'], null);

                        } else {
                            apiResponse(412, 'Select the way you want to receive the verification code. 0 for phone and 1 for email.', 'invalid choice', null);
                        }

                        break;
                    case 'verifyCode':
                        if (!empty($request->all()['security_code'])) {

                            $response = $instagramWeb->codeVerification($checkpointDetails['checkpoint_url'], $request['security_code'], $checkpointDetails['session_details'], $checkpointDetails['browser_details']);
                            if ($response['code'] == 200) {

                                //scrape the profile and fetch the basic details and store it in table along with session_detials and browser details
                                $profileDetails = $this->getProfileDetails($checkpointDetails['username'], $response['data']['session_details'], $response['data']['browser_details']);

                                if (!empty($profileDetails) && is_array($profileDetails)) {
                                    //store in table and send response to mobile team as well

                                    $profileDetails['username'] = $checkpointDetails['username'];
                                    $profileDetails['password'] = $checkpointDetails['password'];
                                    $profileDetails['device_id'] = $checkpointDetails['device_id'];
                                    $profileDetails['device_type'] = $checkpointDetails['device_type'];
                                    $profileDetails['session_details'] = $response['data']['session_details'];
                                    $profileDetails['browser_details'] = $response['data']['browser_details'];

                                    //creating instance of InstagramUsers Model ( insta_users) table
                                    $objModelInstaUsers = new InstagramUsers();

                                    //code to check if the same username(instagram id) is already present in table, update the row.
                                    $checkOlderDetails = $objModelInstaUsers->getInstaUserDetails(['rawQuery' => 'id = ?', 'bindParams' => [$profileDetails['id']]], ['ins_user_id']);
                                    $checkOlderDetails = json_decode(json_encode($checkOlderDetails), true);
                                    if (!empty($checkOlderDetails)) {
                                        //only update rows with recent count and new session & browser details.

//                                        unset($profileDetails['followers_gained']);

                                        $objModelInstaUsers->updateInstaUsers(['rawQuery' => 'ins_user_id = ?', 'bindParams' => [$checkOlderDetails[0]['ins_user_id']]], $profileDetails);
                                        $addedInstaUser = $checkOlderDetails[0]['ins_user_id'];
                                    } else {
                                        //Storing profile details , username, session and browser details in insta_users table


                                        $addedInstaUser = $objModelInstaUsers->addInstaUserDetails($profileDetails);
                                    }

                                    if ($addedInstaUser) {
                                        //removing the password,and cookie details from the profileDetails array
                                        $objInstagramWeb = new InstagramWeb();
                                        $response = $objInstagramWeb->getNonFollowerDetails('', $profileDetails['username'], $profileDetails['session_details'], $profileDetails['browser_details']);
                                        if ($response != null) {
                                            $profileDetails['non_followers_count'] = count(json_decode(json_encode($response), true));
                                        } else {
                                            $profileDetails['non_followers_count'] = null;
                                        }

                                        unset($profileDetails['session_details']);
                                        unset($profileDetails['browser_details']);
                                        unset($profileDetails['password']);
                                        unset($profileDetails['device_id']);
                                        unset($profileDetails['device_type']);
                                        $profileDetails['account_token'] = generateAccessToken(['username' => $checkpointDetails['username'], 'device_id' => $checkpointDetails['device_id'], 'device_type' => $checkpointDetails['device_type'], 'ins_user_id' => $addedInstaUser]);
                                        //sending json response to mobile team with data as profileDetails.
                                        apiResponse(200, 'Account added successfully.', null, $profileDetails);
                                    } else {
                                        apiResponse(400, 'Something went wrong in adding account.', 'error in account adding', null);
                                    }
                                } else {
                                    apiResponse(400, 'Something went wrong in fetching details, please try after sometime.', 'error in account adding', null);
                                }
                            } else
                                apiResponse($response['code'], $response['message'], $response['error'], null);

                        } else {
                            apiResponse(412, 'Enter the code sent to you.', 'security_code param is missing.', null);
                        }
                        break;
                }
            } else {
                apiResponse(401, 'method is missing or may be invalid.', 'proper method is not passed.', null);
            }
        } else {
            apiResponse(401, 'Please provide a valid checkpoint_token', 'invalid checkpoint_token', null);
        }

    }

    public function testsss(Request $request)
    {
        $username = $request->input('username');
        $session = $request->input('session');
        $browser = $request->input('browser');

        $data = $this->getProfileDetails($username, $session, $browser);
        dd($data);
    }

    public function getProfileDetails($username, $sessionDetails, $browserDetails)
    {
        $instagramWeb = InstagramWeb::getInstance();
        $response = $instagramWeb->getInstaProfileDetails($username, $sessionDetails, $browserDetails);
        return $response;
    }

    public function getFollowingDetails()
    {
        $instagramWeb = InstagramWeb::getInstance();
        $response = $instagramWeb->getFollowingDetails(2210222772, 'saurabh_bond', '', '');
        dd($response);

    }

    public function getFollowerDetails()
    {
        $instagramWeb = InstagramWeb::getInstance();
        $response = $instagramWeb->getFollowerDetails(2210222772, 'saurabh_bond', '', '');
        dd($response);

    }

    public function getNonFollowerDetails(Request $request)
    {
        if (!empty($request->input('account_token'))) {
            if (array_key_exists('ins_user_id', parseAccessToken($request['account_token']))) {

                $accountDetails = parseAccessToken($request['account_token']);
                $objInstaUser = InstagramUsers::getInstance();
                $instaMetaDetails = $objInstaUser->getInstaUserMetaDetails(['rawQuery' => 'ins_user_id = ?', 'bindParams' => [$accountDetails['ins_user_id']]]);

                if ($instaMetaDetails) {
                    $nonFollowerList = json_decode($instaMetaDetails[0]['non_follower_list'], true);
                    apiResponse(200, 'Non followers list.', null, $nonFollowerList);
                } else {
                    apiResponse(402, 'Please wait for data update. ', 'kindly wait, we are updating the data', null);

                }

            } else {
                apiResponse(400, 'account_token is not valid, reconnect account.', 'invalid token', null);
            }
        } else {
            apiResponse(400, 'account_token is required.', 'account_token is missing', null);
        }

    }

    public function refreshAccount(Request $request)
    {

        if (!empty($request->input('account_token'))) {
            if (array_key_exists('ins_user_id', parseAccessToken($request['account_token']))) {
                $accountDetails = parseAccessToken($request['account_token']);
                $objInstaUser = InstagramUsers::getInstance();
                $instaUserDetails = $objInstaUser->getInstaUserDetails(['rawQuery' => 'ins_user_id = ?', 'bindParams' => [$accountDetails['ins_user_id']]]);
                if ($instaUserDetails) {
                    $instaUserDetails = json_decode(json_encode($instaUserDetails[0]), true);

                    unset($instaUserDetails['session_details']);
                    unset($instaUserDetails['browser_details']);
                    unset($instaUserDetails['password']);
                    $instaUserDetails['account_token'] = generateAccessToken(['username' => $instaUserDetails['username'], 'device_id' => $instaUserDetails['device_id'], 'device_type' => $instaUserDetails['device_type'], 'ins_user_id' => $instaUserDetails['ins_user_id']]);
                    unset($instaUserDetails['device_id']);
                    unset($instaUserDetails['device_type']);
                    unset($instaUserDetails['created_at']);
                    unset($instaUserDetails['updated_at']);

                    //sending json response to mobile team with data as profileDetails.
                    apiResponse(200, 'Account with latest count.', null, $instaUserDetails);
                }

            } else {
                apiResponse(400, 'account_token is not valid, reconnect account.', 'invalid token', null);
            }
        } else {
            apiResponse(400, 'account_token is required.', 'account_token is missing', null);
        }

    }

    public function getFollowersProgress(Request $request)
    {
        $validator = Validator::make($request->all(), ['basis' => 'required'], ['basis.required' => 'Please provide the basis on which followers report needs to be sent.']);
        if (!$validator->fails()) {

            if (!empty($request->input('account_token'))) {
                if (array_key_exists('ins_user_id', parseAccessToken($request['account_token']))) {

                    $accountDetails = parseAccessToken($request['account_token']);
                    $objInstaUser = InstagramUsers::getInstance();

                    $userDetails = $objInstaUser->getInstaUsersWithMetaDetails(['rawQuery' => 'insta_users.ins_user_id = ?', 'bindParams' => [$accountDetails['ins_user_id']]], ['insta_users_meta.*', 'insta_users.username']);
                    if (empty($userDetails) || (!empty($userDetails) && $userDetails[0]['followers_count_daily'] == null)) {
                        apiResponse(402, 'Please wait for data update. ', 'kindly wait, we are updating the data', null);
                    }

                    $start = ($request->input('next_id')) ? abs($request->input('next_id')) : 0;
                    $length = ($request->input('length')) ? abs($request->input('length')) : 7;

                    switch ($request['basis']) {

                        case 'daily':
                            $followersDetails = json_decode($userDetails[0]['followers_count_daily'], true);

                            if (!($request->input('length'))) {
                                $dailyFollowersReport = $followersDetails;
                                $nextId = 0;
                                $hasNext = false;
                                $previousId = 0;
                                $hasPrevious = false;
                            } else {

                                if ($request->input('previous_id')) {
                                    $offset = ($request->input('previous_id') - $length > 0) ? $request->input('previous_id') - $length : 0;
                                    $dailyFollowersReport = array_slice($followersDetails, $offset, $length);
                                    if ($offset > 0) {
                                        $previousId = $offset;
                                        $hasPrevious = true;
                                    } else {
                                        $previousId = 0;
                                        $hasPrevious = false;
                                    }
                                } else {
                                    $dailyFollowersReport = array_slice($followersDetails, $start, $length);
                                    if ($request->input('next_id')) {
                                        $previousId = intval($request->input('next_id'));
                                        $hasPrevious = true;

                                    } else {
                                        $previousId = 0;
                                        $hasPrevious = false;
                                    }
                                }

                                if ($start + $length < count($followersDetails)) {
                                    $nextId = $start + count($dailyFollowersReport);
                                    $hasNext = true;
                                } else {
                                    $nextId = 0;
                                    $hasNext = false;
                                }
                            }

                            http_response_code(200);
                            echo json_encode(['code' => 200, 'message' => 'Followers report on ' . $request['basis'] . ' basis', 'error' => null, 'next_id' => $nextId, 'has_next' => $hasNext, 'previous_id' => $previousId, 'has_previous' => $hasPrevious, 'data' => $dailyFollowersReport]);
                            die;
//                            apiResponse(200, 'Followers report on ' . $request['basis'] . ' basis', null, json_decode($userDetails[0]['followers_count_daily'], true));
                            break;

                        case 'weekly':
                            $followersReport = json_decode($userDetails[0]['followers_count_daily'], true);
                            if (!empty($followersReport)) {

                                $weeklyReport = [];
                                $i = 0;
                                $j = 0;
                                $followersGained = 0;
                                $value1 = [];
                                $value1['week'] = 0;
                                $value1['avg_followers_gained'] = 0;
                                $value1['avg_gainOrLoss'] = '';
                                $value1['daily_report'] = [];
                                foreach (($followersReport) as $key => $value) {
                                    if ((int)floor($key % 7) == 0 && $key != 0) {
                                        $i++;
                                        $followersGained = 0;
                                        $j = 0;
                                        $value1 = [];
                                        $value1['week'] = 0;
                                        $value1['avg_followers_gained'] = 0;
                                        $value1['avg_gainOrLoss'] = '';
                                        $value1['daily_report'] = [];
                                    }

                                    $followersGained += $value['followers_gained'];

                                    $value1['week'] = $i + 1;
                                    $value1['avg_followers_gained'] = $followersGained;
                                    $value1['avg_gainOrLoss'] = ($followersGained > 0) ? 'gain' : (($followersGained < 0) ? 'loss' : 'equal');
                                    $value1['daily_report'][$j] = $value;
                                    $weeklyReport[$i] = $value1;

                                    ++$j;
                                }

                                $totalWeeks = $i;

                                if (!($request->input('length'))) {
                                    $weeklyFollowersReport = $weeklyReport;
                                    $nextId = 0;
                                    $hasNext = false;
                                    $previousId = 0;
                                    $hasPrevious = false;
                                } else {

                                    if ($request->input('previous_id')) {
                                        $offset = ($request->input('previous_id') - $length > 0) ? $request->input('previous_id') - $length : 0;
//                                        dd($offset,$length);
                                        $weeklyFollowersReport = array_slice($weeklyReport, $offset, $length);
                                        if ($offset > 0) {
                                            $previousId = $offset;
                                            $hasPrevious = true;
                                        } else {
                                            $previousId = 0;
                                            $hasPrevious = false;
                                        }

                                    } else {
                                        $weeklyFollowersReport = array_slice($weeklyReport, $start, $length);
                                        if ($request->input('next_id')) {
                                            $previousId = intval($request->input('next_id'));
                                            $hasPrevious = true;

                                        } else {
                                            $previousId = 0;
                                            $hasPrevious = false;
                                        }
                                    }

                                    if ($start + $length < $totalWeeks + 1) {
                                        $nextId = $start + count($weeklyFollowersReport);
                                        $hasNext = true;
                                    } else {
                                        $nextId = 0;
                                        $hasNext = false;
                                    }
                                }

                                http_response_code(200);
                                echo json_encode(['code' => 200, 'message' => 'Followers report on ' . $request['basis'] . ' basis', 'error' => null, 'next_id' => $nextId, 'has_next' => $hasNext, 'previous_id' => $previousId, 'has_previous' => $hasPrevious, 'data' => $weeklyFollowersReport]);
                                die;

                            } else
                                apiResponse(402, 'Please wait for data update. ', 'kindly wait, we are updating the data', null);
                            break;

                        case 'monthly':
                            $followersReport = json_decode($userDetails[0]['followers_count_daily'], true);
                            if (!empty($followersReport)) {

                                $monthlyReport = [];
                                $i = 0;
                                $j = 0;
                                $followersGained = 0;
                                $value1 = [];
                                $value1['month'] = '';
                                $value1['avg_followers_gained'] = 0;
                                $value1['avg_gainOrLoss'] = '';
                                $value1['daily_report'] = [];

                                $months = array_unique(array_map(function ($f) {
                                    return date('M', $f['time']);
                                }, $followersReport));
                                $month = $months[0];

                                foreach (($followersReport) as $key => $value) {

                                    if (in_array($key, array_keys($months)) && $key != 0) {
                                        $i++;
                                        $followersGained = 0;
                                        $j = 0;
                                        $value1 = [];
                                        $value1['month'] = '';
                                        $value1['avg_followers_gained'] = 0;
                                        $value1['avg_gainOrLoss'] = '';
                                        $value1['daily_report'] = [];
                                        $month = $months[$key];
                                    }

                                    $followersGained += $value['followers_gained'];

                                    $value1['month'] = isset($month) ? $month : date('M', $value['time']);
                                    $value1['avg_followers_gained'] = $followersGained;
                                    $value1['avg_gainOrLoss'] = ($followersGained > 0) ? 'gain' : (($followersGained < 0) ? 'loss' : 'equal');
                                    $value1['daily_report'][$j] = $value;
                                    $monthlyReport[$i] = $value1;

                                    ++$j;
                                }

                                $totalMonths = $i;

                                if (!($request->input('length'))) {
                                    $weeklyFollowersReport = $monthlyReport;
                                    $nextId = 0;
                                    $hasNext = false;
                                    $previousId = 0;
                                    $hasPrevious = false;
                                } else {

                                    if ($request->input('previous_id')) {
                                        $offset = ($request->input('previous_id') - $length > 0) ? $request->input('previous_id') - $length : 0;
                                        $weeklyFollowersReport = array_slice($monthlyReport, $offset, $length);
                                        if ($offset > 0) {
                                            $previousId = $offset;
                                            $hasPrevious = true;
                                        } else {
                                            $previousId = 0;
                                            $hasPrevious = false;
                                        }
                                    } else {
                                        $weeklyFollowersReport = array_slice($monthlyReport, $start, $length);
                                        if ($request->input('next_id')) {
                                            $previousId = intval($request->input('next_id'));
                                            $hasPrevious = true;

                                        } else {
                                            $previousId = 0;
                                            $hasPrevious = false;
                                        }
                                    }

                                    if ($start + $length < $totalMonths + 1) {
                                        $nextId = $start + count($weeklyFollowersReport);
                                        $hasNext = true;
                                    } else {
                                        $nextId = 0;
                                        $hasNext = false;
                                    }
                                }

                                http_response_code(200);
                                echo json_encode(['code' => 200, 'message' => 'Followers report on ' . $request['basis'] . ' basis', 'error' => null, 'next_id' => $nextId, 'has_next' => $hasNext, 'previous_id' => $previousId, 'has_previous' => $hasPrevious, 'data' => $weeklyFollowersReport]);
                                die;

                            } else
                                apiResponse(402, 'Please wait for data update. ', 'kindly wait, we are updating the data', null);
                            break;

                        default:
                            apiResponse(200, 'Please provide correct basis', 'wrong basis', null);
                            break;

                    }
                } else {
                    apiResponse(400, 'account_token is not valid, reconnect account.', 'invalid token', null);
                }
            } else {
                apiResponse(400, 'account_token is required.', 'account_token is missing', null);
            }


        } else {
            $errMsg = json_decode($validator->messages(), true);
            apiResponse(412, 'Validation error', $errMsg[array_keys($errMsg)[0]][0], null);
        }

    }

    public function getFollowingsProgress(Request $request)
    {
        if (!empty($request->input('account_token'))) {
            if (array_key_exists('ins_user_id', parseAccessToken($request['account_token']))) {

                $accountDetails = parseAccessToken($request['account_token']);
                $objInstaUser = InstagramUsers::getInstance();

                $userDetails = $objInstaUser->getInstaUsersWithMetaDetails(['rawQuery' => 'insta_users.ins_user_id = ?', 'bindParams' => [$accountDetails['ins_user_id']]], ['insta_users_meta.*', 'insta_users.username']);

                if (empty($userDetails) || (!empty($userDetails) && $userDetails[0]['followings_count_daily'] == null)) {
                    apiResponse(402, 'Please wait for data update. ', 'kindly wait, we are updating the data', null);
                }


                $start = ($request->input('next_id')) ? abs($request->input('next_id')) : 0;
                $length = ($request->input('length')) ? abs($request->input('length')) : 7;

                $followingsDetails = json_decode($userDetails[0]['followings_count_daily'], true);

                if ($followingsDetails == null) {
                    apiResponse(400, 'Something went wrong, please try after sometime ', 'wrong json format', null);
                }

                foreach ($followingsDetails as $key => $f) {
                    $followingsDetails[$key]['date'] = date('d M Y', $f['time']);
                }

                if (!($request->input('length'))) {
                    $dailyFollowersReport = $followingsDetails;
                    $nextId = 0;
                    $hasNext = false;
                } else {
                    $dailyFollowersReport = array_slice($followingsDetails, $start, $length);
                    if ($start + $length < count($followingsDetails)) {
                        $nextId = $start + count($dailyFollowersReport);
                        $hasNext = true;
                    } else {
                        $nextId = 0;
                        $hasNext = false;
                    }
                }

                http_response_code(200);
                echo json_encode(['code' => 200, 'message' => 'Followings report', 'error' => null, 'next_id' => $nextId, 'has_next' => $hasNext, 'data' => $dailyFollowersReport]);
                die;
            } else {
                apiResponse(400, 'account_token is not valid, reconnect account.', 'invalid token', null);
            }
        } else {
            apiResponse(400, 'account_token is required.', 'account_token is missing', null);
        }
    }

    public function getStatsLikesDetails(Request $request)
    {
        if (!empty($request->input('account_token'))) {
            if (array_key_exists('ins_user_id', parseAccessToken($request['account_token']))) {

                $accountDetails = parseAccessToken($request['account_token']);

                $instaUser = InstagramUsers::getInstance();
                $where = ['rawQuery' => 'insta_users_meta.ins_user_id=?', 'bindParams' => [$accountDetails['ins_user_id']]];
                $selectCols = ['insta_users_meta.*', 'insta_users.*'];
                $instaUserDetails = $instaUser->getInstaUsersWithMetaDetails($where, $selectCols);

                if (empty($userDetails) || (!empty($userDetails) && $instaUserDetails[0]['likes_stats'] == null)) {
                    apiResponse(400, 'Please wait for data update. ', 'kindly wait, we are updating the data', null);
                } else {
                    apiResponse(200, 'Likes stats details', null, json_decode($instaUserDetails[0]['likes_stats'], true));
                }

//                return ($instaUserDetails);
            } else {
                apiResponse(400, 'account_token is not valid, reconnect account.', 'invalid token', null);
            }
        } else {
            apiResponse(400, 'account_token is required.', 'account_token is missing', null);
        }
    }

    public function getLikesStats(Request $request)
    {

        if (!empty($request->input('account_token'))) {
            if (array_key_exists('ins_user_id', parseAccessToken($request['account_token']))) {

                $accountDetails = parseAccessToken($request['account_token']);
                $objInstaUser = InstagramUsers::getInstance();
                $instagramWeb = InstagramWeb::getInstance();
                $ObjInstagram_acount = new Instagram_accounts();


                $userDetails = $objInstaUser->getInstaUsersWithMetaDetails(['rawQuery' => 'insta_users.ins_user_id = ?', 'bindParams' => [$accountDetails['ins_user_id']]], ['insta_users_meta.*', 'insta_users.username', 'insta_users.id']);
                if (count($userDetails) > 0) {
                    if ($userDetails[0]['likes_stats'] == null) {
                        apiResponse(402, 'Please wait for data update. ', 'kindly wait, we are updating the data', null);
                    }

                    $likesStats = json_decode($userDetails[0]['likes_stats'], true);

                    if ($likesStats == null) {
                        apiResponse(400, 'Something went wrong, please try after sometime ', 'wrong json format', null);
                    }
                    $user = $ObjInstagram_acount->getrandomInsaAccount();
                    $proxy = [
                        'proxy_username' => $user[0]->proxy_username,
                        'proxy_password' => $user[0]->proxy_password,
                        'proxy_ip' => $user[0]->proxy_ip,
                        'proxy_port' => $user[0]->proxy_port
                    ];


                    $mediaDetails = $instagramWeb->getMediaDetails($userDetails[0]['id'], $userDetails[0]['username'], $user[0]->account_session_details, $user[0]->account_browser_details, $proxy, 9, $request->input('end_cursor'));

                    $likesStatsReport = [];
                    if (isset($mediaDetails->media_data)) {
                        foreach ($mediaDetails->media_data as $key => $media) {

//                        $followersDetails = $instagramWeb->getFollowerDetails($userDetails[0]['id'], $userDetails[0]['username'], $userDetails[0]['session_details'], $userDetails[0]['browser_details']);
//                        $followers = [];
//                        foreach ($followersDetails as $followersDetail) {
//                            array_push($followers, $followersDetail['username']);
//                        }
//
//                        $likers = $instagramWeb->getLikers($userDetails[0]['username'], $userDetails[0]['session_details'], $userDetails[0]['browser_details'], 50, $media['shortcode']);
//
//                        $totalLikes = $likers['data']['shortcode_media']['edge_liked_by']['count'];
//                        $likersUsername = [];
//                        foreach ($likers['data']['shortcode_media']['edge_liked_by']['edges'] as $lik) {
//                            array_push($likersUsername, $lik['node']['username']);
//                        }
//                        $FollowersLikeCount = 0;
//                        foreach ($followers as $followersname) {
//                            if (in_array($followersname, $likersUsername)) {
//                                $FollowersLikeCount++;
//                            }
//                        }


                            if (array_key_exists($media['shortcode'], $likesStats)) {
                                $likesStatsReport['media_data'][$key] = $media;
                                $likesStatsReport['media_data'][$key]['stats_report'] = true;
                                $likesStatsReport['media_data'][$key]['stats_details'] = $likesStats[$media['shortcode']];
//                            $likesStatsReport['media_data'][$key]['totalLikes'] = $totalLikes;
//                            $likesStatsReport['media_data'][$key]['likesByFollowersCount'] = $FollowersLikeCount;
//                            $likesStatsReport['media_data'][$key]['likesByNonFollowersCount'] = $totalLikes - $FollowersLikeCount;

                            } else {
                                $likesStatsReport['media_data'][$key] = $media;
                                $likesStatsReport['media_data'][$key]['stats_report'] = false;
//                            $likesStatsReport['media_data'][$key]['totalLikes'] = $totalLikes;
//                            $likesStatsReport['media_data'][$key]['likesByFollowersCount'] = $FollowersLikeCount;
//                            $likesStatsReport['media_data'][$key]['likesByNonFollowersCount'] = $totalLikes - $FollowersLikeCount;
                            }

                        }


                        if (!empty($likesStatsReport)) {
                            if (isset($mediaDetails->page_info)) $likesStatsReport['page_info'] = $mediaDetails->page_info;


                            apiResponse(200, 'Likes stats report', null, $likesStatsReport);
                        } else {
                            apiResponse(400, 'Something went wrong, please try again after sometime.', 'error in fetching media details.', null);
                        }
                    } else {
                        apiResponse(400, 'Something went wrong, please try again after sometime.', 'error in fetching media details.', null);
                    }
                } else {
                    apiResponse(400, 'Something went wrong, please try again after sometime.', 'error in fetching media details.', null);
                }
            } else {
                apiResponse(400, 'account_token is not valid, reconnect account.', 'invalid token', null);
            }
        } else {
            apiResponse(400, 'account_token is required.', 'account_token is missing', null);
        }
    }

//    public function getLikesStats(Request $request)
//    {
//        if (!empty($request->input('account_token'))) {
//            if (array_key_exists('ins_user_id', parseAccessToken($request['account_token']))) {
//
//                $accountDetails = parseAccessToken($request['account_token']);
//                $objInstaUser = InstagramUsers::getInstance();
//                $instagramWeb = InstagramWeb::getInstance();
//
//                $userDetails = $objInstaUser->getInstaUsersWithMetaDetails(['rawQuery' => 'insta_users.ins_user_id = ?', 'bindParams' => [$accountDetails['ins_user_id']]], ['insta_users_meta.*', 'insta_users.username', 'insta_users.id', 'insta_users.session_details', 'insta_users.browser_details']);
//                if ($userDetails[0]['likes_stats'] == null) {
//                    apiResponse(400, 'Please wait for data update. ', 'kindly wait, we are updating the data', null);
//                }
//
//                $likesStats = json_decode($userDetails[0]['likes_stats'], true);
//
//
//                if ($likesStats == null) {
//                    apiResponse(400, 'Something went wrong, please try after sometime ', 'wrong json format', null);
//                }
//                $mediaDetails = $instagramWeb->getMediaDetails($userDetails[0]['id'], $userDetails[0]['username'], $userDetails[0]['session_details'], $userDetails[0]['browser_details'], 12);
//
//                $likesStatsReport = [];
//                foreach ($mediaDetails->media_data as $key => $media) {
//
//                    $followersDetails = $instagramWeb->getFollowerDetails($userDetails[0]['id'], $userDetails[0]['username'], $userDetails[0]['session_details'], $userDetails[0]['browser_details']);
//                    $followers = [];
//                    foreach ($followersDetails as $followersDetail) {
//                        array_push($followers, $followersDetail['username']);
//                    }
//
//
//                    $likers = $instagramWeb->getLikers($userDetails[0]['username'], $userDetails[0]['session_details'], $userDetails[0]['browser_details'], 50, $media['shortcode']);
//
//                    $totalLikes = $likers['data']['shortcode_media']['edge_liked_by']['count'];
//                    $likersUsername = [];
//                    foreach ($likers['data']['shortcode_media']['edge_liked_by']['edges'] as $lik) {
//                        array_push($likersUsername, $lik['node']['username']);
//                    }
//                    $FollowersLikeCount = 0;
//                    foreach ($followers as $followersname) {
//                        if (in_array($followersname, $likersUsername)) {
//                            $FollowersLikeCount++;
//                        }
//                    }
//
//                    if (array_key_exists($media['shortcode'], $likesStats)) {
//                        $likesStatsReport[$key] = $media;
//                        $likesStatsReport[$key]['stats_report'] = true;
//                        $likesStatsReport[$key]['stats_details'] = $likesStats[$media['shortcode']];
//                        $likesStatsReport[$key]['totalLikes'] = $totalLikes;
//                        $likesStatsReport[$key]['likesByFollowersCount'] = $FollowersLikeCount;
//                        $likesStatsReport[$key]['likesByNonFollowersCount'] = $totalLikes - $FollowersLikeCount;
//
//
//                    } else {
//                        $likesStatsReport[$key] = $media;
//                        $likesStatsReport[$key]['stats_report'] = false;
//                        $likesStatsReport[$key]['totalLikes'] = $totalLikes;
//                        $likesStatsReport[$key]['likesByFollowersCount'] = $FollowersLikeCount;
//                        $likesStatsReport[$key]['likesByNonFollowersCount'] = $totalLikes - $FollowersLikeCount;
//                    }
//
//                }
//                if (!empty($likesStatsReport)) {
//                    apiResponse(200, 'Likes stats report', null, $likesStatsReport);
//                } else {
//                    apiResponse(400, 'Something went wrong, please try again after sometime.', 'error in fetching media details.', null);
//                }
//
//
//            } else {
//                apiResponse(400, 'account_token is not valid, reconnect account.', 'invalid token', null);
//            }
//        } else {
//            apiResponse(400, 'account_token is required.', 'account_token is missing', null);
//        }
//    }


    public function deleteAccount(Request $request)
    {
        if (!empty($request->input('account_token'))) {
            if (array_key_exists('ins_user_id', parseAccessToken($request['account_token']))) {
                $accountDetails = parseAccessToken($request['account_token']);
                $objInstaUser = InstagramUsers::getInstance();


                $userDetails = $objInstaUser->getInstaUsersWithMetaDetails(['rawQuery' => 'insta_users.ins_user_id = ?', 'bindParams' => [$accountDetails['ins_user_id']]], ['insta_users_meta.*', 'insta_users.username']);


                if (!empty($userDetails)) {
                    $deleted = $objInstaUser->deleteInstaUsersWithMetaDetails(['rawQuery' => 'insta_users.ins_user_id = ?', 'bindParams' => [$accountDetails['ins_user_id']]]);

                    if ($deleted)
                        apiResponse(200, $accountDetails['username'] . ' records has been removed successfully.', null, null);
                    else
                        apiResponse(200, 'Something went wrong, please try after sometime.', 'error in deletion.', null);
                } else {
                    apiResponse(200, 'No records found for ' . $accountDetails['username'], 'already removed.', null);
                }

            } else {
                apiResponse(400, 'account_token is not valid, reconnect account.', 'invalid token', null);
            }
        } else {
            apiResponse(400, 'account_token is required.', 'account_token is missing', null);
        }
    }

    public function getFollowerNonfolllowersLikers(Request $request)
    {
        if (!empty($request->input('account_token'))) {
            if (array_key_exists('ins_user_id', parseAccessToken($request['account_token']))) {

                $accountDetails = parseAccessToken($request['account_token']);
                $objInstaUser = InstagramUsers::getInstance();
                $instagramWeb = InstagramWeb::getInstance();
                $userDetails = $objInstaUser->getInstaUsersWithMetaDetails(['rawQuery' => 'insta_users.ins_user_id = ?', 'bindParams' => [$accountDetails['ins_user_id']]], ['insta_users_meta.*', 'insta_users.username', 'insta_users.id', 'insta_users.session_details', 'insta_users.browser_details']);

                $likesStats = json_decode($userDetails[0]['likes_stats'], true);

                if ($likesStats == null) {
                    apiResponse(400, 'Something went wrong, please try after sometime ', 'wrong json format', null);
                }


                $followersDetails = $instagramWeb->getFollowerDetails($userDetails[0]['id'], $userDetails[0]['username'], $userDetails[0]['session_details'], $userDetails[0]['browser_details']);
                $followers = [];
                foreach ($followersDetails as $followersDetail) {
                    array_push($followers, $followersDetail['username']);
                }

                $allData = [];
                try {

                    foreach ($likesStats as $shortcutKey => $instaUserDetail) {
                        $likers = $instagramWeb->getLikers($userDetails[0]['username'], $userDetails[0]['session_details'], $userDetails[0]['browser_details'], 50, $shortcutKey);
                        $totalLikes = $likers['data']['shortcode_media']['edge_liked_by']['count'];
                        $likersUsername = [];
                        foreach ($likers['data']['shortcode_media']['edge_liked_by']['edges'] as $lik) {
                            array_push($likersUsername, $lik['node']['username']);
                        }

                        $FollowersLikeCount = 0;
                        foreach ($followers as $followersname) {
                            if (in_array($followersname, $likersUsername)) {
                                $FollowersLikeCount++;
                            }
                        }
                        $singleData = ['shortCutCode' => $shortcutKey, 'totalLikes' => $totalLikes, 'likesByFollowersCount' => $FollowersLikeCount, 'likesByNonFollowersCount' => $totalLikes - $FollowersLikeCount];
                        array_push($allData, $singleData);

//                        $allData->$shortcutKey = ['totalLikes' => $totalLikes, 'likesByFollowersCount' => $FollowersLikeCount, 'likesByNonFollowersCount' => $totalLikes - $FollowersLikeCount];
                    }
                    apiResponse(200, 'Like count details', null, $allData);

                } catch (\ErrorException $exception) {
                    apiResponse(400, 'something went wrong ', 'please try again', null);
                }
            } else {
                apiResponse(400, 'account_token is not valid, reconnect account.', 'invalid token', null);
            }
        } else {
            apiResponse(400, 'account_token is required.', 'account_token is missing', null);
        }
    }

//    public function geTtopLikersDetails(Request $request)
//    {
//        if (!empty($request->input('account_token'))) {
//            if (array_key_exists('ins_user_id', parseAccessToken($request['account_token']))) {
//
//
//                $dfd = '{"ludwig_vielerlive.de":{"TotalCountLikes":4,"LikedMedia":[{"Thumnail":"https:\/\/instagram.fbom6-1.fna.fbcdn.net\/vp\/fc5c5ee827625887c340da430a72695b\/5B85DA04\/t51.2885-15\/s640x640\/sh0.08\/e35\/30958443_1521587724634133_5046651405331333120_n.jpg?ig_cache_key=MTc2NjY3MjQwODAxOTg3MTEzNw%3D%3D.2","ShortCutCode":"BiEezHigiWh","like_count":3,"is_video":false,"comment_count":0},{"Thumnail":"https:\/\/instagram.fbom6-1.fna.fbcdn.net\/vp\/434bf90aa2f315b7273bc703de2206c4\/5B90040D\/t51.2885-15\/s640x640\/sh0.08\/e35\/30945214_1530998733693449_9047873213509402624_n.jpg?ig_cache_key=MTc2NjU0NTAwMDExMzUwOTM2Mg%3D%3D.2","ShortCutCode":"BiEB1FrghPy","like_count":3,"is_video":false,"comment_count":0},{"Thumnail":"https:\/\/instagram.fbom6-1.fna.fbcdn.net\/vp\/9a6289989adda93b275e3a43eba3c70c\/5BC13F4D\/t51.2885-15\/s640x640\/sh0.08\/e35\/30829976_1817856965175835_8304368302457618432_n.jpg?ig_cache_key=MTc2NjAwOTY2Mzc2MzA0NDQ2OA%3D%3D.2","ShortCutCode":"BiCIG62gNh0","like_count":2,"is_video":false,"comment_count":1},{"Thumnail":"https:\/\/instagram.fbom6-1.fna.fbcdn.net\/vp\/e476439eca129985f44f411fde3b4ad4\/5B9F1365\/t51.2885-15\/s640x640\/sh0.08\/e35\/30593619_238159220256325_4571863944947302400_n.jpg?ig_cache_key=MTU4MzEzOTg0MDE5NDg0NDk0Nw%3D%3D.2","ShortCutCode":"BX4cUv8lRkT","like_count":4,"is_video":false,"comment_count":0}],"profilePicUrl":"https:\/\/instagram.fbom6-1.fna.fbcdn.net\/vp\/ee2f91574dd8a9a445ff30e26513c0ee\/5B82CA4D\/t51.2885-19\/s150x150\/20479155_257425301416529_6403031716977442816_a.jpg"},"ort_13":{"TotalCountLikes":3,"LikedMedia":[{"Thumnail":"https:\/\/instagram.fbom6-1.fna.fbcdn.net\/vp\/647374582031a82eec6ef5ea2ef20131\/5B89BD70\/t51.2885-15\/s640x640\/sh0.08\/e35\/c0.63.1080.1080\/30841398_1807832329520992_1141330405782192128_n.jpg?ig_cache_key=MTcyODg4NDE3MzQ0Njc2NDUwNg%3D%3D.2.c","ShortCutCode":"Bf-Ov7oFtfa","like_count":5,"is_video":false,"comment_count":1},{"Thumnail":"https:\/\/instagram.fbom6-1.fna.fbcdn.net\/vp\/e476439eca129985f44f411fde3b4ad4\/5B9F1365\/t51.2885-15\/s640x640\/sh0.08\/e35\/30593619_238159220256325_4571863944947302400_n.jpg?ig_cache_key=MTU4MzEzOTg0MDE5NDg0NDk0Nw%3D%3D.2","ShortCutCode":"BX4cUv8lRkT","like_count":4,"is_video":false,"comment_count":0},{"Thumnail":"https:\/\/instagram.fbom6-1.fna.fbcdn.net\/vp\/2c7a3bfaccb31cebdba9d4540c6d82df\/5B84C555\/t51.2885-15\/s640x640\/sh0.08\/e35\/30593662_100411737492435_3341854666504798208_n.jpg?ig_cache_key=MTU4MzEzOTczMzAxMzU0MDkwNw%3D%3D.2","ShortCutCode":"BX4cTMIFDAr","like_count":4,"is_video":false,"comment_count":0}],"profilePicUrl":"https:\/\/instagram.fbom6-1.fna.fbcdn.net\/vp\/0d6a8b2f6069f15f66e44ff93a7fda22\/5B945C9D\/t51.2885-19\/s150x150\/20688299_747282032146188_8700501322375364608_a.jpg"},"hockeychicchelle":{"TotalCountLikes":2,"LikedMedia":[{"Thumnail":"https:\/\/instagram.fbom6-1.fna.fbcdn.net\/vp\/fc5c5ee827625887c340da430a72695b\/5B85DA04\/t51.2885-15\/s640x640\/sh0.08\/e35\/30958443_1521587724634133_5046651405331333120_n.jpg?ig_cache_key=MTc2NjY3MjQwODAxOTg3MTEzNw%3D%3D.2","ShortCutCode":"BiEezHigiWh","like_count":3,"is_video":false,"comment_count":0},{"Thumnail":"https:\/\/instagram.fbom6-1.fna.fbcdn.net\/vp\/434bf90aa2f315b7273bc703de2206c4\/5B90040D\/t51.2885-15\/s640x640\/sh0.08\/e35\/30945214_1530998733693449_9047873213509402624_n.jpg?ig_cache_key=MTc2NjU0NTAwMDExMzUwOTM2Mg%3D%3D.2","ShortCutCode":"BiEB1FrghPy","like_count":3,"is_video":false,"comment_count":0}],"profilePicUrl":"https:\/\/instagram.fbom6-1.fna.fbcdn.net\/vp\/40fa453f7a2ba47c09876325d04dbab9\/5B90CAFD\/t51.2885-19\/s150x150\/20482247_1765856566788270_4260402829425901568_a.jpg"},"barber_hadi_kurd":{"TotalCountLikes":2,"LikedMedia":[{"Thumnail":"https:\/\/instagram.fbom6-1.fna.fbcdn.net\/vp\/fc5c5ee827625887c340da430a72695b\/5B85DA04\/t51.2885-15\/s640x640\/sh0.08\/e35\/30958443_1521587724634133_5046651405331333120_n.jpg?ig_cache_key=MTc2NjY3MjQwODAxOTg3MTEzNw%3D%3D.2","ShortCutCode":"BiEezHigiWh","like_count":3,"is_video":false,"comment_count":0},{"Thumnail":"https:\/\/instagram.fbom6-1.fna.fbcdn.net\/vp\/434bf90aa2f315b7273bc703de2206c4\/5B90040D\/t51.2885-15\/s640x640\/sh0.08\/e35\/30945214_1530998733693449_9047873213509402624_n.jpg?ig_cache_key=MTc2NjU0NTAwMDExMzUwOTM2Mg%3D%3D.2","ShortCutCode":"BiEB1FrghPy","like_count":3,"is_video":false,"comment_count":0}],"profilePicUrl":"https:\/\/instagram.fbom6-1.fna.fbcdn.net\/vp\/027bc1aeb300ac29b5b3f7f1b8ef6244\/5B8CCDA7\/t51.2885-19\/s150x150\/29716350_427252481033020_3251902688228540416_n.jpg"},"harol.ticbasti":{"TotalCountLikes":2,"LikedMedia":[{"Thumnail":"https:\/\/instagram.fbom6-1.fna.fbcdn.net\/vp\/647374582031a82eec6ef5ea2ef20131\/5B89BD70\/t51.2885-15\/s640x640\/sh0.08\/e35\/c0.63.1080.1080\/30841398_1807832329520992_1141330405782192128_n.jpg?ig_cache_key=MTcyODg4NDE3MzQ0Njc2NDUwNg%3D%3D.2.c","ShortCutCode":"Bf-Ov7oFtfa","like_count":5,"is_video":false,"comment_count":1},{"Thumnail":"https:\/\/instagram.fbom6-1.fna.fbcdn.net\/vp\/e476439eca129985f44f411fde3b4ad4\/5B9F1365\/t51.2885-15\/s640x640\/sh0.08\/e35\/30593619_238159220256325_4571863944947302400_n.jpg?ig_cache_key=MTU4MzEzOTg0MDE5NDg0NDk0Nw%3D%3D.2","ShortCutCode":"BX4cUv8lRkT","like_count":4,"is_video":false,"comment_count":0}],"profilePicUrl":"https:\/\/instagram.fbom6-1.fna.fbcdn.net\/vp\/4d516ef7b210aa758f6c855a4a4ad72d\/5B89A5FD\/t51.2885-19\/s150x150\/16789782_388629664832930_1910908431200419840_a.jpg"},"ohlinonfleek":{"TotalCountLikes":2,"LikedMedia":[{"Thumnail":"https:\/\/instagram.fbom6-1.fna.fbcdn.net\/vp\/e476439eca129985f44f411fde3b4ad4\/5B9F1365\/t51.2885-15\/s640x640\/sh0.08\/e35\/30593619_238159220256325_4571863944947302400_n.jpg?ig_cache_key=MTU4MzEzOTg0MDE5NDg0NDk0Nw%3D%3D.2","ShortCutCode":"BX4cUv8lRkT","like_count":4,"is_video":false,"comment_count":0},{"Thumnail":"https:\/\/instagram.fbom6-1.fna.fbcdn.net\/vp\/2c7a3bfaccb31cebdba9d4540c6d82df\/5B84C555\/t51.2885-15\/s640x640\/sh0.08\/e35\/30593662_100411737492435_3341854666504798208_n.jpg?ig_cache_key=MTU4MzEzOTczMzAxMzU0MDkwNw%3D%3D.2","ShortCutCode":"BX4cTMIFDAr","like_count":4,"is_video":false,"comment_count":0}],"profilePicUrl":"https:\/\/instagram.fbom6-1.fna.fbcdn.net\/vp\/613676a34e18447da421a2572edb380d\/5BA47335\/t51.2885-19\/s150x150\/26071075_138352580172545_5522564559463776256_n.jpg"},"austinanderson884":{"TotalCountLikes":1,"LikedMedia":[{"Thumnail":"https:\/\/instagram.fbom6-1.fna.fbcdn.net\/vp\/9a6289989adda93b275e3a43eba3c70c\/5BC13F4D\/t51.2885-15\/s640x640\/sh0.08\/e35\/30829976_1817856965175835_8304368302457618432_n.jpg?ig_cache_key=MTc2NjAwOTY2Mzc2MzA0NDQ2OA%3D%3D.2","ShortCutCode":"BiCIG62gNh0","like_count":2,"is_video":false,"comment_count":1}],"profilePicUrl":"https:\/\/instagram.fbom6-1.fna.fbcdn.net\/vp\/4d2185544267a95460c10e58747a359f\/5B7ED19E\/t51.2885-19\/s150x150\/30605317_166493947347036_3110082790805209088_n.jpg"},"helena_eimers_":{"TotalCountLikes":1,"LikedMedia":[{"Thumnail":"https:\/\/instagram.fbom6-1.fna.fbcdn.net\/vp\/647374582031a82eec6ef5ea2ef20131\/5B89BD70\/t51.2885-15\/s640x640\/sh0.08\/e35\/c0.63.1080.1080\/30841398_1807832329520992_1141330405782192128_n.jpg?ig_cache_key=MTcyODg4NDE3MzQ0Njc2NDUwNg%3D%3D.2.c","ShortCutCode":"Bf-Ov7oFtfa","like_count":5,"is_video":false,"comment_count":1}],"profilePicUrl":"https:\/\/instagram.fbom6-1.fna.fbcdn.net\/vp\/0c1c507bebc9bb693430d17473c44bab\/5B93B9C6\/t51.2885-19\/s150x150\/31495695_196295157671176_2883795987774570496_n.jpg"},"carinaabeya6581":{"TotalCountLikes":1,"LikedMedia":[{"Thumnail":"https:\/\/instagram.fbom6-1.fna.fbcdn.net\/vp\/647374582031a82eec6ef5ea2ef20131\/5B89BD70\/t51.2885-15\/s640x640\/sh0.08\/e35\/c0.63.1080.1080\/30841398_1807832329520992_1141330405782192128_n.jpg?ig_cache_key=MTcyODg4NDE3MzQ0Njc2NDUwNg%3D%3D.2.c","ShortCutCode":"Bf-Ov7oFtfa","like_count":5,"is_video":false,"comment_count":1}]},"dimembribesdacunha":{"TotalCountLikes":1,"LikedMedia":[{"Thumnail":"https:\/\/instagram.fbom6-1.fna.fbcdn.net\/vp\/647374582031a82eec6ef5ea2ef20131\/5B89BD70\/t51.2885-15\/s640x640\/sh0.08\/e35\/c0.63.1080.1080\/30841398_1807832329520992_1141330405782192128_n.jpg?ig_cache_key=MTcyODg4NDE3MzQ0Njc2NDUwNg%3D%3D.2.c","ShortCutCode":"Bf-Ov7oFtfa","like_count":5,"is_video":false,"comment_count":1}],"profilePicUrl":"https:\/\/instagram.fbom6-1.fna.fbcdn.net\/vp\/743aa85e7aced8aa3c1e5e2696420ecd\/5BA03D12\/t51.2885-19\/s150x150\/31043026_2118312665072397_6444663766985474048_n.jpg"},"linea_h_":{"TotalCountLikes":1,"LikedMedia":[{"Thumnail":"https:\/\/instagram.fbom6-1.fna.fbcdn.net\/vp\/2c7a3bfaccb31cebdba9d4540c6d82df\/5B84C555\/t51.2885-15\/s640x640\/sh0.08\/e35\/30593662_100411737492435_3341854666504798208_n.jpg?ig_cache_key=MTU4MzEzOTczMzAxMzU0MDkwNw%3D%3D.2","ShortCutCode":"BX4cTMIFDAr","like_count":4,"is_video":false,"comment_count":0}],"profilePicUrl":"https:\/\/instagram.fbom6-1.fna.fbcdn.net\/vp\/e795609a1d65288558b2a529616cc995\/5BBDE3E8\/t51.2885-19\/s150x150\/23101576_1065763540226700_1282941743888596992_n.jpg"},"psi_marketing":{"TotalCountLikes":1,"LikedMedia":[{"Thumnail":"https:\/\/instagram.fbom6-1.fna.fbcdn.net\/vp\/2c7a3bfaccb31cebdba9d4540c6d82df\/5B84C555\/t51.2885-15\/s640x640\/sh0.08\/e35\/30593662_100411737492435_3341854666504798208_n.jpg?ig_cache_key=MTU4MzEzOTczMzAxMzU0MDkwNw%3D%3D.2","ShortCutCode":"BX4cTMIFDAr","like_count":4,"is_video":false,"comment_count":0}],"profilePicUrl":"https:\/\/instagram.fbom6-1.fna.fbcdn.net\/vp\/ec28e08b13742e6e42562f76a48013d1\/5B8F6EFF\/t51.2885-19\/s150x150\/18644798_670695716469544_931579673517752320_a.jpg"}}';
//
//
//                $accountDetails = parseAccessToken($request['account_token']);
//                $objInstaUser = InstagramUsers::getInstance();
//                $instagramWeb = InstagramWeb::getInstance();
//                $userDetails = $objInstaUser->getInstaUsersWithMetaDetails(['rawQuery' => 'insta_users.ins_user_id = ?', 'bindParams' => [$accountDetails['ins_user_id']]], ['insta_users_meta.*', 'insta_users.username', 'insta_users.id', 'insta_users.session_details', 'insta_users.browser_details']);
//
//                $data = json_decode($userDetails[0]['top_likers_lists']);
//
//                foreach ($data as $key => $val) {
//                    $hh = $instagramWeb->instaScrapePage($key);
//
//                    if ($hh != null) $data->$key->profilePicUrl = $hh['profile_pic_url'];
//
//                    foreach ($val->LikedMedia as $keyss => $med) {
//                        $deta = $instagramWeb->instaScrapePagess($med->ShortCutCode);
//                        $data->$key->LikedMedia[$keyss]->like_count = $deta['shortcode_media']['edge_media_preview_like']['count'];
//                        $data->$key->LikedMedia[$keyss]->is_video = $deta['shortcode_media']['is_video'];
//                        $data->$key->LikedMedia[$keyss]->comment_count = $deta['shortcode_media']['edge_media_to_comment']['count'];
//                    }
//                }
//
//                $array = json_decode(json_encode(json_decode(json_encode($data))), true);
//                $dddd = array_values($array);
//                if ($userDetails[0]['top_likers_lists'] == null) {
//                    apiResponse(400, 'Please wait for data update. ', 'kindly wait, we are updating the data', null);
//                }
//                apiResponse(200, 'Top LikersDetails', 'null', $dddd);
//
//            } else {
//                apiResponse(400, 'account_token is not valid, reconnect account.', 'invalid token', null);
//            }
//        } else {
//            apiResponse(400, 'account_token is required.', 'account_token is missing', null);
//        }
//
//    }

    public function geTtopLikersDetails(Request $request)
    {
        if (!empty($request->input('account_token'))) {
            if (array_key_exists('ins_user_id', parseAccessToken($request['account_token']))) {
                $accountDetails = parseAccessToken($request['account_token']);
//                dd($accountDetails['ins_user_id']);
                $objInstaUser = InstagramUsers::getInstance();
                $userDetails = $objInstaUser->getInstaUsersWithMetaDetails(['rawQuery' => 'insta_users.ins_user_id = ?', 'bindParams' => [$accountDetails['ins_user_id']]], ['insta_users_meta.*', 'insta_users.username', 'insta_users.id']);

                try {
                    $data = json_decode($userDetails[0]['top_likers_lists']);
                    $finals = [];
                    foreach ($data as $keys => $values) {
                        $arr = [];
                        if (isset($values->profilePicUrl)) $arr['profilePicUrl'] = $values->profilePicUrl;
//                        else $arr['profilePicUrl'] = 'https://instagram.fbom6-1.fna.fbcdn.net/vp/027bc1aeb300ac29b5b3f7f1b8ef6244/5B8CCDA7/t51.2885-19/s150x150/29716350_427252481033020_3251902688228540416_n.jpg';
                        else $arr['profilePicUrl'] = 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSV-gSknP2s2Viq9vKP2xoWq2jZc1q77ydN-_so5AwjKKTsrh8-bQ';

                        if (isset($keys)) $arr['user_name'] = $keys;
                        else $arr['user_name'] = 'fun_fectory';
                        $arr ['TotalLikedMedia'] = $values->TotalCountLikes;
                        $arr ['LikedMedia'] = $values->LikedMedia;
                        array_push($finals, $arr);
                    }
                } catch (\ErrorException $e) {
                    apiResponse(402, 'Please wait for data update. ', 'kindly wait, we are updating the data', null);
                }
                apiResponse(200, 'data', 'TopLikersDetails', $finals);
            } else {
                apiResponse(400, 'account_token is not valid, reconnect account.', 'invalid token', null);
            }
        } else {
            apiResponse(400, 'account_token is required.', 'account_token is missing', null);
        }

    }

    public function unfollowAccount(Request $request)
    {
        if (!empty($request->input('account_token'))) {
            if (array_key_exists('ins_user_id', parseAccessToken($request['account_token']))) {

                if (!empty($request->input('account_id'))) {

                    $accountDetails = parseAccessToken($request['account_token']);

                    $objInstaUser = InstagramUsers::getInstance();
                    $userDetails = $objInstaUser->getInstaUsersWithMetaDetails(['rawQuery' => 'insta_users.ins_user_id = ?', 'bindParams' => [$accountDetails['ins_user_id']]], ['insta_users.username', 'insta_users.session_details', 'insta_users.browser_details', 'insta_users_meta.non_follower_list']);

                    if (!empty($userDetails)) {

                        $username = $userDetails[0]['username'];
                        $session_details = $userDetails[0]['session_details'];
                        $browser_details = $userDetails[0]['browser_details'];
                        $account_id = $request['account_id'];

                        $instagramWeb = InstagramWeb::getInstance();
                        $response = $instagramWeb->unfollowInstaAccount($account_id, $username, $session_details, $browser_details);

                        if ($response['status'] == "ok") {

                            $non_follower_list = json_decode($userDetails[0]['non_follower_list'], true);
                            foreach ($non_follower_list as $key => $val) {
                                if ($val['id'] == $account_id) {
                                    unset($non_follower_list[$key]);
                                    break;
                                }
                            }

                            $newNonFollowerLists = [];
                            foreach ($non_follower_list as $key => $val) {
                                $newNonFollowerLists[] = $val;
                            }

                            //update new follower list in insta_users_meta table
                            $dataToUpdate = ['non_followers_count' => count($newNonFollowerLists), 'non_follower_list' => json_encode($newNonFollowerLists)];
                            $updatedUsersMeta = $objInstaUser->updateInstaUsersWithMetaDetails(['rawQuery' => 'insta_users.ins_user_id = ?', 'bindParams' => [$accountDetails['ins_user_id']]], $dataToUpdate);

                            apiResponse(200, 'unfollowed account successfully.', null, null);
                        } else {
                            apiResponse(400, 'Something went wrong, please try after sometime.', 'error in doing unfollow.', null);
                        }


                    } else
                        apiResponse(400, 'User details not found.', 'invalid token, account may be deleted.', null);
                } else
                    apiResponse(400, 'Please provide the account id to unfollow the account.', 'account id is missing.', null);
            } else {
                apiResponse(400, 'account_token is not valid, reconnect account.', 'invalid token', null);
            }
        } else {
            apiResponse(400, 'account_token is required.', 'account_token is missing', null);
        }
    }

    public function getLikesStatsForsingleMedia(Request $request)
    {
        if (!empty($request->input('account_token'))) {
            if (array_key_exists('ins_user_id', parseAccessToken($request['account_token']))) {

                $validator = Validator::make($request->all(), [
                        'media_shortcode' => 'required',
                    ]
                );
                if (!$validator->fails()) {


                    $accountDetails = parseAccessToken($request['account_token']);
                    $objInstaUser = InstagramUsers::getInstance();
                    $instagramWeb = InstagramWeb::getInstance();
                    $shortcutKey = $request->input('media_shortcode');
                    try {

                        $ObjInstagram_acount = new Instagram_accounts();
                        $user = $ObjInstagram_acount->getrandomInsaAccount();
                        $proxy = [
                            'proxy_username' => $user[0]->proxy_username,
                            'proxy_password' => $user[0]->proxy_password,
                            'proxy_ip' => $user[0]->proxy_ip,
                            'proxy_port' => $user[0]->proxy_port
                        ];

                        $userDetails = $objInstaUser->getInstaUsersWithMetaDetails(['rawQuery' => 'insta_users.ins_user_id = ?', 'bindParams' => [$accountDetails['ins_user_id']]], ['insta_users_meta.*', 'insta_users.username', 'insta_users.id']);
//                    $user[0]->account_browser_details, $user[0]->account_session_details, $proxy
                        $followersDetails = $instagramWeb->getFollowerDetails($userDetails[0]['id'], $userDetails[0]['username'], $user[0]->account_session_details, $user[0]->account_browser_details, $proxy);
                        $followers = [];
                        foreach ($followersDetails as $followersDetail) {
                            array_push($followers, $followersDetail['username']);
                        }


                        $likers = $instagramWeb->getLikers($userDetails[0]['username'], $user[0]->account_session_details, $user[0]->account_browser_details, 50, $shortcutKey, $proxy);
                        $totalLikes = $likers['data']['shortcode_media']['edge_liked_by']['count'];
                        $likersUsername = [];
                        foreach ($likers['data']['shortcode_media']['edge_liked_by']['edges'] as $lik) {
                            array_push($likersUsername, $lik['node']['username']);
                        }
                        $LikesFromFollowers = 0;
                        foreach ($likersUsername as $Key => $val) {
                            if (in_array($val, $likersUsername)) $LikesFromFollowers++;
                        }
                        $data = ['totalLikes' => $totalLikes, 'likesByFollowersCount' => $LikesFromFollowers, 'likesByNonFollowersCount' => $totalLikes - $LikesFromFollowers, 'media short Key' => $shortcutKey];

                        apiResponse(200, 'Likes from followers and non followers count', null, $data);

                    } catch (\ErrorException $e) {
                        apiResponse(402, 'something went wrong..plese try again', 'please wait', null);
                    }

                } else {
                    $errMsg = json_decode($validator->messages(), true);
                    $err = '';
                    foreach ($errMsg as $key => $val) {
                        $err = $val[0];
                        break;
                    }
                    apiResponse(412, 'Validation error', $err, null);
                }
            } else {
                apiResponse(400, 'account_token is not valid, reconnect account.', 'invalid token', null);
            }
        } else {
            apiResponse(400, 'account_token is required.', 'account_token is missing', null);
        }
    }


    public function testing()
    {

        $objInstagramWeb = new InstagramWeb();
        dd($objInstagramWeb->login());

    }

    public function testNonfollowers(Request $request)
    {
        /*$objInstagramWeb = new InstagramWeb();
        $username = $request->input('username');
        $session = $request->input('session');
        $browser_details = $request->input('browser');
//        $response = $objInstagramWeb->getNonFollowerDetails('', $username, $session, $browser_details);
        $response = $objInstagramWeb->instaScrapePagess($username);
        dd($response);
        $non_followers_count = count(json_decode(json_encode($response), true));
        dd($non_followers_count);*/

        $username = $request->input('username');
        $session = $request->input('session');
        $browser_details = $request->input('browser');
        $id = $request->input('id');
        $objInstagramWeb = new InstagramWeb();
//        $objInstagramWeb->getMediaDetails($id, $username, $session, $browser_details);
        $objInstagramWeb->getInstaProfileDetails($username, $session, $browser_details);
        dd($objInstagramWeb);
    }


}
