<?php namespace App\Http\Controllers\INSTASTATS;

use App\Http\Models\User;
use App\Http\Models\Banner;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;
use Illuminate\Validation\Rule;
use Intervention\Image\Facades\Image as Image;
use Laravel\Lumen\Routing\Controller;

class UserController extends Controller
{

    protected $response;
    protected $objModelUser;
    private $imageWidth = 400, $imageHeight = 400;

    public function __construct()
    {
        $this->response = new \stdClass();
        $this->objModelUser = new User();
    }


    /**
     * @param Request $postData
     * @date 30-01-2018
     * @dev saurabh Kumar <saurabh.kumar@globussoft.com>
     */
    public function signup(Request $postData)
    {

        if ($postData->isMethod('post')) {

            $validator = Validator::make($postData->all(), [
                'username' => ['required', 'regex:/^[A-Za-z0-9._\s]+$/', 'min:4', 'max:20', Rule::unique('users')->where('status', 1)->where('registered_through', 6)], //->where('status', 1)
                'email' => ['required', 'email', 'max:200', Rule::unique('users')->where('status', 1)->where('registered_through', 6)],
                'password' => 'required|confirmed',
                'password_confirmation' => 'required|',
                'device_type' => 'required',
                'device_id' => 'required',
            ]);

            if (!$validator->fails()) {

                $emailAlreadyExists = $this->objModelUser->getUserDetail(['rawQuery' => 'email=? and registered_through=?', 'bindParams' => [$postData['email'], 6]], ['id', 'username', 'email', 'created_at']);

                $otp = $postData['otp'] = mt_rand(100000, 999999);

                if (!$emailAlreadyExists) {
                    $user = User::create([
                        'username' => $postData['username'],
                        'email' => $postData['email'],
                        'password' => Hash::make($postData['password']),
                        'role' => '1',
                        'status' => '0',
                        'registered_through' => '6', //6= for INSTASTATS users
                        'device_type' => $postData['device_type'],
                        'device_id' => $postData['device_id'],
                        'user_free_package' => 0,
                        'rated_app' => 0,
                        'activation_otp' => $otp
                    ]);
                } else {
                    $emailAlreadyExists['otp'] = $otp;
                    $this->objModelUser->updateUserDetails(['rawQuery' => 'email = ?', 'bindParams' => [$postData['email']]], ['activation_otp' => $otp]);
                }

                if (isset($user) || $emailAlreadyExists) {

                    $email = ($emailAlreadyExists) ? $emailAlreadyExists['email'] : $user->email;
                    $id = ($emailAlreadyExists) ? $emailAlreadyExists['id'] : $user->id;
                    $subject = ($emailAlreadyExists) ? 'Activate Account.' : 'Registration Successful';
                    $bodyContent = ($emailAlreadyExists) ? getTemplates('activateAccount', $emailAlreadyExists, 'INSTASTATS') : getTemplates('registration', $postData, 'INSTASTATS');

                    $mailResponse = sendEmailThroughMandrill($email, $subject, $bodyContent);

                    if ($mailResponse[0]['status'] == "sent") {
                        $msg = ($emailAlreadyExists) ? 'Your account has already been registered, please activate your account.' : 'User registration successful, please activate the account using the OTP sent in email.';
                        apiResponse(200, $msg, null, ['email' => $email]);
                    } else {
                        //Delete users when mail is not sent
                        $this->objModelUser->deleteUserDetails(['rawQuery' => 'id = ?', 'bindParams' => [$id]]);
                        apiResponse(400, 'Some error occurred in sending mail, please register again.', 'Error in sending mail.', null);
                    }
                } else
                    apiResponse(400, 'Some error occurred, try again.', 'Error in account creation.', null);

            } else {
                $errMsg = json_decode($validator->messages(), true);
                foreach ($errMsg as $key => $val) {
                    $errMsg = $val[0];
                }
                apiResponse(412, 'Validation error', $errMsg, null);
            }

        } else
            apiResponse(405, 'Method not allowed.', 'Only request through post method is allowed.', null);
    }

    public function activateAccount(Request $request)
    {
        if ($request->isMethod('post')) {
            $validator = Validator::make($request->all(), [
                'email' => 'required|exists:users',
                'otp' => 'required|numeric|min:100000|max:999999'
            ], ['otp.min' => 'Not a valid otp', 'otp.max' => 'Not a valid otp', 'otp.numeric' => 'Not a valid otp']);

            if (!$validator->fails()) {

                $result = $this->objModelUser->getUserDetail(['rawQuery' => 'email = ? ', 'bindParams' => [$request['email']]]);

                if ($result) {
                    if ($result['status'] == 0) {
                        if ($result['activation_otp'] == $request['otp']) {
                            $updated = $this->objModelUser->updateUserDetails(['rawQuery' => 'email = ?', 'bindParams' => [$request['email']]], ['status' => 1, 'activation_otp' => 0]);

                            unset($result['password']);
                            unset($result['activation_otp']);
                            unset($result['pd_reset_token']);
                            $result['iat'] = time();

                            $accessToken = generateAccessToken($result);
                            apiResponse(200, 'Account has been activated.', null, ['access_token' => $accessToken, 'id' => $result['id'], 'username' => $result['username'], 'email' => $result['email']]);

                        } else
                            apiResponse(400, 'OTP didn\'t match.', 'Wrong OTP.', null);
                    } else {
                        apiResponse(400, 'Account has already been activated, please login', null, null);
                    }
                } else
                    apiResponse(400, 'User doesn\'t exist.', 'Invalid email.', null);

            } else {
                $errMsg = json_decode($validator->messages(), true);
                foreach ($errMsg as $key => $val) {
                    $errMsg = $val[0];
                }
                apiResponse(412, 'Validation error', $errMsg, null);
            }
        } else
            apiResponse(405, 'Method not allowed.', 'Only request through post method is allowed.', null);
    }

    public function login(Request $request)
    {
        if ($request->isMethod('post')) {
            $validator = Validator::make($request->all(), [
                'emailOrUsername' => 'required|',
                'password' => 'required'
            ]);

            if (!$validator->fails()) {
                $field = 'email';
                if (strpos($request['emailOrUsername'], '@') == false) {
                    $field = 'username';
                }
                $result = $this->objModelUser->getUserDetail(['rawQuery' => $field . '= ?', 'bindParams' => [$request['emailOrUsername']]]);
                if ($result) {
                    if (Hash::check($request['password'], $result['password'])) {

                        unset($result['password']);
                        unset($result['activation_otp']);
                        unset($result['pd_reset_token']);
                        $result['iat'] = time();

                        $accessToken = generateAccessToken($result);
                        apiResponse(200, 'Login successful.', null, ['access_token' => $accessToken, 'id' => $result['id'], 'username' => $result['username'], 'email' => $result['email']]);

                    } else
                        apiResponse(400, 'You have entered wrong password.', 'invalid password.', null);

                } else {
                    apiResponse(400, 'Email or username doesn\'t exist, please check again or register.', 'email or username not exists', null);
                }


            } else {
                $errMsg = json_decode($validator->messages(), true);
                foreach ($errMsg as $key => $val) {
                    $errMsg = $val[0];
                }
                apiResponse(412, 'Validation error', $errMsg, null);
            }
        } else
            apiResponse(405, 'Method not allowed.', 'Only request through post method is allowed.', null);
    }

    public function recoverPassword(Request $request)
    {
        if ($request->isMethod('post')) {

            $validator = Validator::make($request->all(), ['email' => 'required|exists:users', 'method' => 'required']);
            if (!$validator->fails()) {

                $whereEmail = ['rawQuery' => 'email = ?', 'bindParams' => [$request['email']]];
                $userDetails = $this->objModelUser->getUserDetail($whereEmail);

                switch ($request['method']) {
                    case 'getOTP':
                        $userDetails['otp'] = mt_rand(100000, 999999);
                        $this->objModelUser->updateUserDetails($whereEmail, ['pd_reset_token' => $userDetails['otp']]);
                        $bodyContent = getTemplates('recoverPasswordOTP', $userDetails, 'INSTASTATS');
                        $mailResponse = sendEmailThroughMandrill($request['email'], 'Reset Password ', $bodyContent);

                        if ($mailResponse[0]['status'] == "sent") {
                            apiResponse(200, 'OTP has been sent to mail. Please enter the otp to confirm your identity.', null, ['email' => $request['email']]);
                        } else {
                            apiResponse(400, 'Some error occurred in sending mail, try again.', 'Error in sending mail.', null);
                        }
                        break;

                    case 'verifyOTP':
                        if ($request->input('otp')) {
                            if ($userDetails['pd_reset_token'] !== '') {
                                if ($request->input('otp') === $userDetails['pd_reset_token']) {


                                    $validator = Validator::make($request->all(), ['newPassword' => 'required|confirmed', 'newPassword_confirmation' => 'required']);
                                    if (!$validator->fails()) {

                                        if (Hash::check($request['newPassword'], $userDetails['password'])) {
                                            apiResponse('400', 'Your new password can\'t be the same as old password.', 'please provide new pwd which is not your current pwd.', null);
                                        }

                                        $updated = $this->objModelUser->updateUserDetails($whereEmail, ['password' => Hash::make($request['newPassword']), 'pd_reset_token' => '']);
                                        if ($updated) {
                                            $userDetails['password'] = $request['newPassword'];
                                            $bodyContent = getTemplates('passwordChanged', $userDetails, 'INSTASTATS');
                                            sendEmailThroughMandrill($request['email'], 'Password Changed ', $bodyContent);
                                            apiResponse(200, 'Password has been changed, login again.', null, null);
                                        }

                                    } else {
                                        $errMsg = json_decode($validator->messages(), true);
                                        foreach ($errMsg as $key => $val) {
                                            $errMsg = $val[0];
                                        }
                                        apiResponse(412, 'Validation error', $errMsg, null);
                                    }
                                } else
                                    apiResponse(400, 'OTP didn\'t match, check and enter again.', 'OTP didn\'t match.', null);
                            } else
                                apiResponse(400, 'Password has already been changed with this otp, generate new otp.', 'OTP already used.', null);
                        } else
                            apiResponse(400, 'Please provide the OTP sent to your email.', 'otp field is missing', null);
                        break;

                    default:
                        apiResponse(400, 'Please specify the correct method.', 'wrong method.', null);
                }

            } else {
                $errMsg = json_decode($validator->messages(), true);
                foreach ($errMsg as $key => $val) {
                    $errMsg = $val[0];
                }
                apiResponse(412, 'Validation error', $errMsg, null);
            }
        } else {
            apiResponse(405, 'Method not allowed.', 'Only request through post method is allowed.', null);
        }
    }

    public function resetPassword(Request $request)
    {
        if ($request->input('token')) {

            if ((time() - parseAccessToken($request['token'])['iat']) < 600) {

                $whereEmail = ['rawQuery' => 'email = ?', 'bindParams' => [parseAccessToken($request['token'])['email']]];
                $userDetails = $this->objModelUser->getUserDetail($whereEmail);

                if ($userDetails['pd_reset_token'] !== '') {

                    if (parseAccessToken($request['token'])['otp'] === $userDetails['pd_reset_token']) {
                        $validator = Validator::make($request->all(), ['newPassword' => 'required|confirmed', 'newPassword_confirmation' => 'required']);
                        if (!$validator->fails()) {

                            if (Hash::check($request['newPassword'], $userDetails['password'])) {
                                apiResponse('400', 'Your new password can\'t be the same as old password.', 'please provide new pwd which is not your current pwd.', null);
                            }

                            $updated = $this->objModelUser->updateUserDetails($whereEmail, ['password' => Hash::make($request['newPassword']), 'pd_reset_token' => '']);
                            if ($updated) {
                                $userDetails['password'] = $request['newPassword'];
                                $bodyContent = getTemplates('passwordChanged', $userDetails, 'INSTASTATS');
                                sendEmailThroughMandrill(parseAccessToken($request['token'])['email'], 'Password Changed ', $bodyContent);
                                apiResponse(200, 'Password has been changed, login again.', null, null);
                            }

                        } else {
                            $errMsg = json_decode($validator->messages(), true);
                            foreach ($errMsg as $key => $val) {
                                $errMsg = $val[0];
                            }
                            apiResponse(412, 'Validation error', $errMsg, null);
                        }
                    } else
                        apiResponse(400, 'OTP didn\'t match, check and enter again.', 'OTP didn\'t match.', null);
                } else
                    apiResponse(400, 'Password has already been changed with this otp, generate new otp.', 'OTP already used.', null);
            } else
                apiResponse(400, 'Token has been expired, please verify otp again.', 'token expired.', null);
        } else
            apiResponse(400, 'Please provide the token', 'token is missing', null);

    }

    public function getProfileDetails(Request $request)
    {
        if ($request->input('access_token')) {
            $details = parseAccessToken($request['access_token']);
            if (array_key_exists('id', $details)) {
                apiResponse(200, 'Profile details.', null, $details);
            } else
                apiResponse(400, 'Not a valid access_token.', 'invalid access_token', null);
        } else
            apiResponse(400, 'Please provide the access token.', 'access_token is missing', null);

    }

    public function updateProfile(Request $request)
    {
        if ($request->input('access_token')) {
            $accessToken = parseAccessToken($request['access_token']);

            if (array_key_exists('id', $accessToken)) {

                $postParams = $request->all();
                unset($postParams['access_token']);

                if (!empty($postParams)) {
                    $columnForUpdate = ['firstname', 'lastname', 'email', 'username', 'profile_pic'];
                    $wrongParamArr = array_diff(array_keys($postParams), $columnForUpdate);

                    if (empty($wrongParamArr)) {

                        $validator = Validator::make($postParams, [
                            'firstname' => 'regex:/^[A-Za-z\s]+$/|max:20',
                            'username' => 'regex:/^[A-Za-z0-9._\s]+$/|min:4|max:20|unique:users,id,' . $accessToken['id'],
                            'email' => 'email|max:200|unique:users,id,' . $accessToken['id'],
                        ]);

                        if (!$validator->fails()) {

                            $updated = $this->objModelUser->updateUserDetails(['rawQuery' => 'id = ?', 'bindParams' => [$accessToken['id']]], $postParams);
                            if ($updated != 2) {
                                if ($updated) {
                                    $result = $this->objModelUser->getUserDetail(['rawQuery' => 'id = ?', 'bindParams' => [$accessToken['id']]]);

                                    unset($result['password']);
                                    unset($result['activation_otp']);
                                    unset($result['pd_reset_token']);
                                    $result['iat'] = time();

                                    apiResponse(200, 'Profile updated successfully.', null, ['access_token' => generateAccessToken($result)]);
                                } else
                                    apiResponse(400, 'You have made no changes to save', 'no data to update, same contents', null);
                            } else
                                apiResponse(400, 'Something went wrong, please try after sometime.', 'error in updation.', null);
                        } else {
                            $errMsg = json_decode($validator->messages(), true);
                            foreach ($errMsg as $key => $val) {
                                $errMsg = $val[0];
                            }
                            apiResponse(412, 'Validation error', $errMsg, null);
                        }
                    } else {
                        apiResponse(400, reset($wrongParamArr) . ' is a wrong param, please correct it.', 'wrong param', null);
                    }

                } else
                    apiResponse(400, 'Please provide the params to update', 'no param passed', null);

            } else
                apiResponse(400, 'Please provide correct access_token', 'invalid access_token', null);

        } else
            apiResponse(400, 'Please provide access token.', 'access_token is missing', null);
    }

    public function updatePassword(Request $request)
    {
        if ($request->input('access_token')) {
            $accessToken = parseAccessToken($request['access_token']);

            if (array_key_exists('id', $accessToken)) {

                $validator = Validator::make($request->all(), ['currentPassword' => 'required', 'newPassword' => 'required|confirmed', 'newPassword_confirmation' => 'required']);
                if (!$validator->fails()) {

                    $userDetails = $this->objModelUser->getUserDetail(['rawQuery' => 'id = ?', 'bindParams' => [$accessToken['id']]]);

                    if (Hash::check($request['currentPassword'], $userDetails['password'])) {

                        if ($request['currentPassword'] === $request['newPassword']) {
                            apiResponse(400, 'you\'re current password and new password is same.', 'nothing to update.', null);
                        }
                        $updated = $this->objModelUser->updateUserDetails(['rawQuery' => 'id = ?', 'bindParams' => [$accessToken['id']]], ['password' => Hash::make($request['newPassword'])]);
                        if ($updated) {
                            $userDetails['password'] = $request['newPassword'];
                            $bodyContent = getTemplates('passwordChanged', $userDetails, 'INSTASTATS');
                            sendEmailThroughMandrill($userDetails['email'], 'Password Changed ', $bodyContent);
                            apiResponse(200, 'Password has been updated.', null, null);
                        }
                    } else
                        apiResponse(400, 'Current password didn\'t match.', 'wrong current password.', null);

                } else {
                    $errMsg = json_decode($validator->messages(), true);
                    foreach ($errMsg as $key => $val) {
                        $errMsg = $val[0];
                    }
                    apiResponse(412, 'Validation error', $errMsg, null);
                }

            } else
                apiResponse(400, 'Please provide correct access_token', 'invalid access_token', null);

        } else
            apiResponse(400, 'Please provide access token.', 'access_token is missing', null);


    }

    public function changeAvatar(Request $request)
    {
        if ($request->input('access_token')) {

            $tokenDetails = parseAccessToken($request['access_token']);

            if (array_key_exists('id', $tokenDetails)) {

                if ($request->hasFile('image')) {

                    $validator = Validator::make($request->all(), ['image' => 'image']);

                    if (!$validator->fails()) {

                        if ((filesize($request->file('image')) / 1024 / 1024) < 3) {

                            $destinationPath = base_path() . '/../web/public/assets/uploads/useravatar/';
                            $fileName = 'instastats_' . $tokenDetails['id'] . '_' . time() . ".jpg";
//                            File::makeDirectory($destinationPath, 0777, true, true);
                            $filePath = $destinationPath . $fileName;
                            $quality = imageQuality($request->file('image'));

                            Image::make($request->file('image'))->resize($this->imageWidth, $this->imageHeight)->save($filePath, $quality);

                            $where = [
                                'rawQuery' => 'id =?',
                                'bindParams' => [$tokenDetails['id']]
                            ];

                            $userDetails = $this->objModelUser->getUserDetail($where);

                            $updated = $this->objModelUser->updateUserDetails($where, ['profile_pic' => env('WEB_URL') . '/assets/uploads/useravatar/' . $fileName]);

                            if ($updated) {
                                if ($userDetails['profile_pic'] != '') {
                                    File::delete($userDetails['profile_pic']);
                                }

                                unset($userDetails['password']);
                                unset($userDetails['activation_otp']);
                                unset($userDetails['pd_reset_token']);
                                $userDetails['profile_pic'] = env('WEB_URL') . '/assets/uploads/useravatar/' . $fileName;
                                $userDetails['iat'] = time();

                                apiResponse(200, 'Profile pic updated successfully.', null, ['access_token' => generateAccessToken($userDetails), 'profile_pic' => env('WEB_URL') . '/assets/uploads/useravatar/' . $fileName]);

                            } else {
                                apiResponse(400, 'Something went wrong, please try after sometime.', 'error in updation', null);
                            }

                        } else
                            apiResponse(400, 'Image should be lesser than 3 mb', 'size exceeded', null);

                    } else
                        apiResponse(412, 'Validation error', json_decode($validator->messages(), true), null);
                } else
                    apiResponse(400, 'Request doesn\'t have image.', 'image is missing.', null);

            } else
                apiResponse(400, 'Not a valid access_token', 'invalid access_token', null);

        } else
            apiResponse(400, 'Please provide the correct access_token', 'access_token is missing.', null);

    }

    
    /**
     * @Desc:getBannerApp
     * @param Request $request
     * @since   11 may  2018
     * @author Monali Samal (monalisamal@globussoft.in)
     */
    public  function  getBanner(Request $request){

        if ($request->isMethod('post')) {
            $objectModalImage = new Banner();

            $whereForUpdate = ['rawQuery' =>'banner_device = ? and banner_for =?', 'bindParams' => [$request->input('device_type'),$request->input('banner_for')]];

            $bannerDetails = $objectModalImage->getOneBannerDetails($whereForUpdate);

            $bannerDetails = json_decode(json_encode($bannerDetails), true);

            if ($bannerDetails)
                apiResponse(200, 'Banner details', null, ['banner_image' => env('WEB_URL') . $bannerDetails['banner_image'], 'banner_url' => $bannerDetails['banner_url']]);
            else
                apiResponse(400, 'Something went wrong, please try again.', 'error in fetching banner records', null);

        } else {
            apiResponse(401, 'Request not allowed, Only get request is allowed', 'method not allowed', null);
        }
        }
}