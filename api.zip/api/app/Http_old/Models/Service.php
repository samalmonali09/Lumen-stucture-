<?php

namespace App\Http\Models;

use Illuminate\Auth\Authenticatable;
use Illuminate\Support\Facades\DB;
use Laravel\Lumen\Auth\Authorizable;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Contracts\Auth\Authenticatable as AuthenticatableContract;
use Illuminate\Contracts\Auth\Access\Authorizable as AuthorizableContract;

class Service extends Model implements AuthenticatableContract, AuthorizableContract
{
    use Authenticatable, Authorizable;

    private static $_instance = null;

    public static function getInstance()
    {
        if (!is_object(self::$_instance))  //or if( is_null(self::$_instance) ) or if( self::$_instance == null )
            self::$_instance = new Service();
        return self::$_instance;
    }


    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'name', 'email',
    ];

    /**
     * The attributes excluded from the model's JSON form.
     *
     * @var array
     */
    protected $hidden = [
        'password',
    ];


    /**
     * @Desc checking user is exist or not
     * @Class getDetails
     * @param $data
     * @since 13 jan 2018
     * @author Sibasankar Bhoi (sibasankarbhoi@globussoft.in)
     */
    public function getaccountDetails($data)
    {
        try {
            if ($data) {
                echo json_encode(['code' => 200, 'status' => 'success', 'message' => 'user is exist', 'followed-by' => $data['user']['followed_by']['count'], 'followers' => $data['user']['follows']['count'], 'account-private' => $data['user']['is_private']]);
            } else {
                echo json_encode(['code' => 401, 'status' => 'false', 'message' => 'user not found', 'data' => null]);
                die;
            }
        } catch (\Exception $exc) {
            echo json_encode(['code' => 401, 'status' => 'failed', 'message' => 'user not exist', 'data' => null]);
            die;
        }
    }

    /**
     * @Desc checking free package, user can get or not
     * @Class checkfreePackage
     * @param $uesername
     * @return mixed
     * @since 17 jan 2018
     * @author Sibasankar Bhoi (sibasankarbhoi@globussoft.in)
     */
    public function checkfreePackage($uesername)
    {
        try {
            $freepackage = DB::table('users')->where('username', $uesername)->first();
            $freepackage_status = $freepackage->user_free_package;
            if ($freepackage_status == 0) {
                echo json_encode(['status' => 'success', 'code' => 200, 'message' => 'user can get free package', 'package_status' => $freepackage_status]);
            die;
            } else {
                echo json_encode(['code' => 401, 'status' => 'false', 'message' => 'user has already taken free package', 'package_status' => $freepackage_status]);
            }
        } catch (\Exception $exc) {
            echo json_encode(['code' => 401, 'status' => 'false', 'message' => 'user is not exist']);
        }
        return $freepackage;
    }


    /**
     * @Desc checking free packages after rating APP
     * @Class ratedAppfreepackage
     * @param $uesername
     * @return mixed
     * @since 17 jan 2018
     * @author Sibasankar Bhoi (sibasankarbhoi@globussoft.in)
     */
    public function ratedAppfreepackage($uesername)
    {
        try {
            $freepackage = DB::table('users')->where('username', $uesername)->first();
            $freepackage_status = $freepackage->rated_app;
            if ($freepackage_status == 1) {
                echo json_encode(['status' => 'success', 'code' => 200, 'message' => 'user can get Free package', 'package_status' => $freepackage_status]);
            } elseif ($freepackage_status == 0) {
                echo json_encode(['code' => 401, 'status' => 'false', 'message' => 'user has not rate the app', 'package_status' => $freepackage_status]);
            } else {
                echo json_encode(['code' => 401, 'status' => 'false', 'message' => 'user has already taken free package', 'package_status' => $freepackage_status]);
            }
        } catch (\Exception $exc) {
            echo json_encode(['code' => 401, 'status' => 'false', 'message' => 'user is not exist']);
        }
        return $freepackage;
    }
}
