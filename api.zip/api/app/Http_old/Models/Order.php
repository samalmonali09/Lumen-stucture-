<?php

namespace App\Http\Models;

use App\Http\Controllers\GILR\OrdersController;
use App\Http\Controllers\InstagramScrape\InstagramScrapeController;
use Illuminate\Auth\Authenticatable;
use Illuminate\Support\Facades\DB;
use Laravel\Lumen\Auth\Authorizable;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Contracts\Auth\Authenticatable as AuthenticatableContract;
use Illuminate\Contracts\Auth\Access\Authorizable as AuthorizableContract;

class Order extends Model implements AuthenticatableContract, AuthorizableContract
{
    use Authenticatable, Authorizable;

    private static $_instance = null;

    public static function getInstance()
    {
        if (!is_object(self::$_instance))  //or if( is_null(self::$_instance) ) or if( self::$_instance == null )
            self::$_instance = new Order();
        return self::$_instance;
    }


    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'name', 'email',
    ];

    /**
     * The attributes excluded from the model's JSON form.
     *
     * @var array
     */
    protected $hidden = [
        'password',
    ];


    /**
     * @Desc placing order
     * @param $order_placingArr
     * @return mixed
     * @since 20 jan 2018
     * @author Sibasankar Bhoi (sibasankarbhoi@globussoft.in)
     */
    public function placingOrder($order_placingArr)
    {
        try {
            $order_placed = DB::table('orders')->insertGetId($order_placingArr);
        } catch (\Exception $exc) {
            dd($exc->getMessage());
            echo json_encode(['code' => 401, 'status' => 'false', 'message' => 'Internal server error, order placing']);
        }
    }


    /**
     * @Desc  placing order for likes, comments, views, follows after complete transaction
     * @param $tx_id
     * @return mixed
     * @since 29 jan 2018
     * @author Sibasankar Bhoi (sibasankarbhoi@globussoft.in)
     */
    public function addOrdersLikes($tx_id)
    {
        try {

            $user_order_details = DB::table('transactions')->where('tx_id', $tx_id)->first();
            if (isset($user_order_details) && !empty($user_order_details)) {
                $check_order_place = DB::table('orders')->where('tx_id', $tx_id)->count();
                if ($check_order_place > 0) {
                    echo json_encode(['code' => 401, 'status' => 'false', 'message' => 'Order Allready Placed']);
                    die;
                } else {
                    return $user_order_details;
                }
            } else {
                echo json_encode(['code' => 401, 'status' => 'false', 'message' => 'transaction is not complete']);
                die;
            }
        } catch (Exception $exc) {
            echo json_encode(['code' => 401, 'status' => 'false', 'message' => 'Internal server error, order placing']);
            die;
        }
    }

    /**
     * @Desc users Order History
     * @param $user_id
     * @return mixed
     * @since 31 jan 2018
     * @author Sibasankar Bhoi (sibasankarbhoi@globussoft.in)
     */
    public function orderHistory($user_id)
    {
        try {
            $user_order_history = DB::table('orders')->where('user_id', $user_id)->get();

            return $user_order_history;

        } catch (\Exception $exc) {
            dd($exc->getMessage());
            die;
        }
    }

}
