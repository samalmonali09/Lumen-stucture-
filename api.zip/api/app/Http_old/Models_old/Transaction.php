<?php

namespace App\Http\Models;

use Illuminate\Auth\Authenticatable;
use Illuminate\Support\Facades\DB;
use Laravel\Lumen\Auth\Authorizable;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Contracts\Auth\Authenticatable as AuthenticatableContract;
use Illuminate\Contracts\Auth\Access\Authorizable as AuthorizableContract;

class Transaction extends Model implements AuthenticatableContract, AuthorizableContract
{
    use Authenticatable, Authorizable;

    private static $_instance = null;

    public static function getInstance()
    {
        if (!is_object(self::$_instance))  //or if( is_null(self::$_instance) ) or if( self::$_instance == null )
            self::$_instance = new Transaction();
        return self::$_instance;
    }


    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'name', 'email',
    ];

    /**
     * The attributes excluded from the model's JSON form.
     *
     * @var array
     */
    protected $hidden = [
        'password',
    ];


    /**
     * @Desc fetching Transaction History
     * @Class getDetails
     * @param $data
     * @since 13 jan 2018
     * @author Sibasankar Bhoi (sibasankarbhoi@globussoft.in)
     */
    public function transactionhistory($user_id)
    {
        try {
            $transaction_history = DB::table('transactions')->where('user_id', $user_id)->get();
            if (isset($transaction_history) && !empty($transaction_history)) {
                return $transaction_history;
            } else {
                echo json_encode(['code' => 400, 'status' => 'failed', 'message' => 'No transaction Found', 'data' => null]);
                die;
            }
        } catch (\Exception $exc) {
            echo json_encode(['code' => 401, 'status' => 'failed', 'message' => 'Internal server error, Transaction History', 'data' => $exc->getMessage()]);
            die;
        }
    }

}
