<?php

namespace App\Http\Models;

use Illuminate\Auth\Authenticatable;
use Illuminate\Contracts\Auth\Access\Authorizable as AuthorizableContract;
use Illuminate\Contracts\Auth\Authenticatable as AuthenticatableContract;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\QueryException;
use Illuminate\Support\Facades\DB;
use Laravel\Lumen\Auth\Authorizable;

class User extends Model implements AuthenticatableContract, AuthorizableContract
{
    use Authenticatable, Authorizable;
    protected $fillable = ['firstname', 'lastname', 'email', 'password', 'username', 'role', 'status', 'registered_through', 'device_type', 'device_id', 'user_free_package', 'rated_app', 'created_at', 'updated_at', 'activation_otp'];
    protected $hidden = ['password', 'pd_reset_token'];

    private static $_instance = null;

    public static function getInstance()
    {
        if (!is_object(self::$_instance))  //or if( is_null(self::$_instance) ) or if( self::$_instance == null )
            self::$_instance = new User();
        return self::$_instance;
    }


    /**
     * @Desc   Register user
     * @Class insertUserData
     * @param $userDetails
     * @return array
     * @since 11 jan 2018
     * @author Sibasankar Bhoi (sibasankarbhoi@globussoft.in)
     */
    public function insertUserData($userDetails)
    {
        try {
            $result = DB::table('users')->insertGetId($userDetails);
            if (isset($result) && !empty($result)){
                return $result;
            }
        } catch (\Exception $exc) {
            dd($exc->getMessage());
            $response = ['code' => 400, 'message' => 'Internal Server Error', 'data' => null];
        }
        return $result;
    }


    /**
     * @Desc Activation of users through OTP verification
     * @Class userActivation
     * @param $otp
     * @return mixed
     * @since 16 jan 2018
     * @author Sibasankar Bhoi (sibasankarbhoi@globussoft.in)
     */
    public function userActivation($otp, $user_id)
    {
        try {
            $verifyOtp = DB::table('users')->where('activation_otp', $otp)->first();
            if ($verifyOtp->id == $user_id) {
                $account_update = DB::table('users')->where('id', $verifyOtp->id)->update(['activation_otp' => null , 'status'=>1]);
            } else {
                echo json_encode(['status' => 'false', 'code' => 401, 'message' => 'Enter Correct user ID']);
                die;
            }
        } catch (\Exception $exc) {
            $response = ['code' => 500, 'message' => 'Internal Server Error, User Activation', 'data' => null];
        }
    }

    /**
     * @Desc  Login User
     * @param $email
     * @return mixed
     * @since 11 Dec 2017
     * @author Sibasankar Bhoi (sibasankarbhoi@globussoft.in)
     */
    public function getUserData($email)
    {
        try {
            $userdetails = DB::table('users')->where('email', $email)->first();
            if ($userdetails->activation_otp == null) {
                return $userdetails;
            } else {
                echo json_encode(['code' => 401, 'status' => 'false', 'message' => 'Please activate your account, OTP sent to your mail']);
                die;
            }
        } catch (\Exception $exc) {
            $response = ['code' => 500, 'message' => 'Internal Server Error', 'data' => null];
        }

    }


    /**
     * @Desc  verification of OTP forget password and update to null after verified
     * @Class verifyOtp
     * @param $otp
     * @return mixed
     * @since 12 Dec 2018
     * @author Sibasankar Bhoi (sibasankarbhoi@globussoft.in)
     */
    public function verifyOtp($otp, $user_id)
    {
        try {
            $verifyOtp = DB::table('users')->where('pd_reset_token', $otp)->first();
            $check_id = DB::table('users')->where('pd_reset_token', $otp)->select('id')->first()->id;
            if ($check_id == $user_id) {
                $password_update = DB::table('users')->where('id', $user_id)->update(['pd_reset_token' => 1]);
                return $check_id;
            } else {
                echo json_encode(['status' => 'false', 'code' => 401, 'message' => 'Enter Correct user ID']);
            }
        } catch (\Exception $exc) {
            echo json_encode(['status' => 'false', 'code' => 401, 'message' => 'Internal Server Error, password token verification']);
        }
    }


    /**
     * @Desc    password change after verified
     * @param $password
     * @param $user_id
     * @return mixed
     * @since 12 jan 2018
     * @author Sibasankar Bhoi (sibasankarbhoi@globussoft.in)
     */
    public function passwordChange($password, $user_id)
    {
        try {
            $passwordchange = DB::table('users')->where('id', $user_id)->update(['password' => $password]);
            return $passwordchange;

        } catch (\Exception $exc) {
            dd($exc->getMessage());
            $response = ['code' => 500, 'message' => 'Internal Server Error', 'data' => null];
        }
    }


    /**
     * @Desc   inserting OTP time of forget password
     * @Class uodateOtp
     * @param $email
     * @param $otp
     * @return mixed
     * @since 12 jan 2018
     * @author Sibasankar Bhoi (sibasankarbhoi@globussoft.in)
     */
    public function insertOtp($email, $otp)
    {
        try {
            $insertOtp = DB::table('users')->where('email', $email)->update(['pd_reset_token' => $otp]);
            $user_id = DB::table('users')->where('email', $email)->select('id')->first()->id;
        } catch (\Exception $exc) {
            echo json_encode(['status' => 'false', 'code' => 401, 'message' => 'user not found']);

        }
        return $user_id;
    }


    /**
     * @Desc  fetching media details
     * @Class getmediaDetails
     * @param $data
     * @since 16 jan 2018
     * @author Sibasankar Bhoi (sibasankarbhoi@globussoft.in)
     */
    public function getmediaDetails($data)
    {
        try {
            if ($data) {
                echo json_encode(['status' => 'success', 'code' => 200, 'message' => 'user is exist', 'followed-by' => $data['user']['followed_by']['count'], 'followers' => $data['user']['follows']['count'], 'account-private' => $data['user']['is_private']]);
                die;
                print_r($data['user']['followed_by']['count']);
                print_r($data['user']['follows']['count']);
                die;
            } else {
                echo json_encode(['status' => 'false', 'code' => 401, 'message' => 'user not found']);
                die;
            }

        } catch (\Exception $exc) {

            echo json_encode(['status' => 'failed', 'code' => 401, 'message' => 'user not exist', 'data' => null]);
            die;
        }
    }

    /**
     * @param $where
     * @return int
     * @date 10-2-2016
     * @dev saurabh Kumar <saurabh.kumar@globussoft.com>
     */
    public function deleteUserDetails($where)
    {
        $result = DB::table('users')
            ->whereRaw($where['rawQuery'], isset($where['bindParams']) ? $where['bindParams'] : array())
            ->delete();
        if ($result)
            return $result;
        else
            return 0;
    }

    public function getUserDetail($where, $selectedCols = ['*'])
    {
        try {
            $result = DB::table('users')
                ->whereRaw($where['rawQuery'], isset($where['bindParams']) ? $where['bindParams'] : array())
                ->select($selectedCols)
                ->first();
            return ($result) ? json_decode(json_encode($result), true) : 0;
        } catch (QueryException $e) {
//            echo $e->getMessage();
            return 0;
        }

    }

    public function updateUserDetails($where, $data)
    {
        try {
            $result = DB::table('users')
                ->whereRaw($where['rawQuery'], isset($where['bindParams']) ? $where['bindParams'] : array())
                ->update($data);
            return ($result) ? $result : 0;
        } catch (QueryException $e) {
//            echo $e->getMessage();
            return 0;
        }

    }

}
