<?php
$router->get('/', function () use ($router) {
    return $router->app->version();
});
//Routes for Authentication for GILR Users --Sibansankar
$router->POST('/register', 'GILR\AuthenticationController@userRegistration');
$router->POST('/user-activation', 'GILR\AuthenticationController@userActivation');
$router->POST('/login', 'GILR\AuthenticationController@userLogin');
$router->POST('/forget-password', 'GILR\AuthenticationController@forgetPassword');
$router->POST('/verify-otp', 'GILR\AuthenticationController@verifyOtp');
$router->POST('/reset-password', 'GILR\AuthenticationController@resetPassword');

$router->GET('/package-list', 'GILR\PackagesController@packageList');
$router->POST('/check-user-account', 'GILR\UserController@checkuserAccount');
$router->POST('/check-user-exist', 'GILR\UserController@usernameExist');
$router->POST('/media-details', 'GILR\UserController@getmediaDetails');               //get all media with their likes,comments,urls

$router->group(['middleware' => 'checkSession'], function () use ($router) {

    $router->POST('/ratedapp-free-package', 'GILR\UserController@ratedappPackage');  //checking status of free packages after rated APP
    $router->POST('/free-package', 'GILR\UserController@freepackage');
    $router->POST('/transaction-history', 'GILR\TransactionController@transactionHistory');
    $router->POST('/order-place', 'GILR\OrdersController@orderPlacing');
    $router->POST('/place-order', 'GILR\OrdersController@placeOrders');
    $router->POST('/order-history', 'GILR\OrdersController@orderHistory');



});