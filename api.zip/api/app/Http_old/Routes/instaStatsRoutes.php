<?php

$router->get('/instastats/test', 'InstaStats\UserController@test');