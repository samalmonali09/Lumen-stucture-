<?php
$router->get('/', function () use ($router) {
    return $router->app->version();
});

//Routes for Authentication for GIVE Users --Sibansankar

$router->post('/give/register', 'GIVE\AuthenticationController@userRegistration');
$router->POST('/give/user-activation', 'GIVE\AuthenticationController@userActivation');
$router->POST('/give/login', 'GIVE\AuthenticationController@userLogin');
$router->POST('/give/forget-password', 'GIVE\AuthenticationController@forgetPassword');
$router->POST('/give/verify-otp', 'GIVE\AuthenticationController@verifyOtp');
$router->POST('/give/reset-password', 'GIVE\AuthenticationController@resetPassword');

$router->GET('/give/package-list', 'GIVE\GivePackagesController@GivePackageList');

$router->POST('/give/check-user-account', 'GIVE\GiveUserdetailsController@checkuserAccount');
$router->POST('/give/check-user-exist', 'GIVE\GiveUserdetailsController@usernameExist');
$router->POST('/give/media-details', 'GIVE\GiveUserdetailsController@getmediaDetails');

$router->group(['middleware' => 'checkSession'], function () use ($router) {

    //Routes for GIVE
    $router->POST('/give/free-package', 'GIVE\GiveUserdetailsController@freepackage');
    $router->POST('/give/ratedapp-free-package', 'GIVE\GiveUserdetailsController@ratedappPackage');  //checking status of free packages after rated APP
    $router->POST('/give/place-order', 'GIVE\GiveOrderController@GivePlaceOrders');
    $router->POST('/give/order-history', 'GIVE\GiveOrderController@GiveorderHistory');
    $router->POST('/give/transaction-history', 'GIVE\GiveTransactionController@GiveTransactionHistory');



});