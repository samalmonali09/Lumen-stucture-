<?php
$router->get('/', function () use ($router) {
return $router->app->version();
});


//Routes for Authentication for AUTOIG Users --Saurabh
$router->post('/autoig/signup', 'AUTOIG\UserController@signup');
$router->post('/autoig/activateAccount', 'AUTOIG\UserController@activateAccount');
$router->post('/autoig/login', 'AUTOIG\UserController@login');
$router->post('/autoig/recoverPassword', 'AUTOIG\UserController@recoverPassword');