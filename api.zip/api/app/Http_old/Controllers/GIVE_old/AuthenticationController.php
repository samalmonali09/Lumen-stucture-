<?php

namespace App\Http\Controllers\GIVE;
use App\Http\Models\User;
use Firebase\JWT\JWT;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Validation\Rule;
use Laravel\Lumen\Routing\Controller as BaseController;

class AuthenticationController
{
    protected $response;
    protected $objModelUser;

    public function __construct()
    {
        $this->response = new \stdClass();
        $this->objModelUser = new User();
    }

    /**
     * @Desc  User registration
     * @Class userRegistration
     * @param Request $request
     * @since 11 jan 2018
     * @author Sibasankar Bhoi (sibasankarbhoi@globussoft.in)
     */
    public function userRegistration(Request $request)
    {

        if ($request->isMethod('post')) {


            $postData = $request->all();
            $rules = [
                'email' => [
                    'required',
                    Rule::unique('users')->ignore($postData['email'])->where(function ($query) {
                        $query->where('registered_through', 3);
                    })
                ],
                'username' => [
                    'required',
                    Rule::unique('users')->ignore($postData['username'])->where(function ($query) {
                        $query->where('registered_through', 3);
                    })
                ],
                'firstname' => 'required',
                'password' => 'required|min:5',
            ];
            $message = [
                'firstname.required' => 'Enter your  First name ',
                'username.unique' => 'This user name already has been taken. Please Enter diffrent User name  ',
                'username.required' => 'Enter Your User name  ',
                'email.required' => 'Enter your Email',
                'password.required' => 'Enter Your password',
            ];
            $response = array('response' => '', 'Success' => false);
            $validator = Validator::make($request->input(), $rules, $message);
            if ($validator->fails()) {
                return json_encode(['code' => 100, 'status' => 'Failed', 'message' => $validator->messages()]);
            } else {
                $otp = mt_rand(100000, 999999);           //create random 6 digit OTP

                $userDetails = array();
                $userDetails['firstname'] = $postData['firstname'];
                $userDetails['lastname'] = $postData['lastname'];
                $userDetails['username'] = $postData['username'];
                $userDetails['email'] = $postData['email'];
                $userDetails['password'] = Hash::make($postData['password']);
                $userDetails['role'] = 1;
                $userDetails['status'] = 0;
                $userDetails['registered_through'] = 3;
                $userDetails['device_type'] = $postData['device_type'];
                $userDetails['device_id'] = $postData['device_id'];
                $userDetails['activation_otp'] = $otp;
                $objmodeluser = User::getInstance();
                $result = $objmodeluser->insertUserData($userDetails);
                if ($result) {

                    $from = new \SendGrid\Email(null, "sibasankarbhoi@globussoft.in");
                    $subject = "This is sibasankar email service of GIVE for activating user";
                    $to = new \SendGrid\Email("Example User", $userDetails['email']);
                    $content = new \SendGrid\Content("text/html", $otp);
                    $mail = new \SendGrid\Mail($from, $subject, $to, $content);

                    $apiKey = env('SENDGRID_API_KEY');
                    $sg = new \SendGrid($apiKey);

                    $response = $sg->client->mail()->send()->post($mail);
                    return json_encode(['code' => 200, 'status' => 'Success', 'message' => 'Data inserted Sucessfully,An otp sent to your mail. please activate your account', 'user_id' => $result]);

                } else {
                    return json_encode(['code' => 401, 'status' => 'Failed', 'message' => 'Data not inserted, Error ']);

                }
            }

        } else {
            $this->apiError(401, 'Request not allowed, Only post request is allowed');
        }
    }


    /**
     * @Desc   Activation of users through OTP verification
     * @Class userActivation
     * @param Request $request
     * @since 16 jan 2018
     * @author Sibasankar Bhoi (sibasankarbhoi@globussoft.in)
     */
    public function userActivation(Request $request)
    {

        $rules = [
            'activation_otp' => 'required|exists:users,activation_otp',
        ];
        $message = [
            'activation_otp.exists' => 'Please Enter valid OTP',
            'activation_otp.required' => 'Please Enter your OTP',

        ];
        $response = array('response' => '', 'Success' => false);
        $validator = Validator::make($request->input(), $rules, $message);
        if ($validator->fails()) {
            return json_encode(['code' => 100, 'status' => 'Failed', 'message' => $validator->messages()]);
        } else {
            try {
                $user_id = $request->all()['user-id'];


                $objmodeluser = User::getInstance(); //  Activation of users through OTP verification and update to null after verified
                $verifyOtp = $objmodeluser->userActivation($request->all()['activation_otp'], $user_id);
                if ($verifyOtp) {
                    $updated = $this->objModelUser->updateUserDetails(['rawQuery' => 'id = ?', 'bindParams' => [$user_id]], ['activation_otp' => null, 'status' => 1]);

                    echo json_encode(['code' => 200, 'status' => 'Success', 'message' => 'Verifyed. You can login now', 'user-id' => $verifyOtp->id, 'registered_through' => $verifyOtp->registered_through]);
                    die;
                } else {
                    $this->apiError(100, 'Please Enter correct OTP');
                }
            } catch (\Exception $exc) {
                dd($exc->getMessage());
                return json_encode(['code' => 100, 'status' => 'false', 'message' => 'Please Enter user id']);
            }

        }

    }


    /**
     * @Desc   user login
     * @Class userLogin
     * @param Request $request
     * @since 11 jan 2018
     * @author Sibasankar Bhoi (sibasankarbhoi@globussoft.in)
     */
    public function userLogin(Request $request)
    {

        $rules = [
            'email' => 'required|exists:users,email',
            'password' => 'required',
        ];
        $message = [
            'email.required' => 'Enter your Email',
            'password.required' => 'Enter Your password',
        ];
        $response = array('response' => '', 'Success' => false);
        $validator = Validator::make($request->input(), $rules, $message);
        if ($validator->fails()) {
            return json_encode(['code' => 100, 'status' => 'Failed', 'message' => $validator->messages()]);
        } else {
            $email = $request->input('email');
            $input_password = $request->input('password');
            $register_through = 3;
            $objmodeluser = User::getInstance();              //get user data after login
            $userdetails = $objmodeluser->getUserData($email, $register_through);

            if (isset($userdetails)) {
                $password = $userdetails->password;
                if (Hash::check($input_password, $password)) {
                    $time = date('Y-m-d H:i:s');      // 2016-10-12 21:09:23
                    $email = $userdetails->email;
                    $user_id = $userdetails->id;
                    $user_name = $userdetails->username;

                    $iat = time();

                    $key = "User access token";               // create access TOKEN
                    $token = array(
                        "created_time" => $time,
                        "email" => $email,
                        "user_id" => $user_id,
                        "user_name" => $user_name,
                        "iat" => $iat,
                        "registered_through" => $register_through
                    );
                    $access_token = JWT::encode($token, $key);
                    $decoded = JWT::decode($access_token, $key, array('HS256'));     // sending user details as a TOKEN
                    return json_encode(['code' => 200, 'status' => 'Success', 'message' => 'Successfully logged in', 'register_through' => $register_through, 'access-token' => $access_token]);

                } else {
                    $this->apiError(100, 'Please Enter correct Password');
                }
            } else {
                $this->apiError(100, 'Please Enter correct Email');
            }
        }
    }




    /**
     * @Desc   forget password,  sending OTP via mail
     * @param Request $request
     * @since 12 jan 2018
     * @author Sibasankar Bhoi (sibasankarbhoi@globussoft.in)
     */
    public function forgetPassword(Request $request)
    {
        $rules = [
            'email' => 'required|email|exists:users,email',
        ];
        $message = [
            'email.exists' => 'This email is not registered, please register first'
        ];
        $validator = Validator::make($request->input(), $rules, $message);
        if ($validator->fails()) {
            return json_encode(['code' => 100, 'status' => 'Failed', 'message' => $validator->messages()]);

        } else {
            $email = $request->all()['email'];
            $otp = mt_rand(100000, 999999);                 //create random 6 digit OTP
            $user_id = DB::table('users')->where('email', $email)->where('registered_through', 3)->select('id')->first()->id;

            $updated = $this->objModelUser->updateUserDetails(['rawQuery' => 'id = ?', 'bindParams' => [$user_id]], ['pd_reset_token' => $otp]);

            if ($updated) {
                $from = new \SendGrid\Email(null, "sibasankarbhoi@globussoft.in");
                $subject = "This is sibasankar email service of give for forget password";
                $to = new \SendGrid\Email("Example User", $email);
                $content = new \SendGrid\Content("text/html", "$otp");
                $mail = new \SendGrid\Mail($from, $subject, $to, $content);
                $apiKey = env('SENDGRID_API_KEY');
                $sg = new \SendGrid($apiKey);

                $response = $sg->client->mail()->send()->post($mail);

                return json_encode(['code' => 200, 'status' => 'Success', 'message' => 'An OTP sent to your Mail , Please check your Mail', 'user_id' => $user_id]);

            } else {
                $this->apiError(100, 'Your Email is not registered, Please Registered first or Enter Correct Email');
            }
        }
    }

    /**
     * @Desc   varification of OTP in forget password
     * @param Request $request
     * @since 12 jan 2018
     * @author Sibasankar Bhoi (sibasankarbhoi@globussoft.in)
     */
    public function verifyOtp(Request $request)
    {


        $rules = [
            'pd_reset_token' => 'required|exists:users,pd_reset_token',
        ];
        $message = [
            'pd_reset_token.exists' => 'Please Enter valid OTP',
            'pd_reset_token.required' => 'Please Enter your OTP',

        ];
        $response = array('response' => '', 'Success' => false);
        $validator = Validator::make($request->input(), $rules, $message);
        if ($validator->fails()) {
            return json_encode(['code' => 100, 'status' => 'Failed', 'message' => $validator->messages()]);
        } else {
            try {
                $user_id = $request->all()['user-id'];
                $objmodeluser = User::getInstance(); //  verification of OTP forget password and update to null after verified
                $verifyOtp = $objmodeluser->verifyOtp($request->all()['pd_reset_token'], $user_id);
                if ($verifyOtp) {
                    $updated = $this->objModelUser->updateUserDetails(['rawQuery' => 'id = ?', 'bindParams' => [$user_id]], ['pd_reset_token' => null]);

                    return json_encode(['code' => 200, 'user-id' => $verifyOtp, 'status' => 'Success', 'message' => 'Verifyed. You can change Ypur Password']);
                    die;
                } else {
                    $this->apiError(100, 'Please Enter correct OTP');
                }
            } catch (\Exception $exc) {
                dd($exc->getMessage());
                echo json_encode(['status' => 'false', 'code' => 401, 'message' => 'Internal Server Error,password verification']);

            }
        }

    }


    /**
     * @Desc   Reset password
     * @param Request $request
     * @since 12 jan 2018
     * @author Sibasankar Bhoi (sibasankarbhoi@globussoft.in)
     */
    public function resetPassword(Request $request)
    {
        $rules = [
            'password' => 'required|min:5',
            'confirm_password' => 'required|same:password'
        ];
        $message = [
            'password.required' => 'Enter your New password',
            'confirm_password.required' => 'Please Confirm password',
        ];
        $response = array('response' => '', 'Success' => false);
        $validator = Validator::make($request->input(), $rules, $message);
        if ($validator->fails()) {
            $this->apiError(100, $validator->messages());


        } else {
            $user_id = $request->all()['user-id'];
            $userDetails = array();

            $userDetails['password'] = Hash::make($request->input('password'));

            $updated = $this->objModelUser->updateUserDetails(['rawQuery' => 'id = ?', 'bindParams' => [$user_id]], ['password' => $userDetails['password']]);
            if ($updated) {
                return json_encode(['code' => 200, 'status' => 'Success', 'message' => 'Your Password Changed Successfully']);
            } else {
                $this->apiError(400, 'Enter Correct user-id');
            }
        }
    }



    /**
     * @Desc   Error response Function
     * @param $code
     * @param $msg
     * @since 11 jan 2018
     * @author Sibasankar Bhoi (sibasankarbhoi@globussoft.in)
     */
    public function apiError($code, $msg)
    {
        header('Content-Type: application/json');
        http_response_code($code);
        echo json_encode(['code' => $code, 'status' => 'failed', 'message' => $msg, 'data' => null]);
        die;
    }


}


?>
