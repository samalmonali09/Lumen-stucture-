<?php

namespace App\Http\Controllers\GIVE;

use App\Http\Models\Package;
use App\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class GivePackagesController
{

    /**
     * @Desc  fetching all packages
     * @Class packageList
     * @param Request $request
     * @since 17 jan 2018
     * @author Sibasankar Bhoi (sibasankarbhoi@globussoft.in)
     */
    public function GivePackageList()
    {
        $package_for=3;      //only for GIVE
        $objmodeluser = Package::getInstance(); //  fetch all packages
        $packageList = $objmodeluser->packageList($package_for);

        $packageListArr = [];
        foreach ($packageList as $key => $list) {
    $packageListArr[$key]['package_id'] = $list->package_id;
    $packageListArr[$key]['package_name'] = $list->package_name;
    $packageListArr[$key]['package_type'] = $list->package_type;
    $packageListArr[$key]['package_status'] = $list->package_status;
    $packageListArr[$key]['package_for'] = $list->package_for;
    $packageListArr[$key]['quantity'] = $list->quantity;
    $packageListArr[$key]['price'] = $list->price;
    $packageListArr[$key]['plan_id'] = $list->plan_id;

        }
        echo json_encode([
            'code' => 200,
            'status' => 'Success',
            'message' => 'All packages fetched Succesfully',
            'data' => $packageListArr
        ]);

    }

}


