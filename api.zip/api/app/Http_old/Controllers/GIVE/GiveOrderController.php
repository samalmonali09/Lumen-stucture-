<?php

namespace App\Http\Controllers\GIVE;
use App\Http\Controllers\InstagramScrape\InstagramScrapeController;
use App\Http\Models\Order;
use App\Http\Models\User;
use Firebase\JWT\JWT;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Validation\Rule;
use Laravel\Lumen\Routing\Controller as BaseController;

class GiveOrderController
{

    /**
     * @Desc placing order
     * @param Request $request
     * @return string
     * @since 03 feb 2018
     * @author Sibasankar Bhoi (sibasankarbhoi@globussoft.in)
     */
    public function orderPlacing(Request $request)
    {
        $rules = [
            'tx_id' => 'required',
            'package_id' => 'required|exists:packages,package_id',
            'autolikes_id' => 'required',
            'subscription_id' => 'required',
            'order_url' => 'required',
        ];
        $message = [
            'tx_id.required' => 'Enter tx_id ',
            'package_id.unique' => 'enter package_id',
            'autolikes_id.required' => 'Enter autolikes_id',
            'subscription_id.required' => 'Enter subscription_id',
            'order_url.required' => 'Enter Your order_url',
        ];
        $response = array('response' => '', 'Success' => false);
        $validator = Validator::make($request->input(), $rules, $message);
        if ($validator->fails()) {
            return json_encode(['code' => 412, 'status' => 'Failed', 'message' => $validator->messages()]);
        } else {
            try {
                $access_token = $request->all()['access-token'];
                $data = $request->all();
                $packageDetails = DB::table('packages')->where('package_id', $data['package_id'])->select('quantity', 'price', 'package_type')->first();
                $key = "User access token";
                $decoded = JWT::decode($access_token, $key, array('HS256'));     //  user details as a TOKEN
                $regexr = "/^(http(s)?:\/\/)?(www\.)?((instagram)\.+)(com)(\/p\/)([a-zA-Z0-9]+\_*\-*[a-zA-Z0-9]*)(\/+)([?a-zA-Z0-9._~@,-=]*)$/";
                $urlType = (preg_match($regexr, $data['order_url'])) ? 1 : 0;

                $objInstagramScrape = new InstagramScrapeController();
                if ($urlType == 0) {
                    if ($packageDetails->package_type == 1) {      // for profile url only
                        $str = substr($data['order_url'], strpos($data['order_url'], '.com/'));
                        $substr = (substr($str, strlen('.com/')));
                        $username = rtrim($substr, '/');

                        $profile_details = $objInstagramScrape->instagramProfileDetails($username);
                        $followed_by = $profile_details['followed_by'];
                        $follows = $profile_details['follows'];
                    } else {
                        return json_encode(['code' => 401, 'status' => 'Failed', 'message' => 'please selcet correct package type']);
                    }
                } else {
                    if ($packageDetails->package_type != 1) {     //for post url only
                        $shortCode = $objInstagramScrape->extractContent($data['order_url'], '/p/', '/');
                        $post_details = $objInstagramScrape->instagramLinkDetails($shortCode);
                        $comments_count = $post_details['comments_count'];
                        $likes_count = $post_details['likes_count'];
                        $is_video = $post_details['is_video'];
                    } else {
                        return json_encode(['code' => 401, 'status' => 'Failed', 'message' => 'please selcet correct package type']);
                    }
                }
                if (preg_match("/^(http(s)?:\/\/)?(www\.)?((instagram)\.+)(com)(\/p\/)([a-zA-Z0-9]+\_*\-*[a-zA-Z0-9]*)(\/+)([?a-zA-Z0-9._~@,-=]*)$/", $data['order_url'])) {
                    $url_type = 0;
                } elseif (preg_match("/^(http(s)?:\/\/)?(www\.)?((instagram)\.+)(com)(\/)([a-zA-Z0-9._^%$#!~@,-]*)(\/*)$/", $data['order_url'])) {
                    $url_type = 1;
                } else {
                    return json_encode(['code' => 412, 'status' => 'Failed', 'message' => 'Please Enter a valid URL']);
                }
                $order_placingArr = array();
                $order_placingArr['user_id'] = $decoded->user_id;
                $order_placingArr['tx_id'] = $data['tx_id'];
                $order_placingArr['package_id'] = $data['package_id'];
                $packageDetails = DB::table('packages')->where('package_id', $data['package_id'])->select('quantity', 'price', 'package_type')->first();
                if ($packageDetails == null) {
                    return json_encode(['code' => 401, 'status' => 'Failed', 'message' => 'Package id is not found']);
                }
                $order_placingArr['autolikes_id'] = $data['autolikes_id'];
                $order_placingArr['subscription_id'] = $data['subscription_id'];
                $order_placingArr['order_url'] = $data['order_url'];
                $order_placingArr['url_type'] = $url_type;
                $order_placingArr['quantity'] = $packageDetails->quantity;
                $order_placingArr['package_type'] = $packageDetails->package_type;
                $order_placingArr['comment_id'] = $data['comment_id'];

                if (isset($data['start_time']) && !empty($data['start_time'])) {
                    $order_placingArr['start_time'] = $data['start_time'];
                } else {
                    $order_placingArr['start_time'] = time();
                }
                $order_placingArr['time_interval'] = $data['time_interval'];
                $order_placingArr['orders_per_run'] = $data['orders_per_run'];
                $order_placingArr['added_time'] = time();
                $order_placingArr['updated_time'] = time();
                $objmodeluser = Order::getInstance();
                $placing_order = $objmodeluser->placingOrder($order_placingArr);

                if ($url_type == 0) {
                    echo json_encode(['code' => 200, 'status' => 'success', 'message' => 'Oeder placed success fully', 'order_id' => $placing_order, 'likes_count' => $likes_count, 'comments_count' => $comments_count, 'is_video' => $is_video]);
                } elseif ($url_type == 1) {
                    echo json_encode(['code' => 200, 'status' => 'success', 'message' => 'Oeder placed success fully', 'order_id' => $placing_order, 'followed_by' => $followed_by, 'follows' => $follows]);
                }
            } catch (\Exception $exc) {
                dd($exc->getMessage());
                echo json_encode(['code' => 412, 'status' => 'false', 'order_id' => 'Please Enter valid Token']);
            }
        }
    }

    /**
     * @Desc place  orders for likes, comments, views, follows after transaction
     * @param Request $request
     * @since 03 feb 2018
     * @author Sibasankar Bhoi (sibasankarbhoi@globussoft.in)
     */
    public function GivePlaceOrders(Request $request)
    {
        try {
            $rules = [
                'tx_id' => 'required|exists:transactions,tx_id',
            ];
            $message = [
                'tx_id.exists' => 'This transaction is not completed'
            ];
            $validator = Validator::make($request->input(), $rules, $message);
            if ($validator->fails()) {
                return json_encode(['code' => 412, 'status' => 'Failed', 'message' => $validator->messages()]);
            } else
                $objmodeluser = Order::getInstance();
            $user_order_details = $objmodeluser->addOrdersLikes($request->all()['tx_id']);
            if (isset($user_order_details) && !empty($user_order_details)) {
                $regexr = "/^(http(s)?:\/\/)?(www\.)?((instagram)\.+)(com)(\/p\/)([a-zA-Z0-9]+\_*\-*[a-zA-Z0-9]*)(\/+)([?a-zA-Z0-9._~@,-=]*)$/";
                $urlType = (preg_match($regexr, $user_order_details->order_url)) ? 1 : 0;   // validating url type
                $objInstagramScrape = new InstagramScrapeController();

                $objplaceorder = new GiveOrderController();
                $packageDetails = DB::table('packages')->where('package_id', $user_order_details->package_id)->select('quantity', 'price', 'package_type')->first();
                if ($packageDetails == null) {
                    $this->apiError(404, 'package not found');

                } else
                    $package_type = $packageDetails->package_type;
                if ($packageDetails->package_type == 0) {
                    if ($urlType == 0) {
                        $this->apiError(405, 'Enter a valid post url');
                        die;
                    } else {
                        $shortCode = $objInstagramScrape->extractContent($user_order_details->order_url, '/p/', '/');
                        $post_details = $objInstagramScrape->instagramLinkDetails($shortCode);
                        $comments_count = $post_details['comments_count'];
                        $likes_count = $post_details['likes_count'];
                        $is_video = $post_details['is_video'];
                        $profile_details = $objplaceorder->Placeorder($user_order_details, $urlType, $package_type,$likes_count);
                    }

                } elseif ($packageDetails->package_type == 1) {     //for profile link
                    if ($urlType == 1) {
                        $this->apiError(405, 'Enter a valid profile URL');
                        die;
                    } else {
                        $str = substr($user_order_details->order_url, strpos($user_order_details->order_url, '.com/'));
                        $substr = (substr($str, strlen('.com/')));
                        $username = rtrim($substr, '/');

                        $profile_details = $objInstagramScrape->instagramProfileDetails($username);
                        $followed_by = $profile_details['followed_by'];
                        $follows = $profile_details['follows'];


                        $profile_details = $objplaceorder->Placeorder($user_order_details, $urlType, $package_type,$followed_by);
                    }
                } elseif ($packageDetails->package_type == 2) {
                    if ($urlType == 0) {
                        $this->apiError(405, 'Enter a valid post URL');
                        die;

                    } else {
                        $shortCode = $objInstagramScrape->extractContent($user_order_details->order_url, '/p/', '/');
                        $post_details = $objInstagramScrape->instagramLinkDetails($shortCode);
                        $comments_count = $post_details['comments_count'];
                        $likes_count = $post_details['likes_count'];
                        $is_video = $post_details['is_video'];
                        $profile_details = $objplaceorder->Placeorder($user_order_details, $urlType, $package_type,$comments_count);
                    }
                } elseif ($packageDetails->package_type == 3) {
                    if ($urlType == 0) {
                        $this->apiError(405, 'Enter a valid post URL');
                        die;

                    } else {
                        $shortCode = $objInstagramScrape->extractContent($user_order_details->order_url, '/p/', '/');
                        $post_details = $objInstagramScrape->instagramLinkDetails($shortCode);
                        $comments_count = $post_details['comments_count'];
                        $likes_count = $post_details['likes_count'];
                        $is_video = $post_details['is_video'];
                        $profile_details = $objplaceorder->Placeorder($user_order_details, $urlType, $package_type,$comments_count);
                    }
                }

                elseif($packageDetails->package_type == 4) {
                    if ($urlType == 0) {
                        $this->apiError(405, 'Enter a valid post URL');
                        die;
                    } else {
                        $package_type = 4;


                        $shortCode = $objInstagramScrape->extractContent($user_order_details->order_url, '/p/', '/');
                        $post_details = $objInstagramScrape->instagramLinkDetails($shortCode);
                        $comments_count = $post_details['comments_count'];
                        $likes_count = $post_details['likes_count'];
                        $is_video = $post_details['is_video'];
                        $views_countr = $post_details['views_count'];

                        $profile_details = $objplaceorder->Placeorder($user_order_details, $urlType, $package_type,$views_countr);
                    }
                }
            } else {
                echo json_encode(['code' => 401, 'status' => 'false', 'message' => 'internal error, orderplacing']);
            }
        } catch (\Exception $exc) {
            dd($exc->getMessage());
            echo json_encode(['code' => 401, 'status' => 'false', 'message' => 'Please enter valid Token']);
        }
    }


    /**
     * @Desc function for storing data in order table after transaction done
     * @param $userDetails
     * @param $urlType
     * @param $package_type
     * @since 29 jan 2018
     * @author Sibasankar Bhoi (sibasankarbhoi@globussoft.in)
     */
    public function Placeorder($userDetails, $urlType, $package_type,$start_count)
    {
        try {
            $order_placingArr = array();
            $order_placingArr['user_id'] = $userDetails->user_id;
            $order_placingArr['tx_id'] = $userDetails->tx_id;
            $order_placingArr['package_id'] = $userDetails->package_id;
            $packageDetails = DB::table('packages')->where('package_id', $userDetails->package_id)->select('quantity', 'price', 'package_type')->first();

            $order_placingArr['order_url'] = $userDetails->order_url;
            $order_placingArr['url_type'] = $urlType;
            $order_placingArr['start_count'] = $start_count;
            $order_placingArr['quantity'] = $packageDetails->quantity;
            $order_placingArr['package_type'] = $packageDetails->package_type;
            $order_placingArr['start_time'] = time();
            $order_placingArr['added_time'] = time();
            $order_placingArr['updated_time'] = time();
            $order_placed = DB::table('orders')->insertGetId($order_placingArr);
            echo json_encode(['code' => 200, 'status' => 'success', 'message' => 'order placed succesfully', 'order_id' => $order_placed]);
        } catch (\Exception $exc) {
            dd($exc->getMessage());
        }
    }

    /**
     * @Desc fetching GIVE users order history
     * @Class orderHistory
     * @param Request $request
     * @since 05 feb 2018
     * @author Sibasankar Bhoi (sibasankarbhoi@globussoft.in)
     */
    public function GiveorderHistory(Request $request)
    {

        $access_token = ($request->header('access-token')) ? $request->header('access-token') : (($request->all()['access-token']) ? $request->all()['access-token'] : '');
        $key = "User access token";
        $decoded = JWT::decode($access_token, $key, array('HS256'));     //  user details as a TOKEN
        $objmodeluser = Order::getInstance();
        $user_order_history = $objmodeluser->orderHistory($decoded->user_id);

        try {
            $order_historyArr = array();
            $objplaceorder = new GiveOrderController();

            foreach ($user_order_history as $key => $history) {
                $order_historyArr[$key]['order_id'] = $history->order_id;
                $order_historyArr[$key]['tx_id'] = $history->tx_id;
                $order_historyArr[$key]['package_id'] = $history->package_id;
                $order_historyArr[$key]['package_type'] = $history->package_type;
                $order_historyArr[$key]['order_url'] = $history->order_url;
                $order_historyArr[$key]['quantity'] = $history->quantity;
                $order_historyArr[$key]['status'] = $history->status;
                $order_historyArr[$key]['added_time_date'] = gmdate("m-d-Y", $history->added_time);
                $added_time = $objplaceorder->convertUT($history->added_time);   // call function for get the timw interval
                $order_historyArr[$key]['added_time_date'] = $added_time;

            }
            if (isset($order_historyArr) && !empty($order_historyArr)) {
                echo json_encode(['code' => 200, 'status' => 'success', 'message' => 'order history fetched succesfully', 'data' => $order_historyArr]);
            } else
                            $this->apiError(401, 'No order placed by this user');



        } catch (\Exception $exc) {

            echo json_encode(['code' => 401, 'status' => 'False', 'message' => 'No order placed by this user']);
            dd($exc->getMessage());
            die;
        }

    }


    /**
     * @Desc  get the exact time interval
     * @Class convertUT
     * @param $ptime
     * @return string
     * @since 31 jan 2018
     * @author Saurabh kumar
     */
    public function convertUT($ptime)
    {
        $difftime = time() - $ptime;


        if ($difftime < 1) {
            return '0 seconds';
        }

        $timeArr = array(365 * 24 * 60 * 60 => 'year',
            30 * 24 * 60 * 60 => 'month',
            24 * 60 * 60 => 'day',
            60 * 60 => 'hour',
            60 => 'minute',
            1 => 'second'
        );
        $timePluralArr = array('year' => 'years',
            'month' => 'months',
            'day' => 'days',
            'hour' => 'hours',
            'minute' => 'minutes',
            'second' => 'seconds'
        );

        foreach ($timeArr as $secs => $str) {
            $d = $difftime / $secs;
            if ($d >= 1) {
                $r = round($d);
                return $r . ' ' . ($r > 1 ? $timePluralArr[$str] : $str);
            }
        }
    }


    /**
     * @Desc   Error response Function
     * @param $code
     * @param $msg
     * @since 11 jan 2018
     * @author Sibasankar Bhoi (sibasankarbhoi@globussoft.in)
     */
    public function apiError($code, $msg)
    {
        header('Content-Type: application/json');
        http_response_code($code);
        echo json_encode(['code' => $code, 'status' => 'failed', 'message' => $msg, 'data' => null]);
        die;
    }


}





?>
