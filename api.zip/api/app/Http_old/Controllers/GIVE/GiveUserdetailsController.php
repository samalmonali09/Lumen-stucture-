<?php

namespace App\Http\Controllers\GIVE;

use App\Http\Models\Service;
use App\User;
use Firebase\JWT\JWT;
use Illuminate\Database\DetectsDeadlocks;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;

class GiveUserdetailsController
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        //
    }

    //


    /**
     * @Desc checking user account and followers
     * @Class checkUser
     * @param Request $request
     * @since 13 jan 2018
     * @author Sibasankar Bhoi (sibasankarbhoi@globussoft.in)
     */
    public function checkuserAccount(Request $request)
    {
        $rules = [
            'username' => 'required',
        ];
        $message = [
            'username.required' => 'Please Enter Your User Name',
        ];
        $response = array('response' => '', 'Success' => false);
        $validator = Validator::make($request->input(), $rules, $message);
        if ($validator->fails()) {
            $this->apiError('412',$validator->messages());

        } else {
            $name = $request->all()['username'];
            $url = 'https://www.instagram.com/' . $name . '/?__a=1';
            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, $url);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            $result = curl_exec($ch);                                         //get all the data
            $data = json_decode($result, true);
            $objmodeluser = Service::getInstance();
            $checkuser = $objmodeluser->getaccountDetails($data);
        }
    }

    /**
     * @Desc   check user name exist or not
     * @Class usernameExist
     * @param Request $request
     * @return string
     * @since 14 jan 2018
     * @author Sibasankar Bhoi (sibasankarbhoi@globussoft.in)
     */
    public function usernameExist(Request $request)
    {
        $rules = [
            'username' => 'required',
        ];
        $message = [
            'username.required' => 'Please Enter Your User Name',
        ];
        $response = array('response' => '', 'Success' => false);
        $validator = Validator::make($request->input(), $rules, $message);
        if ($validator->fails()) {
            $this->apiError('412',$validator->messages());

//            return json_encode(['code' => 100, 'status' => 'Failed', 'message' => $validator->messages()]);
        } else {
            $name = $request->all()['username'];
            $url = 'https://www.instagram.com/' . $name . '/?__a=1';

            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, $url);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

            $result = curl_exec($ch);
            $data = json_decode($result, true);
            if ($data == null) {
                $this->apiError('412','User name does not exist');

            } else {
                return json_encode(['code' => 200, 'status' => 'success', 'message' => 'user name  exist']);
            }
        }
    }


    /**
     * @Desc fetching media details with comments, likes
     * @Class getmediaDetails
     * @param Request $request
     * @return string
     * @since 16 jan 2018
     * @author Sibasankar Bhoi (sibasankarbhoi@globussoft.in)
     */
    public function getmediaDetails(Request $request)
    {

        $name = $request->all()['username'];
        $url = 'https://www.instagram.com/' . $name . '/?__a=1';
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        $result = curl_exec($ch);
        $data = json_decode($result, true);
        $total_media = count($data['user']['media']['nodes']);
        $mediaDetails = $data['user']['media']['nodes'];
        if ($mediaDetails == null) {                        //checking condition user exist or not
            $this->apiError('401','user not found, please enter correct user name');
        } elseif ($mediaDetails) {                         // fetching all data
            $mediaDetailsArr = [];
            foreach ($mediaDetails as $key => $media) {
                $mediaDetailsArr[$key]['media_image_url'] = $media['thumbnail_src'];
                $mediaDetailsArr[$key]['comments_count'] = $media['comments']['count'];
                $mediaDetailsArr[$key]['likes_count'] = $media['likes']['count'];
                $mediaDetailsArr[$key]['is_video'] = $media['is_video'];
                $mediaDetailsArr[$key]['media_url'] = 'https://instagram.com/p/' . $media['code'];

            }
            return json_encode([
                'code' => 200,
                'status' => 'success',
                'message' => 'users media fetched succesfully',
                'data' => $mediaDetailsArr
            ]);
            die();
        } else {                                           // response for if no media found

            $this->apiError('401',' No media found for this user');

        }
    }

    /**
     * @Desc check free package, after sign up user get a free package
     * @Class freepackage
     * @since 16 jan 2018
     * @author Sibasankar Bhoi (sibasankarbhoi@globussoft.in)
     */
    public function freepackage(Request $request)
    {
        try {
            $access_token = ($request->header('access-token')) ? $request->header('access-token') : (($request->all()['access-token']) ? $request->all()['access-token'] : '');
            $key = "User access token";
            $decoded = JWT::decode($access_token, $key, array('HS256'));     //  user details as a TOKEN
            $userdetails = DB::table('users')->where('email', $decoded->email)->first();
            $username = $userdetails->username;
            $objmodeluser = Service::getInstance();    //checking free package status
            $freepackage = $objmodeluser->checkfreePackage($username);
//            $ratedAppfreepackage = $objmodeluser->ratedAppfreepackage($username);
        } catch (\Exception $exc) {
            echo json_encode(['code' => 401, 'status' => 'false', 'message' => 'Please Enter valid Token']);
        }
    }


    /**
     * @Desc checking free packages after rated APP
     * @Class ratedAppfreepackage
     * @param Request $request
     * @return string
     * @since 17 jan 2018
     * @author Sibasankar Bhoi (sibasankarbhoi@globussoft.in)
     */
    public function ratedappPackage(Request $request)
    {
        try {
            $access_token = ($request->header('access-token')) ? $request->header('access-token') : (($request->all()['access-token']) ? $request->all()['access-token'] : '');
            $key = "User access token";
            $decoded = JWT::decode($access_token, $key, array('HS256'));     //  user details as a TOKEN
            $userdetails = DB::table('users')->where('email', $decoded->email)->first();
            $username = $userdetails->username;
            $objmodeluser = Service::getInstance();    //checking free package status
            $ratedAppfreepackage = $objmodeluser->ratedAppfreepackage($username);
        } catch (\Exception $exc) {
            echo json_encode(['code' => 401, 'status' => 'false', 'message' => 'Please Enter valid Token']);
        }
    }

    /**
     * @Desc error response function
     * @Class apiError
     * @param $code
     * @param $msg
     * @since 17 jan 2018
     * @author Sibasankar Bhoi (sibasankarbhoi@globussoft.in)
     */
    public function apiError($code, $msg)
    {
        header('Content-Type: application/json');
        http_response_code($code);
        echo json_encode(['code' => $code, 'status' => 'failed', 'message' => $msg, 'data' => null]);
        die();
    }
}


