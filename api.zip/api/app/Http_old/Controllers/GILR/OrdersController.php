<?php

namespace App\Http\Controllers\GILR;

use App\Http\Controllers\InstagramScrape\InstagramScrapeController;
use App\Http\Models\Order;

use Firebase\JWT\JWT;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;

class OrdersController
{



    /**
     * @Desc place  orders for likes, comments, views, follows after transaction
     * @param Request $request
     * @since 3 feb 2018
     * @author Sibasankar Bhoi (sibasankarbhoi@globussoft.in)
     */
    public function placeOrders(Request $request)
    {
        try {
            $rules = [
                'tx_id' => 'required|exists:transactions,tx_id',
            ];
            $message = [
                'tx_id.exists' => 'This transaction is not completed'
            ];
            $validator = Validator::make($request->input(), $rules, $message);
            if ($validator->fails()) {
                return json_encode(['code' => 412, 'status' => 'Failed', 'message' => $validator->messages()]);
            } else
                $objmodeluser = Order::getInstance();
            $user_order_details = $objmodeluser->addOrdersLikes($request->all()['tx_id']);
            if (isset($user_order_details) && !empty($user_order_details)) {
                $regexr = "/^(http(s)?:\/\/)?(www\.)?((instagram)\.+)(com)(\/p\/)([a-zA-Z0-9]+\_*\-*[a-zA-Z0-9]*)(\/+)([?a-zA-Z0-9._~@,-=]*)$/";
                $urlType = (preg_match($regexr, $user_order_details->order_url)) ? 1 : 0;   // validating url type
                $objInstagramScrape = new InstagramScrapeController();

                $objplaceorder = new OrdersController();
                $packageDetails = DB::table('packages')->where('package_id', $user_order_details->package_id)->select('quantity', 'price', 'package_type')->first();
                if ($packageDetails == null) {
                    return json_encode(['code' => 401, 'status' => 'Failed', 'message' => 'package not found']);

                } else
                    $package_type = $packageDetails->package_type;
                if ($packageDetails->package_type == 0) {
                    if ($urlType == 0) {
                        echo json_encode(['code' => 401, 'status' => 'false', 'message' => 'Enter a valid post url']);
                        die;
                    } else {
                        $shortCode = $objInstagramScrape->extractContent($user_order_details->order_url, '/p/', '/');
                        $post_details = $objInstagramScrape->instagramLinkDetails($shortCode);
                        $comments_count = $post_details['comments_count'];
                        $likes_count = $post_details['likes_count'];
                        $is_video = $post_details['is_video'];
                        $profile_details = $objplaceorder->Placeorder($user_order_details, $urlType, $package_type,$likes_count);
                    }

                } elseif ($packageDetails->package_type == 1) {     //for profile link
                    if ($urlType == 1) {
                        echo json_encode(['code' => 401, 'status' => 'false', 'message' => 'Enter a valid Profile url']);
                        die;
                    } else {
                        $str = substr($user_order_details->order_url, strpos($user_order_details->order_url, '.com/'));
                        $substr = (substr($str, strlen('.com/')));
                        $username = rtrim($substr, '/');

                        $profile_details = $objInstagramScrape->instagramProfileDetails($username);
                        $followed_by = $profile_details['followed_by'];
                        $follows = $profile_details['follows'];


                        $profile_details = $objplaceorder->Placeorder($user_order_details, $urlType, $package_type,$followed_by);
                    }
                } elseif ($packageDetails->package_type == 2) {
                    if ($urlType == 0) {
                        echo json_encode(['code' => 401, 'status' => 'false', 'message' => 'Enter a valid post url']);
                        die;

                    } else {
                        $shortCode = $objInstagramScrape->extractContent($user_order_details->order_url, '/p/', '/');
                        $post_details = $objInstagramScrape->instagramLinkDetails($shortCode);
                        $comments_count = $post_details['comments_count'];
                        $likes_count = $post_details['likes_count'];
                        $is_video = $post_details['is_video'];
                        $profile_details = $objplaceorder->Placeorder($user_order_details, $urlType, $package_type,$comments_count);
                    }
                } elseif ($packageDetails->package_type == 3) {
                    if ($urlType == 0) {
                        echo json_encode(['code' => 401, 'status' => 'false', 'message' => 'Enter a valid post url']);
                        die;

                    } else {
                        $shortCode = $objInstagramScrape->extractContent($user_order_details->order_url, '/p/', '/');
                        $post_details = $objInstagramScrape->instagramLinkDetails($shortCode);
                        $comments_count = $post_details['comments_count'];
                        $likes_count = $post_details['likes_count'];
                        $is_video = $post_details['is_video'];
                        $profile_details = $objplaceorder->Placeorder($user_order_details, $urlType, $package_type,$comments_count);
                    }
                }

                elseif($packageDetails->package_type == 4) {
                    if ($urlType == 0) {
                        echo json_encode(['code' => 401, 'status' => 'false', 'message' => 'Enter a valid post url']);
                        die;
                    } else {
                        $package_type = 4;


                        $shortCode = $objInstagramScrape->extractContent($user_order_details->order_url, '/p/', '/');
                        $post_details = $objInstagramScrape->instagramLinkDetails($shortCode);
                        $comments_count = $post_details['comments_count'];
                        $likes_count = $post_details['likes_count'];
                        $is_video = $post_details['is_video'];
                        $views_countr = $post_details['views_count'];

                        $profile_details = $objplaceorder->Placeorder($user_order_details, $urlType, $package_type,$views_countr);
                    }
                }
            } else {
                echo json_encode(['code' => 401, 'status' => 'false', 'message' => 'internal error, orderplacing']);
            }
        } catch (\Exception $exc) {
            dd($exc->getMessage());
            echo json_encode(['code' => 401, 'status' => 'false', 'message' => 'Please enter valid Token']);
        }
    }


    /**
     * @Desc function for storing data in order table after transaction done
     * @param $userDetails
     * @param $urlType
     * @param $package_type
     * @since 29 jan 2018
     * @author Sibasankar Bhoi (sibasankarbhoi@globussoft.in)
     */
    public function Placeorder($userDetails, $urlType, $package_type,$start_count)
    {
        try {
            $order_placingArr = array();
            $order_placingArr['user_id'] = $userDetails->user_id;
            $order_placingArr['tx_id'] = $userDetails->tx_id;
            $order_placingArr['package_id'] = $userDetails->package_id;
            $packageDetails = DB::table('packages')->where('package_id', $userDetails->package_id)->select('quantity', 'price', 'package_type')->first();

            $order_placingArr['order_url'] = $userDetails->order_url;
            $order_placingArr['url_type'] = $urlType;
            $order_placingArr['start_count'] = $start_count;
            $order_placingArr['quantity'] = $packageDetails->quantity;
            $order_placingArr['package_type'] = $packageDetails->package_type;
            $order_placingArr['start_time'] = time();
            $order_placingArr['added_time'] = time();
            $order_placingArr['updated_time'] = time();
            $order_placed = DB::table('orders')->insertGetId($order_placingArr);
            echo json_encode(['code' => 200, 'status' => 'success', 'message' => 'order placed succesfully', 'order_id' => $order_placed]);
        } catch (\Exception $exc) {
            dd($exc->getMessage());
        }
    }

    /**
     * @Desc fetching users order history
     * @Class orderHistory
     * @param Request $request
     * @since 31 jan 2018
     * @author Sibasankar Bhoi (sibasankarbhoi@globussoft.in)
     */
    public function orderHistory(Request $request)
    {

        $access_token = ($request->header('access-token')) ? $request->header('access-token') : (($request->all()['access-token']) ? $request->all()['access-token'] : '');
        $key = "User access token";
        $decoded = JWT::decode($access_token, $key, array('HS256'));     //  user details as a TOKEN
        $objmodeluser = Order::getInstance();
        $user_order_history = $objmodeluser->orderHistory($decoded->user_id);

        try {
            $order_historyArr = array();
            $objplaceorder = new OrdersController();

            foreach ($user_order_history as $key => $history) {
                $order_historyArr[$key]['order_id'] = $history->order_id;
                $order_historyArr[$key]['tx_id'] = $history->tx_id;
                $order_historyArr[$key]['package_id'] = $history->package_id;
                $order_historyArr[$key]['package_type'] = $history->package_type;
                $order_historyArr[$key]['order_url'] = $history->order_url;
                $order_historyArr[$key]['quantity'] = $history->quantity;
                $order_historyArr[$key]['status'] = $history->status;
                $order_historyArr[$key]['added_time_date'] = gmdate("m-d-Y", $history->added_time);
                $added_time = $objplaceorder->convertUT($history->added_time);   // call function for get the timw interval
                $order_historyArr[$key]['added_time_date'] = $added_time;

            }
            if (isset($order_historyArr) && !empty($order_historyArr)) {
                echo json_encode(['code' => 200, 'status' => 'success', 'message' => 'order history fetched succesfully', 'data' => $order_historyArr]);
            } else             echo json_encode(['code' => 401, 'status' => 'False', 'message' => 'No order placed by this user', 'user_id' => $decoded->user_id]);


        } catch (\Exception $exc) {
            echo json_encode(['code' => 401, 'status' => 'False', 'message' => 'No order placed by this user']);
            dd($exc->getMessage());
            die;
        }

    }


    /**
     * @Desc  get the exact time interval
     * @Class convertUT
     * @param $ptime
     * @return string
     * @since 31 jan 2018
     * @author Saurabh kumar
     */
    public function convertUT($ptime)
    {
        $difftime = time() - $ptime;


        if ($difftime < 1) {
            return '0 seconds';
        }

        $timeArr = array(365 * 24 * 60 * 60 => 'year',
            30 * 24 * 60 * 60 => 'month',
            24 * 60 * 60 => 'day',
            60 * 60 => 'hour',
            60 => 'minute',
            1 => 'second'
        );
        $timePluralArr = array('year' => 'years',
            'month' => 'months',
            'day' => 'days',
            'hour' => 'hours',
            'minute' => 'minutes',
            'second' => 'seconds'
        );

        foreach ($timeArr as $secs => $str) {
            $d = $difftime / $secs;
            if ($d >= 1) {
                $r = round($d);
                return $r . ' ' . ($r > 1 ? $timePluralArr[$str] : $str);
            }
        }
    }
}

