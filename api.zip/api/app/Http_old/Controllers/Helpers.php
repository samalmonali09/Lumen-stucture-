<?php

use Firebase\JWT\JWT;

/**
 * @date 29-01-2018
 * @dev saurabh Kumar <saurabh.kumar@globussoft.com>
 */
function apiResponse($code, $msg, $err, $data)
{
    $data = [
        'code' => $code,
        'message' => $msg,
        'error' => $err,
        'data' => $data
    ];

    http_response_code($code);
    echo response()->json($data, $code);
    die;
}

function generateAccessToken($data)
{
    return JWT::encode($data, env('JWT_KEY'));
}

function parseAccessToken($token)
{
    $decoded = JWT::decode($token, env('JWT_KEY'), array('HS256'));
    return json_decode(json_encode($decoded), true);
}

function sendEmailThroughMandrill($toEmail, $subject, $bodyContent)
{
    $mandrill = new Mandrill(env('MANDRILL_KEY'));
    $async = false;
    $ip_pool = 'Main Pool';
    $message = array(
        'html' => $bodyContent,
        'subject' => $subject,
        'from_email' => "support@messazon.com",
        'to' => array(
            array(
                'email' => $toEmail,
                'type' => 'to'
            )
        ),
        'merge_vars' => array(
            array(
                "rcpt" => $toEmail,
                'vars' => array()
            )
        ),
    );
    $mailResponse = $mandrill->messages->send($message, $async, $ip_pool);
    return $mailResponse;
}

function getTemplates($templateFor, $data)
{
    $content = '';
    switch ($templateFor) {
        case 'registration':
            $content = '<div style="border: 1px solid #4A4A4A; border-radius: 10px; padding:30px; width:60%; margin-left: 20%; margin-right: 20%;" >
                            <div>
                                <a class="text-center" href="http://messazon.com/">
                                    <img src="http://igautolikes.globusapps.com/images/autoig_logo.png" alt="AUTOIG" class="img-responsive" alt="logo" height="50px" width="250px" style="margin-left: 15%; margin-top: -1%;" />
                                </a>
                            </div>
                            <hr color="#4A4A4A">
                            <div style="padding-left:30px;">
                                Dear, ' . strtoupper($data['firstname']) . '<br>
                                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;You have succesfully registered for AUTOIG app, Your OTP to activate the account is <u>' . $data['otp'] . '</u><br><br>
                                Use this credentials for further login <br>
                                Username :' . $data['username'] . '<br>
                                Password :' . $data['password'] . '<br>
                            <br><br>
                            </div><br>
                            <hr color="#4A4A4A">
                            <font color = "#4A4A4A" > Regards <br> AUTOIG Team <br> Contact : support@messazon.com </font>
                        </div>';
            break;
        case 'recoverPasswordOTP':
            $content = '<div style="border: 1px solid #4A4A4A; border-radius: 10px; padding:30px; width:60%; margin-left: 20%; margin-right: 20%;" >
                            <div>
                                <a class="text-center" href="http://messazon.com/">
                                    <img src="http://igautolikes.globusapps.com/images/autoig_logo.png" alt="AUTOIG" class="img-responsive" alt="logo" height="50px" width="250px" style="margin-left: 15%; margin-top: -1%;" />
                                </a>
                            </div>
                            <hr color="#4A4A4A">
                            <div style="padding-left:30px;">
                                Hi ' . strtoupper($data['firstname']) . ',<br>
                                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Please use the following code to confirm your identity and reset your password. 
                                <br><b><u>' . $data['otp'] . '</u></b><br><br>
                                If this wasn\'t you, please ignore this message.
                            <br><br>
                            </div><br>
                            <hr color="#4A4A4A">
                            <font color = "#4A4A4A" > Regards <br> AUTOIG Team <br> Contact : support@messazon.com </font>
                        </div>';
            break;
        case 'passwordChanged':
            $content = '<div style="border: 1px solid #4A4A4A; border-radius: 10px; padding:30px; width:60%; margin-left: 20%; margin-right: 20%;" >
                            <div>
                                <a class="text-center" href="http://messazon.com/">
                                    <img src="http://igautolikes.globusapps.com/images/autoig_logo.png" alt="AUTOIG" class="img-responsive" alt="logo" height="50px" width="250px" style="margin-left: 15%; margin-top: -1%;" />
                                </a>
                            </div>
                            <hr color="#4A4A4A">
                            <div style="padding-left:30px;">
                                Hi ' . strtoupper($data['firstname']) . ',<br>
                                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Your password has been changed recently, please use the new credentials for login. 
                                <br>
                                Email :' . $data['email'] . '<br>
                                Username :' . $data['username'] . '<br>
                                Password :' . $data['password'] . '<br>
                            <br><br>
                            </div><br>
                            <hr color="#4A4A4A">
                            <font color = "#4A4A4A" >Best Regards <br> AUTOIG Team <br> Contact : support@messazon.com </font>
                        </div>';
            break;


    }
    return $content;
}

