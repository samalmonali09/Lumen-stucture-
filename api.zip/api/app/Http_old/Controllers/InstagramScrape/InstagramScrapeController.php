<?php namespace App\Http\Controllers\InstagramScrape;

use Illuminate\Support\Facades\DB;

class InstagramScrapeController
{


    /**
     * @Desc fetch users post details
     * @param $shortCode
     * @return array
     * @since 24 jan 2018
     * @author Sibasankar Bhoi (sibasankarbhoi@globussoft.in)
     */
    public function instagramLinkDetails($shortCode)
    {
        $url = 'https://www.instagram.com/p/' . $shortCode . '/?__a=1';
        $result = $this->instaCurlHitGet($url);
        $postDetails = $result;
        if ($postDetails['graphql']['shortcode_media']['owner']['is_private'] == false) {
            $mediaDetailsArr = [];
            $mediaDetailsArr['comments_count'] = $postDetails['graphql']['shortcode_media']['edge_media_to_comment']['count'];
            $mediaDetailsArr['likes_count'] = $postDetails['graphql']['shortcode_media']['edge_media_preview_like']['count'];
            $mediaDetailsArr['is_video'] = $postDetails['graphql']['shortcode_media']['is_video'];
            if ($mediaDetailsArr["is_video"] == true) {
                $mediaDetailsArr['views_count'] =$postDetails['graphql']['shortcode_media']['video_view_count'];

            }
            return $mediaDetailsArr;
        } else {
            echo json_encode(['code' => 401, 'status' => 'false', 'message' => 'User Account is private']);
            die;
        }
    }

    /**
     * @Desc fetch users profile details
     * @Class instagramProfileDetails
     * @param $username
     * @return array
     * @since 24 jan 2018
     * @author Sibasankar Bhoi (sibasankarbhoi@globussoft.in)
     */
    public function instagramProfileDetails($username)
    {
        $url = 'https://www.instagram.com/' . $username . '/?__a=1';

        $data = $this->instaCurlHitGet($url);
        if ($data['user']["is_private"] == false) {
            $profileDetailsArr = [];
            $profileDetailsArr['followed_by'] = $data['user']['followed_by']['count'];
            $profileDetailsArr['follows'] = $data['user']['follows']['count'];
            return $profileDetailsArr;
        } else {
            echo json_encode(['code' => 401, 'status' => 'false', 'message' => 'User Account is private']);
            die;
        }

    }

    /**
     * @Desc fetch data from IG url
     * @Class instaCurlHitGet
     * @param $url
     * @return mixed|null
     * @since 24 jan 2018
     * @author Sibasankar Bhoi (sibasankarbhoi@globussoft.in)
     */
    public function instaCurlHitGet($url)
    {
        //TODO Hit instagram with proxies;
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_VERBOSE, true);
        $result = curl_exec($ch);
//        dd(json_decode($result));
        if (curl_errno($ch) > 0) {
            print_r(curl_error($ch));
        }
        return ($result) ? json_decode($result, true) : null;

    }

    public function extractContent($string, $startIndex, $endIndex)
    {
        $str = substr($string, strpos($string, $startIndex));
        if (isset($endIndex))
            $str = (substr($str, strlen($startIndex)));
        $extractedStr = substr($str, 0, strpos($str, $endIndex));
        return trim($extractedStr);
    }

}