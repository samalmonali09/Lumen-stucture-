<?php namespace App\Http\Controllers\AUTOIG;

use Laravel\Lumen\Routing\Controller;

class OrderController extends Controller
{

    public function addOrders()
    {


    }

}