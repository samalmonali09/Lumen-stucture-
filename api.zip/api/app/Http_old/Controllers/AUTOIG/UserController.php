<?php namespace App\Http\Controllers\AUTOIG;

use App\Http\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;
use Laravel\Lumen\Routing\Controller;

class UserController extends Controller
{

    protected $response;
    protected $objModelUser;

    public function __construct()
    {
        $this->response = new \stdClass();
        $this->objModelUser = new User();
    }


    /**
     * @param Request $postData
     * @date 30-01-2018
     * @dev saurabh Kumar <saurabh.kumar@globussoft.com>
     */
    public function signup(Request $postData)
    {

        if ($postData->isMethod('post')) {

            $validator = Validator::make($postData->all(), [
                'firstname' => 'required|regex:/^[A-Za-z\s]+$/|max:20',
                'username' => 'required|regex:/^[A-Za-z0-9._\s]+$/|min:4|max:20|unique:users',
                'email' => 'required|email|max:200|unique:users',
                'password' => 'required|confirmed',
                'password_confirmation' => 'required|',
                'device_type' => 'required',
                'device_id' => 'required',
            ]);

            if (!$validator->fails()) {

                $email = $postData['email'];
                $otp = $postData['otp'] = mt_rand(100000, 999999);

                $user = User::create([
                    'firstname' => $postData['firstname'],
                    'lastname' => ($postData->input('lastname')) ? $postData['lastname'] : '',
                    'username' => $postData['username'],
                    'email' => $postData['email'],
                    'password' => Hash::make($postData['password']),
                    'role' => '1',
                    'status' => '0',
                    'registered_through' => '5', //5= for AUTOIG users
                    'device_type' => $postData['device_type'],
                    'device_id' => $postData['device_id'],
                    'user_free_package' => 0,
                    'rated_app' => 0,
                    'activation_otp' => $otp
                ]);

                if ($user) {

                    $bodyContent = getTemplates('registration', $postData);
                    $mailResponse = sendEmailThroughMandrill($email, 'Registration Successful', $bodyContent);

                    if ($mailResponse[0]['status'] == "sent") {
                        apiResponse(200, 'User registration successful, please activate the account using the OTP sent in email.', null, ['id' => $user->id]);
                    } else {
                        //Delete users when mail is not sent
                        $this->objModelUser->deleteUserDetails(['rawQuery' => 'id = ?', 'bindParams' => [$user->id]]);
                        apiResponse(400, 'Some error occurred in sending mail, please register again.', 'Error in sending mail.', null);
                    }
                } else
                    apiResponse(400, 'Some error occurred, try again.', 'Error in account creation.', null);

            } else
                apiResponse(412, 'Validation error', json_decode($validator->messages(), true), null);

        } else
            apiResponse(405, 'Method not allowed.', 'Only request through post method is allowed.', null);
    }

    public function activateAccount(Request $request)
    {
        if ($request->isMethod('post')) {
            $validator = Validator::make($request->all(), [
                'id' => 'required|exists:users',
                'otp' => 'required|numeric|min:100000|max:999999'
            ], ['otp.min' => 'Not a valid otp', 'otp.max' => 'Not a valid otp', 'otp.numeric' => 'Not a valid otp']);

            if (!$validator->fails()) {
                $result = $this->objModelUser->getUserDetail(['rawQuery' => 'id = ? and activation_otp = ?', 'bindParams' => [$request['id'], $request['otp']]]);

                if ($result) {
                    $updated = $this->objModelUser->updateUserDetails(['rawQuery' => 'id = ?', 'bindParams' => [$request['id']]], ['status' => 1, 'activation_otp' => 0]);
                    apiResponse(200, 'Account has been activated, please login now.', null, null);
                } else {
                    apiResponse(400, 'Account has already been activated, please login', null, null);
                }

            } else
                apiResponse(412, 'Validation error', json_decode($validator->messages(), true), null);
        } else
            apiResponse(405, 'Method not allowed.', 'Only request through post method is allowed.', null);
    }

    public function login(Request $request)
    {
        if ($request->isMethod('post')) {
            $validator = Validator::make($request->all(), [
                'emailOrUsername' => 'required|',
                'password' => 'required'
            ]);

            if (!$validator->fails()) {
                $field = 'email';
                if (strpos($request['emailOrUsername'], '@') == false) {
                    $field = 'username';
                }
                $result = $this->objModelUser->getUserDetail(['rawQuery' => $field . '= ?', 'bindParams' => [$request['emailOrUsername']]]);
                if ($result) {
                    if (Hash::check($request['password'], $result['password'])) {

                        unset($result['password']);
                        unset($result['activation_otp']);
                        unset($result['pd_reset_token']);
                        $result['iat'] = time();

                        $accessToken = generateAccessToken($result);
                        apiResponse(200, 'Login successful.', null, ['accessToken' => $accessToken]);
                    }

                } else {
                    apiResponse(400, 'Email or username doesn\'t exist, please check again or register.', 'email or username not exists', null);
                }


            } else
                apiResponse(412, 'Validation error', json_decode($validator->messages(), true), null);
        } else
            apiResponse(405, 'Method not allowed.', 'Only request through post method is allowed.', null);
    }

    public function recoverPassword(Request $request)
    {
        if ($request->isMethod('post')) {

            $validator = Validator::make($request->all(), ['email' => 'required|exists:users', 'method' => 'required']);
            if (!$validator->fails()) {

                $whereEmail = ['rawQuery' => 'email = ?', 'bindParams' => [$request['email']]];
                $userDetails = $this->objModelUser->getUserDetail($whereEmail);

                switch ($request['method']) {
                    case 'getOTP':
                        $userDetails['otp'] = mt_rand(100000, 999999);
                        $this->objModelUser->updateUserDetails($whereEmail, ['pd_reset_token' => $userDetails['otp']]);
                        $bodyContent = getTemplates('recoverPasswordOTP', $userDetails);
                        $mailResponse = sendEmailThroughMandrill($request['email'], 'Reset Password ', $bodyContent);

                        if ($mailResponse[0]['status'] == "sent") {
                            apiResponse(200, 'OTP has been sent to mail. Please enter the otp to confirm your identity.', null, ['email' => $request['email']]);
                        } else {
                            apiResponse(400, 'Some error occurred in sending mail, try again.', 'Error in sending mail.', null);
                        }
                        break;

                    case 'resetPassword':
                        if ($request->input('otp')) {
                            if ($userDetails['pd_reset_token'] !== '') {

                                if ($request->input('otp') === $userDetails['pd_reset_token']) {
                                    $validator = Validator::make($request->all(), ['newPassword' => 'required|confirmed', 'newPassword_confirmation' => 'required']);
                                    if (!$validator->fails()) {

                                        if (Hash::check($request['newPassword'], $userDetails['password'])) {
                                            apiResponse('400', 'Your new password can\'t be the same as old password.', 'please provide new pwd which is not your current pwd.', null);
                                        }

                                        $updated = $this->objModelUser->updateUserDetails($whereEmail, ['password' => Hash::make($request['newPassword']), 'pd_reset_token' => '']);
                                        if ($updated) {
                                            $userDetails['password'] = $request['newPassword'];
                                            $bodyContent = getTemplates('passwordChanged', $userDetails);
                                            sendEmailThroughMandrill($request['email'], 'Password Changed ', $bodyContent);
                                            apiResponse(200, 'Password has been changed, login again.', null, null);
                                        }

                                    } else {
                                        apiResponse(412, 'Validation error', json_decode($validator->messages(), true), null);
                                    }
                                } else
                                    apiResponse(400, 'OTP didn\'t match, check and enter again.', 'OTP didn\'t match.', null);
                            } else
                                apiResponse(400, 'Password has already been changed with this otp, generate new otp.', 'OTP expired.', null);
                        } else
                            apiResponse(400, 'Please provide the OTP sent to your email.', 'otp field is missing', null);

                }

            } else {
                apiResponse(412, 'Validation error', json_decode($validator->messages(), true), null);
            }
        } else {
            apiResponse(405, 'Method not allowed.', 'Only request through post method is allowed.', null);
        }
    }

}